import { t, getLanguage } from './i18n.ts';
import { revealNewContent } from './motion-runtime.ts';
import { readChatStream, type ChatEvent } from './chat-stream.ts';
import { readUploadPacket } from './upload-preview.ts';
import { uploadMetadata, uploadSummary, uploadWorkbook, cacheUploadPreview, selectTable, chatPayload, MAX_ATTACHED_TABLES, UPLOAD_ACCEPT, prepareChatUploads, appendDescription, metadataChatState, clearUploadPreviews, type Upload } from './chat-upload.ts';

type Message = { role: 'user' | 'assistant'; text?: string; system?: boolean; files?: Upload[]; built?: Extract<ChatEvent, { kind: 'built' }>; draftId?: string };
type State = { conversationId?: string; messages: Message[]; input: string; attachments: Upload[]; available?: Upload[]; pending?: boolean };
const key = 'blocks:chat:v1';
let state: State = { messages: [], input: '', attachments: [] };
try {
  const stored = sessionStorage.getItem(key);
  if (stored) {
    const saved = JSON.parse(stored) as State;
    if (Array.isArray(saved.messages) && typeof saved.input === 'string' && Array.isArray(saved.attachments)) {
      state = metadataChatState(saved);
      if (state.pending) state.messages.push({ role: 'assistant', text: 'The connection ended before completion was confirmed. Check My Apps before trying again.', system: true });
      state.pending = false;
    }
  }
} catch { /* The conversation remains usable in memory. */ }
let active: AbortController | undefined;
let uploading = false;
let progress = '';
let error = '';
let uploadNotices: { name: string; key: string }[] = [];
let view: HTMLElement | undefined;
let navigate: ((path: string) => void) | undefined;
const save = () => { try { sessionStorage.setItem(key, JSON.stringify(metadataChatState(state))); } catch { /* Keep the open conversation usable. */ } };
function node<K extends keyof HTMLElementTagNameMap>(tag: K, text?: string, className?: string): HTMLElementTagNameMap[K] {
  const el = document.createElement(tag); if (text !== undefined) el.textContent = text; if (className) el.className = className; return el;
}
function button(label: string, action: () => void, className = 'button button-secondary'): HTMLButtonElement {
  const el = node('button', t(label), className); el.type = 'button'; el.addEventListener('click', action); return el;
}
function link(label: string, path: string): HTMLAnchorElement {
  const el = node('a', t(label), 'button button-primary'); el.href = path;
  el.addEventListener('click', (event) => { if (event.button === 0 && !event.metaKey && !event.ctrlKey && !event.shiftKey && !event.altKey) { event.preventDefault(); navigate?.(path); } }); return el;
}
type ChatView = {
  section: HTMLElement; transcript: HTMLElement; messages: HTMLElement; welcome: HTMLElement;
  input: HTMLTextAreaElement; send: HTMLButtonElement; stop: HTMLButtonElement; attach: HTMLButtonElement;
  fresh: HTMLButtonElement; tray: HTMLDetailsElement; trayTitle: HTMLElement; attachments: HTMLElement;
  status: HTMLElement; feedback: HTMLElement; latest: HTMLButtonElement; counter: HTMLElement;
  messageCount: number; attachmentKey: string; error: string; language: string;
};
let mounted: ChatView | undefined;
function redraw(): void { if (view?.isConnected && /^\/chat\/?$/.test(location.pathname)) draw(); }
function grow(input: HTMLTextAreaElement): void {
  input.style.height = 'auto'; input.style.height = `${Math.min(160, Math.max(64, input.scrollHeight))}px`;
}
function messageElement(message: Message): HTMLElement {
  const article = node('article', undefined, `chat-message chat-${message.role}`);
  article.append(node('p', t(message.role === 'user' ? 'You' : 'Blocks'), 'chat-speaker'));
  if (message.text) article.append(node('p', message.system ? t(message.text) : message.text, 'chat-prose'));
  for (const file of message.files ?? []) article.append(uploadSummary(file));
  if (message.built) {
    const card = node('div', undefined, 'chat-app-card');
    card.append(node('span', t(message.built.updated ? 'App updated' : 'App created'), 'saved-badge'), node('h3', message.built.name), node('p', message.built.description), link('Open app', `/apps/${encodeURIComponent(message.built.appId)}`)); article.append(card);
  }
  if (message.draftId) article.append(link('View drafts in My Apps', '/apps'));
  return article;
}
function mount(): ChatView {
  const section = node('section', undefined, 'chat-screen');
  const heading = node('header', undefined, 'page-heading'); const title = node('div');
  title.append(node('p', 'BLOCKS', 'eyebrow'), node('h1', t('Create app')));
  const fresh = button('New conversation', () => {
    clearUploadPreviews(); state = { messages: [], input: '', attachments: [] }; progress = ''; error = ''; uploadNotices = [];
    mounted = undefined; save(); redraw(); document.getElementById('chat-message')?.focus();
  }); heading.append(title, fresh); section.append(heading);
  const transcript = node('div', undefined, 'chat-transcript'); transcript.id = 'chat-transcript'; transcript.tabIndex = 0;
  transcript.setAttribute('role', 'region'); transcript.setAttribute('aria-label', t('Conversation'));
  const welcome = node('div', undefined, 'chat-welcome');
  welcome.append(node('div', '✦', 'chat-mark'), node('h2', t('What would you like to build?')), node('p', t('Describe the task. Blocks will ask what it needs, then build an app you can keep using.')));
  const suggestions = node('div', undefined, 'chat-suggestions');
  for (const suggestion of ['Show a daily chart for the companies I follow.', 'Summarise my spreadsheet in a table and a few key numbers.', 'Compare companies using the metrics I choose.']) {
    const item = button(suggestion, () => { if (active || uploading) return; state.input = t(suggestion); save(); redraw(); input.focus(); }, 'button button-secondary suggestion-card');
    const fill = node('span', undefined, 'suggestion-fill'); fill.setAttribute('aria-hidden', 'true');
    const arrow = node('span', '↗', 'suggestion-arrow'); arrow.setAttribute('aria-hidden', 'true');
    item.replaceChildren(fill, node('span', t(suggestion), 'suggestion-copy'), arrow); suggestions.append(item);
  }
  welcome.append(suggestions);
  const messages = node('div', undefined, 'chat-messages'); messages.setAttribute('role', 'log'); messages.setAttribute('aria-live', 'polite'); messages.setAttribute('aria-relevant', 'additions');
  const status = node('p', '', 'chat-progress'); status.id = 'chat-progress'; status.setAttribute('role', 'status');
  transcript.append(welcome, messages, status);
  const latest = button('New messages · Jump to latest', () => { transcript.scrollTop = transcript.scrollHeight; latest.hidden = true; }, 'button button-secondary chat-latest'); latest.hidden = true;
  transcript.addEventListener('scroll', () => { if (transcript.scrollHeight - transcript.scrollTop - transcript.clientHeight < 80) latest.hidden = true; });
  const form = node('form', undefined, 'chat-composer');
  const label = node('label', t('Message'), 'screen-visually-hidden'); label.htmlFor = 'chat-message';
  const input = node('textarea'); input.id = 'chat-message'; input.rows = 2; input.maxLength = 4000;
  input.placeholder = t('Describe an app, or ask for a change…'); input.setAttribute('aria-describedby', 'chat-input-help chat-file-help');
  const send = node('button', t('Send'), 'button button-primary'); send.type = 'submit';
  const counter = node('span', undefined, 'chat-counter');
  input.addEventListener('input', () => { state.input = input.value; save(); grow(input); counter.textContent = `${input.value.length} / 4000`; send.disabled = !!active || uploading || (!state.input.trim() && !state.attachments.length); });
  input.addEventListener('keydown', (event) => { if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) { event.preventDefault(); if (!send.disabled) form.requestSubmit(); } });
  const tray = node('details', undefined, 'chat-attachment-tray'); const trayTitle = node('summary');
  const attachments = node('div', undefined, 'chat-attachments'); tray.append(trayTitle, attachments);
  const fileInput = node('input'); fileInput.type = 'file'; fileInput.multiple = true; fileInput.accept = UPLOAD_ACCEPT; fileInput.hidden = true;
  fileInput.addEventListener('change', () => { if (fileInput.files) void uploadFiles(Array.from(fileInput.files)); fileInput.value = ''; });
  const attach = button('Attach files', () => fileInput.click());
  const stop = button('Stop', () => active?.abort()); stop.hidden = true;
  const actions = node('div', undefined, 'chat-actions');
  const inputHelp = node('span', t('Enter to send · Shift + Enter for a new line'), 'field-help'); inputHelp.id = 'chat-input-help';
  actions.append(attach, fileInput, inputHelp, counter, stop, send);
  const feedback = node('div', undefined, 'chat-feedback'); feedback.setAttribute('role', 'alert');
  form.append(tray, label, input, actions);
  form.addEventListener('submit', (event) => { event.preventDefault(); void submit(); });
  for (const type of ['dragover', 'dragenter']) section.addEventListener(type, (event) => { event.preventDefault(); form.classList.add('chat-drop'); });
  section.addEventListener('dragleave', (event) => { if (!section.contains((event as DragEvent).relatedTarget as Node | null)) form.classList.remove('chat-drop'); });
  section.addEventListener('drop', (event) => { event.preventDefault(); form.classList.remove('chat-drop'); if (event.dataTransfer?.files.length) void uploadFiles(Array.from(event.dataTransfer.files)); });
  const help = node('details', undefined, 'chat-help'); help.append(node('summary', t('Files and conversation privacy')));
  const fileHelp = node('p', t('CSV, TSV, Excel or Markdown · 20 MB per file · Up to 5 selected tables per message'), 'field-help'); fileHelp.id = 'chat-file-help';
  help.append(fileHelp, node('p', t('Markdown prose is added to your message for review. Tables are saved separately; only selected table IDs accompany your message.'), 'field-help'), node('p', t('Files stay in this workspace. The builder sees column names, types and counts, not your rows. Attach files instead of pasting rows into chat.'), 'field-help'),
    node('p', t('Conversations expire after an hour of inactivity or a server restart. Saved apps remain in My Apps.'), 'field-help'));
  section.append(transcript, latest, feedback, form, help); view!.replaceChildren(section);
  return { section, transcript, messages, welcome, input, send, stop, attach, fresh, tray, trayTitle, attachments, status, feedback, latest, counter,
    messageCount: 0, attachmentKey: '', error: '', language: getLanguage() };
}
function draw(): void {
  if (!view) return;
  const created = !mounted || !view.contains(mounted.section) || mounted.language !== getLanguage();
  if (created) mounted = mount();
  const ui = mounted!;
  const follow = created || ui.transcript.scrollHeight - ui.transcript.scrollTop - ui.transcript.clientHeight < 80;
  const added = state.messages.length > ui.messageCount;
  const incoming = state.messages.slice(ui.messageCount).map(messageElement);
  ui.messages.append(...incoming);
  if (!created && follow) void revealNewContent(incoming);
  ui.messageCount = state.messages.length; ui.welcome.hidden = state.messages.length > 0;
  ui.status.textContent = active ? t(progress || 'Working on your app…') : '';
  if (ui.input.value !== state.input) { ui.input.value = state.input; grow(ui.input); }
  ui.input.disabled = !!active || uploading;
  ui.counter.textContent = `${state.input.length} / 4000`;
  ui.fresh.disabled = !!active || uploading; ui.attach.disabled = !!active || uploading;
  ui.attach.textContent = t(uploading ? 'Uploading…' : 'Attach files');
  ui.send.hidden = !!active; ui.stop.hidden = !active;
  ui.send.disabled = !!active || uploading || (!state.input.trim() && !state.attachments.length);
  const available = [...new Map([...(state.available ?? []), ...state.attachments].map((file) => [file.id, file])).values()];
  ui.tray.hidden = !available.length && !uploadNotices.length;
  ui.trayTitle.textContent = t('Saved tables: {saved} · Selected: {selected} / 5', { saved: available.length, selected: state.attachments.length });
  const signature = JSON.stringify([available.map((file) => file.id), uploadNotices]);
  if (ui.attachmentKey !== signature) {
    ui.attachmentKey = signature;
    ui.attachments.replaceChildren(node('p', t('Each worksheet counts as one table. All saved tables are also available in Data.'), 'field-help'));
    const groups = new Map<string, Upload[]>();
    for (const file of available) { const name = file.sourceFile || t('Saved tables'); const group = groups.get(name) ?? []; group.push(file); groups.set(name, group); }
    for (const [name, files] of groups) {
      const group = node('section', undefined, 'chat-file-group'); group.append(node('h3', name));
      for (const file of files) {
        const item = node('div', undefined, 'chat-attachment'); const label = node('label', undefined, 'chat-table-choice');
        const choice = node('input'); choice.type = 'checkbox'; choice.dataset.uploadId = file.id;
        choice.setAttribute('aria-label', t('Attach {name}', { name: file.name }));
        choice.addEventListener('change', () => {
          try { state.attachments = selectTable(state.attachments, file, choice.checked); error = ''; } catch (cause) { error = (cause as Error).message; }
          save(); redraw();
        });
        label.append(choice, node('span', t('Attach table'))); item.append(label, uploadSummary(file)); group.append(item);
      }
      ui.attachments.append(group);
    }
    for (const notice of uploadNotices) ui.attachments.append(node('p', t(notice.key, { name: notice.name }), 'notice'));
  }
  for (const choice of Array.from(ui.attachments.querySelectorAll<HTMLInputElement>('input[data-upload-id]'))) {
    choice.checked = state.attachments.some((file) => file.id === choice.dataset.uploadId);
    choice.disabled = !!active || uploading || (!choice.checked && state.attachments.length >= MAX_ATTACHED_TABLES);
  }
  if (ui.error !== error) {
    ui.error = error; ui.feedback.replaceChildren();
    if (error) ui.feedback.append(node('p', t(error), 'notice'), link('Open My Apps', '/apps'));
  }
  if (follow) ui.transcript.scrollTop = ui.transcript.scrollHeight;
  else if (added) {
    const wasHidden = ui.latest.hidden; ui.latest.hidden = false;
    if (wasHidden) void revealNewContent([ui.latest]);
  }
  if (created) grow(ui.input);
}
async function ready(): Promise<void> {
  // This also establishes the HttpOnly browser library cookie on a direct /chat visit.
  const response = await fetch('/api/apps', { credentials: 'same-origin', signal: AbortSignal.timeout(30_000) });
  if (!response.ok) throw new Error('We could not connect to your library. Please try again.');
}
async function uploadFiles(files: File[]): Promise<void> {
  if (active || uploading) return;
  error = '';
  if (files.length > 5) { error = 'Upload at most 5 files at a time.'; redraw(); return; }
  uploading = true; redraw();
  try {
    const prepared = await prepareChatUploads(files, state.input);
    await ready();
    for (const { file, description, hasTables } of prepared) {
      if (hasTables) {
        const uploaded = await uploadWorkbook(file);
        const sheets = uploaded.sheets ?? [{ dataset: uploaded.dataset, blankCounts: uploaded.blankCounts, preview: uploaded.preview, analysis: uploaded.analysis }];
        for (const sheet of sheets) {
          const metadata = uploadMetadata({ ...readUploadPacket(sheet).upload, sourceFile: file.name, ...('sheetName' in sheet && typeof sheet.sheetName === 'string' ? { sheetName: sheet.sheetName } : {}) });
          state.available = [...(state.available ?? []), metadata];
          cacheUploadPreview(sheet);
          if (sheets.length === 1 && !uploaded.skippedSheets?.length && state.attachments.length < MAX_ATTACHED_TABLES) {
            state.attachments = selectTable(state.attachments, metadata, true);
          }
        }
        for (const skipped of uploaded.skippedSheets ?? []) uploadNotices.push({ name: `${file.name} · ${skipped.sheetName}`,
          key: skipped.reason === 'NO_COLUMNS' ? 'Skipped {name}: no column headers.' : 'Could not save {name}. Other saved tables remain available below.' });
      }
      if (description) {
        state.input = appendDescription(state.input, description);
        uploadNotices.push({ name: file.name, key: 'Added Markdown description from {name}. Review it in the message before sending.' });
      }
      save();
    }
  } catch (cause) { error = cause instanceof Error && !(cause instanceof TypeError) && cause.name !== 'TimeoutError' ? cause.message : 'The file could not be uploaded. Try again.'; }
  finally { uploading = false; redraw(); if (mounted?.section.isConnected) mounted.tray.open = true; }
}
async function submit(): Promise<void> {
  if (active || uploading || (!state.input.trim() && !state.attachments.length)) return;
  if (state.input.length > 4000) { error = 'Use at most 4,000 characters per message.'; redraw(); return; }
  const message = state.input.trim(); const files = [...state.attachments]; const previous = state.conversationId;
  const controller = new AbortController(); active = controller; error = ''; progress = '';
  state.pending = true; state.messages.push({ role: 'user', text: message, files }); state.input = ''; state.attachments = []; save(); redraw(); if (mounted?.section.isConnected) { mounted.tray.open = false; mounted.transcript.scrollTop = mounted.transcript.scrollHeight; }
  const timer = window.setTimeout(() => controller.abort(), 11 * 60_000);
  let accepted = false;
  try {
    await ready();
    const response = await fetch('/api/chat', { method: 'POST', credentials: 'same-origin', signal: controller.signal,
      headers: { 'Content-Type': 'application/json', 'X-Blocks-Request': '1' },
      body: JSON.stringify(chatPayload(message, previous, files)),
    });
    if (!response.ok) { const body = await response.json(); throw new Error(body.error?.message ?? 'The chat could not be reached. Please try again.'); }
    if (!response.body || !response.headers.get('content-type')?.includes('text/event-stream')) throw new Error('The chat could not be reached. Please try again.');
    accepted = true;
    await readChatStream(response.body, (event) => {
      if (event.kind === 'conversation') {
        state.conversationId = event.conversationId;
        if (previous && event.conversationId !== previous) state.messages.push({ role: 'assistant', text: 'Your earlier conversation expired or the server restarted. This message started a new conversation.', system: true });
      } else if (event.kind === 'progress') {
        progress = event.line;
        const status = document.getElementById('chat-progress'); if (status) status.textContent = t(progress);
        return;
      } else if (event.kind === 'question') state.messages.push({ role: 'assistant', text: event.questions.join('\n\n') });
      else if (event.kind === 'built') state.messages.push({ role: 'assistant', built: event });
      else state.messages.push({ role: 'assistant', text: event.summary, system: true, ...(event.draftId ? { draftId: event.draftId } : {}) });
      save(); redraw();
    });
  } catch (cause) {
    error = controller.signal.aborted ? 'Sending stopped. A build may already have been saved; check My Apps before sending again.'
      : accepted ? 'The connection ended before completion was confirmed. Check My Apps before trying again.'
      : cause instanceof Error && !(cause instanceof TypeError) && cause.name !== 'TimeoutError' ? cause.message : 'The chat could not be reached. Please try again.';
    state.messages.push({ role: 'assistant', text: error, system: true });
    // Preserve the input for an explicit retry, never send a second request automatically.
    if (!accepted) { state.input = message; state.attachments = files; }
  } finally { window.clearTimeout(timer); active = undefined; state.pending = false; progress = ''; save(); redraw(); if (mounted?.section.isConnected && mounted.latest.hidden) mounted.input.focus({ preventScroll: true }); }
}
export function showChatScreen(target: HTMLElement, go: (path: string) => void): void { view = target; navigate = go; draw(); }
