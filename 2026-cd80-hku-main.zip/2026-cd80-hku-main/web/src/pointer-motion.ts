import type { Gsap } from './motion-runtime.ts';
import { magneticButton } from './motion-elements.ts';

type Magnet = { face: HTMLElement; box: DOMRect; x: ReturnType<Gsap['quickTo']>; y: ReturnType<Gsap['quickTo']>; returning?: ReturnType<Gsap['to']> };
/** One pointer listener owns cursor, magnetic faces and card lighting across dynamic views. */
export function mountPointerMotion(root: HTMLElement, gsap: Gsap): () => void {
  if (!gsap.quickTo || !document.createElement) return () => {};
  const abort = new AbortController(); const signal = abort.signal;
  const magnets = new Map<HTMLElement, Magnet>();
  const selector = '.button:not(.suggestion-card):not([data-expand-tool]), .theme-toggle, .preferences .icon-button, [data-magnetic]';
  const layer = document.createElement('div'); layer.id = 'custom-cursor'; layer.setAttribute('aria-hidden', 'true');
  const follower = document.createElement('div'); follower.className = 'cursor-follower';
  const face = document.createElement('i'); face.className = 'cursor-face'; const label = document.createElement('span'); label.className = 'cursor-label';
  follower.append(face, label); layer.append(follower); root.append(layer);
  const xTo = gsap.quickTo(follower, 'x', { duration: .18, ease: 'power3.out' });
  const yTo = gsap.quickTo(follower, 'y', { duration: .18, ease: 'power3.out' });
  let active: HTMLElement | undefined; let pressed = false; let point: { x: number; y: number } | undefined;
  let card: HTMLElement | undefined; let spin: ReturnType<Gsap['to']> | undefined; let mode = ''; let visible = false; let frame = 0; let dead = false;
  const base = 10 / 88;
  const resetMagnet = () => {
    if (!active) return; const button = active; const record = magnets.get(button); active = undefined; pressed = false;
    if (record) { record.x.tween.pause(); record.y.tween.pause(); record.returning?.kill(); record.returning = gsap.to(record.face, { x: 0, y: 0, duration: .7, ease: 'elastic.out(1, .45)', overwrite: true, onComplete: () => { delete button.dataset.magneticActive; } }); }
  };
  const resetCard = () => { if (card) delete card.dataset.spotlightActive; spin?.kill(); spin = undefined; card = undefined; };
  const resetCursor = () => { visible = false; mode = ''; layer.style.opacity = '0'; delete document.documentElement.dataset.cursorActive; xTo.tween.pause(); yTo.tween.pause(); gsap.killTweensOf([face, label]); gsap.set(face, { scale: base }); gsap.set(label, { autoAlpha: 0 }); };
  const reset = () => { resetMagnet(); resetCard(); resetCursor(); };
  const hostCursor = () => { const dialogs = Array.from(document.querySelectorAll<HTMLDialogElement>('dialog[open]')); const host = dialogs.at(-1) ?? root; if (layer.parentElement !== host) host.append(layer); };
  const paint = (target: Element | null, follow = true) => {
    if (!point) return; hostCursor();
    if (document.documentElement.dataset.cursor !== 'off') {
      if (!visible) { gsap.set(follower, { x: point.x, y: point.y }); xTo(point.x, point.x); yTo(point.y, point.y); layer.style.opacity = '1'; document.documentElement.dataset.cursorActive = ''; visible = true; }
      else if (follow) { xTo(point.x); yTo(point.y); }
      const image = target?.closest('[data-cursor-image], img');
      const rail = target?.closest<HTMLElement>('[data-drag-rail]');
      const next = image ? 'image' : rail && rail.scrollWidth > rail.clientWidth + 1 ? 'drag' : 'dot';
      if (mode !== next) { mode = next; layer.dataset.mode = next; label.textContent = next === 'image' ? 'Open' : next === 'drag' ? 'Drag' : ''; gsap.to(face, { scale: next === 'image' ? 1 : next === 'drag' ? 64 / 88 : base, duration: .4, ease: 'power3.out', overwrite: true }); gsap.to(label, { autoAlpha: next === 'dot' ? 0 : 1, duration: .2, overwrite: true }); }
    } else resetCursor();
    const nextCard = target?.closest<HTMLElement>('[data-card-spotlight]');
    if (card !== nextCard) {
      resetCard();
      if (nextCard) { card = nextCard; card.dataset.spotlightActive = ''; spin = gsap.fromTo(card, { '--spotlight-angle': '0deg' }, { '--spotlight-angle': '360deg', duration: 3.8, ease: 'none', repeat: -1 }); }
    }
    if (card) { const box = card.getBoundingClientRect(); card.style.setProperty('--x', `${point.x - box.left}px`); card.style.setProperty('--y', `${point.y - box.top}px`); }
    if (pressed) return;
    if (target?.closest('input,textarea,select,[data-dragging],table,[data-chart]')) { resetMagnet(); return; }
    const modal = target?.closest('dialog[open]'); let nearest: HTMLElement | undefined; let distance = Infinity;
    for (const [button, record] of magnets) {
      if (button.matches(':disabled,[aria-disabled="true"],:focus-visible') || !button.isConnected || button.closest('dialog[open]') !== (modal ?? null)) continue;
      if (document.querySelector('dialog[open]') && !modal) continue;
      const box = record.box; if (!box.width || !box.height) continue;
      const reach = Number(button.dataset.magneticRadius) || 24;
      const d = Math.hypot(Math.max(box.left - point.x, 0, point.x - box.right), Math.max(box.top - point.y, 0, point.y - box.bottom));
      if (d <= reach && d < distance) { distance = d; nearest = button; }
    }
    if (nearest !== active) { resetMagnet(); active = nearest; if (active) { magnets.get(active)!.returning?.kill(); active.dataset.magneticActive = ''; } }
    if (active) {
      const record = magnets.get(active)!; const travel = Number(active.dataset.magneticTravel) || 6;
      const clamp = (value: number) => Math.max(-travel, Math.min(travel, value));
      record.x(clamp((point.x - record.box.left - record.box.width / 2) * .2), Number(gsap.getProperty(record.face, 'x')));
      record.y(clamp((point.y - record.box.top - record.box.height / 2) * .2), Number(gsap.getProperty(record.face, 'y')));
    }
  };
  const scan = () => {
    frame = 0; if (dead) return;
    for (const [button, record] of magnets) if (!root.contains(button) || record.face.parentElement !== button || !button.getClientRects().length) {
      if (button === active) resetMagnet(); record.x.tween.kill(); record.y.tween.kill(); gsap.killTweensOf(record.face); record.face.style.removeProperty('transform'); resize.unobserve(button); delete button.dataset.magneticActive; magnets.delete(button);
    }
    for (const button of Array.from(root.querySelectorAll<HTMLElement>(selector))) {
      if (!button.getClientRects().length || button.closest('.segmented-control,[role="tablist"]')) continue;
      if (!magnets.has(button)) {
        magneticButton(button); resize.observe(button); const face = button.querySelector<HTMLElement>(':scope > .magnetic-face')!;
        magnets.set(button, { face, box: button.getBoundingClientRect(), x: gsap.quickTo(face, 'x', { duration: .23, ease: 'power3.out' }), y: gsap.quickTo(face, 'y', { duration: .23, ease: 'power3.out' }) });
      }
    }
    for (const [button, record] of magnets) record.box = button.getBoundingClientRect();
    hostCursor(); if (point) paint(document.elementFromPoint(point.x, point.y), false);
  };
  const schedule = () => { if (!frame && !dead) frame = requestAnimationFrame(scan); };
  const resize = new ResizeObserver(schedule); resize.observe(root);
  const observer = new MutationObserver((records) => { if (records.some((record) => record.target !== layer && !layer.contains(record.target))) schedule(); });
  observer.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['open', 'hidden', 'disabled', 'aria-disabled'] });
  document.addEventListener('pointermove', (event) => { if (event.pointerType !== 'mouse') { reset(); return; } point = { x: event.clientX, y: event.clientY }; paint(document.elementFromPoint(point.x, point.y)); }, { passive: true, signal });
  document.addEventListener('pointerdown', () => { if (active) { pressed = true; const record = magnets.get(active)!; record.x.tween.pause(); record.y.tween.pause(); } }, { signal });
  document.addEventListener('pointerup', () => { pressed = false; }, { signal });
  document.addEventListener('pointerout', (event) => { if (!event.relatedTarget) { point = undefined; reset(); } }, { signal });
  document.addEventListener('pointercancel', reset, { signal });
  document.addEventListener('keydown', () => { point = undefined; reset(); }, { signal });
  document.addEventListener('scroll', () => { resetMagnet(); schedule(); }, { capture: true, passive: true, signal });
  window.addEventListener('resize', schedule, { passive: true, signal }); window.addEventListener('blur', () => { point = undefined; reset(); }, { signal });
  window.addEventListener('blocks:appearance', schedule, { signal });
  scan();
  return () => {
    dead = true; abort.abort(); observer.disconnect(); resize.disconnect(); if (frame) cancelAnimationFrame(frame); reset();
    for (const [button, record] of magnets) { record.x.tween.kill(); record.y.tween.kill(); gsap.killTweensOf(record.face); gsap.set(record.face, { clearProps: 'transform' }); delete button.dataset.magneticActive; }
    xTo.tween.kill(); yTo.tween.kill(); gsap.killTweensOf([face, label]); layer.remove(); magnets.clear();
  };
}

/** Dragging is a direct input, so it stays usable when decorative motion is disabled. */
export function mountDragRails(root: HTMLElement): () => void {
  if (typeof root.addEventListener !== 'function') return () => {};
  const controller = new AbortController(); const signal = controller.signal;
  let active: { rail: HTMLElement; id: number; x: number; left: number } | undefined;
  const end = () => { if (!active) return; const { rail, id } = active; active = undefined; delete rail.dataset.dragging; if (rail.hasPointerCapture(id)) rail.releasePointerCapture(id); };
  root.addEventListener('pointerdown', (event) => {
    const rail = (event.target as Element).closest<HTMLElement>('[data-drag-rail]');
    if (!rail || event.pointerType !== 'mouse' || event.button !== 0 || rail.scrollWidth <= rail.clientWidth + 1 || (event.target as Element).closest('button,a,input,select,textarea')) return;
    end(); event.preventDefault(); rail.focus({ preventScroll: true }); active = { rail, id: event.pointerId, x: event.clientX, left: rail.scrollLeft }; rail.dataset.dragging = ''; rail.setPointerCapture(event.pointerId);
  }, { signal });
  root.addEventListener('pointermove', (event) => { if (!active || event.pointerId !== active.id) return; if (!(event.buttons & 1) || !active.rail.isConnected) { end(); return; } active.rail.scrollLeft = active.left + active.x - event.clientX; }, { passive: true, signal });
  for (const type of ['pointerup', 'pointercancel', 'lostpointercapture']) root.addEventListener(type, end, { signal });
  root.addEventListener('keydown', (event) => {
    const rail = (event.target as Element).closest<HTMLElement>('[data-drag-rail]'); if (!rail) return;
    if (event.key === 'Escape') { end(); return; }
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault(); end(); rail.scrollLeft = event.key === 'Home' ? 0 : event.key === 'End' ? rail.scrollWidth : rail.scrollLeft + (event.key === 'ArrowRight' ? 340 : -340);
  }, { signal });
  window.addEventListener('blur', end, { signal }); window.addEventListener('pagehide', end, { signal }); window.addEventListener('resize', end, { signal });
  const observer = new MutationObserver(() => { if (active && !active.rail.isConnected) end(); }); observer.observe(root, { childList: true, subtree: true });
  return () => { end(); controller.abort(); observer.disconnect(); };
}
