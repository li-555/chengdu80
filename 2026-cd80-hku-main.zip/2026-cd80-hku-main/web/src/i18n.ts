export type Language = 'en' | 'zh';
export type Theme = 'light' | 'dark';
const translations: Record<string, string> = {
  "Monitoring": "监控",
  "Latest monitoring": "最新监控",
  "Reflects the latest completed monitored update, which may differ from the historical run selected above. Scheduled monitoring runs while the server is on; check here for updates.": "显示最近一次已完成的监控更新，可能与上方选中的历史运行不同。服务器运行时执行定时监控；请在此查看更新。",
  "Monitoring request failed.": "监控请求失败。",
  "No monitoring events are configured for this application.": "此应用未配置监控事件。",
  "Latest data record: {id}{date}": "最新数据记录：{id}{date}",
  "No completed monitored update yet.": "尚无已完成的监控更新。",
  "Baseline recorded. Changes will be compared with the next completed monitored update.": "基线已记录。下一次监控更新完成后将比较变更。",
  "{active} active · {unacknowledged} unacknowledged · {acknowledged} acknowledged · {unknown} unknown": "{active} 条触发 · {unacknowledged} 条未确认 · {acknowledged} 条已确认 · {unknown} 条未知",
  "Some monitoring results are unknown. Unknown results do not mean all clear.": "部分监控结果未知。未知不表示全部正常。",
  "Change summary": "变更摘要",
  "No recorded changes in the latest monitored update.": "最近监控更新未记录变更。",
  "Before: {before} → After: {after}": "之前：{before} → 之后：{after}",
  "Showing 50 of {count} changes.": "显示 {count} 条变更中的前 50 条。",
  "Alerts": "提醒",
  "No recorded alerts.": "暂无提醒记录。",
  "Value: {value}": "数值：{value}",
  "First seen: {first} · Last seen: {last} · Data record: {id}": "首次出现：{first} · 最近出现：{last} · 数据记录：{id}",
  "Acknowledged: {date}": "确认时间：{date}",
  "Showing 50 of {count} alerts. Counts include all alerts.": "显示 {count} 条提醒中的前 50 条。数量统计包含全部提醒。",
  "Reopen": "重新打开",
  "Acknowledge": "确认已阅",
  "Monitoring could not be loaded. Refresh to try again.": "无法加载监控。请刷新重试。",
  "Acknowledgment saved.": "确认记录已保存。",
  "Alert reopened.": "提醒已重新打开。",
  "This alert changed. Refresh before acknowledging its latest revision.": "此提醒已变更。请刷新后再确认最新版本。",
  "Acknowledgment is unconfirmed. Refresh to check the saved state.": "尚无法确认保存结果。请刷新检查已保存状态。",
  "Run this application to establish a monitor baseline.": "请运行应用以建立监控基线。",
  "Monitor context changed. Run again to establish a new baseline.": "监控上下文已变更。请重新运行以建立新基线。",
  "Monitor context changed. A new baseline was established; current conditions are queued.": "监控上下文已变更，已建立新基线；当前条件已加入队列。",
  "Baseline established. Current active conditions are queued; no changes have been reported yet.": "基线已建立，当前触发条件已加入队列；尚未报告变更。",
  "Compared with the previous successful monitor run.": "已与上一次成功的监控运行比较。",
  "Show selection": "显示所选记录",
  "Current selection": "当前选择",
  "{selection} (not in latest results)": "{selection}（不在最新结果中）",
  "active": "已触发",
  "cleared": "已消除",
  "unknown": "未知",
  "new": "新增",
  "changed": "已变更",
  "The action was saved, but other saved settings changed. Review latest saved settings before saving or rerunning your draft.": "操作已保存，但其他已保存设置发生变化。再次保存或运行草稿前，请检查最新设置。",
  "The action was saved. Refresh saved settings before saving again; your other entries are retained.": "操作已保存。再次保存前请刷新设置；其他输入已保留。",
  "Use Tushare and your own authorised data. Missing inputs are never replaced with invented values.": "使用 Tushare 和您获授权的数据。缺少输入时不会用虚构数值填充。",
  "Tushare requires a server token and API permissions. Upload your own private records before running.": "Tushare 需要服务器令牌和相应接口权限。运行前请上传您自己的业务资料。",
  "Tushare research and historical risk using your own holdings and disclosure evidence.": "使用 Tushare、您的持仓及披露证据开展投研和历史风险分析。",
  "Tushare financial checks with your own disclosure evidence and regulatory documents.": "使用 Tushare 财务数据，以及您提供的披露证据和法规文档开展检查。",
  "Your client, approved-product and activity records, with Tushare fund NAV references.": "使用您的客户、已审批产品和活动记录，并参考 Tushare 基金净值。",
  "Connect Tushare and your own data. Invented flagship inputs are no longer available.": "请连接 Tushare 和您自己的数据。旗舰应用不再提供虚构演示输入。",
  "This saved flagship uses retired invented inputs. Open Flagship applications and connect Tushare and your own data in a new copy.": "此旧版旗舰应用使用已停用的虚构输入。请打开旗舰应用，在新副本中连接 Tushare 和您自己的数据。",
  "Flagship applications": "旗舰应用",
  "Start with invented demo inputs, or connect your own authorised data.": "使用虚构演示输入，或连接您获授权的数据。",
  "Research": "研究",
  "Risk review": "风险复核",
  "Client service": "客户服务",
  "Watchlist research, company comparisons and historical portfolio risk.": "自选研究、公司比较与历史组合风险。",
  "Explainable financial checks, disclosure evidence and recorded review.": "可解释财务核查、披露证据与复核记录。",
  "Client constraints, product eligibility, pipeline and follow-up work.": "客户约束、产品资格、商机与跟进工作。",
  "Explore demo": "查看演示",
  "Connect my data": "连接我的数据",
  "Demo inputs are invented. Outputs are calculated by the platform.": "演示输入为虚构数据，结果由平台实际计算。",
  "Adding the application to your library…": "正在将应用添加到您的工作区…",
  "Saved list actions": "已保存列表操作",
  "Add or remove a record ID from a saved list setting, then rerun the application. These are local workflow settings, not institutional approvals.": "向已保存的列表参数添加或移除记录 ID，然后重新运行应用。这些是本地工作流设置，并非机构审批。",
  "Record ID": "记录 ID",
  "Action": "操作",
  "Add": "添加",
  "Remove": "移除",
  "Note": "备注",
  "Save action": "保存操作",
  "Refresh": "刷新",
  "Retry same action": "重试同一操作",
  "Saved IDs": "已保存的 ID",
  "Local action history": "本地操作历史",
  "No saved actions yet.": "暂无已保存的操作。",
  "Before": "操作前",
  "After": "操作后",
  "The action could not be confirmed.": "无法确认操作结果。",
  "Saved actions could not be loaded.": "无法加载已保存的操作。",
  "Saved. Rerun to apply the changed list setting.": "已保存。请重新运行以应用修改后的列表参数。",
  "Saved list actions could not be loaded. Check storage and try again.": "无法加载已保存的列表操作，请检查存储后重试。",
  "Choose a declared list setting, record ID and valid action.": "请选择应用声明的列表参数、记录 ID 及有效操作。",
  "Settings changed. Refresh before saving another action.": "参数已变化，请刷新后再保存下一项操作。",
  "This request ID belongs to another action.": "此请求 ID 已用于其他操作。",
  "Choose a declared text list setting and valid record ID.": "请选择应用声明的文本列表参数并输入有效记录 ID。",
  "Saving could not be confirmed. Retry the same action or refresh its history.": "无法确认保存结果，请重试同一操作或刷新操作历史。",
  "The list action request could not be read.": "无法读取列表操作请求。",
  "Templates could not be loaded.": "无法加载应用模板。",
  "The application could not be added.": "无法添加应用。",
  "Open My Apps before importing a template.": "导入模板前请先打开“我的应用”。",
  "Choose demo inputs or connect your own data.": "请选择演示输入或连接自己的数据。",
  "This template is not available.": "此模板不可用。",
  "The template could not be installed. Check storage and try again.": "无法安装模板，请检查存储后重试。",

  'Upload a CSV, TSV, Excel or Markdown file.': '请上传 CSV、TSV、Excel 或 Markdown 文件。',
  'CSV, TSV, Excel or Markdown · 20 MB per file · Up to 5 selected tables per message': 'CSV、TSV、Excel 或 Markdown · 每个文件不超过 20 MB · 每条消息最多选择 5 张表',
  'Markdown prose is added to your message for review. Tables are saved separately; only selected table IDs accompany your message.': 'Markdown 说明会加入消息框供你检查和编辑。表格单独保存；发送时仅附带所选表格的 ID。',
  'Added Markdown description from {name}. Review it in the message before sending.': '已加入 {name} 的 Markdown 说明。发送前请检查消息内容。',
  'This Markdown file has no description or tables.': '此 Markdown 文件没有说明或表格。',
  'Your message and Markdown descriptions exceed 4,000 characters. Shorten them before uploading.': '消息和 Markdown 说明合计超过 4,000 个字符。请缩短后再上传。',
  '{count} blanks': '{count} 个空值', 'First {count} rows': '前 {count} 行', 'Uploaded file preview': '上传文件预览',
  'This preview is no longer in memory. Attach the file again to view it.': '此预览已不在内存中。如需查看，请重新上传文件。',
  'This preview stays in this page and is not sent to the builder.': '预览只保留在当前页面，不会发送给应用构建器。',
  'Wide tables and long values are shortened in this preview.': '预览会缩减过宽表格并截断过长内容。',
  "Application": "应用",
  "Choose Yes or No.": "请选择是或否。",
  "Enter a finite number.": "请输入有效的有限数字。",
  "Enter a value of at least {value}.": "请输入不小于 {value} 的值。",
  "Enter a value no greater than {value}.": "请输入不大于 {value} 的值。",
  "Use increments of {value}.": "请使用 {value} 的步长。",
  "Enter a valid date.": "请输入有效日期。",
  "Choose one of the listed options.": "请选择列表中的选项。",
  "This setting is not available.": "此参数不可用。",
  "End date must be on or after the start date.": "结束日期不能早于开始日期。",
  "{label} (one value per line)": "{label}（每行一个值）",
  "Open this application to change its settings.": "请打开此应用以更改参数。",
  "Setting": "参数",
  "{label} · Start date": "{label} · 开始日期",
  "{label} · End date": "{label} · 结束日期",
  "Inspect · Failed run attempt": "检查 · 失败的运行",
  "This run failed. The dimmed values below are from the last displayed successful run ({date}). Your settings are retained.": "本次运行失败。下方淡化的结果来自上次显示的成功运行（{date}）。已保留您的参数。",
  "This application has no saved run results yet. Choose settings and run it to see results.": "此应用暂无已保存的运行结果。请选择参数并运行以查看结果。",

  'All example values are invented.':'示例数值均为虚构数据。', 'Appearance samples · Drag or use arrow keys':'外观样例 · 拖动或使用方向键', 'Muted':'次要文字',
  '.':'。', 'Home':'首页', 'Data space':'数据空间', 'Components':'组件展示', 'Explore':'探索',
  'Your idea,':'让想法，', 'your application':'成为你的应用', 'Start building':'开始构建',
  'Connect your data with a sentence. Make everyday analysis your own.':'用一句话连接数据，把重复的分析，交给自己的应用。',
  'Appearance':'外观', 'Quick find':'快速查找', 'Make it yours.':'调到你喜欢。', 'Close':'关闭',
  'Accent':'强调色', 'Background':'页面底色', 'Surface':'内容表面', 'Text color':'主文字色',
  'Corner radius':'圆角', 'Sidebar width':'侧栏宽度', 'Spacing':'内容留白', 'Custom cursor':'全页面自定义光标', 'Motion':'交互动效',
  'Reset appearance':'恢复初始外观', 'Appearance is saved in this browser. Reduced motion always takes priority.':'外观保存在当前浏览器。系统减少动态效果设置始终优先。',
  'My Apps': '我的应用', 'Data': '数据', 'Create app': '创建应用', 'Your workspace': '我的工作区',
  'Theme': '主题', 'Language': '语言', 'Light': '浅色', 'Dark': '深色',
  'Switch to dark theme': '切换到深色主题', 'Switch to light theme': '切换到浅色主题',
  'Skip to content': '跳到正文', 'Blocks home': 'Blocks 首页', 'Main navigation': '主导航', 'WORKSPACE': '工作区',
  'Small apps.': '轻量应用。', 'A space of your own.': '专属工作空间。',
  'YOUR LIBRARY': '我的应用库', 'A home for the apps you make your own.': '保存、运行和分享为你而建的应用。',
  '＋ Import app': '＋ 导入应用', 'Import app': '导入应用', 'Your next useful app starts here': '从这里创建下一个实用应用',
  'Have an app someone shared with you? Import it and keep it in your library.': '用对话创建应用，或导入别人分享的应用。',
  'Import your first app': '导入第一个应用', 'Drafts': '草稿', 'Needs attention': '需要处理', 'Download details': '下载详情',
  'Delete': '删除', '← Back to My Apps': '← 返回我的应用', 'Saved to your library': '已保存到应用库',
  'Export app': '导出应用', 'Added to your library': '加入应用库时间', 'Last updated': '最近更新',
  'Compare two runs': '对比两次运行', 'Inspect · Where the data came from': '检查 · 数据来源', 'Settings used': '本次参数',
  'No source records were saved for this run.': '本次运行没有保存来源记录。',
  'Dataset': '数据集', 'Source': '来源', 'Field mapping': '字段映射', 'Requested dates': '请求日期范围',
  'Data as of': '数据截至日期', 'Rows after filtering': '筛选后行数', 'Dataset version': '数据集版本',
  'Fetch duration': '取数耗时', 'Filters sent to provider': '发送给数据源的筛选条件', 'Local filters': '本地筛选条件',
  'Not specified': '未指定', 'Not supplied': '未提供', 'None': '无', 'Scheduled tasks': '定时任务',
  'Refresh tasks': '刷新任务',
  'Runs while the server is on, even with this page closed. Resume after saving data connections. At most one pending run within 24 hours is caught up using current data; older occurrences are skipped. Interrupted runs are not replayed.': '服务运行时，即使关闭页面也会执行任务。修正并保存数据连接后请点击恢复。仅补跑 24 小时内的一次待执行任务，使用当前数据；更早的任务会跳过，中断的任务不会自动重跑。',
  'This application has no clock or market triggers.': '此应用没有定时或开收盘触发器。', 'Trigger removed': '触发器已移除',
  'Version confirmation required': '需要确认版本', 'Running': '运行中', 'Waiting for data': '等待数据连接',
  'Interrupted': '已中断', 'Enabled': '已启用', 'Paused': '已暂停', 'Not enabled': '未启用', 'Not scheduled': '尚未安排',
  'See run history': '查看运行记录', 'Pause': '暂停', 'Resume': '恢复', 'Enable': '启用', 'Confirm version and resume': '确认版本并恢复',
  'Review the current application and check the confirmation box first.': '请先查看当前应用并勾选版本确认。',
  'Task enabled.': '任务已启用。', 'Task paused. An already running execution may finish.': '任务已暂停。已经开始的运行仍可完成。',
  'Run application': '运行应用', 'Run with the settings below. Run changes apply once. Use Save connection and settings below to keep them for future runs.': '使用以下参数运行。临时更改只影响本次运行；点击“保存连接和参数”可用于以后运行。',
  'Retry same run': '重试同一次运行', 'Refresh run history': '刷新运行记录', 'Connect your data': '连接数据',
  'Save connection and settings': '保存连接和参数', 'Save and run': '保存并运行', 'Review latest saved settings': '查看最新已保存设置',
  'Choose a dataset for each requirement, then match its columns. Saving also keeps the parameter values above for future runs.': '为每项数据需求选择数据集并映射字段。保存时也会保存上方参数，供以后运行使用。',
  'Automatic matching': '自动匹配', 'Choose a dataset': '选择数据集',
  'Latest saved settings are shown below. Your draft is unchanged. Review before saving your draft over these settings.': '下方是最新已保存设置，你的草稿仍保留。请先核对，再决定是否用草稿覆盖这些设置。',
  'Connection and settings saved. Running will check that the selected data is readable.': '连接和参数已保存。运行时会检查所选数据是否可读取。',
  'Running…': '运行中…', 'Saved run result': '已保存的运行结果', 'Recent runs': '最近运行', 'No saved runs yet.': '暂无运行记录。',
  'One value per line.': '每行输入一个值。', 'Choose an option': '请选择', 'Running application…': '正在运行应用…',
  'Choose an available dataset below, then save and run. No failed run was saved.': '请在下方选择可用数据集，然后保存并运行。此次未生成失败记录。',
  'Match the required columns below, then save and run. Your other entries are retained.': '请映射下方必需字段，然后保存并运行。其他输入均已保留。',
  'An execution is still active. Refresh run history or retry the same run later.': '仍有一次运行正在进行。请刷新运行记录，或稍后重试同一次运行。',
  'Opening your app…': '正在打开应用…', 'Loading your apps…': '正在加载应用…', 'Try again': '重试',
  'Importing…': '正在导入…', 'Choose a JSON app file, or paste the app document below.': '请选择 JSON 应用文件，或在下方粘贴应用文档。',
  'This file is too large. Choose an app document smaller than 1 MB.': '文件过大，请选择小于 1 MB 的应用文档。',
  'Choose an app file or paste an app document to continue.': '请选择应用文件或粘贴应用文档。',
  'This document is too large. Use an app document smaller than 1 MB.': '文档过大，请使用小于 1 MB 的应用文档。',
  'The app was saved with a few things to review.': '应用已保存，有一些提示需要查看。',
  'The page could not be opened. Please refresh and try again.': '页面无法打开，请刷新重试。', 'Date unavailable': '日期不可用',
  'The run could not be confirmed. Retry the same request or check run history.': '无法确认运行结果。请重试同一次请求或查看运行记录。',
  'Saving could not be confirmed. Your draft is retained. Review latest saved settings before saving again.': '无法确认保存结果。草稿仍保留，请查看最新设置后再保存。',
  'The task update could not be confirmed. Refresh tasks before trying again.': '无法确认任务更新结果。请刷新任务后再试。',
  'The import could not be confirmed. Close this window and refresh your library before trying again.': '无法确认导入结果。请关闭窗口并刷新应用库后再试。',
  'We could not connect to your library. Please try again.': '无法连接应用库，请重试。',
  'Your request could not be completed. Please try again.': '请求未能完成，请重试。', 'Something went wrong. Please try again.': '操作出错，请重试。',
  'See what needs to be changed': '查看需要修改的内容', 'ADD TO YOUR LIBRARY': '添加到应用库', 'Import an app': '导入应用',
  'Close import': '关闭导入窗口', 'Choose a Blocks app file. We will check it before adding it to your library.': '选择 Blocks 应用文件。系统检查后会将其加入应用库。',
  'Choose an app file': '选择应用文件', 'JSON file · Up to 1 MB': 'JSON 文件 · 最大 1 MB', 'Choose an app document, rather than a spreadsheet.': '请选择应用文档，而非电子表格。',
  'Or paste an app document': '或粘贴应用文档', 'App document': '应用文档', 'Paste your app document here': '在此粘贴应用文档',
  'Pasting content replaces the selected file. Up to 1 MB.': '粘贴内容将替代所选文件。最大 1 MB。', 'Cancel': '取消',
  'Turn on JavaScript in your browser to open and import apps.': '请启用浏览器 JavaScript 以打开和导入应用。',
  'YOUR DATASETS': '我的数据集', 'Browse available datasets and their columns. Dataset contents stay in your workspace.': '浏览可用数据集及其字段。数据内容保留在工作区。',
  'Refresh datasets': '刷新数据集', 'Loading dataset details…': '正在加载数据集详情…', 'No datasets available': '暂无可用数据集',
  'Attach a file in chat or check the data service, then refresh this list.': '在聊天中上传文件或检查数据服务，然后刷新列表。',
  'Find a dataset': '查找数据集', 'Search names or columns': '搜索名称或字段', 'All sources': '全部来源',
  'Uploaded file': '上传文件', 'Connected API': '已连接的 API', 'Columns': '字段数', 'Rows': '行数', 'Date coverage': '日期范围',
  'Not reported': '未提供', 'Start not reported': '起始日期未提供', 'End not reported': '结束日期未提供',
  'Datasets': '数据集', 'Dataset details': '数据集详情', 'Select a dataset to see its source, date coverage and column definitions.': '选择数据集以查看来源、日期范围和字段定义。',
  'Column definitions are not available yet.': '暂无字段定义。', 'Column definitions': '字段定义',
  'Column': '字段', 'Type': '类型', 'Unit': '单位', 'Empty values': '空值', 'Allowed': '允许', 'Not allowed': '不允许',
  'Select a dataset to see its column definitions.': '选择数据集以查看字段定义。', 'No datasets match. Try another name or source.': '没有匹配的数据集，请更换名称或来源。',
  'Datasets could not be loaded.': '无法加载数据集。', 'This dataset is no longer available. Refresh the list to choose another.': '此数据集已不可用，请刷新列表并重新选择。',
  'Dataset details are unavailable. Please try again.': '无法获取数据集详情，请重试。', 'Dataset details are unavailable.': '无法获取数据集详情。',
  'We could not connect to the data service. Please try again.': '无法连接数据服务，请重试。', 'Please try again.': '请重试。',
  'Field': '字段', 'Run A': '运行 A', 'Run B': '运行 B', 'Difference (B − A)': '差异（B − A）', 'Changed': '已变化', 'Unchanged': '未变化', 'Missing': '缺失',
  'Refresh runs': '刷新运行记录', 'Choose two saved runs. Settings and results appear side by side.': '选择两次已保存的运行，并排对比参数和结果。',
  'Choose two different runs.': '请选择两次不同的运行。', 'Settings that differ': '不同的参数', 'Changed settings': '参数变化',
  'The settings are identical.': '参数相同。', 'These runs used different app versions. Settings can be compared, but result differences are unavailable. Choose runs from the same version.': '这两次运行使用了不同版本的应用，只能比较参数。请选用同一版本的运行以比较结果。',
  'One run has no saved results. Missing values are labelled below.': '其中一次运行没有保存结果，缺失值会在下方标明。',
  'No saved output values or tables are available.': '没有可用的已保存输出。', 'Column differences': '字段差异',
  'Rows are compared by position; columns are matched by name. A change in row order also counts as a difference.': '行按位置比较，列按名称匹配。行顺序变化也会计入差异。',
  'Showing the first 100 rows. Changed cell count includes every row.': '显示前 100 行，变化单元格数量统计全部行。', 'Saved values side by side': '已保存结果并排对比',
  'Loading saved runs…': '正在加载运行记录…', 'Save at least two runs to compare. Change the run settings above and run the application again.': '至少需要两次运行记录。可以修改上方参数并再次运行应用。',
  'Saved runs could not be loaded. Try Refresh runs.': '无法加载运行记录，请刷新。',
  'Yes': '是', 'No': '否', 'This information is not available yet.': '暂无此信息。',
  'This part of the screen could not be displayed.': '无法显示这部分内容。', 'This part of the app is not available yet.': '这部分应用功能暂不可用。',
  'This chart type is not available yet.': '暂不支持此图表类型。', 'Grouped charts need a separate text series column and exactly one y column.': '分组图表需要独立的文本分组字段和一个 y 值字段。',
  'The chart needs columns that are not available in this result.': '结果中缺少图表所需字段。', 'There are no values to chart.': '没有可绘制的数据。',
  'This chart has too many rows. Limit the result to 5,000 rows or fewer.': '图表数据过多，请将结果限制在 5,000 行以内。',
  'Every chart row needs a category or date.': '每行图表数据都需要类别或日期。', 'Every grouped chart row needs a non-empty text series value.': '每行分组数据都需要非空文本分组值。',
  'Several rows share a category and series. Group the result before charting it.': '存在相同类别和分组的重复行，请先汇总结果。',
  'Every heatmap row needs both categories.': '热力图每行都需要两个类别值。', 'Several values share a heatmap cell. Group the result before charting it.': '同一热力图单元格有多个值，请先汇总结果。',
  'Several rows share a chart category. Group the result before charting it.': '多个数据行使用了同一图表类别，请先汇总结果。',
  'There are no plottable numeric values. Missing and non-numeric values are not treated as zero.': '没有可绘制的数值。缺失值和非数值不会当作零。',
  'Prices': '价格', 'View chart data': '查看图表数据', 'Chart source values': '图表原始值', 'Chart': '图表',
  'The result for this chart is not available yet.': '暂无此图表的结果。', 'Preparing chart…': '正在准备图表…',
  'Missing, invalid or precision-sensitive values are left blank. See source values below.': '缺失、无效或可能损失精度的值保留为空，请查看下方原始值。',
  'The chart could not be displayed. Source values are available below.': '无法显示图表，请查看下方原始值。',
  'The chart could not be loaded. Refresh to try again. Source values are available below.': '无法加载图表，请刷新重试。下方仍可查看原始值。',
  'Preparing the example…': '正在准备示例…', 'The example could not be loaded. Please try again.': '无法加载示例，请重试。',
  'The example could not finish running. Please try again.': '示例运行未完成，请重试。', 'The example finished with notes to review.': '示例运行完成，有提示需要查看。',
  'Review notes': '查看提示', 'The example took too long to open. Please try again.': '示例打开超时，请重试。',
  'Charts': '图表', 'Screen elements': '界面组件', 'INVENTED EXAMPLE': '虚构数据示例', 'Turn on JavaScript to view this example.': '请启用 JavaScript 以查看示例。',
  'All values are invented.': '所有数值均为虚构。', 'Explore the other screen elements': '查看其他界面组件',
  'All names, values and links in this example are invented. No market data is requested and nothing is saved to your library.': '本示例所有名称、数值和链接均为虚构，不请求市场数据，也不保存到应用库。',
  'What would you like to build?': '你想创建什么应用？', 'Describe the task. Blocks will ask what it needs, then build an app you can keep using.': '描述你的任务。Blocks 会询问必要信息，为你创建可以持续使用的应用。',
  'New conversation': '新对话', 'Message': '消息', 'Describe an app, or ask for a change…': '描述一个应用，或提出修改要求…',
  'Send': '发送', 'Stop': '停止', 'Attach files': '添加文件', 'Remove attachment': '移除附件', 'Uploading…': '正在上传…',
  'CSV or Excel · Up to 5 files · 20 MB each': 'CSV 或 Excel · 最多 5 个文件 · 每个最大 20 MB',
  'Files stay in this workspace. The builder sees column names, types and counts, not your rows. Attach files instead of pasting rows into chat.': '文件保留在此工作区。生成模型只接收字段名、类型和行数，不接收数据行。请上传文件，不要把数据行粘贴到聊天中。',
  'Drop files here': '将文件拖到此处', 'You': '你', 'Blocks': 'Blocks', 'Open app': '打开应用', 'App created': '应用已创建', 'App updated': '应用已更新',
  'View drafts in My Apps': '前往我的应用查看草稿', 'Working on your app…': '正在处理你的应用…',
  'Sending stopped. A build may already have been saved; check My Apps before sending again.': '已停止等待。应用可能已经保存，请先查看我的应用再发送。',
  'The connection ended before completion was confirmed. Check My Apps before trying again.': '连接在确认完成之前中断。请先查看我的应用，再决定是否重试。',
  'Your earlier conversation expired or the server restarted. This message started a new conversation.': '之前的会话已过期或服务已重启，本条消息开启了新会话。',
  'Conversations expire after an hour of inactivity or a server restart. Saved apps remain in My Apps.': '对话闲置一小时或服务重启后会失效，已保存的应用仍在我的应用中。',
  'Use at most 4,000 characters per message.': '每条消息最多 4,000 字符。', 'Attach at most 5 files per message.': '每条消息最多附加 5 个文件。',
  'Upload a CSV, TSV or Excel file.': '请上传 CSV、TSV 或 Excel 文件。', 'Upload a file no larger than 20 MB.': '请上传不超过 20 MB 的文件。',
  'The file could not be uploaded. Try again.': '文件上传失败，请重试。', 'The chat could not be reached. Please try again.': '无法连接聊天服务，请重试。',
  'The AI is not set up on this computer yet. Ask whoever installed Blocks to add the AI key.': '此电脑尚未配置 AI 服务，请联系安装人员配置 AI 密钥。',
  'Something went wrong while building. Please try again in a moment.': '创建应用时出错，请稍后重试。',
  'The AI took too long to answer. Please try again in a few minutes.': 'AI 响应超时，请稍后重试。',
  'I could not finish building this application.': '未能完成此应用的创建。', 'I could not build this application. I saved my draft so nothing is lost.': '未能创建此应用，已保存草稿供后续处理。',
  'I could not build this application, and I could not keep my draft this time.': '未能创建此应用，本次也未能保存草稿。',
  'Still working on your last message.': '上一条消息仍在处理中，请稍后再试。',
  'That file is no longer available. Please upload it again.': '该文件已不可用，请重新上传。',
  'Show a daily chart for the companies I follow.': '为我关注的公司制作每日价格图表。',
  'Summarise my spreadsheet in a table and a few key numbers.': '把我的表格汇总为一个表格和几个关键指标。',
  'Compare companies using the metrics I choose.': '使用我选择的指标比较多家公司。',
  '{count} apps in your library': '应用库中有 {count} 个应用', 'Open {name}': '打开 {name}', 'Saved {date}': '保存于 {date}',
  '{name} was added to your library.': '{name} 已加入应用库。', 'Review {count} notes': '查看 {count} 条提示',
  'Run {id} · {date} · {status}': '运行 {id} · {date} · {status}', 'Task {number}: {trigger}': '任务 {number}：{trigger}',
  'Next run (UTC): {date}': '下次运行（UTC）：{date}', 'Last result: {status} · {id}': '最近结果：{status} · {id}',
  'I reviewed the current application and trigger (version {version}).': '我已查看当前应用和触发器（版本 {version}）。',
  '{name} · {type}{required}': '{name} · {type}{required}', ' · required': ' · 必填', '{name} (not in this dataset)': '{name}（不在此数据集中）',
  '{name} (unavailable or uploaded data)': '{name}（不可用或上传的数据）', '{name} (one value per line)': '{name}（每行一个值）',
  'Run {status}{reused}.': '运行{status}{reused}。', ' · saved result reused': ' · 使用已保存结果',
  '{count} of {total} datasets': '显示 {count} / {total} 个数据集', '{source} · {count} columns': '{source} · {count} 个字段',
  '{start} to {end}': '{start} 至 {end}', '{title}. {kind} chart. Source values are available below.': '{title}。{kind}图。下方可查看原始值。',
  'Showing the first 100 of {count} source rows.': '显示 {count} 行原始数据中的前 100 行。',
  'Showing the first 20 series in result order. Hidden series: {names}.': '按结果顺序显示前 20 组，已隐藏：{names}。',
  'Row {number} · {column}': '第 {number} 行 · {column}', ' · Single value': ' · 单值',
  'Run A: {left} rows · Run B: {right} rows · {changed} changed cells': '运行 A：{left} 行 · 运行 B：{right} 行 · {changed} 个单元格变化',
  'Run {label}: {date} · {status} · Data as of {asOf}': '运行 {label}：{date} · {status} · 数据截至 {asOf}',
  '{count} rows · {columns} columns': '{count} 行 · {columns} 个字段', 'Open My Apps': '打开我的应用',
  'Success': '成功', 'Partial': '部分成功', 'Failed': '失败', 'Manual': '手动', 'Market open': '开盘', 'Market close': '收盘',
  'Text': '文本', 'Number': '数字', 'Date': '日期', 'Boolean': '布尔值', 'Line': '折线', 'Bar': '柱状', 'Candlestick': 'K 线', 'Heatmap': '热力',
};
Object.assign(translations, {
  'Select at most 5 tables per message.': '每条消息最多选择 5 张表。',
  'Select tables to attach: {count} / 5': '选择要附加的表：{count} / 5',
  'Each worksheet counts as one table. All saved tables are also available in Data.': '每张工作表计为一张表。所有已保存的表也可在“数据”页找到。',
  'Attach {name}': '附加 {name}', 'Attach table': '附加此表',
  'CSV or Excel · 20 MB per file · Up to 5 selected tables per message': 'CSV 或 Excel · 每个文件最大 20 MB · 每条消息最多选择 5 张表',
  'Upload at most 5 files at a time.': '每次最多上传 5 个文件。',
  'Skipped {name}: no column headers.': '已跳过 {name}：没有列标题。',
  'Could not save {name}. Other saved tables remain available below.': '无法保存 {name}。其他已保存的表仍可在下方使用。',
  'Preview: first 5 rows. Statistics cover the full table.': '预览显示前 5 行，统计覆盖整张表。',
  'Table preview': '表格预览', 'Column statistics': '字段统计',
  'This table has headers but no data rows.': '此表有列标题，但没有数据行。',
  'Preview shows the first 50 columns.': '预览显示前 50 列。',
  'Statistics show the first 200 columns.': '统计显示前 200 列。',
  'Statistics are unavailable for this table. The table is still saved and usable.': '此表暂时无法生成统计，但已保存并可使用。',
  'Numeric values': '有效数值', 'Empty cells': '空单元格', 'Minimum': '最小值', 'Maximum': '最大值', 'Mean': '平均值', 'Sum': '总和', 'Outliers': '异常值数',
  'Empty cells are missing cells or empty strings. Outliers are numeric values more than 3 population standard deviations from the mean.': '空单元格指缺失单元格或空字符串。异常值指偏离平均值超过 3 个总体标准差的数值。',
  'Preview rows and statistics are only shown to you; they are not attached to the builder.': '预览行和统计仅展示给你，不会附加给生成模型。',
  'Loading table preview…': '正在加载表格预览…',
  'The table preview could not be loaded.': '无法加载表格预览。',
  'This uploaded table is not available in your workspace.': '你的工作区中没有此上传表格。',
  "Value": "数值",
  "A single value is needed here, but this result contains several rows.": "此处需要单个数值，但结果包含多行。",
  "There are no rows to show.": "没有可显示的数据行。",
  "Results table": "结果表格",
  "Results": "结果",
  "Previous": "上一页",
  "Next": "下一页",
  "There are no items to show.": "没有可显示的条目。",
  "Column {number}": "第 {number} 列",
  "Previous page: {title}": "上一页：{title}",
  "Next page: {title}": "下一页：{title}",
  "{start}–{end} of {total}": "第 {start}–{end} 行，共 {total} 行",
  "{title} (opens in a new tab)": "{title}（在新标签页打开）",
  "Change: {value}": "变化：{value}",
  "The chart could not be displayed.": "无法显示图表。",
  "Reading what you asked for.": "正在理解你的需求。",
  "Still reading what you asked for.": "仍在理解你的需求。",
  "Looking for the right data.": "正在寻找合适的数据。",
  "Still looking for the right data.": "仍在寻找合适的数据。",
  "Found it. Checking what is in it.": "已找到数据，正在检查内容结构。",
  "Still checking what is in the data.": "仍在检查数据结构。",
  "Writing your application.": "正在创建你的应用。",
  "Still writing your application.": "仍在创建你的应用。",
  "Checking it before it runs.": "正在进行运行前检查。",
  "Still checking it.": "仍在检查应用。",
  "Fixing one small thing.": "正在修正一处问题。",
  "Still fixing it.": "仍在修正问题。",
  "Running it for the first time.": "正在进行首次运行。",
  "Still running it.": "仍在运行中。",
  "Done. Your application is ready.": "完成，应用已准备好。",
  "That looks like rows of data. Please drop it into the chat as a file instead of pasting it. I only look at the column names of a file, never at its rows.": "这看起来是数据行。请将其作为文件上传，不要直接粘贴。生成模型只查看文件字段信息，不查看数据行。",
  "Open My Apps in this browser before continuing.": "请先在此浏览器中打开我的应用。",
  "Your drafts could not be loaded. Check storage and try again.": "无法加载草稿，请检查存储后重试。",
  "This draft is not in your library.": "你的应用库中没有此草稿。",
  "This draft could not be loaded. Check storage and try again.": "无法加载草稿，请检查存储后重试。",
  "This draft could not be deleted. Check storage and try again.": "无法删除草稿，请检查存储后重试。",
  "Your applications could not be loaded. Check storage and try again.": "无法加载应用，请检查存储后重试。",
  "This application is not in your library.": "你的应用库中没有此应用。",
  "This application could not be loaded. Check storage and try again.": "无法加载应用，请检查存储后重试。",
  "This application could not be exported. Check storage and try again.": "无法导出应用，请检查存储后重试。",
  "Run history could not be loaded. Check storage and try again.": "无法加载运行记录，请检查存储后重试。",
  "Scheduled tasks could not be loaded.": "无法加载定时任务。",
  "Choose a declared task and action.": "请选择应用声明的任务及操作。",
  "The application changed. Refresh tasks and review its current version.": "应用已变化，请刷新任务并查看当前版本。",
  "Choose a clock or market trigger declared by this application.": "请选择应用声明的定时或开收盘触发器。",
  "Review and confirm the current application version before resuming.": "恢复前请查看并确认当前应用版本。",
  "The task could not be updated. Refresh tasks and check its status before trying again.": "无法更新任务，请刷新并检查状态后重试。",
  "Data connection settings could not be loaded. Try again.": "无法加载数据连接设置，请重试。",
  "Check the data connection settings.": "请检查数据连接设置。",
  "Settings changed in another session. Reload saved settings before saving again.": "设置已在其他会话中更改，请查看最新保存的设置后再保存。",
  "Saving could not be confirmed. Your draft is retained; reload saved settings to check.": "无法确认保存结果。草稿已保留，请重新加载已保存设置进行确认。",
  "Choose valid run settings and a run identifier.": "请使用有效的运行参数和标识。",
  "Choose a UTF-8 JSON application file.": "请选择 UTF-8 编码的 JSON 应用文件。",
  "Choose a JSON application file.": "请选择 JSON 应用文件。",
  "Choose an application file with content.": "请选择有内容的应用文件。",
  "The application was not saved. Check storage and try again.": "应用未保存，请检查存储后重试。",
  "Choose an application file no larger than 1 MB.": "请选择不超过 1 MB 的应用文件。",
  "Choose an uncompressed UTF-8 JSON application file.": "请选择未压缩的 UTF-8 JSON 应用文件。",
  "The application request could not be read.": "无法读取应用请求。",
  "The application request could not be completed.": "应用请求未能完成。",
  "A saved parameter has an invalid value.": "某个保存的参数值无效。",
  "Choose declared data requirements and fields.": "请选择应用声明的数据需求和字段。",
  "The trading calendar is unavailable or incomplete. Check the data connection, then resume the task.": "交易日历不可用或不完整。请检查数据连接后恢复任务。",
  "The application changed. Review and confirm its current version before resuming.": "应用已变化，恢复前请查看并确认当前版本。",
  "The scheduled execution could not be confirmed. Review its status before enabling it again.": "无法确认定时运行结果，请检查状态后再启用。",
  "An occurrence older than 24 hours was skipped. Historical backlogs are not replayed.": "已跳过超过 24 小时的待执行任务，不补跑历史积压任务。",
  "The calendar changed; the pending market occurrence was rescheduled.": "交易日历已变化，开收盘任务已重新安排。",
  "The execution stopped before its result was saved. Its carried state was not updated. This occurrence will not be replayed automatically.": "运行在结果保存前中断，结转状态未更新，本次任务不会自动重跑。",
  "The next execution time could not be calculated. Review the schedule before enabling it again.": "无法计算下次运行时间，请检查计划后再启用。",
  "The carried state changed during this run. Its new state was not saved.": "运行期间结转状态发生变化，本次新状态未保存。",
  "The saved application or its settings are invalid.": "保存的应用或参数无效。",
  "Choose a supported data adapter. Invented examples must be explicitly enabled.": "请选择受支持的数据连接。虚构示例需要显式启用。",
  "This execution entry does not enable external model steps.": "当前运行入口尚未启用应用内部的 AI 步骤。",
  "The data adapter could not resolve this application.": "无法为此应用读取所需数据。",
  "The application could not finish running.": "应用未能完成运行。",
  "The run returned values that cannot be saved.": "运行返回的值无法保存。",
  "The execution exceeded its time limit.": "运行超时。",
  "The execution was cancelled.": "运行已取消。",
  "Use a dataset name between 1 and 80 characters.": "数据集名称需要 1 至 80 个字符。",
  "Upload a file containing columns and data.": "请上传包含字段和数据的文件。",
  "The file could not be read as a table.": "无法将此文件读取为表格。",
  "The file must have column headers.": "文件必须包含列标题。",
  "The upload request could not be read.": "无法读取上传请求。",
  "The upload could not be stored or read. Please try again.": "无法保存或读取上传文件，请重试。",
  "Fictional charts and company series": "虚构图表及公司分组示例",
  "Explore lines, grouped and stacked company bars, daily candles and a heatmap.": "查看折线、公司分组与堆叠柱形图、日 K 线和热力图。",
  "An overview, ready to explore": "界面组件示例",
  "A fictional example showing tables, a single value, text, a note and a grouped list.": "使用虚构数据展示表格、单值、文字、提示和分组列表。",
  "Choose a dataset for: {details}": "请为以下需求选择数据集：{details}",
  "Match required fields: {details}": "请映射必需字段：{details}"
});

// Desktop workspace labels. Application content continues to retain its original language.
Object.assign(translations, {
  "Find an app": "查找应用",
  "Search apps": "搜索应用名称或描述",
  "Sort by": "排序方式",
  "Recently updated": "最近更新",
  "Recently added": "最近添加",
  "Name": "名称",
  "Library view": "应用库视图",
  "Grid": "网格",
  "List": "列表",
  "No apps match your search.": "没有符合搜索条件的应用。",
  "Clear search": "清除搜索",
  "{count} of {total} apps": "显示 {count} / {total} 个应用",
  "Updated {date}": "更新于 {date}",
  "Drafts need review before they can become runnable apps.": "草稿需要检查和修正后才能成为可运行的应用。",
  "Application views": "应用工作区视图",
  "Run history": "运行历史",
  "Compare": "对比",
  "Inspect": "来源检查",
  "Run settings": "运行设置",
  "Run this app to see its results here.": "运行应用后，结果会显示在这里。",
  "Select a saved run to inspect its sources.": "选择一次已保存的运行，查看其数据来源。",
  "Showing run from {date} · {status}": "当前结果：{date} · {status}",
  "This run has no saved output. Review its status and sources.": "本次运行没有保存输出，请检查状态和来源。",
  "Times are shown in your browser time zone.": "时间按浏览器所在时区显示。",
  "Data as of {date}": "数据截至 {date}",
  "App version: {version}": "应用版本：{version}",
  "Save at least two runs to compare. Change the run settings and run the application again.": "至少保存两次运行后才能对比。请修改运行参数，再运行一次应用。",
  "Conversation": "对话记录",
  "New messages · Jump to latest": "有新消息 · 查看最新",
  "Enter to send · Shift + Enter for a new line": "Enter 发送 · Shift + Enter 换行",
  "Files and conversation privacy": "文件与对话说明",
  "Saved tables": "已保存的表",
  "Saved tables: {saved} · Selected: {selected} / 5": "已保存 {saved} 张表 · 本次已选 {selected} / 5",
  "Dataset views": "数据集视图",
  "Preview and statistics": "预览与统计",
  "Clear filters": "清除筛选",
  "Upload files": "上传文件",
  "Saved {count} tables from {name}.": "已从 {name} 保存 {count} 张表。"
});

let language: Language = 'en';
let theme: Theme = systemTheme();
try {
  if (typeof window !== 'undefined') {
    language = window.localStorage.getItem('blocks:language') === 'zh' ? 'zh' : 'en';
    const saved = window.localStorage.getItem('blocks:theme');
    theme = resolveThemePreference(saved);
    if (saved !== null && saved !== theme) window.localStorage.setItem('blocks:theme', theme);
  }
} catch { /* Preferences remain usable without browser storage. */ }
export function isTheme(value: unknown): value is Theme { return value === 'light' || value === 'dark'; }
function systemTheme(): Theme {
  return typeof window !== 'undefined' && window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}
/** Older saved choices migrate without adding extra selectable themes. */
export function resolveThemePreference(value: unknown): Theme {
  if (value === 'night' || value === 'dark') return 'dark';
  if (value === 'daylight' || value === 'paper' || value === 'desk' || value === 'light') return 'light';
  return systemTheme();
}
/** Storage notifications must not write back and bounce between open tabs. */
export function syncThemePreference(value: string | null): void {
  theme = resolveThemePreference(value);
  applyPreferences();
}
export function getLanguage(): Language { return language; }
export function getTheme(): Theme { return theme; }
export function locale(): string { return language === 'zh' ? 'zh-CN' : 'en'; }
const numberFormats = new Map<string, Intl.NumberFormat>();
/** Fixed display precision only; exact decimal strings never pass through Number. */
export function formatNumber(value: number | bigint | string, digits: 0 | 2 = 2): string {
  if (typeof value === 'number' && !Number.isFinite(value)) return '—';
  const key = `${locale()}:${digits}`;
  let formatter = numberFormats.get(key);
  if (!formatter) {
    formatter = new Intl.NumberFormat(locale(), { minimumFractionDigits: digits, maximumFractionDigits: digits });
    numberFormats.set(key, formatter);
  }
  let numeric: number | bigint;
  let fraction: string | undefined;
  if (typeof value === 'string') {
    if (!/^-?\d+(?:\.\d+)?$/.test(value)) return value;
    const negative = value.startsWith('-');
    const [whole = '0', decimal = ''] = value.replace(/^-/, '').split('.');
    const scale = 10n ** BigInt(digits);
    let rounded = BigInt(whole) * scale + BigInt(decimal.padEnd(digits, '0').slice(0, digits) || '0');
    if ((decimal[digits] ?? '0') >= '5') rounded++;
    const integer = rounded / scale;
    numeric = negative && rounded !== 0n ? integer === 0n ? -0 : -integer : integer;
    fraction = (rounded % scale).toString().padStart(digits, '0');
  } else numeric = value;
  const parts = formatter.formatToParts(numeric).map((part) => part.type === 'fraction' && fraction !== undefined ? { ...part, value: fraction } : part);
  const zero = parts.filter((part) => part.type === 'integer' || part.type === 'fraction').every((part) => /^0+$/.test(part.value));
  return parts.filter((part) => !(zero && part.type === 'minusSign')).map((part) => part.value).join('');
}
export function t(key: string, values: Record<string, string | number> = {}): string {
  if (language === 'zh') {
    for (const [prefix, pattern] of [['Choose a dataset for: ', 'Choose a dataset for: {details}'], ['Match required fields: ', 'Match required fields: {details}']] as const) {
      if (key !== pattern && key.startsWith(prefix)) return t(pattern, { details: key.slice(prefix.length) });
    }
  }
  const template = language === 'zh' ? translations[key] ?? key : key;
  return template.replace(/\{(\w+)\}/g, (match, name: string) => Object.hasOwn(values, name) ? String(values[name]) : match);
}
export function statusText(value: string): string {
  return t(({ ok: 'Success', partial: 'Partial', failed: 'Failed', running: 'Running', manual: 'Manual',
    text: 'Text', number: 'Number', date: 'Date', boolean: 'Boolean', line: 'Line', bar: 'Bar', candlestick: 'Candlestick', heatmap: 'Heatmap' } as Record<string, string>)[value] ?? value);
}
export function setLanguage(value: Language): void {
  if (typeof window !== 'undefined') window.dispatchEvent(new Event('blocks:before-language'));
  language = value;
  try { if (typeof window !== 'undefined') window.localStorage.setItem('blocks:language', value); } catch { /* In-memory preference remains active. */ }
  applyPreferences();
  if (typeof window !== 'undefined') window.dispatchEvent(new Event('blocks:language'));
}
export function setTheme(value: Theme): void {
  theme = value;
  try { if (typeof window !== 'undefined') window.localStorage.setItem('blocks:theme', value); } catch { /* In-memory preference remains active. */ }
  applyPreferences();
}
export function applyPreferences(): void {
  if (typeof document === 'undefined') return;
  document.documentElement.lang = locale();
  document.documentElement.dataset.theme = theme;
  document.documentElement.style.colorScheme = theme;
  if (typeof window !== 'undefined') window.dispatchEvent(new Event('blocks:theme'));
  for (const el of Array.from(document.querySelectorAll<HTMLElement>('[data-i18n]'))) { const translated = t(el.dataset.i18n!); if (el.textContent !== translated) el.textContent = translated; }
  for (const attr of ['aria-label', 'placeholder', 'title']) {
    for (const el of Array.from(document.querySelectorAll<HTMLElement>(`[data-i18n-${attr}]`))) el.setAttribute(attr, t(el.getAttribute(`data-i18n-${attr}`)!));
  }
}
applyPreferences();
