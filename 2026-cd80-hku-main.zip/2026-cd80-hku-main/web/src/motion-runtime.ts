export type Gsap = typeof import('gsap').gsap;

export function reducedMotion(): boolean {
  return (typeof document !== 'undefined' && document.documentElement.dataset?.motion === 'off')
    || (typeof window !== 'undefined' && !!window.matchMedia?.('(prefers-reduced-motion: reduce)').matches);
}

/** Detached DOM/state tests and unavailable browser APIs retain the static UI. */
export function canAnimate(): boolean {
  return typeof window !== 'undefined' && typeof document !== 'undefined'
    && typeof window.requestAnimationFrame === 'function' && typeof window.getComputedStyle === 'function'
    && typeof document.documentElement.getBoundingClientRect === 'function';
}

let loading: Promise<Gsap | null> | undefined;
export function loadGsap(): Promise<Gsap | null> {
  if (!canAnimate() || reducedMotion()) return Promise.resolve(null);
  const runtime = window as Window & { gsap?: Gsap };
  if (runtime.gsap) return Promise.resolve(runtime.gsap);
  if (!loading) loading = new Promise((resolve) => {
    const script = document.createElement('script');
    script.src = '/assets/gsap.min.js'; script.async = true;
    const finish = () => { window.clearTimeout(timeout); script.onload = null; script.onerror = null; resolve(runtime.gsap ?? null); };
    const timeout = window.setTimeout(finish, 5000);
    script.onload = finish; script.onerror = finish;
    document.head.append(script);
  });
  return loading;
}

/** Only called for newly appended, visible content, never for restored history. */
export async function revealNewContent(elements: HTMLElement[]): Promise<void> {
  if (!elements.length || !canAnimate() || reducedMotion() || document.hidden) return;
  const started = performance.now();
  const gsap = await loadGsap();
  if (!gsap || reducedMotion() || document.hidden || performance.now() - started > 250) return;
  const targets = elements.filter((element) => element.isConnected && !element.hidden);
  if (!targets.length) return;
  const media = window.matchMedia('(prefers-reduced-motion: reduce)');
  let context: ReturnType<Gsap['context']> | undefined;
  const stop = () => {
    context?.revert(); observer.disconnect(); media.removeEventListener('change', stop);
    window.removeEventListener('blocks:appearance', stop); window.removeEventListener('pagehide', stop); document.removeEventListener('visibilitychange', onVisibility);
  };
  const onVisibility = () => { if (document.hidden) stop(); };
  const observer = new MutationObserver(() => { if (targets.some((target) => !target.isConnected || target.hidden)) stop(); });
  observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['hidden'] });
  window.addEventListener('blocks:appearance', stop); media.addEventListener('change', stop); window.addEventListener('pagehide', stop); document.addEventListener('visibilitychange', onVisibility);
  context = gsap.context(() => {
    gsap.fromTo(targets, { opacity: 0, y: 8 }, { opacity: 1, y: 0, duration: .26, stagger: .045,
      ease: 'power2.out', overwrite: 'auto', onComplete: stop });
  });
}

let splitting: Promise<typeof import('gsap/SplitText').SplitText | null> | undefined;
export async function loadSplitText() {
  const gsap = await loadGsap(); if (!gsap) return null;
  const runtime = window as Window & { SplitText?: typeof import('gsap/SplitText').SplitText };
  if (!runtime.SplitText) splitting ??= new Promise((resolve) => {
    const script = document.createElement('script'); script.src = '/assets/SplitText.min.js';
    const finish = () => { window.clearTimeout(timeout); script.onload = null; script.onerror = null; resolve(runtime.SplitText ?? null); };
    const timeout = window.setTimeout(finish, 5000); script.onload = finish; script.onerror = finish; document.head.append(script);
  });
  const split = runtime.SplitText ?? await splitting;
  if (split) gsap.registerPlugin(split);
  return split;
}
