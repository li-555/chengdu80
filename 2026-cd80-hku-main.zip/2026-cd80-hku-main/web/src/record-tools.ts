import { t } from './i18n.ts';
import type { ParamDecl } from './app-types.ts';
import type { RunResult } from '../../src/compute/result.ts';
import type { ListActionPanel } from './list-actions.ts';
function node<K extends keyof HTMLElementTagNameMap>(tag: K, text?: string, className?: string): HTMLElementTagNameMap[K] { const result = document.createElement(tag); if (text !== undefined) result.textContent = t(text); if (className) result.className = className; return result; }
type Options = { displayLabel?: (value: string) => string; params: ParamDecl[]; getRaw(key: string): unknown; setParam(key: string, value: string): void; run(): void | Promise<void>; canEdit(): boolean; actions: Pick<ListActionPanel, 'snapshot' | 'isBusy' | 'saveRecordAction'> };
/** Reserved output names bind only to declared text settings. */
export function createRecordTools(options: Options) {
  const element = node('section', undefined, 'screen-panel'); element.dataset.recordTools = 'true'; element.hidden = true;
  let syncers: (() => void)[] = [];
  function clear() { element.replaceChildren(); syncers = []; element.hidden = true; }
  function sync() { syncers.forEach((update) => update()); }
  function show(outputs: RunResult['outputs']) {
    clear();
    for (const param of [...options.params.filter((param) => !param.list), ...options.params.filter((param) => param.list)]) {
      if (param.type !== 'text') continue;
      const table = outputs[`${param.list ? 'act' : 'pick'}_${param.key}`];
      if (!table || !Array.isArray(table.schema) || !Array.isArray(table.rows)) continue;
      const names = table.schema.map((column) => column.name);
      const required = param.list ? ['record_id', 'label', 'add_label', 'remove_label'] : ['value', 'label'];
      if (new Set(names).size !== names.length || !required.every((name) => names.includes(name))) continue;
      const index = (name: string) => names.indexOf(name);
      const seen = new Set<string>();
      const rows: { id: string; label: string; add: string; remove: string; detail: string }[] = [];
      for (const row of table.rows.slice(0, 10000)) {
        if (!Array.isArray(row)) continue;
        const id = row[index(param.list ? 'record_id' : 'value')], label = row[index('label')];
        if (typeof id !== 'string' || (!id.trim() && (param.list || id !== '')) || id.length > (param.list ? 200 : 10000) || typeof label !== 'string' || !label.trim() || label.length > 1000 || seen.has(id)) continue;
        const add = param.list ? row[index('add_label')] : '', remove = param.list ? row[index('remove_label')] : '';
        if (typeof add !== 'string' || typeof remove !== 'string' || (param.list && (!add.trim() || !remove.trim() || add.length > 1000 || remove.length > 1000))) continue;
        const detail = row[index('detail')];
        seen.add(id); rows.push({ id, label: options.displayLabel?.(label) ?? label, add: options.displayLabel?.(add) ?? add, remove: options.displayLabel?.(remove) ?? remove, detail: typeof detail === 'string' ? (options.displayLabel?.(detail) ?? detail).slice(0, 2000) : '' });
        if (rows.length >= (param.list ? 50 : 500)) break;
      }
      if (!rows.length) continue;
      const group = param.list ? node('details') : node('div', undefined, 'run-setting');
      if (param.list) { (group as HTMLDetailsElement).open = rows.length <= 3; group.append(node('summary', `${param.label} (${rows.length})`)); }
      else group.append(node('h3', param.label));
      element.append(group);
      if (!param.list) {
        let lastRaw: unknown = Symbol('initial');
        const select = node('select'); const button = node('button', 'Show selection', 'button button-secondary'); button.type = 'button';
        const update = () => { const raw = options.getRaw(param.key); const previous = select.value; select.replaceChildren(); const current = typeof raw === 'string' ? raw : ''; if (!rows.some((row) => row.id === current)) { const missing = node('option', t('{selection} (not in latest results)', {selection: current || t('Current selection')})); missing.value = current; select.append(missing); } for (const row of rows) { const choice = node('option', row.label); choice.value = row.id; select.append(choice); } select.value = raw === lastRaw && rows.some((row) => row.id === previous) ? previous : current; lastRaw = raw; select.disabled = !options.canEdit() || options.actions.isBusy(); button.disabled = select.disabled || !rows.some((row) => row.id === select.value); };
        select.setAttribute('aria-label', param.label); select.addEventListener('change', () => { button.disabled = select.disabled || !rows.some((row) => row.id === select.value); });
        button.addEventListener('click', () => { if (!options.canEdit() || options.actions.isBusy() || !rows.some((row) => row.id === select.value)) return; options.setParam(param.key, select.value); void options.run(); });
        group.append(select, button); syncers.push(update); update();
      } else for (const row of rows) {
        const item = node('div', undefined, 'screen-panel'); const button = node('button', undefined, 'button button-secondary'); button.type = 'button';
        const saved = () => options.actions.snapshot()?.params.find((value) => value.key === param.key);
        const update = () => { button.textContent = saved()?.values.includes(row.id) ? row.remove : row.add; button.disabled = !options.canEdit() || options.actions.isBusy() || !saved(); };
        button.addEventListener('click', () => { const current = saved(); if (!options.canEdit() || options.actions.isBusy() || !current) return; void options.actions.saveRecordAction({ param: param.key, recordId: row.id, action: current.values.includes(row.id) ? 'remove' : 'add', note: '' }); });
        item.append(node('h4', row.label)); if (row.detail) item.append(node('p', row.detail, 'field-help')); item.append(button); group.append(item); syncers.push(update); update();
      }
    }
    element.hidden = syncers.length === 0;
  }
  return { element, show, sync, clear };
}
