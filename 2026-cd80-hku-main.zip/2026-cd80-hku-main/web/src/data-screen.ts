import { t, locale, statusText } from './i18n.ts';
import { createTabs } from './workspace-ui.ts';
import { expandingTool } from './motion-elements.ts';
import { createUploadPreview, uploadWorkbook, cacheUploadPreview, UPLOAD_ACCEPT } from './chat-upload.ts';
import type { Dataset } from '../../src/data/types.ts';

function node<K extends keyof HTMLElementTagNameMap>(tag: K, text?: string, className?: string): HTMLElementTagNameMap[K] {
  const result = document.createElement(tag);
  if (text !== undefined) result.textContent = text;
  if (className) result.className = className;
  return result;
}

type DataViewState = { query: string; source: string; selectedId?: string; tab: 'fields' | 'preview' };
const dataViews = new Map<string, DataViewState>();
const sources = { tushare: 'Tushare', upload: 'Uploaded file', api: 'Connected API' };

function action(label: string, run: () => void): HTMLButtonElement {
  const button = node('button', label, 'button button-secondary');
  button.type = 'button'; button.addEventListener('click', run);
  return button;
}

async function metadata<T>(path: string): Promise<T> {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), 30_000);
  try {
    const response = await fetch(path, { credentials: 'same-origin', signal: controller.signal });
    if (response.status === 404) throw new Error(t('This dataset is no longer available. Refresh the list to choose another.'));
    if (!response.ok) throw new Error(t('Dataset details are unavailable. Please try again.'));
    return await response.json() as T;
  } catch (error) {
    if (error instanceof Error && (error.message.startsWith('This dataset') || error.message.startsWith(t('Dataset details')))) throw error;
    throw new Error(t('We could not connect to the data service. Please try again.'));
  } finally { window.clearTimeout(timer); }
}

function summary(dataset: Dataset): HTMLDListElement {
  const list = node('dl', undefined, 'data-summary');
  for (const [label, value] of [
    [t('Source'), t(sources[dataset.source])],
    [t('Columns'), String(dataset.fields.length)],
    [t('Rows'), dataset.rowCount === undefined ? t('Not reported') : dataset.rowCount.toLocaleString(locale())],
    [t('Date coverage'), dataset.coverageStart || dataset.coverageEnd
      ? t('{start} to {end}', { start: dataset.coverageStart ?? t('Start not reported'), end: dataset.coverageEnd ?? t('End not reported') }) : t('Not reported')],
  ]) { const item = node('div'); item.append(node('dt', label), node('dd', value)); list.append(item); }
  return list;
}

/** Combine shared provider metadata with uploads returned for this profile. */
export function visibleDatasets(catalogue: Dataset[], uploads: Dataset[]): Dataset[] {
  const owned = uploads.filter((dataset) => dataset.source === 'upload');
  return [...new Map([...catalogue.filter((dataset) => dataset.source === 'tushare'), ...owned]
    .map((dataset) => [dataset.id, dataset])).values()];
}

/** Read-only dataset metadata; profile must match the surrounding workspace. */
export async function showDataScreen(view: HTMLElement, options: { profile?: string; moveFocus?: boolean } = {}): Promise<void> {
  const profile = options.profile && /^[A-Za-z0-9_-]{1,40}$/.test(options.profile) ? options.profile : 'default';
  const query = `?profile=${encodeURIComponent(profile)}`;
  let saved = dataViews.get(profile);
  if (!saved) {
    saved = { query: '', source: 'all', tab: 'fields' };
    try {
      const value = JSON.parse(sessionStorage.getItem(`blocks:data-view:${profile}`) ?? '{}');
      if (typeof value.query === 'string') saved.query = value.query;
      if (['all', 'upload', 'tushare', 'api'].includes(value.source)) saved.source = value.source;
      if (typeof value.selectedId === 'string') saved.selectedId = value.selectedId;
      if (value.tab === 'preview') saved.tab = 'preview';
    } catch { /* In-memory fallback. */ }
    dataViews.set(profile, saved);
  }
  const state = saved;
  const persist = () => { try { sessionStorage.setItem(`blocks:data-view:${profile}`, JSON.stringify(state)); } catch { /* In-memory fallback. */ } };
  const screen = node('section', undefined, 'data-screen');
  const header = node('header', undefined, 'page-heading');
  const title = node('div');
  const heading = node('h1', t('Data')); heading.tabIndex = -1;
  title.append(node('p', t('YOUR DATASETS'), 'eyebrow'), heading, node('p', t('Browse available datasets and their columns. Dataset contents stay in your workspace.')));
  const refresh = action(t('Refresh datasets'), () => { void showDataScreen(view, { profile, moveFocus: true }); });
  const actions = node('div', undefined, 'heading-actions');
  const fileInput = node('input'); fileInput.type = 'file'; fileInput.multiple = true; fileInput.accept = UPLOAD_ACCEPT; fileInput.hidden = true;
  const upload = action(t('Upload files'), () => fileInput.click()); upload.disabled = true;
  actions.append(upload, fileInput, expandingTool(refresh, '↻')); header.append(title, actions); screen.append(header);
  const uploadFeedback = node('div'); uploadFeedback.setAttribute('role', 'status'); screen.append(uploadFeedback);
  const status = node('p', t('Loading dataset details…'), 'loading-message'); status.setAttribute('role', 'status');
  screen.append(status); view.replaceChildren(screen);
  if (options.moveFocus) heading.focus();
  const active = () => view.contains(screen);
  try {
    // Establish the same HttpOnly library cookie on a direct /data visit before uploads.
    await metadata('/api/apps');
    if (!active()) return;
    // Both endpoints must enforce the requested profile on the server.
    const [catalogue, uploads] = await Promise.all([
      metadata<{ datasets: Dataset[] }>(`/api/data/datasets${query}`),
      metadata<{ datasets: Dataset[] }>(`/api/uploads${query}`),
    ]);
    if (!active()) return;
    let datasets = visibleDatasets(catalogue.datasets, uploads.datasets);
    upload.disabled = false;
    status.remove();
    const controls = node('div', undefined, 'data-controls');
    const searchLabel = node('label', t('Find a dataset'), 'run-setting');
    const search = node('input'); search.type = 'search'; search.placeholder = t('Search names or columns'); search.value = state.query; searchLabel.append(search);
    const sourceLabel = node('label', t('Source'), 'run-setting');
    const source = node('select');
    for (const [value, label] of [['all', t('All sources')], ...Object.entries(sources)]) {
      const option = node('option', t(label!)); option.value = value ?? 'all'; source.append(option);
    }
    source.value = state.source;
    sourceLabel.append(source); controls.append(searchLabel, sourceLabel);
    const count = node('p', undefined, 'library-caption'); count.setAttribute('role', 'status');
    const layout = node('div', undefined, 'data-layout');
    const list = node('ul', undefined, 'data-list'); list.setAttribute('aria-label', t('Datasets'));
    const detail = node('section', undefined, 'data-detail'); detail.setAttribute('aria-label', t('Dataset details'));
    detail.append(node('h2', t('Choose a dataset')), node('p', t('Select a dataset to see its source, date coverage and column definitions.'), 'muted'));
    layout.append(list, detail); screen.append(controls, count, layout);
    let selection = 0;
    let selectedId: string | undefined;
    let loadedVersion = '';
    async function choose(dataset: Dataset, moveFocus = true): Promise<void> {
      const request = ++selection; selectedId = dataset.id;
      if (state.selectedId !== dataset.id) state.tab = 'fields';
      state.selectedId = dataset.id; persist();
      for (const item of Array.from(list.querySelectorAll('button'))) item.setAttribute('aria-pressed', String(item.dataset.datasetId === dataset.id));
      const loading = node('p', t('Loading dataset details…'), 'loading-message'); loading.setAttribute('role', 'status');
      detail.replaceChildren(loading);
      try {
        const current = dataset.source === 'upload' ? dataset
          : (await metadata<{ dataset: Dataset }>(`/api/data/datasets/${encodeURIComponent(dataset.id)}${query}`)).dataset;
        if (!active() || request !== selection) return;
        const detailHeading = node('h2', current.name); detailHeading.tabIndex = -1;
        loadedVersion = JSON.stringify(dataset);
        detail.replaceChildren(detailHeading, node('p', current.id, 'data-id'), summary(current));
        const fields = node('section'); const preview = node('section'); let previewReady = false;
        const tabs = createTabs('dataset', t('Dataset views'), [
          { id: 'fields', label: t('Column definitions'), panel: fields, activate: () => { state.tab = 'fields'; persist(); } },
          ...(current.source === 'upload' ? [{ id: 'preview', label: t('Preview and statistics'), panel: preview, activate: () => {
            state.tab = 'preview'; persist(); if (!previewReady) { previewReady = true; preview.append(createUploadPreview(current.id)); }
          } }] : []),
        ]);
        detail.append(tabs.root);
        if (state.tab === 'preview' && current.source === 'upload') tabs.select('preview');
        if (current.notes) fields.append(node('p', current.notes, 'muted'));
        if (!current.fields.length) fields.append(node('p', t('Column definitions are not available yet.'), 'notice'));
        else {
          const scroll = node('div', undefined, 'data-columns'); scroll.tabIndex = 0; scroll.setAttribute('role', 'region'); scroll.setAttribute('aria-label', t('Column definitions'));
          const table = node('table'); table.append(node('caption', t('Column definitions')));
          const head = node('thead'); const row = node('tr');
          for (const label of [t('Column'), t('Type'), t('Unit'), t('Empty values')]) { const cell = node('th', label); cell.scope = 'col'; row.append(cell); }
          head.append(row); const body = node('tbody');
          for (const field of current.fields) {
            const row = node('tr'); const name = node('th'); name.scope = 'row';
            name.append(node('span', field.label || field.name), node('code', field.name));
            row.append(name, node('td', statusText(field.type)), node('td', field.unit ?? t('Not reported')), node('td', field.nullable ? t('Allowed') : t('Not allowed'))); body.append(row);
          }
          table.append(head, body); scroll.append(table); fields.append(scroll);
        }
        if (moveFocus) detailHeading.focus();
      } catch (error) {
        if (!active() || request !== selection) return;
        const notice = node('div', undefined, 'notice'); notice.setAttribute('role', 'alert');
        notice.append(node('p', error instanceof Error ? error.message : t('Dataset details are unavailable.')), action(t('Try again'), () => { void choose(dataset); })); detail.replaceChildren(notice);
      }
    }
    function filter(): void {
      state.query = search.value; state.source = source.value; persist();
      const term = search.value.trim().toLocaleLowerCase();
      const shown = datasets.filter((dataset) => (source.value === 'all' || dataset.source === source.value)
        && [dataset.name, dataset.id, ...dataset.fields.map((field) => `${field.name} ${field.label}`)].some((value) => value.toLocaleLowerCase().includes(term)));
      count.textContent = t('{count} of {total} datasets', { count: shown.length, total: datasets.length });
      list.replaceChildren();
      for (const dataset of shown) {
        const item = node('li'); const select = action('', () => { void choose(dataset); });
        select.className = 'data-choice'; select.dataset.datasetId = dataset.id; select.setAttribute('aria-pressed', String(state.selectedId === dataset.id));
        select.append(node('strong', dataset.name), node('span', t('{source} · {count} columns', { source: t(sources[dataset.source]), count: dataset.fields.length }), 'muted'));
        item.append(select); list.append(item);
      }
      const chosen = shown.find((item) => item.id === state.selectedId);
      if (chosen) {
        if (selectedId !== chosen.id || loadedVersion !== JSON.stringify(chosen)) void choose(chosen, false);
      } else {
        ++selection; selectedId = undefined; loadedVersion = '';
        detail.replaceChildren(node('h2', t('Choose a dataset')), node('p', t('Select a dataset to see its source, date coverage and column definitions.'), 'muted'));
      }
      if (!shown.length) {
        const empty = node('li', undefined, 'data-list-empty');
        empty.append(node('p', t(datasets.length ? 'No datasets match. Try another name or source.' : 'No datasets available')));
        if (datasets.length) empty.append(action(t('Clear filters'), () => { search.value = ''; source.value = 'all'; filter(); search.focus(); }));
        list.append(empty);
      }
    }
    fileInput.addEventListener('change', () => {
      const files = Array.from(fileInput.files ?? []); fileInput.value = ''; if (!files.length) return;
      if (files.length > 5) { uploadFeedback.replaceChildren(node('p', t('Upload at most 5 files at a time.'), 'notice')); return; }
      upload.disabled = true; refresh.disabled = true; upload.textContent = t('Uploading…'); uploadFeedback.replaceChildren();
      void (async () => {
        try {
          for (const file of files) {
            const result = await uploadWorkbook(file);
            if (!active()) return;
            const sheets = result.sheets ?? [{ dataset: result.dataset, blankCounts: result.blankCounts, preview: result.preview, analysis: result.analysis }];
            datasets = visibleDatasets(datasets, [...datasets.filter((item) => item.source === 'upload'), ...sheets.map((sheet) => sheet.dataset)]);
            for (const sheet of sheets) cacheUploadPreview(sheet);
            uploadFeedback.append(node('p', t('Saved {count} tables from {name}.', { count: sheets.length, name: file.name }), 'field-help'));
            for (const skipped of result.skippedSheets ?? []) uploadFeedback.append(node('p', t(skipped.reason === 'NO_COLUMNS' ? 'Skipped {name}: no column headers.' : 'Could not save {name}. Other saved tables remain available below.', { name: `${file.name} · ${skipped.sheetName}` }), 'notice'));
            state.selectedId = sheets[0]?.dataset.id; state.tab = 'preview'; search.value = ''; source.value = 'upload'; filter();
          }
        } catch (error) {
          if (active()) uploadFeedback.append(node('p', t(error instanceof Error && !(error instanceof TypeError) && error.name !== 'TimeoutError' ? error.message : 'The file could not be uploaded. Try again.'), 'notice'));
        } finally { upload.disabled = false; refresh.disabled = false; upload.textContent = t('Upload files'); }
      })();
    });
    search.addEventListener('input', filter); source.addEventListener('change', filter); filter();
  } catch (error) {
    if (!active()) return;
    status.remove(); const notice = node('div', undefined, 'notice'); notice.setAttribute('role', 'alert');
    notice.append(node('h2', t('Datasets could not be loaded.')), node('p', error instanceof Error ? error.message : t('Please try again.')), action(t('Try again'), () => { void showDataScreen(view, { profile, moveFocus: true }); })); screen.append(notice);
  }
}
