/** Decorations preserve the native control, accessible name and click handler. */
export function magneticButton<T extends HTMLElement>(button: T): T {
  if (button.querySelector(':scope > .magnetic-face')) return button;
  const face = document.createElement('span'); face.className = 'magnetic-face';
  while (button.firstChild) face.append(button.firstChild);
  button.append(face); button.dataset.magnetic = ''; return button;
}

export function expandingTool<T extends HTMLElement>(button: T, symbol: string): T {
  const text = button.textContent ?? '';
  button.setAttribute('aria-label', text); button.title = text; button.dataset.expandTool = '';
  const icon = document.createElement('span'); icon.className = 'tool-icon'; icon.textContent = symbol; icon.setAttribute('aria-hidden', 'true');
  const label = document.createElement('span'); label.className = 'tool-label'; label.textContent = text;
  button.replaceChildren(icon, label); return button;
}
