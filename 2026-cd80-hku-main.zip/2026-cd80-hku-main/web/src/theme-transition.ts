import { reducedMotion } from './motion-runtime.ts';
import type { Theme } from './i18n.ts';

/** A viewport-sized circle, measured once before any snapshot or style writes. */
export function themeCircle(rect: Pick<DOMRect, 'left' | 'top' | 'width' | 'height'>, width: number, height: number) {
  const x = Math.max(0, Math.min(width, rect.left + rect.width / 2));
  const y = Math.max(0, Math.min(height, rect.top + rect.height / 2));
  const radius = Math.ceil(Math.hypot(Math.max(x, width - x), Math.max(y, height - y)));
  return { x, y, radius };
}

function nextPaint(): Promise<void> {
  return new Promise((resolve) => {
    // Background tabs may suspend animation frames. Never hold the preference lock indefinitely.
    let frame = 0;
    const timeout = window.setTimeout(() => { window.cancelAnimationFrame(frame); resolve(); }, 80);
    frame = window.requestAnimationFrame(() => { window.clearTimeout(timeout); resolve(); });
  });
}

type TransitionRun = { view?: ViewTransition; animation?: Animation; commit: () => void };

/** One transition at a time; external storage changes can invalidate an uncommitted snapshot. */
export function createThemeTransition() {
  let active: TransitionRun | undefined;
  const cancel = () => {
    const previous = active;
    active = undefined;
    previous?.view?.skipTransition();
    previous?.animation?.cancel();
    const clean = () => { if (!active && typeof document !== 'undefined') delete document.documentElement.dataset.themeTransition; };
    if (previous?.view) void previous.view.finished.then(clean, clean); else clean();
  };
  return {
    get running(): boolean { return !!active; },
    cancel,
    finish() { active?.commit(); cancel(); },
    async run(trigger: HTMLElement, next: Theme, update: () => void): Promise<void> {
      if (active) return;
      let committed = false;
      const run: TransitionRun = { commit: () => {
        if (active !== run || committed) return;
        committed = true;
        update();
      } };
      active = run;
      const root = document.documentElement;
      try {
        if (reducedMotion() || typeof document.startViewTransition !== 'function'
          || typeof root.animate !== 'function' || typeof window.requestAnimationFrame !== 'function'
          || document.visibilityState === 'hidden') {
          run.commit();
          return;
        }
        const { x, y, radius } = themeCircle(trigger.getBoundingClientRect(), window.innerWidth, window.innerHeight);
        const collapsed = `circle(0px at ${x}px ${y}px)`;
        const expanded = `circle(${radius}px at ${x}px ${y}px)`;
        const expanding = next === 'dark';
        root.dataset.themeTransition = expanding ? 'expand' : 'contract';
        run.view = document.startViewTransition(async () => {
          run.commit();
          // Theme observers redraw existing ECharts canvases before the new snapshot is captured.
          await nextPaint();
          await nextPaint();
        });
        // These promises can reject independently when the document is hidden or the transition is skipped.
        void run.view.finished.catch(() => {});
        void run.view.updateCallbackDone.catch(() => {});
        await run.view.ready;
        if (active !== run) return;
        run.animation = root.animate({ clipPath: expanding ? [collapsed, expanded] : [expanded, collapsed] }, {
          duration: 520,
          easing: 'cubic-bezier(.22, 1, .36, 1)',
          fill: 'both',
          pseudoElement: expanding ? '::view-transition-new(root)' : '::view-transition-old(root)',
        });
        await run.animation.finished;
        await run.view.finished;
      } catch {
        // Theme changes remain usable if the browser cannot capture or animate a snapshot.
        run.commit();
        run.view?.skipTransition();
      } finally {
        // Even skipped/failed snapshots must finish before removing their styling.
        await run.view?.finished.catch(() => {});
        run.animation?.cancel();
        if (active === run) {
          active = undefined;
          delete root.dataset.themeTransition;
        }
      }
    },
  };
}
