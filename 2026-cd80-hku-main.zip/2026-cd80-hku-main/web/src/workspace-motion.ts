import { mountPointerMotion, mountDragRails } from './pointer-motion.ts';
import { canAnimate, loadGsap, loadSplitText, reducedMotion } from './motion-runtime.ts';

type Engine = NonNullable<Awaited<ReturnType<typeof loadGsap>>>;
type Effect = { destroy: () => void; refresh: () => void };
type Box = Pick<DOMRect, 'left' | 'top' | 'width' | 'height'>;
const targets = '[data-follow-nav], #landing-title, .suggestion-card';

/** Bound the visual movement without moving the button's actual click target. */
export function magneticOffset(box: Box, x: number, y: number, reach = 16, strength = 5): { x: number; y: number } | null {
  if (box.width <= 0 || box.height <= 0 || x < box.left - reach || x > box.left + box.width + reach || y < box.top - reach || y > box.top + box.height + reach) return null;
  const clamp = (value: number) => Math.max(-strength, Math.min(strength, value));
  return {
    x: clamp((x - box.left - box.width / 2) / (box.width / 2 + reach) * strength),
    y: clamp((y - box.top - box.height / 2) / (box.height / 2 + reach) * strength),
  };
}

/** Include all corners, including when the origin is near the card's edge. */
export function coveringRadius(width: number, height: number, x: number, y: number): number {
  return Math.ceil(Math.hypot(Math.max(Math.abs(x), Math.abs(width - x)), Math.max(Math.abs(y), Math.abs(height - y)))) + 1;
}

function listen(target: EventTarget, type: string, listener: EventListener, options?: AddEventListenerOptions): () => void {
  target.addEventListener(type, listener, options);
  return () => target.removeEventListener(type, listener, options);
}

function inlineSnapshot(element: HTMLElement, properties: string[]): () => void {
  const saved = properties.map((property) => [property, element.style.getPropertyValue(property), element.style.getPropertyPriority(property)] as const);
  return () => { for (const [property, value, priority] of saved) { if (value) element.style.setProperty(property, value, priority); else element.style.removeProperty(property); } };
}

function navigation(container: HTMLElement, gsap: Engine): Effect {
  const selector = '.nav-item';
  const track = document.createElement('span'); track.className = 'navigation-follow'; track.setAttribute('aria-hidden', 'true');
  let hovered: HTMLElement | null = null; let focused: HTMLElement | null = null; let positioned = false; let frame = 0; let dead = false;
  const geometry = { x: 0, y: 0, width: 44, height: 44 };
  container.classList.add('navigation-ready'); container.prepend(track);
  const current = () => container.querySelector<HTMLElement>(`${selector}[aria-current="page"]`);
  const paint = () => {
    gsap.set(track, { x: geometry.x, y: geometry.y });
    // One rounded surface stays continuous at fractional zoom/device scales.
    // Its absolute positioning keeps size changes out of the links' layout.
    track.style.width = `${geometry.width}px`;
    track.style.height = `${geometry.height}px`;
  };
  const refresh = () => {
    if (dead) return;
    const item = hovered ?? focused ?? current();
    container.querySelectorAll('[data-nav-highlight]').forEach((node) => node.removeAttribute('data-nav-highlight'));
    if (!item || !item.getClientRects().length) { track.hidden = true; positioned = false; return; }
    item.dataset.navHighlight = ''; track.hidden = false;
    const box = item.getBoundingClientRect(), parent = container.getBoundingClientRect();
    const next = { x: box.left - parent.left + container.scrollLeft, y: box.top - parent.top + container.scrollTop, width: box.width, height: box.height };
    if (!positioned) { Object.assign(geometry, next); paint(); positioned = true; }
    else gsap.to(geometry, { ...next, duration: .48, ease: 'power3.out', overwrite: true, onUpdate: paint });
  };
  const schedule = () => { if (!frame && !dead) frame = requestAnimationFrame(() => { frame = 0; refresh(); }); };
  const resolve = (node: EventTarget | null) => node instanceof Element ? node.closest<HTMLElement>(selector) : null;
  const cleanups = [
    listen(container, 'pointerover', (event) => { hovered = resolve(event.target); schedule(); }),
    listen(container, 'pointerleave', () => { hovered = null; focused = null; schedule(); }),
    listen(container, 'focusin', (event) => { focused = resolve(event.target); hovered = null; schedule(); }),
    listen(container, 'focusout', () => { focused = null; schedule(); }),
  ];
  const observer = new ResizeObserver(schedule); observer.observe(container); container.querySelectorAll(selector).forEach((item) => observer.observe(item)); refresh();
  return { refresh: schedule, destroy() { dead = true; if (frame) cancelAnimationFrame(frame); observer.disconnect(); cleanups.forEach((cleanup) => cleanup()); gsap.killTweensOf(geometry); track.remove(); container.classList.remove('navigation-ready'); container.querySelectorAll('[data-nav-highlight]').forEach((node) => node.removeAttribute('data-nav-highlight')); } };
}

function titleReveal(element: HTMLElement, gsap: Engine): Effect {
  let dead = false; let split: InstanceType<NonNullable<Awaited<ReturnType<typeof loadSplitText>>>> | undefined;
  void loadSplitText().then((SplitText) => {
    if (!SplitText || dead || reducedMotion() || !element.getClientRects().length) return;
    split = SplitText.create(element, { type: 'lines,chars', tag: 'span', linesClass: 'home-title-line', charsClass: 'home-title-char', aria: 'auto', autoSplit: true,
      onSplit(self) { return gsap.fromTo(self.chars, { yPercent: 110 }, { yPercent: 0, duration: 1.1, stagger: .03, ease: 'expo.out', clearProps: 'transform' }); } });
  });
  return { refresh() {}, destroy() { dead = true; split?.revert(); } };
}

function suggestion(element: HTMLElement, gsap: Engine): Effect | null {
  const fill = element.querySelector<HTMLElement>('.suggestion-fill'); const arrow = element.querySelector<HTMLElement>('.suggestion-arrow');
  if (!fill || !arrow) return null;
  const restoreElement = inlineSnapshot(element, ['--suggestion-invert']); const restoreFill = inlineSnapshot(fill, ['clip-path']); const restoreArrow = inlineSnapshot(arrow, ['transform', 'translate', 'rotate', 'scale']);
  let timeline: ReturnType<Engine['timeline']> | null = null; let hovered = element.matches(':hover'); let focused = element.matches(':focus-within'); let geometry = '';
  let frame = 0; let dead = false; element.classList.add('suggestion-ready');
  const refresh = () => {
    if (dead || !element.getClientRects().length) return;
    const box = element.getBoundingClientRect();
    // The arrow rotates, so use its stable layout offsets instead of transformed bounds.
    const x = arrow.offsetLeft + arrow.offsetWidth / 2; const y = arrow.offsetTop + arrow.offsetHeight / 2;
    const next = [box.width, box.height, x, y].join(':'); if (next === geometry && timeline) return;
    geometry = next; timeline?.kill();
    const center = `${x}px ${y}px`; const radius = coveringRadius(element.clientWidth, element.clientHeight, x, y);
    timeline = gsap.timeline({ paused: true, defaults: { duration: .4, ease: 'power3.inOut' } })
      .fromTo(fill, { clipPath: `circle(0px at ${center})` }, { clipPath: `circle(${radius}px at ${center})` }, 0)
      .fromTo(element, { '--suggestion-invert': '0%' }, { '--suggestion-invert': '100%', duration: .24 }, .08)
      .fromTo(arrow, { rotation: 0 }, { rotation: 45, duration: .32, ease: 'power3.out' }, 0);
    timeline.progress(hovered || focused ? 1 : 0).pause();
  };
  const schedule = () => { if (!frame && !dead) frame = requestAnimationFrame(() => { frame = 0; refresh(); }); };
  const update = () => { if (hovered || focused) timeline?.play(); else timeline?.reverse(); };
  const cleanups = [
    listen(element, 'pointerenter', () => { hovered = true; update(); }),
    listen(element, 'pointerleave', () => { hovered = false; update(); }),
    listen(element, 'focusin', () => { focused = true; update(); }),
    listen(element, 'focusout', (event) => { focused = element.contains((event as FocusEvent).relatedTarget as Node | null); update(); }),
  ];
  const observer = new ResizeObserver(schedule); observer.observe(element); observer.observe(arrow); refresh();
  return { refresh: schedule, destroy() {
    dead = true; if (frame) cancelAnimationFrame(frame); timeline?.kill(); observer.disconnect(); cleanups.forEach((cleanup) => cleanup());
    gsap.set(arrow, { rotation: 0 }); restoreElement(); restoreFill(); restoreArrow(); element.classList.remove('suggestion-ready');
  } };
}

/** One desktop controller owns every effect, including panels added after navigation. */
export function mountWorkspaceMotion(root: HTMLElement): () => void {
  if (!canAnimate() || typeof ResizeObserver === 'undefined' || typeof MutationObserver === 'undefined') return () => {};
  const stopDrag = mountDragRails(root);
  const effects = new Map<HTMLElement, Effect>(); const media = window.matchMedia('(prefers-reduced-motion: reduce)');
  let stopPointer: (() => void) | undefined;
  let engine: Engine | null = null; let loading = false; let disposed = false; let suspended = document.hidden; let frame = 0;
  const enabled = () => !disposed && !suspended && !reducedMotion();
  const clear = () => { stopPointer?.(); stopPointer = undefined; if (frame) cancelAnimationFrame(frame); frame = 0; effects.forEach((effect) => effect.destroy()); effects.clear(); };
  const reconcile = () => {
    frame = 0; if (!engine || !enabled()) return;
    stopPointer ??= mountPointerMotion(root, engine);
    effects.forEach((effect, element) => { if (!root.contains(element) || !element.matches(targets) || !element.getClientRects().length) { effect.destroy(); effects.delete(element); } });
    for (const element of Array.from(root.querySelectorAll<HTMLElement>(targets))) {
      if (!element.getClientRects().length) continue;
      if (effects.has(element)) { effects.get(element)!.refresh(); continue; }
      let effect: Effect | null = null;
      if (element.matches('[data-follow-nav]')) effect = navigation(element, engine);
      else if (element.id === 'landing-title') effect = titleReveal(element, engine);
      else effect = suggestion(element, engine);
      if (effect) effects.set(element, effect);
    }
  };
  const schedule = () => { if (engine && enabled() && !frame) frame = requestAnimationFrame(reconcile); };
  const changed = () => {
    if (!enabled()) { clear(); return; }
    if (engine) { schedule(); return; }
    if (loading) return;
    loading = true;
    void loadGsap().then((value) => { engine = value; loading = false; schedule(); }).catch(() => { loading = false; });
  };
  const containsTarget = (node: Node) => node instanceof HTMLElement && (node.matches(targets) || !!node.querySelector(targets));
  const observer = new MutationObserver((records) => {
    if (records.some((record) => record.type === 'attributes'
      ? record.attributeName !== 'hidden' || containsTarget(record.target)
      : [...Array.from(record.addedNodes), ...Array.from(record.removedNodes)].some(containsTarget))) schedule();
  });
  observer.observe(root, { childList: true, subtree: true, attributes: true, attributeFilter: ['aria-current', 'aria-selected', 'hidden'] });
  const cleanups = [
    listen(media, 'change', changed),
    listen(window, 'resize', schedule, { passive: true }),
    listen(window, 'blocks:appearance', changed),
    listen(window, 'blocks:before-language', () => { effects.forEach((effect, element) => { if (element.id === 'landing-title') { effect.destroy(); effects.delete(element); } }); }),
    listen(window, 'blocks:language', schedule),
    listen(document, 'visibilitychange', () => { suspended = document.hidden; changed(); }),
    listen(window, 'pagehide', () => { suspended = true; clear(); }),
    listen(window, 'pageshow', () => { suspended = document.hidden; changed(); }),
  ];
  changed();
  void document.fonts?.ready.then(() => schedule());
  return () => { if (disposed) return; disposed = true; stopDrag(); observer.disconnect(); cleanups.forEach((cleanup) => cleanup()); clear(); };
}
