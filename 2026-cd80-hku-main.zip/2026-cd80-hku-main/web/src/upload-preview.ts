import { t, statusText } from './i18n.ts';

export type UploadMetadata = { id: string; name: string; rowCount?: number; fields: { name: string; type: string; blankCount?: number }[] };
export type UploadPreview = { columns: string[]; rows: string[][]; shortened: boolean };
const MAX_COLUMNS = 50;
const MAX_CHARS = 2000;

function count(value: unknown): number | undefined { return typeof value === 'number' && Number.isSafeInteger(value) && value >= 0 ? value : undefined; }
/** Explicit metadata whitelist: uploaded values never enter saved chat state. */
export function uploadMetadata(file: UploadMetadata): UploadMetadata {
  return { id: file.id, name: file.name, ...(count(file.rowCount) === undefined ? {} : { rowCount: file.rowCount }),
    fields: file.fields.map((field) => ({ name: field.name, type: field.type, ...(count(field.blankCount) === undefined ? {} : { blankCount: field.blankCount }) })) };
}
export function readUploadPacket(packet: { dataset: UploadMetadata; blankCounts?: unknown; preview?: unknown }): { upload: UploadMetadata; preview?: UploadPreview } {
  const upload = uploadMetadata(packet.dataset);
  const blankCounts = packet.blankCounts;
  if (Array.isArray(blankCounts)) upload.fields = upload.fields.map((field, index) => ({ ...field,
    ...(count(blankCounts[index]) === undefined ? {} : { blankCount: count(blankCounts[index]) }) }));
  const value = packet.preview as { columns?: unknown; rows?: unknown } | undefined;
  if (!value || !Array.isArray(value.columns) || !Array.isArray(value.rows)) return { upload };
  let shortened = value.columns.length > MAX_COLUMNS;
  const clip = (value: unknown): string => {
    const text = typeof value === 'string' ? value : typeof value === 'number' && Number.isFinite(value) || typeof value === 'boolean' ? String(value) : '';
    if (text.length <= MAX_CHARS) return text;
    shortened = true; return `${text.slice(0, MAX_CHARS)}…`;
  };
  const columns = value.columns.slice(0, MAX_COLUMNS).map(clip);
  const rows = value.rows.slice(0, 5).filter(Array.isArray).map((row) => columns.map((_, index) => clip(row[index])));
  return { upload, preview: { columns, rows, shortened } };
}
/** Keep recent local previews bounded; older cards retain metadata. */
export function rememberUploadPreview(previews: Map<string, UploadPreview>, id: string, preview: UploadPreview): void {
  previews.delete(id); previews.set(id, preview);
  while (previews.size > 20) { const oldest = previews.keys().next().value; if (oldest === undefined) break; previews.delete(oldest); }
}
export function chatRequestBody(message: string, files: readonly UploadMetadata[], conversationId?: string): string {
  return JSON.stringify({ message, ...(conversationId ? { conversationId } : {}), ...(files.length ? { uploads: files.map((file) => file.id) } : {}) });
}
export type SavedChatState = { conversationId?: string; messages: { role: 'user' | 'assistant'; text?: string; system?: boolean; files?: UploadMetadata[]; built?: { kind: 'built'; appId: string; name: string; description: string; updated: boolean }; draftId?: string }[]; input: string; attachments: UploadMetadata[]; pending?: boolean };
export function metadataChatState(state: SavedChatState): SavedChatState {
  return { ...(state.conversationId ? { conversationId: state.conversationId } : {}), input: state.input, pending: state.pending,
    attachments: state.attachments.map(uploadMetadata), messages: state.messages.slice(-60).map((message) => ({ role: message.role,
      ...(message.text === undefined ? {} : { text: message.text }), ...(message.system === undefined ? {} : { system: message.system }),
      ...(message.files ? { files: message.files.map(uploadMetadata) } : {}), ...(message.draftId ? { draftId: message.draftId } : {}),
      ...(message.built ? { built: { kind: 'built', appId: message.built.appId, name: message.built.name, description: message.built.description, updated: message.built.updated } } : {}) })) };
}
function node<K extends keyof HTMLElementTagNameMap>(tag: K, text?: string): HTMLElementTagNameMap[K] {
  const element = document.createElement(tag); if (text !== undefined) element.textContent = text; return element;
}
export function uploadCard(file: UploadMetadata, preview?: UploadPreview): HTMLElement {
  const card = node('details'); card.className = 'chat-file'; card.open = !!preview;
  card.append(node('summary', file.name), node('p', t('{count} rows · {columns} columns', { count: file.rowCount ?? '—', columns: file.fields.length })));
  const list = node('ul');
  for (const field of file.fields.slice(0, 200)) list.append(node('li', `${field.name} · ${statusText(field.type)}${field.blankCount === undefined ? '' : ` · ${t('{count} blanks', { count: field.blankCount })}`}`));
  card.append(list);
  if (!preview) { const help = node('p', t('This preview is no longer in memory. Attach the file again to view it.')); help.className = 'field-help'; card.append(help); return card; }
  const scroll = node('div'); scroll.className = 'chat-upload-preview'; scroll.tabIndex = 0; scroll.setAttribute('role', 'region'); scroll.setAttribute('aria-label', t('Uploaded file preview'));
  const table = node('table'); table.append(node('caption', t('First {count} rows', { count: Math.min(5, preview.rows.length) })));
  const head = node('thead'), row = node('tr');
  for (const column of preview.columns.slice(0, MAX_COLUMNS)) { const cell = node('th', column); cell.scope = 'col'; row.append(cell); }
  head.append(row); const body = node('tbody');
  for (const values of preview.rows.slice(0, 5)) { const row = node('tr'); for (let index = 0; index < Math.min(MAX_COLUMNS, preview.columns.length); index++) row.append(node('td', values[index] ?? '')); body.append(row); }
  table.append(head, body); scroll.append(table); card.append(scroll);
  const privacy = node('p', t('This preview stays in this page and is not sent to the builder.')); privacy.className = 'field-help'; card.append(privacy);
  if (preview.shortened) { const help = node('p', t('Wide tables and long values are shortened in this preview.')); help.className = 'field-help'; card.append(help); }
  return card;
}
