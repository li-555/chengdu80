import type { ConnectionSettings } from '../../src/platform/connections.ts';
import type { ListActionSnapshot } from '../../src/platform/list-actions.ts';

/** Preserve unrelated saved values when reconciling a single list mutation. */
export function settingsAfterListAction(previous: ConnectionSettings | undefined, snapshot: ListActionSnapshot, param: string): ConnectionSettings | undefined {
  const changed = snapshot.params.find((entry) => entry.key === param);
  if (!previous || !changed) return undefined;
  return { ...previous, params: { ...previous.params, [param]: [...changed.values] } };
}
function ordered(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(ordered);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, entry]) => [key, ordered(entry)]));
  return value;
}
/** Accept a new revision only when no unrelated saved settings changed. */
export function sameSettings(first: ConnectionSettings, second: ConnectionSettings): boolean {
  return JSON.stringify(ordered(first)) === JSON.stringify(ordered(second));
}
