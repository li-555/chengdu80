import { t, formatNumber, statusText } from "./i18n.js";
import { renderScreenControl } from "./screen-controls.js";
import { renderChart } from "./charts.js";
export { mountScreenCharts, disposeScreenCharts } from "./charts.js";
const tones = new Set(['default', 'positive', 'negative', 'warning', 'muted']);
function node(tag, className, text) {
    const result = document.createElement(tag);
    if (className)
        result.className = className;
    if (text !== undefined)
        result.textContent = text;
    return result;
}
function text(definition, key) {
    const value = definition[key];
    return typeof value === 'string' ? value : undefined;
}
function tone(target, value) {
    if (typeof value === 'string' && tones.has(value))
        target.dataset.tone = value;
}
function scalar(value) {
    if (value === null || value === undefined)
        return '—';
    if (typeof value === 'string' || typeof value === 'bigint')
        return String(value);
    if (typeof value === 'boolean')
        return value ? t('Yes') : t('No');
    if (typeof value === 'number')
        return Number.isFinite(value) ? String(value) : '—';
    return '—';
}
/** Percent results already use percentage points: 25 is displayed as 25%. */
export function formatScreenValue(value, format = 'text') {
    if (value === null || value === undefined)
        return '—';
    if (format === 'date') {
        const date = scalar(value);
        const match = /^(\d{4}-\d{2}-\d{2})(?:$|[T ])/.exec(date);
        return match?.[1] ?? date;
    }
    if (format === 'text')
        return scalar(value);
    const numeric = typeof value === 'number' && Number.isFinite(value) || typeof value === 'bigint'
        || typeof value === 'string' && /^-?\d+(?:\.\d+)?$/.test(value);
    if (!numeric) {
        return scalar(value);
    }
    const result = formatNumber(value, format === 'integer' ? 0 : 2);
    return format === 'percent' ? `${result}%` : result;
}
function format(value) {
    return value === 'number' || value === 'money' || value === 'percent' || value === 'date' || value === 'integer'
        ? value : 'text';
}
/** Only explicit web links can become clickable; all other values remain plain text. */
export function safeScreenLink(value) {
    if (typeof value !== 'string')
        return undefined;
    try {
        const url = new URL(value);
        if ((url.protocol === 'https:' || url.protocol === 'http:') && !url.username && !url.password)
            return url.href;
    }
    catch {
        return undefined;
    }
    return undefined;
}
function panel(definition, kind, headingLevel) {
    const result = node('section', `screen-panel screen-${kind}`);
    tone(result, definition.tone);
    const title = text(definition, 'title');
    if (title)
        result.append(heading(title, headingLevel));
    return result;
}
function heading(value, level) {
    return node(`h${Math.min(6, Math.max(2, level))}`, 'screen-heading', value);
}
function unavailable(message = t('This information is not available yet.')) {
    return node('p', 'screen-empty', message);
}
function resultFor(definition, results) {
    const name = text(definition, 'from');
    return name ? results.get(name) : undefined;
}
function hasColumns(result, names) {
    return names.every((name) => result.columns.some((column) => column.name === name));
}
function metric(definition, results) {
    const target = panel(definition, 'metric', 2);
    target.append(node('p', 'screen-metric-label', text(definition, 'label') ?? t('Value')));
    const result = resultFor(definition, results);
    const valueColumn = text(definition, 'value');
    const changeColumn = text(definition, 'change');
    if (!result || !valueColumn || !hasColumns(result, [valueColumn, ...(changeColumn ? [changeColumn] : [])])) {
        target.append(unavailable());
        return target;
    }
    if (result.rows.length > 1) {
        target.append(unavailable(t('A single value is needed here, but this result contains several rows.')));
        return target;
    }
    const row = result.rows[0];
    const value = row?.[valueColumn];
    const displayFormat = format(definition.format);
    const line = node('p', 'screen-metric-value', formatScreenValue(value, displayFormat));
    const unit = text(definition, 'unit');
    if (unit && value !== null && value !== undefined && !(displayFormat === 'percent' && unit === '%')) {
        line.append(node('span', 'screen-metric-unit', unit));
    }
    target.append(line);
    if (changeColumn && row) {
        const change = row[changeColumn];
        const changeText = formatScreenValue(change, displayFormat);
        const delta = node('p', 'screen-metric-change');
        const direction = typeof change === 'number' && Number.isFinite(change) ? Math.sign(change) : 0;
        if (direction !== 0)
            delta.dataset.direction = direction > 0 ? 'up' : 'down';
        delta.append(node('span', undefined, t('Change: {value}', { value: `${direction > 0 ? '+' : ''}${changeText}` })));
        target.append(delta);
    }
    return target;
}
function table(definition, results, headingLevel) {
    const target = panel(definition, 'table', headingLevel);
    const result = resultFor(definition, results);
    const columns = Array.isArray(definition.columns) ? definition.columns.filter((column) => column !== null && typeof column === 'object' && typeof column.col === 'string') : [];
    if (!result || columns.length === 0 || !hasColumns(result, columns.map((column) => String(column.col)))) {
        target.append(unavailable());
        return target;
    }
    if (result.rows.length === 0) {
        target.append(unavailable(text(definition, 'emptyHint') ?? t('There are no rows to show.')));
        return target;
    }
    const scroll = node('div', 'screen-table-scroll');
    scroll.tabIndex = 0;
    scroll.setAttribute('role', 'region');
    scroll.setAttribute('aria-label', text(definition, 'title') ?? t('Results table'));
    const grid = node('table', 'screen-data-table');
    const caption = node('caption', 'screen-visually-hidden', text(definition, 'title') ?? t('Results'));
    const head = node('thead');
    const header = node('tr');
    for (const [index, column] of columns.entries()) {
        const cell = node('th', undefined, text(column, 'label') ?? t('Column {number}', { number: index + 1 }));
        cell.scope = 'col';
        header.append(cell);
    }
    head.append(header);
    const body = node('tbody');
    grid.append(caption, head, body);
    scroll.append(grid);
    target.append(scroll);
    const pageSize = typeof definition.pageSize === 'number' && Number.isInteger(definition.pageSize)
        ? Math.min(200, Math.max(5, definition.pageSize)) : 25;
    const totalPages = Math.ceil(result.rows.length / pageSize);
    let currentPage = 0;
    const pager = node('div', 'screen-pagination');
    const status = node('span', 'screen-page-status');
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');
    const previous = node('button', 'button button-secondary', t('Previous'));
    const next = node('button', 'button button-secondary', t('Next'));
    previous.type = next.type = 'button';
    previous.setAttribute('aria-label', t('Previous page: {title}', { title: text(definition, 'title') ?? t('Results') }));
    next.setAttribute('aria-label', t('Next page: {title}', { title: text(definition, 'title') ?? t('Results') }));
    const draw = () => {
        const start = currentPage * pageSize;
        const rows = result.rows.slice(start, start + pageSize).map((row) => {
            const line = node('tr');
            for (const column of columns) {
                const displayFormat = format(column.format);
                const cell = node('td', displayFormat !== 'text' && displayFormat !== 'date' ? 'screen-number' : undefined, formatScreenValue(row[String(column.col)], displayFormat));
                line.append(cell);
            }
            return line;
        });
        body.replaceChildren(...rows);
        previous.disabled = currentPage === 0;
        next.disabled = currentPage === totalPages - 1;
        status.textContent = t('{start}–{end} of {total}', { start: start + 1, end: Math.min(start + pageSize, result.rows.length), total: result.rows.length });
    };
    previous.addEventListener('click', () => {
        currentPage -= 1;
        draw();
        if (previous.disabled)
            next.focus();
    });
    next.addEventListener('click', () => {
        currentPage += 1;
        draw();
        if (next.disabled)
            previous.focus();
    });
    pager.append(previous, status, next);
    if (totalPages > 1)
        target.append(pager);
    draw();
    return target;
}
function list(definition, results, headingLevel) {
    const target = panel(definition, 'list', headingLevel);
    const result = resultFor(definition, results);
    const titleColumn = text(definition, 'itemTitle');
    const bodyColumn = text(definition, 'itemBody');
    const linkColumn = text(definition, 'itemLink');
    const toneColumn = text(definition, 'itemTone');
    const groupColumn = text(definition, 'groupBy');
    const columns = [titleColumn, bodyColumn, linkColumn, toneColumn, groupColumn].filter((value) => value !== undefined);
    if (!result || !titleColumn || !hasColumns(result, columns)) {
        target.append(unavailable());
        return target;
    }
    if (result.rows.length === 0) {
        target.append(unavailable(text(definition, 'emptyHint') ?? t('There are no items to show.')));
        return target;
    }
    const groups = new Map();
    for (const row of result.rows) {
        const value = groupColumn ? row[groupColumn] : undefined;
        const key = value === null || value === undefined || value === '' ? 'Other' : scalar(value);
        const rows = groups.get(key) ?? [];
        rows.push(row);
        groups.set(key, rows);
    }
    for (const [group, rows] of groups) {
        if (groupColumn)
            target.append(heading(group, headingLevel + 1));
        const items = node('ul', 'screen-items');
        for (const row of rows) {
            const item = node('li', 'screen-list-item');
            if (toneColumn)
                tone(item, row[toneColumn]);
            const title = scalar(row[titleColumn]);
            const titleElement = heading(title, headingLevel + (groupColumn ? 2 : 1));
            const href = linkColumn ? safeScreenLink(row[linkColumn]) : undefined;
            if (href) {
                const link = node('a', undefined, title);
                link.href = href;
                link.target = '_blank';
                link.rel = 'noopener noreferrer';
                link.setAttribute('aria-label', t('{title} (opens in a new tab)', { title }));
                titleElement.replaceChildren(link);
            }
            item.append(titleElement);
            if (bodyColumn && row[bodyColumn] !== null && row[bodyColumn] !== undefined) {
                item.append(node('p', 'screen-prose', scalar(row[bodyColumn])));
            }
            items.append(item);
        }
        target.append(items);
    }
    return target;
}
/** Render a validated document using named relations returned by the run engine. */
export function renderScreen(ui, results, controls, displayLabel = (value) => value) {
    const definitions = ui.elements;
    let remaining = 120;
    function render(id, ancestors, headingLevel) {
        const definition = definitions[id];
        if (!definition || ancestors.has(id) || remaining-- <= 0)
            return unavailable(t('This part of the screen could not be displayed.'));
        const path = new Set(ancestors).add(id);
        let target;
        switch (definition.type) {
            case 'Section': {
                target = panel(definition, 'section', headingLevel);
                const grid = node('div', 'screen-section-grid');
                grid.dataset.columns = String(definition.columns === 2 || definition.columns === 3 ? definition.columns : 1);
                const children = Array.isArray(definition.children) ? definition.children : [];
                for (const child of children) {
                    if (typeof child === 'string')
                        grid.append(render(child, path, headingLevel + (definition.title ? 1 : 0)));
                }
                target.append(grid);
                break;
            }
            case 'Text':
                target = definition.emphasis === 'heading'
                    ? heading(text(definition, 'text') ?? '', headingLevel)
                    : node('p', definition.emphasis === 'caption' ? 'screen-prose screen-caption' : 'screen-prose', text(definition, 'text') ?? '');
                break;
            case 'Callout':
                target = panel(definition, 'callout', headingLevel);
                target.append(node('p', 'screen-prose', text(definition, 'text') ?? ''));
                break;
            case 'NumberInput':
            case 'SelectInput':
            case 'TextInput':
            case 'DateRangeInput':
            case 'RunButton':
                target = renderScreenControl(definition, controls);
                break;
            case 'Metric':
                target = metric(definition, results);
                break;
            case 'Table':
                target = table(definition, results, headingLevel);
                break;
            case 'List':
                target = list(definition, results, headingLevel);
                break;
            case 'Chart':
                target = renderChart(definition, resultFor(definition, results), headingLevel, displayLabel);
                break;
            default: target = unavailable(t('This part of the app is not available yet.'));
        }
        target.dataset.elementId = id;
        target.dataset.elementType = String(definition.type);
        tone(target, definition.tone);
        return target;
    }
    const root = node('div', 'screen-elements');
    root.append(render(ui.root, new Set(), 2));
    return root;
}
/** Refresh result leaves while retaining parameter inputs, focus and section layout. */
export function refreshScreenResults(root, ui, results, displayLabel = (value) => value) {
    const fresh = renderScreen(ui, results, undefined, displayLabel);
    const replacements = new Map(Array.from(fresh.querySelectorAll('[data-element-id]')).map((element) => [element.dataset.elementId, element]));
    for (const existing of Array.from(root.querySelectorAll('[data-element-id]'))) {
        if (!['Metric', 'Table', 'List', 'Chart'].includes(existing.dataset.elementType ?? ''))
            continue;
        const replacement = replacements.get(existing.dataset.elementId);
        if (replacement)
            existing.replaceWith(replacement);
    }
}
