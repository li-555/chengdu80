import { t } from "./i18n.js";
function node(tag, text, className) {
    const element = document.createElement(tag);
    if (text !== undefined)
        element.textContent = t(text);
    if (className)
        element.className = className;
    return element;
}
export function createMonitorPanel(appId, canEdit, displayLabel = (value) => value) {
    const element = node('section', undefined, 'screen-panel');
    element.dataset.monitorPanel = 'true';
    const refreshButton = node('button', 'Refresh', 'button button-secondary');
    refreshButton.type = 'button';
    const feedback = node('p', '', 'notice');
    feedback.setAttribute('role', 'status');
    feedback.hidden = true;
    const content = node('div');
    element.append(node('h2', 'Latest monitoring'), node('p', 'Reflects the latest completed monitored update, which may differ from the historical run selected above. Scheduled monitoring runs while the server is on; check here for updates.', 'field-help'), refreshButton, feedback, content);
    let snapshot, busy = false, refreshRequired = false, refreshQueued = false;
    let actions = [];
    function sync() { feedback.hidden = !feedback.textContent; refreshButton.disabled = busy; for (const button of actions)
        button.disabled = busy || refreshRequired || !canEdit(); }
    async function request(path, init) {
        const controller = new AbortController();
        const timer = window.setTimeout(() => controller.abort(), 30_000);
        try {
            const response = await fetch(`/api/apps/${encodeURIComponent(appId)}/monitor${path}`, { ...init, credentials: 'same-origin', signal: controller.signal });
            if (!response.ok)
                throw Object.assign(new Error('Monitoring request failed.'), { status: response.status });
            return await response.json();
        }
        finally {
            window.clearTimeout(timer);
        }
    }
    function render() {
        if (!snapshot)
            return;
        const value = snapshot;
        actions = [];
        content.replaceChildren();
        content.append(node('p', t(value.notice), 'notice'));
        if (!value.enabled) {
            content.append(node('p', 'No monitoring events are configured for this application.', 'field-help'));
            return;
        }
        content.append(node('p', value.lastRunId ? t('Latest data record: {id}{date}', { id: value.lastRunId, date: value.lastRunAt ? ` · ${value.lastRunAt}` : '' }) : 'No completed monitored update yet.', 'field-help'));
        if (value.lastRunId && !value.previousRunId)
            content.append(node('p', 'Baseline recorded. Changes will be compared with the next completed monitored update.', 'field-help'));
        const counts = value.counts;
        content.append(node('p', t('{active} active · {unacknowledged} unacknowledged · {acknowledged} acknowledged · {unknown} unknown', counts)));
        if (counts.unknown)
            content.append(node('p', 'Some monitoring results are unknown. Unknown results do not mean all clear.', 'notice'));
        content.append(node('h3', 'Change summary'));
        if (!value.changes.length)
            content.append(node('p', 'No recorded changes in the latest monitored update.', 'field-help'));
        for (const change of value.changes.slice(0, 50)) {
            const item = node('details');
            item.append(node('summary', `${displayLabel(change.title)} · ${t(change.kind)}`), node('p', displayLabel(change.detail)), node('p', t('Before: {before} → After: {after}', { before: change.before ?? t('Unavailable'), after: change.after ?? t('Unavailable') }), 'field-help'));
            content.append(item);
        }
        if (value.changes.length > 50)
            content.append(node('p', t('Showing 50 of {count} changes.', { count: value.changes.length }), 'field-help'));
        content.append(node('h3', 'Alerts'));
        if (!value.alerts.length)
            content.append(node('p', 'No recorded alerts.', 'field-help'));
        for (const alert of value.alerts.slice(0, 50)) {
            const card = node('article', undefined, 'screen-panel');
            card.append(node('h4', `${displayLabel(alert.title)} · ${t(alert.status)}`), node('p', displayLabel(alert.detail)), node('p', t('Value: {value}', { value: alert.value })), node('p', t('First seen: {first} · Last seen: {last} · Data record: {id}', { first: alert.firstSeenAt, last: alert.lastSeenAt, id: alert.runId }), 'field-help'));
            if (alert.acknowledgedAt)
                card.append(node('p', t('Acknowledged: {date}', { date: alert.acknowledgedAt }), 'field-help'));
            if (alert.sourceUrl) {
                try {
                    const url = new URL(alert.sourceUrl);
                    if (url.protocol === 'https:' && !url.username && !url.password) {
                        const link = node('a', 'Source');
                        link.href = url.href;
                        link.target = '_blank';
                        link.rel = 'noopener noreferrer';
                        card.append(link);
                    }
                }
                catch { /* Invalid sources have no link. */ }
            }
            if (alert.status !== 'cleared') {
                const button = node('button', alert.acknowledgedAt ? 'Reopen' : 'Acknowledge', 'button button-secondary');
                button.type = 'button';
                button.addEventListener('click', () => { void acknowledge(alert.id, !alert.acknowledgedAt); });
                actions.push(button);
                card.append(button);
            }
            content.append(card);
        }
        if (value.alerts.length > 50)
            content.append(node('p', t('Showing 50 of {count} alerts. Counts include all alerts.', { count: value.alerts.length }), 'field-help'));
        sync();
    }
    async function finishRequest() {
        busy = false;
        sync();
        const queued = refreshQueued;
        refreshQueued = false;
        if (queued && element.isConnected)
            await refresh();
    }
    async function refresh() {
        if (!element.isConnected)
            return;
        if (busy) {
            refreshQueued = true;
            return;
        }
        busy = true;
        sync();
        try {
            const value = await request('');
            if (!element.isConnected)
                return;
            snapshot = value;
            refreshRequired = false;
            feedback.textContent = '';
            render();
        }
        catch {
            refreshRequired = true;
            if (element.isConnected)
                feedback.textContent = t('Monitoring could not be loaded. Refresh to try again.');
        }
        finally {
            await finishRequest();
        }
    }
    async function acknowledge(alertId, acknowledged) {
        if (busy || refreshRequired || !canEdit() || !element.isConnected)
            return;
        busy = true;
        sync();
        try {
            await request('/ack', { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Blocks-Request': '1' }, body: JSON.stringify({ alertId, acknowledged }) });
            if (!element.isConnected)
                return;
            // Read authoritative state after saving; never infer an acknowledgment timestamp locally.
            snapshot = await request('');
            if (!element.isConnected)
                return;
            feedback.textContent = t(acknowledged ? 'Acknowledgment saved.' : 'Alert reopened.');
            render();
        }
        catch (error) {
            if (!element.isConnected)
                return;
            refreshRequired = true;
            feedback.textContent = error && typeof error === 'object' && 'status' in error && error.status === 409
                ? t('This alert changed. Refresh before acknowledging its latest revision.')
                : t('Acknowledgment is unconfirmed. Refresh to check the saved state.');
        }
        finally {
            await finishRequest();
        }
    }
    refreshButton.addEventListener('click', () => { void refresh(); });
    return { element, refresh, sync };
}
