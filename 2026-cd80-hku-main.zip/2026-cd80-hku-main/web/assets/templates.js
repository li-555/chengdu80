import { t } from "./i18n.js";
function element(tag, text, className) {
    const node = document.createElement(tag);
    if (text !== undefined)
        node.textContent = text;
    if (className)
        node.className = className;
    return node;
}
export async function showTemplates(view, navigate) {
    view.replaceChildren(element('h1', t('Flagship applications')), element('p', t('Use Tushare and your own authorised data. Missing inputs are never replaced with invented values.'), 'library-caption'));
    const feedback = element('p', '', 'notice');
    feedback.setAttribute('role', 'status');
    feedback.hidden = true;
    view.append(feedback);
    try {
        const established = await fetch('/api/apps', { credentials: 'same-origin' });
        if (!established.ok)
            throw new Error(t('Your library could not be opened.'));
        const response = await fetch('/api/examples');
        if (!response.ok)
            throw new Error(t('Templates could not be loaded.'));
        const { templates } = await response.json();
        if (!view.isConnected || !/^\/examples\/?$/.test(location.pathname))
            return;
        const grid = element('div', undefined, 'app-grid');
        for (const template of templates) {
            const card = element('article', undefined, 'screen-panel template-card');
            card.append(element('p', t(template.category), 'eyebrow'), element('h2', template.name), element('p', t(template.description)));
            const modes = ['connect'];
            const controls = modes.map((mode) => {
                const button = element('button', t('Connect my data'), 'button button-primary');
                button.type = 'button';
                button.addEventListener('click', async () => {
                    for (const item of Array.from(grid.querySelectorAll('button')))
                        item.disabled = true;
                    feedback.hidden = false;
                    feedback.textContent = t('Adding the application to your library…');
                    try {
                        const reply = await fetch(`/api/examples/${encodeURIComponent(template.id)}/import`, { method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/json', 'X-Blocks-Request': '1' }, body: JSON.stringify({ mode }) });
                        const result = await reply.json();
                        if (!reply.ok)
                            throw new Error(result.error?.message ?? t('The application could not be added.'));
                        if (view.isConnected && /^\/examples\/?$/.test(location.pathname))
                            navigate(`/apps/${encodeURIComponent(result.appId)}`);
                    }
                    catch (error) {
                        feedback.textContent = error instanceof Error ? t(error.message) : t('The application could not be added.');
                    }
                    finally {
                        for (const item of Array.from(grid.querySelectorAll('button')))
                            item.disabled = false;
                    }
                });
                return button;
            });
            const actions = element('div', undefined, 'heading-actions');
            actions.append(...controls);
            card.append(actions, element('p', t('Tushare requires a server token and API permissions. Upload your own private records before running.'), 'field-help'));
            grid.append(card);
        }
        view.append(grid);
    }
    catch (error) {
        feedback.hidden = false;
        feedback.textContent = error instanceof Error ? t(error.message) : t('Templates could not be loaded.');
    }
}
