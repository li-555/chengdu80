import { applyPreferences, getLanguage, getTheme, setLanguage, setTheme, syncThemePreference, t } from "./i18n.js";
import { magneticButton } from "./motion-elements.js";
import { createThemeTransition } from "./theme-transition.js";
const mounted = new WeakMap();
let iconSequence = 0;
function themeIcon() {
    const ns = 'http://www.w3.org/2000/svg';
    const svg = document.createElementNS(ns, 'svg');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('aria-hidden', 'true');
    svg.setAttribute('class', 'theme-icon');
    const maskId = `theme-moon-${++iconSequence}`;
    const defs = document.createElementNS(ns, 'defs');
    const mask = document.createElementNS(ns, 'mask');
    mask.id = maskId;
    mask.setAttribute('maskUnits', 'userSpaceOnUse');
    mask.setAttribute('x', '0');
    mask.setAttribute('y', '0');
    mask.setAttribute('width', '24');
    mask.setAttribute('height', '24');
    const white = document.createElementNS(ns, 'rect');
    white.setAttribute('width', '24');
    white.setAttribute('height', '24');
    white.setAttribute('fill', 'white');
    const cutout = document.createElementNS(ns, 'circle');
    cutout.setAttribute('cx', '12');
    cutout.setAttribute('cy', '12');
    cutout.setAttribute('r', '4');
    cutout.setAttribute('fill', 'black');
    cutout.setAttribute('class', 'theme-icon-cutout');
    mask.append(white, cutout);
    defs.append(mask);
    const core = document.createElementNS(ns, 'circle');
    core.setAttribute('cx', '12');
    core.setAttribute('cy', '12');
    core.setAttribute('r', '4');
    core.setAttribute('fill', 'currentColor');
    core.setAttribute('mask', `url(#${maskId})`);
    core.setAttribute('class', 'theme-icon-core');
    const rays = document.createElementNS(ns, 'path');
    rays.setAttribute('d', 'M12 2v2 M12 20v2 M2 12h2 M20 12h2 M4.9 4.9l1.4 1.4 M17.7 17.7l1.4 1.4 M4.9 19.1l1.4-1.4 M17.7 6.3l1.4-1.4');
    rays.setAttribute('fill', 'none');
    rays.setAttribute('stroke', 'currentColor');
    rays.setAttribute('stroke-width', '1.6');
    rays.setAttribute('stroke-linecap', 'round');
    rays.setAttribute('class', 'theme-icon-rays');
    svg.append(defs, core, rays);
    return svg;
}
/** Shared controls on the library, chat, catalogue and example pages. */
export function mountPreferences() {
    applyPreferences();
    const host = document.querySelector('[data-preferences]');
    if (!host)
        return;
    mounted.get(host)?.();
    const transition = createThemeTransition();
    const themeGroup = document.createElement('div');
    themeGroup.className = 'theme-preference';
    const themeCaption = document.createElement('span');
    const theme = document.createElement('button');
    theme.type = 'button';
    theme.id = 'theme-picker';
    theme.className = 'theme-toggle';
    const themeValue = document.createElement('span');
    theme.append(themeIcon(), themeValue);
    magneticButton(theme);
    themeGroup.append(themeCaption, theme);
    const label = document.createElement('label');
    const languageCaption = document.createElement('span');
    const language = document.createElement('select');
    language.id = 'language-picker';
    for (const [value, text] of [['en', 'English'], ['zh', '中文']]) {
        const option = document.createElement('option');
        option.value = value;
        option.textContent = text;
        language.append(option);
    }
    label.append(languageCaption, language);
    host.replaceChildren(themeGroup, label);
    const draw = () => {
        themeCaption.textContent = t('Theme');
        languageCaption.textContent = t('Language');
        themeValue.textContent = t(getTheme() === 'dark' ? 'Dark' : 'Light');
        const action = t(getTheme() === 'dark' ? 'Switch to light theme' : 'Switch to dark theme');
        theme.setAttribute('aria-label', action);
        theme.title = action;
        theme.setAttribute('aria-disabled', String(transition.running));
        language.value = getLanguage();
    };
    const toggle = async (trigger) => {
        if (transition.running)
            return;
        const next = getTheme() === 'dark' ? 'light' : 'dark';
        const pending = transition.run(trigger, next, () => { setTheme(next); draw(); });
        draw();
        await pending;
        draw();
    };
    theme.addEventListener('click', () => { void toggle(theme); });
    const toggleFromDialog = (event) => { void toggle(event.detail); };
    window.addEventListener('blocks:toggle-theme', toggleFromDialog);
    language.addEventListener('change', () => {
        if (language.value === 'en' || language.value === 'zh')
            setLanguage(language.value);
    });
    const storage = (event) => {
        if (event.storageArea !== window.localStorage)
            return;
        if (event.key === 'blocks:theme' || event.key === null) {
            transition.cancel();
            syncThemePreference(event.key === null ? null : event.newValue);
            draw();
        }
        if (event.key === 'blocks:language' && (event.newValue === 'en' || event.newValue === 'zh') && event.newValue !== getLanguage())
            setLanguage(event.newValue);
    };
    const finish = () => { transition.finish(); draw(); };
    const preference = window.matchMedia?.('(prefers-reduced-motion: reduce)');
    const reduce = () => { if (preference?.matches)
        finish(); };
    draw();
    window.addEventListener('blocks:language', draw);
    window.addEventListener('storage', storage);
    window.addEventListener('pagehide', finish);
    const appearance = () => { if (document.documentElement.dataset.motion === 'off')
        finish(); };
    window.addEventListener('blocks:appearance', appearance);
    preference?.addEventListener?.('change', reduce);
    mounted.set(host, () => {
        transition.cancel();
        window.removeEventListener('blocks:toggle-theme', toggleFromDialog);
        window.removeEventListener('blocks:language', draw);
        window.removeEventListener('storage', storage);
        window.removeEventListener('pagehide', finish);
        window.removeEventListener('blocks:appearance', appearance);
        preference?.removeEventListener?.('change', reduce);
    });
}
