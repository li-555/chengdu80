import { isFlagshipDocument, localizeFlagshipDocument, localizeFlagshipDescription, localizeFlagshipResults, flagshipFieldLabel, flagshipText, flagshipValue } from "./flagship-i18n.js";
import { createMonitorPanel } from "./monitor-panel.js";
import { showExampleScreen } from "./screen-example.js";
import { t, locale, statusText } from "./i18n.js";
import { createTabs, filterApps } from "./workspace-ui.js";
import { mountAppearance } from "./appearance.js";
import { mountPreferences } from "./preferences.js";
import { mountWorkspaceMotion } from "./workspace-motion.js";
import { expandingTool, magneticButton } from "./motion-elements.js";
import { showTemplates } from "./templates.js";
import { createListActionPanel } from "./list-actions.js";
import { createRecordTools } from "./record-tools.js";
import { sameSettings, settingsAfterListAction } from "./record-state.js";
import { showChatScreen } from "./chat-screen.js";
import { ScreenControls } from "./screen-controls.js";
import { createComparePanel } from "./compare.js";
import { showDataScreen } from "./data-screen.js";
import { renderScreen, refreshScreenResults, mountScreenCharts, disposeScreenCharts } from "./screen-elements.js";
const MAX_DOCUMENT_BYTES = 1024 * 1024;
const view = requiredElement('view');
const announcements = requiredElement('announcements');
const dialog = requiredElement('import-dialog');
const form = requiredElement('import-form');
const fileInput = requiredElement('app-file');
const contentInput = requiredElement('app-content');
const importFeedback = requiredElement('import-feedback');
const submitImport = requiredElement('submit-import');
const closeImport = requiredElement('close-import');
const cancelImport = requiredElement('cancel-import');
let renderSequence = 0;
let disposeExample;
let runScreen;
let selectedRunId;
let importing = false;
let activeAppRuns = 0;
let refreshLanguageAfterRun = false;
let returnAppId;
let importOpener = null;
const libraryState = { query: '', sort: 'updated', layout: 'grid' };
try {
    const saved = JSON.parse(sessionStorage.getItem('blocks:library-view') ?? '{}');
    if (typeof saved.query === 'string')
        libraryState.query = saved.query;
    if (['updated', 'created', 'name'].includes(saved.sort))
        libraryState.sort = saved.sort;
    if (saved.layout === 'list')
        libraryState.layout = 'list';
}
catch { /* The library remains usable without browser storage. */ }
function saveLibraryView() { try {
    sessionStorage.setItem('blocks:library-view', JSON.stringify(libraryState));
}
catch { /* In-memory fallback. */ } }
class LibraryRequestError extends Error {
    issues;
    code;
    constructor(message, code = 'REQUEST_FAILED', issues = []) {
        super(message);
        this.name = 'LibraryRequestError';
        this.issues = issues;
        this.code = code;
    }
}
function requiredElement(id) {
    const found = document.getElementById(id);
    if (!found)
        throw new Error(t('The page could not be opened. Please refresh and try again.'));
    return found;
}
function element(tag, className, text) {
    const result = document.createElement(tag);
    if (className)
        result.className = className;
    if (text !== undefined)
        result.textContent = text;
    return result;
}
function button(text, action, className = 'button button-primary') {
    const result = element('button', className, text);
    result.type = 'button';
    result.addEventListener('click', action);
    return result;
}
function appIcon(name) {
    const icon = element('span', 'app-icon', Array.from(name.trim())[0]?.toLocaleUpperCase() ?? 'B');
    icon.setAttribute('aria-hidden', 'true');
    return icon;
}
function dateLabel(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime()))
        return t('Date unavailable');
    return new Intl.DateTimeFormat(locale(), { month: 'short', day: 'numeric', year: 'numeric' }).format(date);
}
function routeLink(text, path, className, appId) {
    const link = element('a', className, text);
    link.href = path;
    link.addEventListener('click', (event) => {
        if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey)
            return;
        event.preventDefault();
        if (appId)
            returnAppId = appId;
        navigate(path);
    });
    return link;
}
function navigate(path) {
    if (window.location.pathname !== path)
        window.history.pushState(null, '', path);
    announcements.replaceChildren();
    void render(true);
    requiredElement('main').scrollTop = 0;
}
async function request(path, options = {}, timeoutMs = 30_000) {
    const controller = new AbortController();
    const timeout = window.setTimeout(() => controller.abort(), timeoutMs);
    let response;
    let body;
    try {
        response = await fetch(path, { ...options, credentials: 'same-origin', signal: controller.signal });
        body = await response.json();
    }
    catch {
        throw new LibraryRequestError(options.method === 'POST'
            ? path.endsWith('/run') ? t('The run could not be confirmed. Retry the same request or check run history.')
                : path.endsWith('/connection') ? t('Saving could not be confirmed. Your draft is retained. Review latest saved settings before saving again.')
                    : path.endsWith('/schedules') ? t('The task update could not be confirmed. Refresh tasks before trying again.')
                        : t('The import could not be confirmed. Close this window and refresh your library before trying again.')
            : t('We could not connect to your library. Please try again.'));
    }
    finally {
        window.clearTimeout(timeout);
    }
    if (!response.ok) {
        const error = body?.error;
        throw new LibraryRequestError(typeof error?.message === 'string' ? t(error.message) : t('Your request could not be completed. Please try again.'), typeof error?.code === 'string' ? error.code : 'REQUEST_FAILED', Array.isArray(error?.issues) ? error.issues : []);
    }
    return body;
}
function issueDetails(issues, label) {
    const details = element('details', 'issues');
    details.append(element('summary', undefined, label));
    const list = element('ul');
    for (const issue of issues) {
        const item = element('li');
        item.append(element('span', undefined, t(issue.message)));
        if (issue.hint)
            item.append(element('p', 'field-help', t(issue.hint)));
        if (issue.pointer)
            item.append(element('span', 'issue-location', issue.pointer));
        list.append(item);
    }
    details.append(list);
    return details;
}
function showFailure(container, error) {
    const notice = element('div', 'notice');
    notice.tabIndex = -1;
    notice.setAttribute('role', 'alert');
    notice.append(element('p', 'notice-title', error instanceof Error ? t(error.message) : t('Something went wrong. Please try again.')));
    if (error instanceof LibraryRequestError && error.issues.length > 0) {
        notice.append(issueDetails(error.issues, t('See what needs to be changed')));
    }
    container.replaceChildren(notice);
    notice.focus();
}
function listHeading() {
    const header = element('header', 'page-heading');
    const text = element('div');
    text.append(element('p', 'eyebrow', t('YOUR LIBRARY')), element('h1', undefined, t('My Apps')), element('p', undefined, t('A home for the apps you make your own.')));
    const actions = element('div', 'heading-actions');
    actions.append(magneticButton(routeLink(t('Create app'), '/chat', 'button button-primary')), magneticButton(button(t('＋ Import app'), openImport, 'button button-secondary')));
    header.append(text, actions);
    return header;
}
function focusPage(preferredId) {
    const card = preferredId ? Array.from(view.querySelectorAll('.app-card')).find((item) => item.dataset.appId === preferredId) : undefined;
    const heading = view.querySelector('h1');
    if (card)
        card.focus();
    else if (heading) {
        heading.tabIndex = -1;
        heading.focus();
    }
}
function showLibrary(apps, drafts) {
    apps = apps.map((app) => ({ ...app, description: localizeFlagshipDescription(app.name, app.description) }));
    view.replaceChildren(listHeading());
    if (apps.length === 0 && drafts.length === 0) {
        const empty = element('section', 'empty-state');
        const illustration = element('div', 'empty-art');
        illustration.setAttribute('aria-hidden', 'true');
        illustration.append(element('span'), element('span', undefined, '+'));
        empty.append(illustration, element('h2', undefined, t('Your next useful app starts here')), element('p', undefined, t('Have an app someone shared with you? Import it and keep it in your library.')), routeLink(t('Create app'), '/chat', 'button button-primary'), button(t('Import your first app'), openImport, 'button button-secondary'));
        view.append(empty);
        return;
    }
    const tools = element('div', 'library-tools');
    const searchLabel = element('label', 'run-setting', t('Find an app'));
    const search = element('input');
    search.type = 'search';
    search.placeholder = t('Search apps');
    search.value = libraryState.query;
    searchLabel.append(search);
    const sortLabel = element('label', 'run-setting', t('Sort by'));
    const sort = element('select');
    for (const [value, label] of [['updated', 'Recently updated'], ['created', 'Recently added'], ['name', 'Name']]) {
        const option = element('option', undefined, t(label));
        option.value = value;
        sort.append(option);
    }
    sort.value = libraryState.sort;
    sortLabel.append(sort);
    const layout = element('div', 'segmented-control');
    layout.setAttribute('role', 'group');
    layout.setAttribute('aria-label', t('Library view'));
    const gridButton = button(t('Grid'), () => { libraryState.layout = 'grid'; refresh(); }, 'button button-secondary');
    const listButton = button(t('List'), () => { libraryState.layout = 'list'; refresh(); }, 'button button-secondary');
    layout.append(gridButton, listButton);
    tools.append(searchLabel, sortLabel, layout);
    const count = element('p', 'library-caption');
    count.setAttribute('role', 'status');
    const grid = element('ul', 'app-grid');
    const noMatches = element('div', 'empty-state');
    noMatches.append(element('h2', undefined, t('No apps match your search.')), button(t('Clear search'), () => { search.value = ''; libraryState.query = ''; refresh(); search.focus(); }, 'button button-secondary'));
    function refresh() {
        saveLibraryView();
        grid.dataset.layout = libraryState.layout;
        gridButton.setAttribute('aria-pressed', String(libraryState.layout === 'grid'));
        listButton.setAttribute('aria-pressed', String(libraryState.layout === 'list'));
        const shown = filterApps(apps, libraryState.query, libraryState.sort, locale());
        count.textContent = t('{count} of {total} apps', { count: shown.length, total: apps.length });
        grid.replaceChildren();
        noMatches.hidden = shown.length !== 0;
        grid.hidden = shown.length === 0;
        for (const app of shown) {
            const item = element('li');
            const card = routeLink('', `/apps/${encodeURIComponent(app.id)}`, 'app-card', app.id);
            card.dataset.cardSpotlight = '';
            card.dataset.appId = app.id;
            card.setAttribute('aria-label', t('Open {name}', { name: app.name }));
            const copy = element('div', 'app-card-copy');
            copy.append(element('h2', undefined, app.name), element('p', undefined, app.description));
            const footer = element('div', 'app-card-footer');
            const arrow = element('span', 'open-arrow', '↗');
            arrow.setAttribute('aria-hidden', 'true');
            footer.append(element('span', undefined, t('Updated {date}', { date: dateLabel(app.updatedAt) })), arrow);
            const visual = element('div', 'card-visual');
            visual.dataset.cursorImage = '';
            visual.setAttribute('aria-hidden', 'true');
            visual.append(appIcon(app.name));
            card.append(visual, copy, footer);
            item.append(card);
            grid.append(item);
        }
    }
    search.addEventListener('input', () => { libraryState.query = search.value; refresh(); });
    sort.addEventListener('change', () => { libraryState.sort = sort.value; refresh(); });
    view.append(tools, count, grid, noMatches);
    refresh();
    if (drafts.length > 0) {
        view.append(element('h2', 'draft-heading', t('Drafts')), element('p', 'muted', t('Drafts need review before they can become runnable apps.')));
        const draftGrid = element('ul', 'app-grid');
        for (const draft of drafts) {
            const item = element('li');
            const card = element('article', 'app-card');
            const feedback = element('div');
            card.append(element('span', 'saved-badge', t('Needs attention')), element('h2', undefined, draft.name), element('p', undefined, draft.reason), element('p', 'library-caption', t('Saved {date}', { date: dateLabel(draft.createdAt) })));
            const actions = element('div', 'app-card-footer');
            const download = button(t('Download details'), () => {
                download.disabled = true;
                void (async () => {
                    try {
                        const { draft: details } = await request(`/api/drafts/${encodeURIComponent(draft.id)}`);
                        const url = URL.createObjectURL(new Blob([JSON.stringify({ doc: details.doc, errors: details.errors }, null, 2)], { type: 'application/json' }));
                        const link = element('a');
                        link.href = url;
                        link.download = `draft-${draft.id}.json`;
                        link.click();
                        window.setTimeout(() => URL.revokeObjectURL(url), 1000);
                    }
                    catch (error) {
                        showFailure(feedback, error);
                    }
                    finally {
                        download.disabled = false;
                    }
                })();
            }, 'button button-secondary');
            const remove = button(t('Delete'), () => {
                remove.disabled = true;
                void (async () => {
                    try {
                        await request(`/api/drafts/${encodeURIComponent(draft.id)}`, { method: 'DELETE', headers: { 'X-Blocks-Request': '1' } });
                        await render(false);
                    }
                    catch (error) {
                        showFailure(feedback, error);
                        remove.disabled = false;
                    }
                })();
            }, 'button button-secondary');
            actions.append(download, remove);
            card.append(actions, feedback);
            item.append(card);
            draftGrid.append(item);
        }
        view.append(draftGrid);
    }
}
function showApp(app) {
    const legacyDemo = ['AlphaVista', 'RiskRift', 'WealthWeave'].includes(app.doc.meta.name)
        && app.doc.meta.description.startsWith('Demo inputs — invented.');
    app = { ...app, doc: localizeFlagshipDocument(app.doc) };
    const back = routeLink(t('← Back to My Apps'), '/apps', 'text-button detail-back');
    const header = element('header', 'detail-header');
    const copy = element('div', 'detail-title');
    copy.append(element('p', 'eyebrow', t('Saved to your library')), element('h1', undefined, app.doc.meta.name), element('p', 'muted', app.doc.meta.description));
    const exportLink = element('a', 'button button-secondary', t('Export app'));
    exportLink.href = `/api/apps/${encodeURIComponent(app.id)}/export`;
    const tools = element('div', 'heading-actions');
    const inspect = button(t('Inspect · Where the data came from'), () => {
        const tab = document.getElementById('app-workspace-tab-inspect');
        tab?.click();
        tab?.focus();
    }, 'button button-secondary');
    tools.append(expandingTool(exportLink, '↥'), expandingTool(inspect, '⌕'));
    header.append(copy, tools);
    view.replaceChildren(back, header);
    if (legacyDemo) {
        tools.replaceChildren();
        view.append(element('p', 'notice', t('This saved flagship uses retired invented inputs. Open Flagship applications and connect Tushare and your own data in a new copy.')), routeLink(t('Flagship applications'), '/examples', 'button button-primary'));
        return;
    }
    showRunWorkspace(app);
}
function inspectRun(run, displayField = (value) => value) {
    const inspect = element('details', 'screen-panel run-inspect');
    inspect.append(element('summary', undefined, t('Inspect · Where the data came from')));
    inspect.append(element('p', 'field-help', t('Run {id} · {date} · {status}', { id: run.id, date: run.startedAt, status: statusText(run.status) })));
    inspect.append(element('h3', undefined, t('Settings used')), element('pre', undefined, JSON.stringify(run.params, null, 2)));
    if (!run.sources?.length)
        inspect.append(element('p', undefined, t('No source records were saved for this run.')));
    for (const source of run.sources ?? []) {
        const section = element('section');
        section.append(element('h3', undefined, displayField(source.key)));
        const details = element('dl');
        const values = [
            [t('Dataset'), source.datasetId], [t('Source'), source.datasetSource],
            [t('Field mapping'), source.fields.map((field) => `${displayField(field.app)} ← ${field.dataset}`).join(', ')],
            [t('Requested dates'), `${source.dateFrom ?? t('Not specified')} → ${source.dateTo ?? t('Not specified')}`],
            [t('Data as of'), source.asOfDate ?? t('Not supplied')], [t('Rows after filtering'), String(source.rows)],
            [t('Dataset version'), source.datasetVersion], [t('Fetch duration'), `${source.durationMs} ms`],
            [t('Filters sent to provider'), JSON.stringify(source.filtersSentToProvider)],
            [t('Local filters'), source.filtersAppliedAfter.join('; ') || t('None')],
        ];
        for (const [label, value] of values)
            details.append(element('dt', undefined, label), element('dd', undefined, value));
        section.append(details);
        for (const warning of source.warnings)
            section.append(element('p', 'notice', warning));
        inspect.append(section);
    }
    return inspect;
}
function schedulePanel(app) {
    const section = element('section', 'screen-panel run-schedules');
    const content = element('div');
    const feedback = element('div');
    feedback.setAttribute('role', 'status');
    let busy = false;
    const refresh = button(t('Refresh tasks'), () => { void load(); }, 'button button-secondary');
    section.append(element('h2', undefined, t('Scheduled tasks')), element('p', 'field-help', t('Runs while the server is on, even with this page closed. Resume after saving data connections. At most one pending run within 24 hours is caught up using current data; older occurrences are skipped. Interrupted runs are not replayed.')), refresh, feedback, content);
    const describe = (trigger) => trigger.kind === 'schedule' ? `${trigger.cron} · ${trigger.tz}`
        : trigger.kind === 'market' ? `${trigger.calendar} ${t(trigger.at === 'open' ? 'Market open' : 'Market close')} ${trigger.offsetMinutes >= 0 ? '+' : ''}${trigger.offsetMinutes} min · Asia/Shanghai` : statusText(trigger.kind);
    async function load() {
        if (busy)
            return;
        busy = true;
        refresh.disabled = true;
        try {
            const data = await request(`/api/apps/${encodeURIComponent(app.id)}/schedules`);
            if (!section.isConnected)
                return;
            content.replaceChildren();
            const indices = new Set(data.triggers.flatMap((trigger, index) => trigger.kind === 'schedule' || trigger.kind === 'market' ? [index] : []));
            for (const task of data.tasks)
                indices.add(task.triggerIndex);
            if (!indices.size)
                content.append(element('p', 'field-help', t('This application has no clock or market triggers.')));
            for (const index of indices) {
                const task = data.tasks.find((item) => item.triggerIndex === index);
                const trigger = data.triggers[index];
                const mismatch = task !== undefined && task.appVersion !== data.appVersion;
                const card = element('div', 'run-task');
                card.append(element('h3', undefined, t('Task {number}: {trigger}', { number: index + 1, trigger: trigger ? describe(trigger) : t('Trigger removed') })));
                const running = task && data.running.find((attempt) => attempt.taskId === task.id);
                const state = mismatch ? t('Version confirmation required') : running ? t('Running') : task?.schedulingIssue?.code === 'needs_data' ? t('Waiting for data')
                    : task?.schedulingIssue?.code === 'interrupted' ? t('Interrupted') : task?.enabled ? t('Enabled') : task ? t('Paused') : t('Not enabled');
                card.append(element('p', undefined, state), element('p', 'field-help', t('Next run (UTC): {date}', { date: task?.nextRunAt ?? t('Not scheduled') })));
                if (task?.lastRunId)
                    card.append(element('p', 'field-help', t('Last result: {status} · {id}', { status: task.lastStatus ? statusText(task.lastStatus) : t('See run history'), id: task.lastRunId })));
                if (task?.schedulingIssue)
                    card.append(element('p', 'notice', t(task.schedulingIssue.message)));
                if (task?.schedulingNote)
                    card.append(element('p', 'field-help', t(task.schedulingNote)));
                let confirmed;
                if (mismatch) {
                    const label = element('label', 'run-setting');
                    confirmed = element('input');
                    confirmed.type = 'checkbox';
                    label.append(confirmed, document.createTextNode(t('I reviewed the current application and trigger (version {version}).', { version: data.appVersion.slice(0, 12) })));
                    card.append(label);
                }
                const act = async (action) => {
                    if (busy)
                        return;
                    if (action === 'confirm' && !confirmed?.checked) {
                        feedback.replaceChildren(element('p', 'notice', t('Review the current application and check the confirmation box first.')));
                        return;
                    }
                    busy = true;
                    for (const control of Array.from(section.querySelectorAll('button')))
                        control.disabled = true;
                    try {
                        const response = await request(`/api/apps/${encodeURIComponent(app.id)}/schedules`, {
                            method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Blocks-Request': '1' },
                            body: JSON.stringify({ triggerIndex: index, action, appVersion: data.appVersion }),
                        });
                        feedback.replaceChildren(element('p', undefined, (response.task.schedulingIssue ? t(response.task.schedulingIssue.message) : undefined) ?? (response.task.enabled ? t('Task enabled.') : t('Task paused. An already running execution may finish.'))));
                    }
                    catch (error) {
                        showFailure(feedback, error);
                    }
                    finally {
                        busy = false;
                        await load();
                    }
                };
                if (task?.enabled)
                    card.append(button(t('Pause'), () => { void act('pause'); }, 'button button-secondary'));
                if (trigger && (trigger.kind === 'schedule' || trigger.kind === 'market') && (!task?.enabled || mismatch)) {
                    card.append(button(mismatch ? t('Confirm version and resume') : task ? t('Resume') : t('Enable'), () => { void act(mismatch ? 'confirm' : task ? 'resume' : 'enable'); }));
                }
                content.append(card);
            }
        }
        catch (error) {
            if (section.isConnected)
                showFailure(feedback, error);
        }
        finally {
            busy = false;
            refresh.disabled = false;
        }
    }
    // The panel is attached by the caller before the response is rendered.
    void load();
    return section;
}
function showRunWorkspace(app) {
    const builtin = isFlagshipDocument(app.doc);
    const displayText = (value) => builtin ? flagshipText(value) : value;
    const displayField = (value) => builtin ? flagshipFieldLabel(value) : value;
    const mappingLabel = (value) => displayField(value) === value ? value : `${displayField(value)} (${value})`;
    const workspace = element('section', 'run-workspace');
    const status = element('div');
    status.setAttribute('role', 'status');
    const history = element('section', 'run-history');
    const output = element('section', 'run-output');
    const inspection = element('section', 'run-inspection');
    const comparison = element('section');
    const schedules = element('section');
    const monitoringHost = element('section');
    const resultMeta = element('p', 'result-meta');
    const runNotices = element('div');
    const screenHost = element('div');
    output.append(element('h2', undefined, t('Application')), resultMeta, runNotices, screenHost);
    inspection.append(element('p', 'field-help', t('Select a saved run to inspect its sources.')));
    let compared = false;
    let scheduled = false;
    const tabs = createTabs('app-workspace', t('Application views'), [
        { id: 'results', label: t('Results'), panel: output, activate: () => { if (runScreen)
                mountScreenCharts(runScreen); } },
        { id: 'monitor', label: t('Monitoring'), panel: monitoringHost },
        { id: 'history', label: t('Run history'), panel: history },
        { id: 'compare', label: t('Compare'), panel: comparison, activate: () => {
                if (compared)
                    return;
                compared = true;
                comparison.append(createComparePanel(app.id, request, {
                    columnLabel: displayField, valueLabel: (value, column) => builtin && column ? String(flagshipValue(column, value)) : value,
                    settingsLabels: Object.fromEntries(app.doc.params.map((param) => [param.key, param.label])),
                    outputLabels: Object.fromEntries(Object.values(app.doc.ui.elements).flatMap((item) => 'from' in item && typeof item.from === 'string' && (('label' in item && typeof item.label === 'string') || ('title' in item && typeof item.title === 'string'))
                        ? [[item.from, 'label' in item ? String(item.label) : String(item.title)]] : [])),
                }));
            } },
        { id: 'schedules', label: t('Scheduled tasks'), panel: schedules, activate: () => { if (!scheduled) {
                scheduled = true;
                schedules.append(schedulePanel(app));
            } } },
        { id: 'inspect', label: t('Inspect'), panel: inspection },
    ]);
    const controls = element('form', 'screen-panel run-controls');
    controls.append(element('h2', undefined, t('Run application')), element('p', 'field-help', t('Run with the settings below. Run changes apply once. Use Save connection and settings below to keep them for future runs.')));
    const readers = new Map();
    const inputs = [];
    const runButton = element('button', 'button button-primary', t('Run application'));
    runButton.type = 'submit';
    runButton.disabled = true;
    const retryButton = button(t('Retry same run'), () => { void submit(true); }, 'button button-secondary');
    retryButton.hidden = true;
    const reloadButton = button(t('Refresh run history'), () => { void loadHistory(false); }, 'button button-secondary');
    const pendingKey = `blocks:pending-run:${app.id}`;
    let pending;
    let running = false;
    let settingsReady = false;
    let connectionRequired = false;
    let connectionDirty = false;
    let resumeRunId;
    const draftKey = `blocks:connection-draft:${app.id}`;
    let draft;
    try {
        const stored = sessionStorage.getItem(draftKey);
        if (stored)
            draft = JSON.parse(stored);
    }
    catch { /* Keep the in-page draft usable. */ }
    connectionDirty = draft?.dirty === true;
    const paramInputs = new Map();
    const embeddedControls = new ScreenControls({
        params: app.doc.params,
        getRaw: (key) => paramInputs.get(key)?.value ?? '',
        setRaw: (key, raw) => { const input = paramInputs.get(key); if (input) {
            input.value = raw;
            rememberDraft();
        } },
        canEdit: () => settingsReady && !running && pending === undefined && !actions?.isBusy(),
        canRun: () => settingsReady && !running && pending === undefined && !connectionRequired && !connectionDirty && !actions?.isBusy(),
        reportValidity: () => controls.reportValidity(),
        onRun: () => { void submit(false); },
    });
    const connection = element('details', 'screen-panel run-connection');
    connection.append(element('summary', undefined, t('Connect your data')));
    const connectionForm = element('form');
    const connectionFields = element('div');
    const connectionFeedback = element('div');
    connectionFeedback.setAttribute('role', 'status');
    const bindingInputs = new Map();
    const mappingInputs = new Map();
    let revision = '';
    let connectionSnapshot;
    let datasets = [];
    const saveConnectionButton = element('button', 'button button-secondary', t('Save connection and settings'));
    saveConnectionButton.type = 'submit';
    const saveRunButton = button(t('Save and run'), () => { void saveConnection(true); });
    const refreshConnectionButton = button(t('Review latest saved settings'), () => { void loadConnection(true); }, 'button button-secondary');
    connectionForm.append(element('p', 'field-help', t('Choose a dataset for each requirement, then match its columns. Saving also keeps the parameter values above for future runs.')), connectionFields, saveConnectionButton, saveRunButton, refreshConnectionButton, connectionFeedback);
    connection.append(connectionForm);
    connectionForm.addEventListener('submit', (event) => { event.preventDefault(); void saveConnection(false); });
    const connectionValues = () => ({
        bindings: Object.fromEntries([...bindingInputs].map(([key, input]) => [key, input.value])),
        mappings: Object.fromEntries([...mappingInputs].map(([key, fields]) => [key,
            Object.fromEntries([...fields].filter(([, input]) => input.value !== '').map(([name, input]) => [name, input.value]))])),
    });
    const rememberDraft = () => {
        draft = { params: Object.fromEntries([...paramInputs].map(([key, input]) => [key, input.value])), ...connectionValues(), dirty: connectionDirty, ...(revision ? { revision } : {}) };
        try {
            sessionStorage.setItem(draftKey, JSON.stringify(draft));
        }
        catch { /* Inputs remain intact in this page. */ }
    };
    function fillMappings(key, chosen) {
        const container = connectionFields.querySelector(`[data-mapping-key="${key}"]`);
        container.replaceChildren();
        const fields = new Map();
        const dataset = datasets.find((item) => item.id === bindingInputs.get(key).value);
        const requirement = app.doc.data.find((item) => item.key === key);
        for (const field of requirement.fields) {
            const label = element('label', 'run-setting', t('{name} · {type}{required}', { name: mappingLabel(field.name), type: statusText(field.type), required: field.required ? t(' · required') : '' }));
            const select = element('select');
            const automatic = element('option', undefined, t('Automatic matching'));
            automatic.value = '';
            select.append(automatic);
            for (const column of dataset?.fields ?? []) {
                const option = element('option', undefined, `${mappingLabel(column.name)} · ${statusText(column.type)}`);
                option.value = column.name;
                select.append(option);
            }
            const value = chosen[field.name] ?? '';
            if (value && !dataset?.fields.some((item) => item.name === value)) {
                const option = element('option', undefined, t('{name} (not in this dataset)', { name: value }));
                option.value = value;
                select.append(option);
            }
            select.value = value;
            select.addEventListener('change', () => { connectionDirty = true; rememberDraft(); setBusy(false); });
            fields.set(field.name, select);
            label.append(select);
            container.append(label);
        }
        mappingInputs.set(key, fields);
    }
    async function loadConnection(review = false) {
        try {
            const response = await request(`/api/apps/${encodeURIComponent(app.id)}/connection`);
            if (!workspace.isConnected)
                return;
            connectionSnapshot = response;
            datasets = response.datasets;
            revision = review ? response.revision : draft?.revision ?? response.revision;
            if (review && bindingInputs.size === app.doc.data.length) {
                connectionFeedback.replaceChildren(element('p', undefined, t('Latest saved settings are shown below. Your draft is unchanged. Review before saving your draft over these settings.')), element('pre', undefined, JSON.stringify(response.settings, null, 2)));
                rememberDraft();
                setBusy(false);
                return;
            }
            const values = draft ?? response.settings;
            connectionFields.replaceChildren();
            bindingInputs.clear();
            mappingInputs.clear();
            for (const requirement of app.doc.data) {
                const group = element('fieldset');
                group.append(element('legend', undefined, mappingLabel(requirement.key)));
                const label = element('label', 'run-setting', t('Dataset'));
                const select = element('select');
                const empty = element('option', undefined, t('Choose a dataset'));
                empty.value = '';
                select.append(empty);
                for (const dataset of datasets) {
                    const option = element('option', undefined, `${displayText(dataset.name)} (${dataset.id})`);
                    option.value = dataset.id;
                    select.append(option);
                }
                const value = values.bindings[requirement.key] ?? requirement.datasetHint ?? '';
                if (value && !datasets.some((item) => item.id === value)) {
                    const option = element('option', undefined, t('{name} (unavailable or uploaded data)', { name: value }));
                    option.value = value;
                    select.append(option);
                }
                select.value = value;
                bindingInputs.set(requirement.key, select);
                const mappings = element('div');
                mappings.dataset.mappingKey = requirement.key;
                label.append(select);
                group.append(label, mappings);
                connectionFields.append(group);
                fillMappings(requirement.key, values.mappings[requirement.key] ?? {});
                select.addEventListener('change', () => {
                    const current = Object.fromEntries([...mappingInputs.get(requirement.key)].map(([name, input]) => [name, input.value]));
                    fillMappings(requirement.key, current);
                    connectionDirty = true;
                    rememberDraft();
                    setBusy(false);
                });
            }
            setBusy(running);
        }
        catch (error) {
            if (workspace.isConnected) {
                showFailure(connectionFeedback, error);
                connection.open = true;
            }
        }
    }
    async function saveConnection(runAfter) {
        if (running || pending || actions?.isBusy() || !settingsReady || !revision || !embeddedControls.valid())
            return;
        rememberDraft();
        setBusy(true);
        try {
            const settings = { params: Object.fromEntries([...readers].map(([key, read]) => [key, read()])), ...connectionValues() };
            const saved = await request(`/api/apps/${encodeURIComponent(app.id)}/connection`, {
                method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Blocks-Request': '1' }, body: JSON.stringify({ settings, revision }),
            });
            if (!workspace.isConnected)
                return;
            connectionSnapshot = saved;
            revision = saved.revision;
            connectionDirty = false;
            rememberDraft();
            connectionRequired = false;
            connectionFeedback.replaceChildren(element('p', undefined, t('Connection and settings saved. Running will check that the selected data is readable.')));
            setBusy(false);
            if (runAfter)
                await submit(false);
        }
        catch (error) {
            if (workspace.isConnected)
                showFailure(connectionFeedback, error);
        }
        finally {
            if (workspace.isConnected)
                setBusy(false);
        }
    }
    try {
        const saved = sessionStorage.getItem(pendingKey);
        if (saved)
            pending = JSON.parse(saved);
    }
    catch { /* The user can still inspect saved history when browser storage is unavailable. */ }
    const syncAvailability = () => {
        const busy = running || Boolean(actions?.isBusy());
        runButton.disabled = busy || pending !== undefined || !settingsReady || connectionRequired || connectionDirty;
        retryButton.disabled = busy || !settingsReady;
        reloadButton.disabled = busy;
        for (const input of inputs)
            input.disabled = busy || pending !== undefined;
        retryButton.hidden = pending === undefined;
        for (const input of [...bindingInputs.values(), ...[...mappingInputs.values()].flatMap((fields) => [...fields.values()])])
            input.disabled = busy || pending !== undefined;
        saveConnectionButton.disabled = busy || pending !== undefined || !revision || !settingsReady;
        saveRunButton.disabled = saveConnectionButton.disabled;
        refreshConnectionButton.disabled = busy || pending !== undefined;
        runButton.textContent = running ? t('Running…') : t('Run application');
        embeddedControls.sync();
        recordTools.sync();
        monitor.sync();
    };
    const setBusy = (busy) => {
        running = busy;
        syncAvailability();
        actions?.dispatchEvent(new Event('blocks:availability'));
    };
    const clearPending = () => {
        pending = undefined;
        try {
            sessionStorage.removeItem(pendingKey);
        }
        catch { /* The in-page request is already resolved. */ }
    };
    function inspectDisplayedRun(...inspections) {
        const dates = element('dl', 'app-dates');
        for (const [label, value] of [[t('Added to your library'), app.createdAt], [t('Last updated'), app.updatedAt]]) {
            const group = element('div');
            group.append(element('dt', undefined, label), element('dd', undefined, dateLabel(value)));
            dates.append(group);
        }
        for (const item of inspections)
            if (item instanceof HTMLDetailsElement)
                item.open = true;
        inspection.replaceChildren(dates, ...inspections);
    }
    let lastSuccessfulRun;
    const display = (run) => {
        recordTools.clear();
        recordOutputVersion = '';
        selectedRunId = run.id;
        const date = new Date(run.startedAt);
        resultMeta.textContent = t('Showing run from {date} · {status}', { date: Number.isNaN(date.getTime()) ? run.startedAt : date.toLocaleString(locale()), status: statusText(run.status) });
        resultMeta.dataset.status = run.status;
        for (const item of Array.from(history.querySelectorAll('[data-run-id]')))
            item.setAttribute('aria-pressed', String(item.dataset.runId === run.id));
        runNotices.replaceChildren();
        if (run.failure)
            runNotices.append(element('p', 'notice', t(run.failure.message)));
        for (const warning of run.result?.warnings ?? [])
            runNotices.append(element('p', 'notice', displayText(warning)));
        if (run.status === 'failed' && lastSuccessfulRun && runScreen) {
            runScreen.dataset.stale = 'true';
            runNotices.append(element('p', 'notice', t('This run failed. The dimmed values below are from the last displayed successful run ({date}). Your settings are retained.', { date: lastSuccessfulRun.startedAt })));
            const failedInspect = inspectRun(run, mappingLabel);
            failedInspect.querySelector('summary').textContent = t('Inspect · Failed run attempt');
            inspectDisplayedRun(inspectRun(lastSuccessfulRun, mappingLabel), failedInspect);
            return;
        }
        if (runScreen)
            disposeScreenCharts(runScreen);
        const results = localizeFlagshipResults(app.doc, new Map(Object.entries(run.status === 'failed' ? {} : run.result?.outputs ?? {}).map(([key, table]) => [key, {
                columns: table.schema.map((column) => ({ name: column.name, type: column.type })),
                rows: table.rows.map((row) => Object.fromEntries(table.schema.map((column, index) => [column.name, row[index]]))),
            }])));
        if (runScreen)
            refreshScreenResults(runScreen, app.doc.ui, results, displayField);
        else {
            runScreen = renderScreen(app.doc.ui, results, embeddedControls, displayField);
            screenHost.append(runScreen);
        }
        delete runScreen.dataset.stale;
        lastSuccessfulRun = run.result !== undefined && run.status !== 'failed' ? run : undefined;
        if (run.result && run.status !== 'failed' && run.appVersion === app.version) {
            recordOutputVersion = run.appVersion;
            recordTools.show(run.result.outputs);
        }
        mountScreenCharts(runScreen);
        inspectDisplayedRun(inspectRun(run, mappingLabel));
    };
    async function loadHistory(initial) {
        try {
            const response = await request(`/api/apps/${encodeURIComponent(app.id)}/runs`);
            if (!workspace.isConnected)
                return;
            if (!settingsReady) {
                await loadConnection();
                if (!workspace.isConnected)
                    return;
                for (const param of app.doc.params) {
                    const savedParams = connectionSnapshot?.settings.params ?? response.params;
                    const value = Object.hasOwn(savedParams, param.key) ? savedParams[param.key] : param.default;
                    const label = element('label', 'run-setting', param.label);
                    let input;
                    if (param.list) {
                        const area = element('textarea');
                        area.value = Array.isArray(value) ? value.join('\n') : '';
                        area.setAttribute('aria-label', t('{name} (one value per line)', { name: param.label }));
                        readers.set(param.key, () => area.value.split('\n').map((item) => item.trim()).filter(Boolean));
                        input = area;
                        label.append(element('span', 'field-help', t('One value per line.')));
                    }
                    else if (param.options) {
                        const select = element('select');
                        select.required = true;
                        const empty = element('option', undefined, t('Choose an option'));
                        empty.value = '';
                        select.append(empty);
                        for (const choice of param.options) {
                            const option = element('option', undefined, choice.label);
                            option.value = choice.value;
                            select.append(option);
                        }
                        select.value = value === undefined ? '' : String(value);
                        readers.set(param.key, () => select.value);
                        input = select;
                    }
                    else if (param.type === 'boolean') {
                        const select = element('select');
                        select.required = true;
                        for (const choice of ['true', 'false']) {
                            const option = element('option', undefined, t(choice === 'true' ? 'Yes' : 'No'));
                            option.value = choice;
                            select.append(option);
                        }
                        select.value = String(value ?? false);
                        readers.set(param.key, () => select.value === 'true');
                        input = select;
                    }
                    else {
                        const field = element('input');
                        field.type = param.type === 'number' ? 'number' : param.type === 'date' ? 'date' : 'text';
                        field.value = value === undefined ? '' : String(value);
                        field.required = param.type !== 'text';
                        if (param.type === 'number') {
                            field.step = param.step === undefined ? 'any' : String(param.step);
                            if (param.min !== undefined)
                                field.min = String(param.min);
                            if (param.max !== undefined)
                                field.max = String(param.max);
                        }
                        readers.set(param.key, () => param.type === 'number' ? Number(field.value) : field.value);
                        input = field;
                    }
                    if (draft?.params && Object.hasOwn(draft.params, param.key))
                        input.value = draft.params[param.key];
                    paramInputs.set(param.key, input);
                    input.addEventListener('input', () => { rememberDraft(); embeddedControls.sync(); });
                    input.addEventListener('change', () => { rememberDraft(); embeddedControls.sync(); });
                    inputs.push(input);
                    label.append(input);
                    controls.insertBefore(label, runButton);
                }
            }
            settingsReady = true;
            if (!runScreen) {
                runScreen = renderScreen(app.doc.ui, new Map(), embeddedControls, displayField);
                screenHost.append(runScreen);
            }
            history.replaceChildren(element('h2', undefined, t('Recent runs')), element('p', 'field-help', t('Times are shown in your browser time zone.')), reloadButton);
            if (!response.runs.length)
                history.append(element('p', 'field-help', t('No saved runs yet.')));
            const timeline = element('ol', 'run-history-list');
            for (const run of response.runs) {
                const row = element('li');
                const choose = button('', () => { display(run); tabs.select('results', true); }, 'run-history-choice');
                const date = new Date(run.startedAt);
                choose.append(element('span', 'run-status', statusText(run.status)), element('strong', undefined, Number.isNaN(date.getTime()) ? run.startedAt : date.toLocaleString(locale())), element('span', 'muted', t('Data as of {date}', { date: run.asOfDate ?? run.result?.asOfDate ?? t('Not supplied') })));
                choose.dataset.runId = run.id;
                choose.dataset.status = run.status;
                choose.setAttribute('aria-pressed', String(run.id === selectedRunId));
                row.append(choose);
                timeline.append(row);
            }
            history.append(timeline);
            if (initial && response.runs[0]) {
                const latest = response.runs.find((run) => run.id === selectedRunId) ?? response.runs[0];
                if (latest.status === 'failed') {
                    const previous = response.runs.filter((run) => run.startedAt <= latest.startedAt).find((run) => run.appVersion === latest.appVersion && run.status !== 'failed' && run.result);
                    if (previous)
                        display(previous);
                }
                display(latest);
            }
            else if (initial && !response.runs.length) {
                runNotices.replaceChildren(element('p', 'notice', t('This application has no saved run results yet. Choose settings and run it to see results.')));
            }
            if (pending && response.runs.some((run) => run.id === pending.runId))
                clearPending();
            setBusy(false);
            void monitor.refresh();
        }
        catch (error) {
            if (workspace.isConnected)
                showFailure(status, error);
        }
    }
    async function submit(retry, afterAction = false) {
        if (running || !settingsReady || (!afterAction && actions?.isBusy()))
            return;
        if (!retry && (pending !== undefined || connectionRequired || connectionDirty || !embeddedControls.valid()))
            return;
        activeAppRuns++;
        try {
            if (!retry) {
                rememberDraft();
                pending = { runId: resumeRunId ?? crypto.randomUUID(), params: Object.fromEntries([...readers].map(([key, read]) => [key, read()])) };
            }
            if (!pending)
                return;
            // Persist before sending so a timeout or refresh can reuse the same request.
            sessionStorage.setItem(pendingKey, JSON.stringify(pending));
            setBusy(true);
            status.replaceChildren(element('p', undefined, t('Running application…')));
            const reply = await request(`/api/apps/${encodeURIComponent(app.id)}/run`, {
                method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Blocks-Request': '1' }, body: JSON.stringify(pending),
            }, 75_000);
            if (!workspace.isConnected)
                return;
            if (reply.kind === 'completed') {
                clearPending();
                resumeRunId = undefined;
                status.replaceChildren(element('p', undefined, t('Run {status}{reused}.', { status: statusText(reply.record.status), reused: reply.reused ? t(' · saved result reused') : '' })));
                display(reply.record);
                tabs.select('results');
                await loadHistory(false);
            }
            else if (reply.kind === 'needs_data') {
                resumeRunId = reply.runId;
                clearPending();
                connectionRequired = true;
                rememberDraft();
                connection.open = true;
                connection.querySelector('summary')?.focus();
                status.replaceChildren(element('h3', undefined, t('Connect your data')), element('p', undefined, t(reply.issue.message)), element('p', 'field-help', reply.issue.code === 'NeedsBindingError' ? t('Choose an available dataset below, then save and run. No failed run was saved.') : t('Match the required columns below, then save and run. Your other entries are retained.')));
                if ('problems' in reply.issue) {
                    const list = element('ul');
                    for (const problem of reply.issue.problems)
                        list.append(element('li', undefined, 'field' in problem ? `${problem.key}.${problem.field}: ${problem.suggestions.join(', ')}` : problem.key));
                    status.append(list);
                }
            }
            else
                status.replaceChildren(element('p', undefined, t('An execution is still active. Refresh run history or retry the same run later.')));
        }
        catch (error) {
            if (workspace.isConnected)
                showFailure(status, error);
        }
        finally {
            activeAppRuns--;
            if (workspace.isConnected)
                setBusy(false);
            if (!activeAppRuns && refreshLanguageAfterRun) {
                refreshLanguageAfterRun = false;
                void render(false);
            }
        }
    }
    controls.append(runButton, retryButton);
    controls.addEventListener('submit', (event) => { event.preventDefault(); void submit(false); });
    const setup = element('aside', 'run-setup');
    setup.setAttribute('aria-label', t('Run settings'));
    setup.append(controls, connection);
    const results = element('div', 'run-main');
    results.append(status, tabs.root);
    history.append(element('h2', undefined, t('Recent runs')), reloadButton);
    const actions = app.doc.params.some((param) => param.list === true)
        ? createListActionPanel(app.id, async (snapshot, param) => {
            if (!workspace.isConnected)
                return;
            const changed = snapshot.params.find((entry) => entry.key === param);
            const input = paramInputs.get(param);
            if (changed && input)
                input.value = changed.values.join('\n');
            rememberDraft();
            embeddedControls.sync();
            const expected = settingsAfterListAction(connectionSnapshot?.settings, snapshot, param);
            try {
                const latest = await request(`/api/apps/${encodeURIComponent(app.id)}/connection`);
                if (!workspace.isConnected)
                    return;
                if (!expected || !sameSettings(expected, latest.settings)) {
                    revision = '';
                    connectionFeedback.replaceChildren(element('p', 'notice', t('The action was saved, but other saved settings changed. Review latest saved settings before saving or rerunning your draft.')));
                    connectionDirty = true;
                    connection.open = true;
                    rememberDraft();
                    return;
                }
                connectionSnapshot = latest;
                revision = latest.revision;
                rememberDraft();
                await submit(false, true);
            }
            catch {
                revision = '';
                connectionDirty = true;
                connectionFeedback.replaceChildren(element('p', 'notice', t('The action was saved. Refresh saved settings before saving again; your other entries are retained.')));
                connection.open = true;
                rememberDraft();
            }
        }, () => settingsReady && !running && pending === undefined && !connectionDirty, displayText)
        : undefined;
    let recordOutputVersion = '';
    const recordTools = createRecordTools({
        displayLabel: displayText,
        params: app.doc.params,
        getRaw: (key) => paramInputs.get(key)?.value ?? '',
        setParam: (key, value) => embeddedControls.update(key, value),
        run: () => submit(false),
        canEdit: () => settingsReady && !running && pending === undefined && !connectionRequired && !connectionDirty && recordOutputVersion === app.version,
        actions: actions ?? { snapshot: () => undefined, isBusy: () => false, saveRecordAction: async () => false },
    });
    const monitor = createMonitorPanel(app.id, () => settingsReady && !running && pending === undefined && !connectionDirty && !actions?.isBusy(), displayText);
    monitoringHost.append(monitor.element);
    output.insertBefore(recordTools.element, screenHost);
    actions?.addEventListener('blocks:list-action-state', syncAvailability);
    if (actions)
        results.append(actions);
    workspace.append(setup, results);
    view.append(workspace);
    void loadHistory(true);
}
async function render(moveFocus = false, importedId) {
    const sequence = ++renderSequence;
    disposeExample?.();
    disposeExample = undefined;
    if (runScreen)
        disposeScreenCharts(runScreen);
    runScreen = undefined;
    for (const link of Array.from(document.querySelectorAll('.nav-item, .data-nav-link'))) {
        if (link.pathname === (window.location.pathname.replace(/\/$/, '') || '/') || (link.pathname === '/apps' && window.location.pathname.startsWith('/apps/')))
            link.setAttribute('aria-current', 'page');
        else
            link.removeAttribute('aria-current');
    }
    const home = window.location.pathname === '/';
    document.body.dataset.view = home ? 'home' : 'workspace';
    const skip = document.querySelector('.skip-link');
    if (skip)
        skip.href = home ? '#landing-main' : '#main';
    requiredElement('landing-main').hidden = !home;
    requiredElement('app-shell').hidden = home;
    const preferences = document.querySelector('[data-preferences]');
    if (preferences)
        requiredElement(home ? 'home-tools' : 'workspace-tools').append(preferences);
    requiredElement('main').dataset.page = /^\/chat\/?$/.test(window.location.pathname) ? 'chat' : 'workspace';
    if (window.location.pathname === '/charts' || window.location.pathname === '/screen-elements') {
        disposeExample = showExampleScreen(view, window.location.pathname === '/charts' ? 'charts' : 'components');
        if (moveFocus)
            focusPage();
        return;
    }
    if (home) {
        view.replaceChildren();
        if (moveFocus)
            requiredElement('landing-main').focus();
        return;
    }
    if (/^\/chat\/?$/.test(window.location.pathname)) {
        showChatScreen(view, navigate);
        return;
    }
    if (/^\/examples\/?$/.test(window.location.pathname)) {
        await showTemplates(view, navigate);
        if (sequence === renderSequence && moveFocus)
            focusPage();
        return;
    }
    if (/^\/data\/?$/.test(window.location.pathname)) {
        await showDataScreen(view, { moveFocus });
        return;
    }
    const match = /^\/apps\/([^/]+)\/?$/.exec(window.location.pathname);
    const loading = element('p', 'loading-message', match ? t('Opening your app…') : t('Loading your apps…'));
    loading.setAttribute('role', 'status');
    const placeholders = element('div', match ? 'run-workspace loading-placeholders' : 'app-grid loading-placeholders');
    placeholders.setAttribute('aria-hidden', 'true');
    for (let index = 0; index < (match ? 2 : 3); index++)
        placeholders.append(element('div', 'loading-placeholder'));
    view.replaceChildren(loading, placeholders);
    try {
        if (match?.[1]) {
            const id = decodeURIComponent(match[1]);
            const { app } = await request(`/api/apps/${encodeURIComponent(id)}`);
            if (sequence !== renderSequence)
                return;
            returnAppId = app.id;
            showApp(app);
        }
        else {
            const { apps } = await request('/api/apps');
            const { drafts } = await request('/api/drafts');
            if (sequence !== renderSequence)
                return;
            if (importedId) {
                libraryState.query = '';
                saveLibraryView();
            }
            showLibrary(apps, drafts);
        }
        if (moveFocus)
            focusPage(match ? undefined : importedId ?? returnAppId);
    }
    catch (error) {
        if (sequence !== renderSequence)
            return;
        view.replaceChildren(match ? routeLink(t('← Back to My Apps'), '/apps', 'text-button detail-back') : listHeading());
        const feedback = element('div');
        view.append(feedback);
        showFailure(feedback, error);
        if (!(error instanceof LibraryRequestError && error.code === 'APP_NOT_FOUND')) {
            view.append(button(t('Try again'), () => { void render(true); }, 'button button-secondary'));
        }
    }
}
function openImport() {
    importOpener = document.activeElement instanceof HTMLElement ? document.activeElement : null;
    form.reset();
    form.querySelector('details')?.removeAttribute('open');
    importFeedback.replaceChildren();
    dialog.showModal();
    fileInput.focus();
}
function setImportBusy(value) {
    importing = value;
    dialog.setAttribute('aria-busy', String(value));
    for (const control of [fileInput, contentInput, submitImport, closeImport, cancelImport])
        control.disabled = value;
    submitImport.textContent = value ? t('Importing…') : t('Import app');
}
async function importDocument() {
    if (importing)
        return;
    setImportBusy(true);
    importFeedback.replaceChildren();
    try {
        const file = fileInput.files?.[0];
        if (file && !/\.json$/i.test(file.name))
            throw new Error(t('Choose a JSON app file, or paste the app document below.'));
        if (file && file.size > MAX_DOCUMENT_BYTES)
            throw new Error(t('This file is too large. Choose an app document smaller than 1 MB.'));
        const text = file ? await file.text() : contentInput.value;
        if (!text.trim())
            throw new Error(t('Choose an app file or paste an app document to continue.'));
        if (new TextEncoder().encode(text).byteLength > MAX_DOCUMENT_BYTES)
            throw new Error(t('This document is too large. Use an app document smaller than 1 MB.'));
        const result = await request('/api/apps/import', {
            method: 'POST',
            headers: { 'Content-Type': 'text/plain; charset=utf-8', 'X-Blocks-Request': '1' },
            body: text,
        });
        dialog.close();
        const notice = element('div', 'notice');
        notice.append(element('p', 'notice-title', t('{name} was added to your library.', { name: result.app.doc.meta.name })));
        if (result.warnings.length > 0) {
            notice.append(element('p', undefined, t('The app was saved with a few things to review.')), issueDetails(result.warnings, t('Review {count} notes', { count: result.warnings.length })));
        }
        announcements.replaceChildren(notice);
        if (window.location.pathname !== '/apps')
            window.history.pushState(null, '', '/apps');
        await render(true, result.app.id);
    }
    catch (error) {
        showFailure(importFeedback, error);
    }
    finally {
        setImportBusy(false);
    }
}
form.addEventListener('submit', (event) => {
    event.preventDefault();
    void importDocument();
});
closeImport.addEventListener('click', () => dialog.close());
cancelImport.addEventListener('click', () => dialog.close());
dialog.addEventListener('cancel', (event) => { if (importing)
    event.preventDefault(); });
dialog.addEventListener('close', () => { if (importOpener?.isConnected)
    importOpener.focus(); });
fileInput.addEventListener('change', () => { if (fileInput.files?.length)
    contentInput.value = ''; });
contentInput.addEventListener('input', () => { if (contentInput.value.length > 0)
    fileInput.value = ''; });
window.addEventListener('blocks:navigate', (event) => navigate(event.detail));
window.addEventListener('popstate', () => {
    if (dialog.open && !importing)
        dialog.close();
    announcements.replaceChildren();
    void render(true);
});
for (const link of Array.from(document.querySelectorAll('.brand, .nav-item, .data-nav-link, .landing-launch, .sidebar-previews a, .landing-nav a'))) {
    link.addEventListener('click', (event) => {
        if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey)
            return;
        event.preventDefault();
        navigate(link.pathname);
    });
}
window.addEventListener('pagehide', () => { if (runScreen)
    disposeScreenCharts(runScreen); });
window.addEventListener('pageshow', () => { if (runScreen)
    mountScreenCharts(runScreen); });
// Preserve the requested route on a full load, including saved-app detail URLs.
mountPreferences();
mountAppearance();
mountWorkspaceMotion(document.body);
window.addEventListener('blocks:language', () => {
    if (activeAppRuns)
        refreshLanguageAfterRun = true;
    else
        void render(false);
});
void render();
