import { t, locale, statusText } from "./i18n.js";
const absent = { present: false };
function valueAt(object, key) {
    return Object.hasOwn(object, key) ? { present: true, value: object[key] } : absent;
}
function stable(value) {
    if (Array.isArray(value))
        return `[${value.map(stable).join(',')}]`;
    if (value && typeof value === 'object')
        return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${stable(value[key])}`).join(',')}}`;
    return JSON.stringify(value) ?? 'undefined';
}
function difference(label, left, right) {
    const changed = left.present !== right.present || stable(left.value) !== stable(right.value);
    const numeric = left.present && right.present && typeof left.value === 'number' && typeof right.value === 'number';
    return { label, left, right, changed, ...(numeric ? { delta: right.value - left.value } : {}) };
}
export function compareRuns(left, right, columnLabel = (value) => value) {
    const settings = [...new Set([...Object.keys(left.params), ...Object.keys(right.params)])].map((key) => difference(key, valueAt(left.params, key), valueAt(right.params, key)));
    const compatible = left.appId === right.appId && left.appVersion === right.appVersion;
    if (!compatible)
        return { compatible, settings, tables: [] };
    const a = left.result?.outputs ?? {}, b = right.result?.outputs ?? {};
    const tables = [...new Set([...Object.keys(a), ...Object.keys(b)])].map((name) => {
        const l = a[name], r = b[name];
        const names = [...new Set([...(l?.schema.map((column) => column.name) ?? []), ...(r?.schema.map((column) => column.name) ?? [])])];
        const columns = names.map((column) => {
            const lc = l?.schema.find((item) => item.name === column), rc = r?.schema.find((item) => item.name === column);
            return difference(columnLabel(column), lc ? { present: true, value: { type: lc.type, unit: lc.unit ?? null } } : absent, rc ? { present: true, value: { type: rc.type, unit: rc.unit ?? null } } : absent);
        });
        const leftIndices = new Map(l?.schema.map((column, index) => [column.name, index]) ?? []);
        const rightIndices = new Map(r?.schema.map((column, index) => [column.name, index]) ?? []);
        const cells = [];
        let changedCells = 0;
        for (let row = 0; row < Math.max(l?.rows.length ?? 0, r?.rows.length ?? 0); row++) {
            for (const column of names) {
                const li = leftIndices.get(column) ?? -1, ri = rightIndices.get(column) ?? -1;
                const lv = li >= 0 && l?.rows[row] ? { present: true, value: l.rows[row][li] } : absent;
                const rv = ri >= 0 && r?.rows[row] ? { present: true, value: r.rows[row][ri] } : absent;
                const cell = difference(t('Row {number} · {column}', { number: row + 1, column: columnLabel(column) }), lv, rv);
                cell.column = column;
                if (cell.changed)
                    changedCells++;
                if (row < 100)
                    cells.push(cell);
            }
        }
        return { name, columns, cells, changedCells, leftRows: l?.rows.length ?? 0, rightRows: r?.rows.length ?? 0, scalar: l?.rows.length === 1 && r?.rows.length === 1 && names.length === 1 };
    });
    return { compatible, settings, tables };
}
function node(tag, text, className) {
    const el = document.createElement(tag);
    if (text !== undefined)
        el.textContent = text;
    if (className)
        el.className = className;
    return el;
}
function shown(value, displayLabel, column) { return value.present ? typeof value.value === 'string' ? JSON.stringify(displayLabel(value.value, column)) : stable(value.value) : t('Missing'); }
function diffTable(rows, caption, displayLabel = (value) => value) {
    const scroll = node('div', undefined, 'screen-table-scroll');
    scroll.tabIndex = 0;
    scroll.setAttribute('aria-label', caption);
    const table = node('table', undefined, 'screen-data-table');
    table.append(node('caption', caption));
    const header = node('tr');
    for (const label of [t('Field'), t('Run A'), t('Run B'), t('Difference (B − A)')]) {
        const th = node('th', label);
        th.scope = 'col';
        header.append(th);
    }
    const head = node('thead');
    head.append(header);
    const body = node('tbody');
    for (const row of rows) {
        const tr = node('tr');
        tr.dataset.changed = String(row.changed);
        const th = node('th', row.label);
        th.scope = 'row';
        tr.append(th, node('td', shown(row.left, displayLabel, row.column)), node('td', shown(row.right, displayLabel, row.column)), node('td', row.changed ? row.delta === undefined ? t('Changed') : String(row.delta) : t('Unchanged')));
        body.append(tr);
    }
    table.append(head, body);
    scroll.append(table);
    return scroll;
}
function runDate(value) {
    const date = new Date(value);
    return Number.isNaN(date.getTime()) ? t('Date unavailable') : new Intl.DateTimeFormat(locale(), { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit', second: '2-digit' }).format(date);
}
function runLabels(runs) {
    const labels = new Map();
    for (const run of runs) {
        const base = `${runDate(run.startedAt)} · ${statusText(run.status)}`;
        const matching = runs.filter((other) => `${runDate(other.startedAt)} · ${statusText(other.status)}` === base);
        if (matching.length === 1) {
            labels.set(run.id, base);
            continue;
        }
        let length = Math.min(6, run.id.length);
        while (length < run.id.length && matching.some((other) => other.id !== run.id && other.id.slice(-length) === run.id.slice(-length)))
            length++;
        labels.set(run.id, `${base} · ${run.id.slice(-length)}`);
    }
    return labels;
}
export function createComparePanel(appId, request, labels = {}) {
    const panel = node('section', undefined, 'screen-panel run-compare');
    const heading = node('h2', t('Compare two runs'));
    heading.tabIndex = -1;
    const controls = node('div', undefined, 'compare-controls');
    const feedback = node('div');
    feedback.setAttribute('role', 'status');
    const output = node('div');
    const selects = [t('Run A'), t('Run B')].map((text) => { const label = node('label', text, 'run-setting'); const select = node('select'); label.append(select); controls.append(label); return select; });
    const refresh = node('button', t('Refresh runs'), 'button button-secondary');
    refresh.type = 'button';
    controls.append(refresh);
    panel.append(heading, node('p', t('Choose two saved runs. Settings and results appear side by side.'), 'field-help'), controls, feedback, output);
    let runs = [];
    let loading = false;
    function display() {
        output.replaceChildren();
        const left = runs.find((run) => run.id === selects[0].value), right = runs.find((run) => run.id === selects[1].value);
        if (!left || !right)
            return;
        if (left.id === right.id) {
            output.append(node('p', t('Choose two different runs.'), 'notice'));
            return;
        }
        const comparison = compareRuns(left, right, labels.columnLabel);
        const metadata = node('div', undefined, 'compare-summary');
        for (const [label, run] of [['A', left], ['B', right]]) {
            const card = node('section', undefined, 'compare-run-card');
            card.append(node('h3', t(label === 'A' ? 'Run A' : 'Run B')), node('p', t('Run {label}: {date} · {status} · Data as of {asOf}', { label, date: runDate(run.startedAt), status: statusText(run.status), asOf: run.asOfDate ?? run.result?.asOfDate ?? t('Not supplied') }), 'field-help'));
            card.append(node('p', t('App version: {version}', { version: run.appVersion.slice(0, 12) }), 'field-help'));
            if (run.failure ?? run.result?.failure)
                card.append(node('p', `Run ${label}: ${(run.failure ?? run.result?.failure).message}`, 'notice'));
            for (const warning of run.result?.warnings ?? [])
                card.append(node('p', `Run ${label}: ${warning}`, 'notice'));
            metadata.append(card);
        }
        output.append(metadata);
        const settings = comparison.settings.filter((row) => row.changed).map((row) => ({ ...row, label: labels.settingsLabels?.[row.label] ?? row.label }));
        output.append(node('h3', t('Settings that differ')), settings.length ? diffTable(settings, t('Changed settings')) : node('p', t('The settings are identical.'), 'field-help'));
        if (!comparison.compatible) {
            output.append(node('p', t('These runs used different app versions. Settings can be compared, but result differences are unavailable. Choose runs from the same version.'), 'notice'));
            return;
        }
        if (!left.result || !right.result)
            output.append(node('p', t('One run has no saved results. Missing values are labelled below.'), 'notice'));
        if (!comparison.tables.length)
            output.append(node('p', t('No saved output values or tables are available.'), 'field-help'));
        for (const table of comparison.tables) {
            const section = node('section', undefined, 'compare-output');
            section.append(node('h3', `${labels.outputLabels?.[table.name] ?? table.name}${table.scalar ? t(' · Single value') : ''}`), node('p', t('Run A: {left} rows · Run B: {right} rows · {changed} changed cells', { left: table.leftRows, right: table.rightRows, changed: table.changedCells }), 'field-help'));
            const changedColumns = table.columns.filter((column) => column.changed);
            if (changedColumns.length)
                section.append(diffTable(changedColumns, t('Column differences')));
            section.append(node('p', t('Rows are compared by position; columns are matched by name. A change in row order also counts as a difference.'), 'field-help'));
            if (Math.max(table.leftRows, table.rightRows) > 100)
                section.append(node('p', t('Showing the first 100 rows. Changed cell count includes every row.'), 'field-help'));
            if (table.cells.length)
                section.append(diffTable(table.cells, t('Saved values side by side'), labels.valueLabel));
            output.append(section);
        }
    }
    async function load() {
        if (loading)
            return;
        loading = true;
        refresh.disabled = true;
        selects.forEach((select) => { select.disabled = true; });
        panel.setAttribute('aria-busy', 'true');
        feedback.replaceChildren(node('p', t('Loading saved runs…'), 'loading-message'));
        try {
            const response = await request(`/api/apps/${encodeURIComponent(appId)}/runs`);
            if (!panel.isConnected)
                return;
            const previous = selects.map((select) => select.value);
            runs = response.runs;
            const optionLabels = runLabels(runs);
            selects.forEach((select, index) => {
                select.replaceChildren();
                for (const run of runs) {
                    const option = node('option', optionLabels.get(run.id));
                    option.value = run.id;
                    select.append(option);
                }
                select.value = runs.some((run) => run.id === previous[index]) ? previous[index] : runs[index === 0 ? 1 : 0]?.id ?? '';
            });
            feedback.replaceChildren();
            output.replaceChildren();
            if (runs.length < 2)
                feedback.append(node('p', t('Save at least two runs to compare. Change the run settings and run the application again.'), 'field-help'));
            else
                display();
        }
        catch (error) {
            feedback.replaceChildren(node('p', error instanceof Error ? error.message : t('Saved runs could not be loaded. Try Refresh runs.'), 'notice'));
        }
        finally {
            loading = false;
            refresh.disabled = false;
            selects.forEach((select) => { select.disabled = runs.length < 2; });
            panel.setAttribute('aria-busy', 'false');
        }
    }
    selects.forEach((select) => select.addEventListener('change', display));
    refresh.addEventListener('click', () => { void load(); });
    // Load after the caller has mounted this panel.
    queueMicrotask(() => { if (panel.isConnected) {
        void load();
    } });
    return panel;
}
