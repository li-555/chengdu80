import { t } from "./i18n.js";
import { mountPreferences } from "./preferences.js";
import { mountAppearance } from "./appearance.js";
import { mountWorkspaceMotion } from "./workspace-motion.js";
import { renderScreen, mountScreenCharts, disposeScreenCharts } from "./screen-elements.js";
function paragraph(value, className) {
    const result = document.createElement('p');
    result.className = className;
    result.textContent = value;
    return result;
}
/** Shared example views use the real example endpoints, within the same desktop shell. */
export function showExampleScreen(view, kind) {
    const section = document.createElement('section');
    const header = document.createElement('header');
    header.className = 'page-heading';
    const copy = document.createElement('div');
    const title = document.createElement('h1');
    title.textContent = t(kind === 'charts' ? 'Charts' : 'Components');
    copy.append(paragraph(t('INVENTED EXAMPLE'), 'eyebrow'), title, paragraph(t('All example values are invented.'), 'muted'));
    header.append(copy);
    const feedback = document.createElement('div');
    feedback.setAttribute('aria-live', 'polite');
    const output = document.createElement('div');
    section.append(header, feedback, output);
    view.replaceChildren(section);
    if (kind === 'components') {
        const rail = document.createElement('div');
        rail.className = 'material-rail';
        rail.dataset.dragRail = '';
        rail.tabIndex = 0;
        rail.setAttribute('role', 'region');
        rail.setAttribute('aria-label', t('Appearance samples · Drag or use arrow keys'));
        for (const [token, text] of [['--accent', 'Accent'], ['--fg', 'Text color'], ['--surface', 'Surface'], ['--muted', 'Muted']]) {
            const card = document.createElement('div');
            card.className = 'material-card';
            const swatch = document.createElement('i');
            swatch.style.background = `var(${token})`;
            const label = document.createElement('h3');
            label.textContent = t(text);
            card.append(swatch, label);
            rail.append(card);
        }
        section.insertBefore(rail, output);
    }
    let controller = new AbortController();
    let active;
    let saved;
    let disposed = false;
    const draw = () => { if (active)
        disposeScreenCharts(active); if (!saved || disposed)
        return; active = renderScreen(saved.document.ui, new Map(saved.results)); output.replaceChildren(active); mountScreenCharts(active); };
    const load = async () => {
        controller = new AbortController();
        output.replaceChildren(paragraph(t('Preparing the example…'), 'loading-message'));
        feedback.replaceChildren();
        const timer = window.setTimeout(() => controller.abort(), 75_000);
        try {
            const response = await fetch(kind === 'charts' ? '/api/chart-example' : '/api/screen-example', { signal: controller.signal, cache: 'no-store' });
            if (!response.ok)
                throw new Error(t('The example could not be loaded. Please try again.'));
            const example = await response.json();
            if (disposed)
                return;
            if (example.status === 'failed')
                throw new Error(t('The example could not finish running. Please try again.'));
            saved = example;
            draw();
            for (const warning of example.warnings)
                feedback.append(paragraph(warning, 'notice'));
        }
        catch (error) {
            if (disposed)
                return;
            const notice = paragraph(error instanceof Error && error.name !== 'AbortError' ? error.message : t('The example took too long to open. Please try again.'), 'notice');
            notice.setAttribute('role', 'alert');
            const retry = document.createElement('button');
            retry.type = 'button';
            retry.className = 'button button-secondary';
            retry.textContent = t('Try again');
            retry.onclick = () => { void load(); };
            output.replaceChildren(notice, retry);
        }
        finally {
            window.clearTimeout(timer);
        }
    };
    const hide = () => { if (active)
        disposeScreenCharts(active); };
    const show = () => { if (active)
        mountScreenCharts(active); };
    const cleanup = () => { if (disposed)
        return; disposed = true; controller.abort(); hide(); window.removeEventListener('pagehide', hide); window.removeEventListener('pageshow', show); window.removeEventListener('blocks:language', draw); };
    window.addEventListener('pagehide', hide);
    window.addEventListener('pageshow', show);
    window.addEventListener('blocks:language', draw);
    void load();
    return cleanup;
}
// Retain the standalone example entry points for existing integrations.
if (document.body.dataset.example) {
    mountPreferences();
    mountAppearance();
    mountWorkspaceMotion(document.body);
    showExampleScreen(document.getElementById('main'), document.body.dataset.example === 'charts' ? 'charts' : 'components');
}
