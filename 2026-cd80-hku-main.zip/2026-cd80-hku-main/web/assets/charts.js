var __rewriteRelativeImportExtension = (this && this.__rewriteRelativeImportExtension) || function (path, preserveJsx) {
    if (typeof path === "string" && /^\.\.?\//.test(path)) {
        return path.replace(/\.(tsx)$|((?:\.d)?)((?:\.[^./]+?)?)\.([cm]?)ts$/i, function (m, tsx, d, ext, cm) {
            return tsx ? preserveJsx ? ".jsx" : ".js" : d && (!ext || !cm) ? m : (d + ext + "." + cm.toLowerCase() + "js");
        });
    }
    return path;
};
import { t, locale, formatNumber, statusText } from "./i18n.js";
const lifecycles = new WeakMap();
const vendorModule = './echarts.esm.min.js';
let library;
function node(tag, className, text) {
    const element = document.createElement(tag);
    if (className)
        element.className = className;
    if (text !== undefined)
        element.textContent = text;
    return element;
}
function label(value) {
    if (typeof value === 'string' && value.length > 0)
        return value;
    if (typeof value === 'number' && Number.isFinite(value))
        return String(value);
    return undefined;
}
// Exact numeric strings stay in the accessible table, rather than being rounded into a chart.
function number(value) {
    return typeof value === 'number' && Number.isFinite(value) && Math.abs(value) <= Number.MAX_SAFE_INTEGER ? value : '-';
}
function prepare(definition, result) {
    const kind = definition.chart;
    if (kind !== 'line' && kind !== 'bar' && kind !== 'candlestick' && kind !== 'heatmap') {
        throw new Error(t('This chart type is not available yet.'));
    }
    const xField = typeof definition.x === 'string' ? definition.x : '';
    const series = Array.isArray(definition.y) ? definition.y.filter((field) => typeof field === 'string') : [];
    const groupField = typeof definition.series === 'string' ? definition.series : undefined;
    if (definition.series !== undefined && (!groupField || (kind !== 'line' && kind !== 'bar')
        || series.length !== 1 || groupField === xField || series.includes(groupField))) {
        throw new Error(t('Grouped charts need a separate text series column and exactly one y column.'));
    }
    const ohlc = definition.ohlc;
    const heat = definition.heat;
    // ECharts expects open, close, low, high, in that order.
    const fields = kind === 'candlestick' ? [xField, ohlc?.open, ohlc?.close, ohlc?.low, ohlc?.high]
        : kind === 'heatmap' ? [xField, heat?.y, heat?.value] : [xField, ...series, ...(groupField ? [groupField] : [])];
    if (fields.length < 2 || fields.some((field) => !field || !result.columns.some((column) => column.name === field))) {
        throw new Error(t('The chart needs columns that are not available in this result.'));
    }
    if (result.rows.length === 0)
        throw new Error(t('There are no values to chart.'));
    if (result.rows.length > 5000)
        throw new Error(t('This chart has too many rows. Limit the result to 5,000 rows or fewer.'));
    const valueFields = kind === 'candlestick' ? fields.slice(1) : kind === 'heatmap' ? [heat.value] : series;
    const data = { kind, x: [], y: [], values: [], heat: [], fields: fields, valueFields, rows: result.rows, omitted: 0, hiddenGroups: [] };
    const groups = new Map();
    const xs = new Map();
    const ys = new Map();
    const pairs = new Set();
    let plotted = 0;
    for (const row of result.rows) {
        const x = label(row[xField]);
        if (x === undefined)
            throw new Error(t('Every chart row needs a category or date.'));
        if (groupField) {
            const group = row[groupField];
            if (typeof group !== 'string' || group.length === 0)
                throw new Error(t('Every grouped chart row needs a non-empty text series value.'));
            const key = JSON.stringify([x, group]);
            if (pairs.has(key))
                throw new Error(t('Several rows share a category and series. Group the result before charting it.'));
            pairs.add(key);
            if (!xs.has(x)) {
                xs.set(x, data.x.length);
                data.x.push(x);
            }
            if (!groups.has(group))
                groups.set(group, new Map());
            groups.get(group).set(x, number(row[series[0]]));
        }
        else if (kind === 'heatmap') {
            const y = label(row[heat.y]);
            if (y === undefined)
                throw new Error(t('Every heatmap row needs both categories.'));
            const key = JSON.stringify([x, y]);
            if (pairs.has(key))
                throw new Error(t('Several values share a heatmap cell. Group the result before charting it.'));
            pairs.add(key);
            if (!xs.has(x)) {
                xs.set(x, data.x.length);
                data.x.push(x);
            }
            if (!ys.has(y)) {
                ys.set(y, data.y.length);
                data.y.push(y);
            }
            const value = number(row[heat.value]);
            if (value === '-')
                data.omitted += 1;
            else {
                data.heat.push([xs.get(x), ys.get(y), value]);
                plotted += 1;
            }
        }
        else {
            if (xs.has(x))
                throw new Error(t('Several rows share a chart category. Group the result before charting it.'));
            xs.set(x, data.x.length);
            data.x.push(x);
            let values = data.fields.slice(1).map((field) => number(row[field]));
            if (kind === 'candlestick') {
                const [open, close, low, high] = values;
                const valid = values.every((value) => value !== '-')
                    && typeof open === 'number' && typeof close === 'number' && typeof low === 'number' && typeof high === 'number'
                    && low <= Math.min(open, close) && high >= Math.max(open, close);
                if (!valid) {
                    values = ['-', '-', '-', '-'];
                    data.omitted += 1;
                }
                else
                    plotted += 1;
            }
            else {
                data.omitted += values.filter((value) => value === '-').length;
                plotted += values.filter((value) => value !== '-').length;
            }
            data.values.push(values);
        }
    }
    if (groupField) {
        // Keep first-seen order; never join different companies or fill absent dates with zero.
        data.groupNames = [...groups.keys()].slice(0, 20);
        data.hiddenGroups = [...groups.keys()].slice(20);
        data.values = data.x.map((x) => data.groupNames.map((group) => groups.get(group).get(x) ?? '-'));
        for (const values of data.values) {
            data.omitted += values.filter((value) => value === '-').length;
            plotted += values.filter((value) => value !== '-').length;
        }
    }
    if (plotted === 0)
        throw new Error(t('There are no plottable numeric values. Missing and non-numeric values are not treated as zero.'));
    return data;
}
function options(definition, data, host, displayLabel) {
    const style = getComputedStyle(host);
    const css = (name) => style.getPropertyValue(name).trim();
    const size = parseFloat(style.fontSize);
    const fg = css('--fg');
    const muted = css('--muted');
    const border = css('--border');
    const axis = {
        axisLabel: { color: muted, fontSize: size, hideOverlap: true },
        axisLine: { lineStyle: { color: border } },
        axisTick: { lineStyle: { color: border } },
        splitLine: { lineStyle: { color: border } },
    };
    const option = {
        animation: false,
        backgroundColor: css('--surface'),
        color: [css('--accent'), css('--up'), css('--down'), muted, fg],
        textStyle: { color: fg, fontFamily: style.fontFamily, fontSize: size },
        aria: { enabled: true, decal: { show: true } },
        grid: { left: size, right: size * 2, top: size * 4, bottom: size * 4, containLabel: true },
        tooltip: { trigger: data.kind === 'heatmap' ? 'item' : 'axis', renderMode: 'richText', confine: true,
            valueFormatter: (value) => (Array.isArray(value) ? value : [value]).map((item) => typeof item === 'number' ? formatNumber(item) : String(item ?? '—')).join(', '),
            backgroundColor: css('--surface'), borderColor: border, textStyle: { color: fg, fontFamily: style.fontFamily } },
        legend: { type: 'scroll', top: 0, textStyle: { color: fg, fontFamily: style.fontFamily, fontSize: size } },
        xAxis: { ...axis, type: 'category', data: data.x, boundaryGap: data.kind !== 'line' },
        yAxis: { ...axis, type: 'value', scale: data.kind === 'candlestick', axisLabel: { ...axis.axisLabel, formatter: (value) => formatNumber(value) } },
    };
    if (data.kind === 'line' || data.kind === 'bar') {
        const kind = data.kind;
        option.series = (data.groupNames ?? data.fields.slice(1)).map((name, index) => ({
            type: kind, name: displayLabel(name), data: data.values.map((values) => values[index]),
            ...(definition.stacked === true ? { stack: 'total' } : {}),
            ...(kind === 'line' ? { connectNulls: false, symbolSize: size / 2 } : {}),
            emphasis: { focus: 'series' },
        }));
    }
    else if (data.kind === 'candlestick') {
        option.series = [{ type: 'candlestick', name: typeof definition.title === 'string' ? definition.title : t('Prices'),
                data: data.values,
                itemStyle: { color: css('--up'), color0: css('--down'), borderColor: css('--up'), borderColor0: css('--down'), borderColorDoji: muted },
            }];
    }
    else {
        option.yAxis = { ...axis, type: 'category', data: data.y, splitArea: { show: false } };
        const values = data.heat.map((cell) => cell[2]);
        // A symmetric range anchors zero at the neutral midpoint whenever signs are mixed.
        const extent = Math.max(...values.map(Math.abs)) || 1;
        const minimum = Math.min(...values) < 0 ? -extent : 0;
        const maximum = Math.max(...values) > 0 ? extent : minimum < 0 ? 0 : 1;
        option.visualMap = { type: 'continuous', min: minimum, max: maximum, dimension: 2,
            formatter: (value) => typeof value === 'number' ? formatNumber(value) : String(value ?? '—'),
            orient: 'horizontal', left: 'center', bottom: 0, calculable: false,
            textStyle: { color: fg },
            inRange: { color: minimum < 0 && maximum > 0 ? [css('--down'), css('--surface'), css('--up')]
                    : minimum < 0 ? [css('--down'), css('--surface')] : [css('--surface'), css('--up')] },
        };
        option.series = [{ type: 'heatmap', name: displayLabel(data.fields[2]), data: data.heat,
                itemStyle: { borderColor: border, borderWidth: 1 },
                label: { show: data.heat.length <= 100, color: fg, formatter: (item) => formatNumber(item.value[2]) },
            }];
    }
    if (data.kind !== 'heatmap' && data.x.length > 20) {
        option.dataZoom = [{ type: 'slider', bottom: 0, startValue: 0, endValue: 19,
                textStyle: { color: fg }, borderColor: border, fillerColor: css('--border'), handleStyle: { color: css('--accent') } }];
    }
    return option;
}
function dataTable(data, displayLabel) {
    const details = node('details', 'screen-chart-data');
    details.append(node('summary', undefined, t('View chart data')));
    const scroll = node('div', 'screen-table-scroll');
    scroll.tabIndex = 0;
    const table = node('table', 'screen-data-table');
    table.append(node('caption', 'screen-visually-hidden', t('Chart source values')));
    const header = node('tr');
    for (const field of data.fields) {
        const cell = node('th', undefined, displayLabel(field));
        cell.scope = 'col';
        header.append(cell);
    }
    const head = node('thead');
    head.append(header);
    const body = node('tbody');
    for (const row of data.rows.slice(0, 100)) {
        const line = node('tr');
        for (const field of data.fields) {
            const value = row[field];
            const numeric = typeof value === 'number' || typeof value === 'bigint' || typeof value === 'string' && /^-?\d+(?:\.\d+)?$/.test(value);
            line.append(node('td', undefined, data.valueFields.includes(field) && numeric ? formatNumber(value) : label(value) ?? '—'));
        }
        body.append(line);
    }
    table.append(head, body);
    scroll.append(table);
    details.append(scroll);
    if (data.rows.length > 100)
        details.append(node('p', 'screen-caption', t('Showing the first 100 of {count} source rows.', { count: data.rows.length })));
    return details;
}
/** Prepare a chart while detached. Call mountScreenCharts after inserting the screen. */
export function renderChart(definition, result, headingLevel, displayLabel = (value) => value) {
    const panel = node('section', 'screen-panel screen-chart');
    const title = typeof definition.title === 'string' ? definition.title : t('Chart');
    panel.append(node(`h${Math.min(6, Math.max(2, headingLevel))}`, 'screen-heading', title));
    let data;
    try {
        if (!result)
            throw new Error(t('The result for this chart is not available yet.'));
        data = prepare(definition, result);
    }
    catch (error) {
        panel.append(node('p', 'screen-empty', error instanceof Error ? error.message : 'This chart could not be displayed.'));
        return panel;
    }
    const host = node('div', 'screen-chart-canvas');
    host.setAttribute('role', 'img');
    host.setAttribute('aria-label', t('{title}. {kind} chart. Source values are available below.', { title, kind: statusText(data.kind) }));
    const status = node('p', 'screen-caption', t('Preparing chart…'));
    status.setAttribute('role', 'status');
    panel.append(status, host);
    if (data.hiddenGroups.length)
        panel.append(node('p', 'screen-caption', t('Showing the first 20 series in result order. Hidden series: {names}.', { names: data.hiddenGroups.join(', ') })));
    if (data.omitted)
        panel.append(node('p', 'screen-caption', t('Missing, invalid or precision-sensitive values are left blank. See source values below.')));
    panel.append(dataTable(data, displayLabel));
    panel.dataset.chart = data.kind;
    let instance;
    let resize;
    let theme;
    let mounted = false;
    let needsRedraw = false;
    let generation = 0;
    const dispose = () => {
        generation += 1;
        mounted = false;
        resize?.disconnect();
        theme?.disconnect();
        instance?.dispose();
        resize = undefined;
        theme = undefined;
        instance = undefined;
    };
    const mount = () => {
        if (mounted || !host.isConnected)
            return;
        mounted = true;
        const current = ++generation;
        library ??= import(__rewriteRelativeImportExtension(vendorModule, true)).catch((error) => { library = undefined; throw error; });
        void library.then((echarts) => {
            if (!mounted || current !== generation || !host.isConnected)
                return;
            const draw = () => {
                if (host.clientWidth === 0 || host.clientHeight === 0)
                    return;
                instance ??= echarts.init(host, undefined, { renderer: 'canvas' });
                instance.setOption(options(definition, data, host, displayLabel), { notMerge: true });
                instance.resize();
                status.hidden = true;
            };
            const safeDraw = () => {
                // A result tab can be hidden when the theme changes. Apply its new
                // palette when it becomes visible, instead of only resizing old colors.
                if (host.clientWidth === 0 || host.clientHeight === 0) {
                    needsRedraw = true;
                    return;
                }
                needsRedraw = false;
                try {
                    draw();
                }
                catch {
                    dispose();
                    status.hidden = false;
                    status.textContent = t('The chart could not be displayed. Source values are available below.');
                }
            };
            resize = new ResizeObserver(() => {
                if (!host.isConnected) {
                    dispose();
                    return;
                }
                if (instance && !needsRedraw)
                    instance.resize();
                else
                    safeDraw();
            });
            resize.observe(host);
            theme = new MutationObserver(safeDraw);
            theme.observe(document.documentElement, { attributes: true, attributeFilter: ['data-theme', 'data-convention', 'style', 'class'] });
            safeDraw();
        }).catch(() => {
            if (current !== generation)
                return;
            dispose();
            status.hidden = false;
            status.textContent = t('The chart could not be loaded. Refresh to try again. Source values are available below.');
        });
    };
    lifecycles.set(panel, { mount, dispose });
    return panel;
}
export function mountScreenCharts(root) {
    for (const panel of Array.from(root.querySelectorAll('[data-chart]')))
        lifecycles.get(panel)?.mount();
}
export function disposeScreenCharts(root) {
    for (const panel of Array.from(root.querySelectorAll('[data-chart]')))
        lifecycles.get(panel)?.dispose();
}
