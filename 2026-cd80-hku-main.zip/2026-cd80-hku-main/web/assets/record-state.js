/** Preserve unrelated saved values when reconciling a single list mutation. */
export function settingsAfterListAction(previous, snapshot, param) {
    const changed = snapshot.params.find((entry) => entry.key === param);
    if (!previous || !changed)
        return undefined;
    return { ...previous, params: { ...previous.params, [param]: [...changed.values] } };
}
function ordered(value) {
    if (Array.isArray(value))
        return value.map(ordered);
    if (value && typeof value === 'object')
        return Object.fromEntries(Object.entries(value).sort(([a], [b]) => a.localeCompare(b)).map(([key, entry]) => [key, ordered(entry)]));
    return value;
}
/** Accept a new revision only when no unrelated saved settings changed. */
export function sameSettings(first, second) {
    return JSON.stringify(ordered(first)) === JSON.stringify(ordered(second));
}
