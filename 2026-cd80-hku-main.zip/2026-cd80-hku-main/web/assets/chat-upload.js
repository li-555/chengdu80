import { locale, statusText, t } from "./i18n.js";
import { parseMarkdownDocument } from "./markdown-tables.js";
import { uploadMetadata as baseUploadMetadata, metadataChatState as baseChatState, readUploadPacket } from "./upload-preview.js";
export const MAX_ATTACHED_TABLES = 5;
export const UPLOAD_ACCEPT = '.csv,.tsv,.xlsx,.xls,.xlsm,.md';
export function validateUpload(file) {
    if (!/\.(csv|tsv|xlsx|xls|xlsm|md)$/i.test(file.name))
        throw new Error('Upload a CSV, TSV, Excel or Markdown file.');
    if (file.size > 20 * 1024 * 1024)
        throw new Error('Upload a file no larger than 20 MB.');
}
export function appendDescription(input, description) {
    return description ? [input.trim(), description].filter(Boolean).join('\n\n') : input;
}
/** Preflight the complete batch before any persistence. Prose stays editable in the composer. */
export async function prepareChatUploads(files, input) {
    if (files.length > 5)
        throw new Error('Upload at most 5 files at a time.');
    for (const file of files)
        validateUpload(file);
    const prepared = [];
    let combined = input;
    for (const file of files) {
        const document = /\.md$/i.test(file.name) ? parseMarkdownDocument(await file.text()) : undefined;
        if (document && !document.description && !document.tables.length)
            throw new Error('This Markdown file has no description or tables.');
        const description = document?.description ?? '';
        combined = appendDescription(combined, description);
        if (combined.length > 4000)
            throw new Error('Your message and Markdown descriptions exceed 4,000 characters. Shorten them before uploading.');
        prepared.push({ file, description, hasTables: document ? document.tables.length > 0 : true });
    }
    return prepared;
}
export async function uploadWorkbook(file) {
    validateUpload(file);
    const response = await fetch(`/api/uploads?filename=${encodeURIComponent(file.name)}`, {
        method: 'POST', credentials: 'same-origin', headers: { 'Content-Type': 'application/octet-stream', 'X-Blocks-Request': '1' },
        body: file, signal: AbortSignal.timeout(90_000),
    });
    const result = await response.json();
    if (!response.ok)
        throw new Error(result.error?.message ?? 'The file could not be uploaded. Try again.');
    return result;
}
/** Project only metadata into transcript and session state. */
export function uploadMetadata(file) {
    return { ...baseUploadMetadata(file),
        ...(typeof file.sourceFile === 'string' ? { sourceFile: file.sourceFile } : {}),
        ...(typeof file.sheetName === 'string' ? { sheetName: file.sheetName } : {}) };
}
export function metadataChatState(state) {
    const safe = baseChatState(state);
    return { ...safe, attachments: state.attachments.map(uploadMetadata),
        ...(state.available ? { available: state.available.map(uploadMetadata) } : {}),
        messages: safe.messages.map((message, index) => ({ ...message,
            ...(message.files ? { files: state.messages.slice(-60)[index].files.map(uploadMetadata) } : {}) })) };
}
export function selectTable(current, file, selected) {
    const rest = current.filter((item) => item.id !== file.id);
    if (!selected)
        return rest;
    if (rest.length >= MAX_ATTACHED_TABLES)
        throw new Error('Select at most 5 tables per message.');
    return [...rest, uploadMetadata(file)];
}
export function chatPayload(message, conversationId, files) {
    const ids = [...new Set(files.map((file) => file.id))];
    if (ids.length > MAX_ATTACHED_TABLES)
        throw new Error('Select at most 5 tables per message.');
    return { message, ...(conversationId ? { conversationId } : {}), ...(ids.length ? { uploads: ids } : {}) };
}
const previews = new Map();
const expanded = new Set();
function rememberPreview(id, value) {
    previews.delete(id);
    previews.set(id, value);
    while (previews.size > 20) {
        const oldest = previews.keys().next().value;
        if (oldest === undefined)
            break;
        previews.delete(oldest);
    }
}
export function clearUploadPreviews() { previews.clear(); expanded.clear(); }
export function cacheUploadPreview(value) { rememberPreview(value.dataset.id, Promise.resolve(value)); }
function preview(id) {
    let pending = previews.get(id);
    if (!pending) {
        pending = fetch(`/api/uploads/${encodeURIComponent(id)}/preview`, { credentials: 'same-origin', cache: 'no-store', signal: AbortSignal.timeout(30_000) })
            .then(async (response) => {
            if (!response.ok)
                throw new Error('The table preview could not be loaded.');
            return await response.json();
        }).catch((error) => { if (previews.get(id) === pending)
            previews.delete(id); throw error; });
        rememberPreview(id, pending);
    }
    return pending;
}
function node(tag, text) {
    const el = document.createElement(tag);
    if (text !== undefined)
        el.textContent = text;
    return el;
}
function table(title, headings, rows) {
    const wrapper = node('div');
    wrapper.className = 'chat-preview-scroll';
    wrapper.tabIndex = 0;
    wrapper.setAttribute('role', 'region');
    wrapper.setAttribute('aria-label', title);
    const el = node('table');
    el.append(node('caption', title));
    const head = node('thead');
    const header = node('tr');
    for (const label of headings) {
        const th = node('th', label);
        th.scope = 'col';
        header.append(th);
    }
    head.append(header);
    el.append(head);
    const body = node('tbody');
    for (const row of rows) {
        const tr = node('tr');
        for (const value of row)
            tr.append(node('td', value));
        body.append(tr);
    }
    el.append(body);
    wrapper.append(el);
    return wrapper;
}
function renderPreview(value) {
    const content = node('div');
    content.className = 'chat-preview';
    const safe = readUploadPacket(value);
    const columns = safe.preview?.columns ?? [];
    content.append(node('p', t('Preview: first 5 rows. Statistics cover the full table.')));
    if (safe.preview?.rows.length)
        content.append(table(t('Table preview'), columns, safe.preview.rows));
    else
        content.append(node('p', t('This table has headers but no data rows.')));
    if (safe.preview?.shortened)
        content.append(node('p', t('Wide tables and long values are shortened in this preview.')));
    const fields = node('ul');
    for (const field of safe.upload.fields.slice(0, 200))
        fields.append(node('li', `${field.name} · ${statusText(field.type)}${field.blankCount === undefined ? '' : ` · ${t('{count} blanks', { count: field.blankCount })}`}`));
    content.append(fields);
    if (!value.analysis)
        content.append(node('p', t('Statistics are unavailable for this table. The table is still saved and usable.')));
    else {
        const number = (value) => value === undefined ? '—' : value.toLocaleString(locale(), { maximumSignificantDigits: 15 });
        const statistics = node('details');
        statistics.className = 'upload-statistics';
        statistics.append(node('summary', t('Column statistics')));
        statistics.append(table(t('Column statistics'), ['Column', 'Type', 'Numeric values', 'Empty cells', 'Minimum', 'Maximum', 'Mean', 'Sum', 'Outliers'].map((key) => t(key)), value.analysis.columns.slice(0, 200).map((column) => [column.name, statusText(column.type), number(column.stats?.count), number(column.nulls),
            number(column.stats?.min), number(column.stats?.max), number(column.stats?.mean), number(column.stats?.sum), number(column.outliers)])));
        statistics.append(node('p', t('Empty cells are missing cells or empty strings. Outliers are numeric values more than 3 population standard deviations from the mean.')));
        if (value.analysis.columns.length > 200)
            statistics.append(node('p', t('Statistics show the first 200 columns.')));
        content.append(statistics);
    }
    content.append(node('p', t('Preview rows and statistics are only shown to you; they are not attached to the builder.')));
    return content;
}
export function uploadSummary(file) {
    const el = node('details');
    el.className = 'chat-file';
    el.open = expanded.has(file.id);
    el.append(node('summary', file.sheetName || file.name));
    const overview = node('p', t('{count} rows · {columns} columns', { count: file.rowCount ?? '—', columns: file.fields.length }));
    overview.className = 'field-help';
    el.append(overview);
    const contents = node('div');
    el.append(contents);
    let loaded = false;
    const load = async () => {
        if (loaded)
            return;
        loaded = true;
        contents.replaceChildren(node('p', t('Loading table preview…')));
        try {
            const value = await preview(file.id);
            contents.replaceChildren(renderPreview(value));
        }
        catch {
            const retry = node('button', t('Try again'));
            retry.type = 'button';
            retry.className = 'button button-secondary';
            retry.addEventListener('click', () => { loaded = false; void load(); });
            contents.replaceChildren(node('p', t('The table preview could not be loaded.')), retry);
        }
    };
    el.addEventListener('toggle', () => { if (el.open) {
        expanded.add(file.id);
        void load();
    }
    else
        expanded.delete(file.id); });
    if (el.open)
        void load();
    return el;
}
/** Lazy preview shared by the catalogue and chat; rows never enter session metadata. */
export function createUploadPreview(id) {
    const content = node('div');
    content.className = 'upload-preview';
    const load = async () => {
        content.replaceChildren(node('p', t('Loading table preview…')));
        try {
            content.replaceChildren(renderPreview(await preview(id)));
        }
        catch {
            const retry = node('button', t('Try again'));
            retry.type = 'button';
            retry.className = 'button button-secondary';
            retry.addEventListener('click', () => { void load(); });
            content.replaceChildren(node('p', t('The table preview could not be loaded.')), retry);
        }
    };
    void load();
    return content;
}
