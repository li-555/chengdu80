import { t } from "./i18n.js";
/** Validate draft text before it becomes a run parameter. Empty numbers never become zero. */
export function parseControlValue(param, raw) {
    const invalid = (message) => ({ ok: false, message });
    if (param.list)
        return { ok: true, value: raw.split('\n').map((value) => value.trim()).filter(Boolean) };
    if (param.type === 'boolean')
        return raw === 'true' || raw === 'false' ? { ok: true, value: raw === 'true' } : invalid(t('Choose Yes or No.'));
    if (param.type === 'number') {
        if (!raw.trim() || !Number.isFinite(Number(raw)))
            return invalid(t('Enter a finite number.'));
        const value = Number(raw);
        if (param.min !== undefined && value < param.min)
            return invalid(t('Enter a value of at least {value}.', { value: param.min }));
        if (param.max !== undefined && value > param.max)
            return invalid(t('Enter a value no greater than {value}.', { value: param.max }));
        if (param.step !== undefined) {
            const steps = (value - (param.min ?? 0)) / param.step;
            if (Math.abs(steps - Math.round(steps)) > 1e-8 * Math.max(1, Math.abs(steps)))
                return invalid(t('Use increments of {value}.', { value: param.step }));
        }
        return { ok: true, value };
    }
    if (param.type === 'date' && (!/^\d{4}-\d{2}-\d{2}$/.test(raw) || Number.isNaN(Date.parse(raw + 'T00:00:00Z')) || new Date(raw + 'T00:00:00Z').toISOString().slice(0, 10) !== raw))
        return invalid(t('Enter a valid date.'));
    if (param.options && !param.options.some((option) => option.value === raw))
        return invalid(t('Choose one of the listed options.'));
    return { ok: true, value: raw };
}
/** Peers share the existing parameter draft; this object never owns a second copy. */
export class ScreenControls {
    hooks;
    peers = new Map();
    buttons = [];
    ranges = [];
    constructor(hooks) { this.hooks = hooks; }
    param(key) { return this.hooks.params.find((param) => param.key === key); }
    error(key) {
        const param = this.param(key);
        if (!param)
            return t('This setting is not available.');
        const result = parseControlValue(param, this.hooks.getRaw(key));
        if (!result.ok)
            return result.message;
        for (const range of this.ranges)
            if (range.to === key && this.hooks.getRaw(range.from) && this.hooks.getRaw(range.to) && this.hooks.getRaw(range.from) > this.hooks.getRaw(range.to))
                return t('End date must be on or after the start date.');
        return '';
    }
    connect(key, peer) { this.peers.set(key, [...(this.peers.get(key) ?? []), peer]); this.sync(); }
    range(from, to) { this.ranges.push({ from, to }); }
    connectButton(button) { this.buttons.push(button); this.sync(); }
    update(key, raw) {
        if (!this.param(key) || !this.hooks.canEdit())
            return;
        this.hooks.setRaw(key, raw);
        this.sync();
    }
    sync() {
        for (const [key, peers] of this.peers)
            for (const peer of peers) {
                peer.value(this.hooks.getRaw(key));
                peer.disabled(!this.hooks.canEdit());
                peer.error(this.error(key));
            }
        for (const button of this.buttons)
            button.disabled = !this.hooks.canRun();
    }
    valid() {
        this.sync();
        for (const param of this.hooks.params)
            if (this.error(param.key)) {
                const peer = this.peers.get(param.key)?.[0];
                if (peer)
                    peer.report();
                else
                    this.hooks.reportValidity();
                return false;
            }
        return this.hooks.reportValidity();
    }
    run() {
        if (!this.hooks.canRun() || !this.valid())
            return false;
        this.hooks.onRun();
        return true;
    }
}
function setting(key, labelText, context, placeholder) {
    const label = document.createElement('label');
    label.className = 'run-setting';
    label.append(document.createTextNode(labelText));
    const param = context.param(key);
    if (!param) {
        const message = document.createElement('p');
        message.className = 'field-help';
        message.textContent = t('This setting is not available.');
        label.append(message);
        return label;
    }
    let input;
    if (param.list) {
        input = document.createElement('textarea');
        input.setAttribute('aria-label', t('{label} (one value per line)', { label: labelText }));
        const help = document.createElement('span');
        help.className = 'field-help';
        help.textContent = t('One value per line.');
        label.append(help);
    }
    else if (param.options || param.type === 'boolean') {
        input = document.createElement('select');
        const choices = param.options ?? [{ value: 'true', label: t('Yes') }, { value: 'false', label: t('No') }];
        const empty = document.createElement('option');
        empty.value = '';
        empty.textContent = t('Choose an option');
        input.append(empty);
        for (const choice of choices) {
            const option = document.createElement('option');
            option.value = choice.value;
            option.textContent = choice.label;
            input.append(option);
        }
    }
    else {
        input = document.createElement('input');
        input.type = param.type === 'number' ? 'number' : param.type === 'date' ? 'date' : 'text';
        if (param.type === 'number') {
            input.step = param.step === undefined ? 'any' : String(param.step);
            if (param.min !== undefined)
                input.min = String(param.min);
            if (param.max !== undefined)
                input.max = String(param.max);
        }
    }
    if (placeholder && (input instanceof HTMLInputElement || input instanceof HTMLTextAreaElement))
        input.placeholder = placeholder;
    input.required = !param.list && (param.type !== 'text' || param.options !== undefined);
    input.addEventListener('input', () => context.update(key, input.value));
    input.addEventListener('change', () => context.update(key, input.value));
    context.connect(key, { value: (raw) => { if (input.value !== raw)
            input.value = raw; }, disabled: (disabled) => { input.disabled = disabled; }, error: (message) => { input.setCustomValidity(message); input.setAttribute('aria-invalid', String(Boolean(message))); }, report: () => input.reportValidity() });
    label.append(input);
    return label;
}
export function renderScreenControl(definition, context) {
    const section = document.createElement('section');
    section.className = 'screen-panel screen-control';
    if (!context) {
        const message = document.createElement('p');
        message.className = 'screen-empty';
        message.textContent = t('Open this application to change its settings.');
        section.append(message);
        return section;
    }
    const label = typeof definition.label === 'string' ? definition.label : t('Setting');
    if (definition.type === 'RunButton') {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'button button-primary';
        button.textContent = label;
        button.addEventListener('click', () => { context.run(); });
        context.connectButton(button);
        section.append(button);
    }
    else if (definition.type === 'DateRangeInput') {
        const from = String(definition.fromParam), to = String(definition.toParam);
        context.range(from, to);
        section.append(setting(from, t('{label} · Start date', { label }), context), setting(to, t('{label} · End date', { label }), context));
    }
    else
        section.append(setting(String(definition.param), label, context, typeof definition.placeholder === 'string' ? definition.placeholder : undefined));
    return section;
}
