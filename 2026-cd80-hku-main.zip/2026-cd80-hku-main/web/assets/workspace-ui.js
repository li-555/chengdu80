export function filterApps(apps, query, sort, locale) {
    const term = query.trim().toLocaleLowerCase(locale);
    return apps.filter((app) => `${app.name}\n${app.description}`.toLocaleLowerCase(locale).includes(term))
        .sort((a, b) => sort === 'name' ? a.name.localeCompare(b.name, locale) || a.id.localeCompare(b.id)
        : (sort === 'created' ? b.createdAt.localeCompare(a.createdAt) : b.updatedAt.localeCompare(a.updatedAt)) || a.id.localeCompare(b.id));
}
/** Keep panels mounted so tab changes preserve forms, selections and results. */
export function createTabs(id, label, items) {
    const root = document.createElement('div');
    root.className = 'workspace-tabs';
    const list = document.createElement('div');
    list.className = 'tab-list';
    list.setAttribute('role', 'tablist');
    list.setAttribute('aria-label', label);
    const buttons = items.map((item) => {
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'tab-button';
        button.textContent = item.label;
        button.id = `${id}-tab-${item.id}`;
        button.setAttribute('role', 'tab');
        button.setAttribute('aria-controls', `${id}-panel-${item.id}`);
        item.panel.id = `${id}-panel-${item.id}`;
        item.panel.setAttribute('role', 'tabpanel');
        item.panel.setAttribute('aria-labelledby', button.id);
        item.panel.tabIndex = 0;
        button.addEventListener('click', () => select(item.id));
        list.append(button);
        return button;
    });
    function select(value, focus = false) {
        const index = items.findIndex((item) => item.id === value);
        if (index < 0)
            return;
        items.forEach((item, i) => {
            item.panel.hidden = i !== index;
            buttons[i].tabIndex = i === index ? 0 : -1;
            buttons[i].setAttribute('aria-selected', String(i === index));
        });
        if (focus)
            buttons[index].focus();
        items[index].activate?.();
    }
    list.addEventListener('keydown', (event) => {
        const current = buttons.indexOf(document.activeElement);
        if (current < 0)
            return;
        const next = event.key === 'ArrowRight' ? (current + 1) % items.length
            : event.key === 'ArrowLeft' ? (current + items.length - 1) % items.length
                : event.key === 'Home' ? 0 : event.key === 'End' ? items.length - 1 : -1;
        if (next >= 0) {
            event.preventDefault();
            select(items[next].id, true);
        }
    });
    root.append(list, ...items.map((item) => item.panel));
    // Initial selection does not trigger loading until the caller has mounted it.
    items.forEach((item, index) => { item.panel.hidden = index !== 0; buttons[index].tabIndex = index === 0 ? 0 : -1; buttons[index].setAttribute('aria-selected', String(index === 0)); });
    return { root, select };
}
