function event(value) {
    if (!value || typeof value !== 'object')
        throw new Error('Invalid chat event.');
    const v = value;
    const strings = (...names) => names.every((name) => typeof v[name] === 'string');
    if ((v.kind === 'conversation' && strings('conversationId')) || (v.kind === 'progress' && strings('stage', 'line'))
        || (v.kind === 'question' && Array.isArray(v.questions) && v.questions.every((q) => typeof q === 'string') && typeof v.acceptsFile === 'boolean')
        || (v.kind === 'built' && strings('appId', 'name', 'description') && typeof v.updated === 'boolean')
        || (v.kind === 'failed' && strings('reason', 'summary') && (v.draftId === undefined || strings('draftId'))))
        return v;
    throw new Error('Invalid chat event.');
}
/** Decode UTF-8 incrementally, including split code points and CRLF event boundaries. */
export async function readChatStream(stream, receive) {
    const reader = stream.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let data = [];
    let terminal = false;
    let conversation = false;
    const dispatch = () => {
        if (!data.length)
            return;
        const parsed = event(JSON.parse(data.join('\n')));
        data = [];
        if (terminal || (!conversation && parsed.kind !== 'conversation'))
            throw new Error('Invalid chat event order.');
        if (parsed.kind === 'conversation') {
            if (conversation)
                throw new Error('Duplicate conversation.');
            conversation = true;
        }
        terminal = ['built', 'question', 'failed'].includes(parsed.kind);
        receive(parsed);
    };
    const line = (raw) => {
        const value = raw.endsWith('\r') ? raw.slice(0, -1) : raw;
        if (value === '')
            dispatch();
        else if (value.startsWith('data:'))
            data.push(value.slice(5).replace(/^ /, ''));
    };
    try {
        while (true) {
            const { value, done } = await reader.read();
            buffer += decoder.decode(value, { stream: !done });
            if (buffer.length > 1_000_000)
                throw new Error('Chat event is too large.');
            let end;
            while ((end = buffer.indexOf('\n')) >= 0) {
                line(buffer.slice(0, end));
                buffer = buffer.slice(end + 1);
            }
            if (done) {
                if (buffer)
                    line(buffer);
                dispatch();
                break;
            }
        }
        if (!terminal)
            throw new Error('Chat ended before a final event.');
    }
    finally {
        await reader.cancel().catch(() => { });
        reader.releaseLock();
    }
}
