import { t } from "./i18n.js";
function node(tag, text, className) { const result = document.createElement(tag); if (text !== undefined)
    result.textContent = text; if (className)
    result.className = className; return result; }
export function createListActionPanel(appId, onSaved, canEdit = () => true, displayLabel = (value) => value) {
    const panel = node('section', undefined, 'screen-panel');
    panel.dataset.listActions = 'true';
    panel.append(node('h2', t('Saved list actions')), node('p', t('Add or remove a record ID from a saved list setting, then rerun the application. These are local workflow settings, not institutional approvals.'), 'field-help'));
    const form = node('form');
    const settingLabel = node('label', t('Setting'), 'run-setting');
    const setting = node('select');
    settingLabel.append(setting);
    const idLabel = node('label', t('Record ID'), 'run-setting');
    const recordId = node('input');
    recordId.required = true;
    recordId.maxLength = 200;
    idLabel.append(recordId);
    const actionLabel = node('label', t('Action'), 'run-setting');
    const action = node('select');
    for (const value of ['add', 'remove']) {
        const option = node('option', t(value === 'add' ? 'Add' : 'Remove'));
        option.value = value;
        action.append(option);
    }
    actionLabel.append(action);
    const noteLabel = node('label', t('Note'), 'run-setting');
    const note = node('textarea');
    note.maxLength = 1000;
    noteLabel.append(note);
    const save = node('button', t('Save action'), 'button button-primary');
    save.type = 'submit';
    const refresh = node('button', t('Refresh'), 'button button-secondary');
    refresh.type = 'button';
    const feedback = node('div');
    feedback.setAttribute('role', 'status');
    const current = node('p', undefined, 'field-help');
    const history = node('div');
    form.append(settingLabel, idLabel, actionLabel, noteLabel, save, refresh);
    panel.append(form, current, feedback, history);
    let snapshot, busy = false, pending;
    const controls = [setting, recordId, action, note];
    function update() { controls.forEach((control) => { control.disabled = busy || !!pending || !canEdit(); }); save.disabled = busy || !snapshot?.params.length || !canEdit(); refresh.disabled = busy; save.textContent = t(pending ? 'Retry same action' : 'Save action'); panel.dispatchEvent(new Event('blocks:list-action-state', { bubbles: true })); current.textContent = `${t('Saved IDs')}: ${(snapshot?.params.find((param) => param.key === setting.value)?.values ?? []).join(', ') || t('None')}`; }
    function show(value) {
        const previous = setting.value;
        snapshot = value;
        setting.replaceChildren();
        for (const param of value.params) {
            const option = node('option', displayLabel(param.label));
            option.value = param.key;
            setting.append(option);
        }
        if (value.params.some((param) => param.key === previous))
            setting.value = previous;
        history.replaceChildren(node('h3', t('Local action history')));
        if (!value.history.length)
            history.append(node('p', t('No saved actions yet.'), 'field-help'));
        for (const event of [...value.history].reverse()) {
            const item = node('details');
            item.append(node('summary', `${event.time} · ${displayLabel(value.params.find((param) => param.key === event.param)?.label ?? event.param)} · ${t(event.action === 'add' ? 'Add' : 'Remove')} · ${event.recordId}`), node('p', event.note), node('p', `${t('Before')}: ${event.before.join(', ') || t('None')} → ${t('After')}: ${event.after.join(', ') || t('None')}`, 'field-help'));
            history.append(item);
        }
        update();
    }
    async function request(init) { const controller = new AbortController(); const timeout = window.setTimeout(() => controller.abort(), 30_000); try {
        const response = await fetch(`/api/apps/${encodeURIComponent(appId)}/list-actions`, { credentials: 'same-origin', ...init, signal: controller.signal });
        const body = await response.json();
        if (!response.ok)
            throw Object.assign(new Error(body.error?.message ?? t('The action could not be confirmed.')), { status: response.status });
        return body;
    }
    finally {
        window.clearTimeout(timeout);
    } }
    async function load() { if (busy)
        return; busy = true; update(); try {
        const value = await request();
        if (!panel.isConnected)
            return;
        show(value);
        feedback.replaceChildren();
    }
    catch (error) {
        if (panel.isConnected)
            feedback.replaceChildren(node('p', error instanceof Error ? t(error.message) : t('Saved actions could not be loaded.'), 'notice'));
    }
    finally {
        busy = false;
        update();
    } }
    async function submit(input) {
        if (busy || !snapshot || !canEdit() || (input && pending))
            return false;
        if (input && (!snapshot.params.some((param) => param.key === input.param) || !input.recordId.trim() || input.recordId.length > 200 || input.note.length > 1000 || !['add', 'remove'].includes(input.action)))
            return false;
        pending ??= { ...(input ?? { param: setting.value, recordId: recordId.value, action: action.value, note: note.value }), requestId: crypto.randomUUID(), revision: snapshot.revision };
        const affected = pending.param;
        busy = true;
        update();
        try {
            const value = await request({ method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Blocks-Request': '1' }, body: JSON.stringify(pending) });
            pending = undefined;
            if (!panel.isConnected)
                return false;
            show(value.snapshot);
            feedback.replaceChildren(node('p', t('Saved. Rerun to apply the changed list setting.')));
            await onSaved(value.snapshot, affected);
            return true;
        }
        catch (error) {
            if (error && typeof error === 'object' && 'status' in error && [400, 404, 409, 413, 422].includes(error.status))
                pending = undefined;
            if (panel.isConnected)
                feedback.replaceChildren(node('p', error instanceof Error ? t(error.message) : t('The action could not be confirmed.'), 'notice'));
            return false;
        }
        finally {
            busy = false;
            update();
        }
    }
    form.addEventListener('submit', (event) => { event.preventDefault(); if (!pending && !form.reportValidity())
        return; void submit(); });
    refresh.addEventListener('click', () => { void load(); });
    setting.addEventListener('change', update);
    panel.addEventListener('blocks:availability', update);
    queueMicrotask(() => { if (panel.isConnected)
        void load(); });
    return Object.assign(panel, { snapshot: () => snapshot, isBusy: () => busy || !!pending, refresh: load, saveRecordAction: (input) => submit(input) });
}
