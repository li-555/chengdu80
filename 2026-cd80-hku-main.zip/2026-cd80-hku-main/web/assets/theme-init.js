/** Classic head script: apply appearance before stylesheets and module loading. */
(() => {
    let theme = window.matchMedia?.('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    try {
        const saved = window.localStorage.getItem('blocks:theme');
        if (saved === 'dark' || saved === 'night')
            theme = 'dark';
        else if (saved === 'light' || saved === 'daylight' || saved === 'paper' || saved === 'desk')
            theme = 'light';
    }
    catch { /* The system preference works when storage is unavailable. */ }
    document.documentElement.dataset.theme = theme;
    document.documentElement.style.colorScheme = theme;
    // Restore validated appearance before CSS and the first paint; the module owns later changes.
    try {
        const saved = JSON.parse(window.localStorage.getItem('blocks:appearance') ?? '{}');
        for (const key of ['motion', 'cursor'])
            if (typeof saved[key] === 'boolean')
                document.documentElement.dataset[key] = saved[key] ? 'on' : 'off';
        for (const [key, min, max, unit] of [['radius', 8, 36, 'px'], ['sidebar', 196, 280, 'px'], ['space', .8, 1.3, '']]) {
            if (typeof saved[key] === 'number' && Number.isFinite(saved[key]))
                document.documentElement.style.setProperty(`--${key}`, `${Math.max(min, Math.min(max, saved[key]))}${unit}`);
        }
        for (const token of ['--accent', '--bg', '--surface', '--fg']) {
            const value = saved[theme]?.[token];
            if (typeof value === 'string' && /^#[\da-f]{6}$/i.test(value))
                document.documentElement.style.setProperty(token, value);
        }
    }
    catch { /* Invalid or unavailable storage retains the accepted defaults. */ }
    try {
        document.documentElement.lang = window.localStorage.getItem('blocks:language') === 'zh' ? 'zh-CN' : 'en';
    }
    catch { /* The document's default language remains usable. */ }
})();
