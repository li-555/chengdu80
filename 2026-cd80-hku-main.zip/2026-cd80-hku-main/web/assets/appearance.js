import { uiIcon } from "./ui-icon.js";
import { getLanguage, getTheme, setLanguage, t } from "./i18n.js";
import { magneticButton } from "./motion-elements.js";
const key = 'blocks:appearance';
const defaults = () => ({ motion: true, cursor: true, radius: 24, sidebar: 224, space: 1, light: {}, dark: {} });
const colors = ['--accent', '--bg', '--surface', '--fg'];
let design = defaults();
try {
    const saved = JSON.parse(localStorage.getItem(key) ?? '{}');
    for (const name of ['motion', 'cursor'])
        if (typeof saved[name] === 'boolean')
            design[name] = saved[name];
    for (const [name, min, max] of [['radius', 8, 36], ['sidebar', 196, 280], ['space', .8, 1.3]])
        if (typeof saved[name] === 'number' && Number.isFinite(saved[name]))
            design[name] = Math.max(min, Math.min(max, saved[name]));
    for (const theme of ['light', 'dark'])
        for (const token of colors)
            if (/^#[\da-f]{6}$/i.test(saved[theme]?.[token] ?? ''))
                design[theme][token] = saved[theme][token];
}
catch { /* Appearance remains usable without storage. */ }
function apply() {
    const root = document.documentElement;
    root.dataset.motion = design.motion ? 'on' : 'off';
    root.dataset.cursor = design.cursor ? 'on' : 'off';
    root.style.setProperty('--radius', `${design.radius}px`);
    root.style.setProperty('--sidebar', `${design.sidebar}px`);
    root.style.setProperty('--space', String(design.space));
    for (const token of colors) {
        const value = design[getTheme()][token];
        if (value)
            root.style.setProperty(token, value);
        else
            root.style.removeProperty(token);
    }
    window.dispatchEvent(new Event('blocks:appearance'));
}
function save() { try {
    localStorage.setItem(key, JSON.stringify(design));
}
catch { /* Keep the current appearance. */ } apply(); }
function node(tag, text, className) {
    const result = document.createElement(tag);
    if (text)
        result.textContent = t(text);
    if (className)
        result.className = className;
    return result;
}
let mounted = false;
export function mountAppearance() {
    if (mounted)
        return;
    mounted = true;
    apply();
    const host = document.querySelector('[data-preferences]');
    if (!host)
        return;
    const studio = node('dialog', undefined, 'appearance-dialog');
    studio.setAttribute('aria-labelledby', 'appearance-title');
    const command = node('dialog');
    command.setAttribute('aria-labelledby', 'command-title');
    document.body.append(studio, command);
    let opener = null;
    const open = (dialog) => { opener = document.activeElement; dialog.showModal(); };
    for (const dialog of [studio, command])
        dialog.addEventListener('close', () => { if (opener?.isConnected)
            opener.focus(); });
    const heading = (dialog, title, id) => {
        const header = node('div', undefined, 'dialog-heading');
        const h = node('h2', title);
        h.id = id;
        const close = node('button', '×', 'icon-button');
        close.type = 'button';
        close.setAttribute('aria-label', t('Close'));
        close.onclick = () => dialog.close();
        header.append(h, close);
        dialog.append(header);
    };
    const draw = () => {
        studio.replaceChildren();
        heading(studio, 'Make it yours.', 'appearance-title');
        const themeLabel = node('label', 'Theme');
        const theme = node('button', getTheme() === 'dark' ? 'Dark' : 'Light', 'button button-secondary');
        theme.type = 'button';
        theme.dataset.appearanceTheme = '';
        theme.onclick = () => { window.dispatchEvent(new CustomEvent('blocks:toggle-theme', { detail: theme })); };
        themeLabel.append(theme);
        studio.append(themeLabel);
        const languageLabel = node('label', 'Language');
        const language = node('select');
        for (const [value, text] of [['en', 'English'], ['zh', '中文']]) {
            const option = node('option', text);
            option.value = value;
            language.append(option);
        }
        language.value = getLanguage();
        language.dataset.appearanceLanguage = '';
        language.onchange = () => { setLanguage(language.value === 'zh' ? 'zh' : 'en'); studio.querySelector('[data-appearance-language]')?.focus(); };
        languageLabel.append(language);
        studio.append(languageLabel);
        const style = getComputedStyle(document.documentElement);
        for (const [token, caption] of [['--accent', 'Accent'], ['--bg', 'Background'], ['--surface', 'Surface'], ['--fg', 'Text color']]) {
            const label = node('label', caption);
            const input = node('input');
            input.type = 'color';
            input.dataset.colorToken = token;
            input.value = style.getPropertyValue(token).trim();
            input.setAttribute('aria-label', t(caption));
            input.oninput = () => { design[getTheme()][token] = input.value; save(); };
            label.append(input);
            studio.append(label);
        }
        for (const [name, caption, min, max, step] of [['radius', 'Corner radius', 8, 36, 1], ['sidebar', 'Sidebar width', 196, 280, 4], ['space', 'Spacing', .8, 1.3, .05]]) {
            const label = node('label', caption);
            const input = node('input');
            const output = node('output', String(design[name]));
            input.type = 'range';
            input.min = String(min);
            input.max = String(max);
            input.step = String(step);
            input.value = String(design[name]);
            input.setAttribute('aria-label', t(caption));
            input.oninput = () => { design[name] = Number(input.value); output.value = input.value; save(); };
            label.append(output, input);
            studio.append(label);
        }
        for (const [name, caption] of [['cursor', 'Custom cursor'], ['motion', 'Motion']]) {
            const label = node('label', caption);
            const input = node('input');
            input.type = 'checkbox';
            input.checked = design[name];
            input.onchange = () => { design[name] = input.checked; save(); };
            label.append(input);
            studio.append(label);
        }
        studio.append(node('p', 'Appearance is saved in this browser. Reduced motion always takes priority.', 'field-help'));
        const reset = node('button', 'Reset appearance', 'button button-secondary');
        reset.type = 'button';
        reset.onclick = () => { design = defaults(); save(); draw(); };
        studio.append(reset);
    };
    const search = node('button', '⌕', 'icon-button');
    search.type = 'button';
    search.setAttribute('aria-label', t('Quick find'));
    search.title = `${t('Quick find')} · ⌘ K`;
    const openCommand = () => {
        command.replaceChildren();
        heading(command, 'Quick find', 'command-title');
        const input = node('input');
        input.type = 'search';
        input.placeholder = t('Search apps');
        input.setAttribute('aria-label', t('Search apps'));
        input.style.width = '100%';
        const list = node('div', undefined, 'command-list');
        command.append(input, list);
        let entries = [{ name: t('Home'), path: '/' }, { name: t('My Apps'), path: '/apps' }, { name: t('Create app'), path: '/chat' }, { name: t('Data space'), path: '/data' }];
        const render = () => {
            list.replaceChildren();
            for (const entry of entries.filter((item) => item.name.toLocaleLowerCase().includes(input.value.toLocaleLowerCase()))) {
                const link = node('a');
                link.textContent = entry.name;
                link.href = entry.path;
                link.onclick = (event) => { if (event.metaKey || event.ctrlKey || event.shiftKey || event.altKey)
                    return; if (document.getElementById('app-shell')) {
                    event.preventDefault();
                    command.close();
                    window.dispatchEvent(new CustomEvent('blocks:navigate', { detail: entry.path }));
                } };
                list.append(link);
            }
        };
        input.oninput = render;
        render();
        open(command);
        input.focus();
        void fetch('/api/apps', { credentials: 'same-origin', signal: AbortSignal.timeout(30_000) }).then(async (response) => {
            if (!response.ok)
                return;
            const data = await response.json();
            entries = [...entries, ...data.apps.map((app) => ({ name: app.name, path: `/apps/${encodeURIComponent(app.id)}` }))];
            if (input.isConnected)
                render();
        }).catch(() => { });
    };
    search.replaceChildren(uiIcon('search'));
    search.onclick = openCommand;
    const settings = node('button', '☷', 'icon-button');
    settings.type = 'button';
    settings.setAttribute('aria-label', t('Appearance'));
    settings.title = t('Appearance');
    settings.onclick = () => { draw(); open(studio); };
    settings.replaceChildren(uiIcon('sliders'));
    host.prepend(magneticButton(search));
    host.append(magneticButton(settings));
    window.addEventListener('keydown', (event) => { if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k' && !document.querySelector('dialog[open]')) {
        event.preventDefault();
        openCommand();
    } });
    window.addEventListener('blocks:theme', () => {
        apply();
        const button = studio.querySelector('[data-appearance-theme]');
        if (button) {
            const face = button.querySelector('.magnetic-face') ?? button;
            face.textContent = t(getTheme() === 'dark' ? 'Dark' : 'Light');
        }
        const style = getComputedStyle(document.documentElement);
        studio.querySelectorAll('[data-color-token]').forEach((input) => { input.value = style.getPropertyValue(input.dataset.colorToken).trim(); });
    });
    window.addEventListener('blocks:language', () => { search.setAttribute('aria-label', t('Quick find')); settings.setAttribute('aria-label', t('Appearance')); if (studio.open)
        draw(); });
}
