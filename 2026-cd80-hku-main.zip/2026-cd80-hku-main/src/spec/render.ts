import { z } from 'zod';

/** Sort maps recursively, keeping arrays in their declared order. */
export function sorted(value: unknown): unknown {
  if (Array.isArray(value)) return value.map(sorted);
  if (value !== null && typeof value === 'object') {
    return Object.fromEntries(Object.entries(value).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)
      .map(([key, item]) => [key, sorted(item)]));
  }
  return value;
}

export const json = (value: unknown): string => JSON.stringify(sorted(value), null, 2) + '\n';
export const schema = (value: z.ZodType) => z.toJSONSchema(value, { target: 'draft-2020-12', io: 'input' });
export const fenced = (value: unknown): string => '```json\n' + json(value) + '```\n';

const cell = (text: string): string => text.replaceAll('|', '\\|').replaceAll('\n', ' ');
export type Shape = {
  type?: string | string[]; const?: unknown; enum?: unknown[]; description?: string;
  properties?: Record<string, Shape>; required?: string[]; items?: Shape; prefixItems?: Shape[];
  anyOf?: Shape[]; oneOf?: Shape[]; additionalProperties?: Shape | boolean;
  default?: unknown; exclusiveMinimum?: number; exclusiveMaximum?: number; minimum?: number; maximum?: number; minLength?: number; maxLength?: number;
  minItems?: number; maxItems?: number; pattern?: string;
};
export const typeOf = (value: Shape): string => {
  if (value.const !== undefined) return JSON.stringify(value.const);
  if (value.enum) return value.enum.map((item) => JSON.stringify(item)).join(' / ');
  if (value.anyOf || value.oneOf) return (value.anyOf ?? value.oneOf)!.map(typeOf).join(' or ');
  if (value.prefixItems) return `[${value.prefixItems.map(typeOf).join(', ')}]`;
  if (value.type === 'array') return `array of ${typeOf(value.items ?? {})}`;
  return Array.isArray(value.type) ? value.type.join(' or ') : value.type ?? 'value';
};

export function propertyTable(value: Shape): string {
  const rows = ['| Name | Type | Required | Meaning |', '| --- | --- | --- | --- |'];
  const visit = (shape: Shape, prefix = ''): void => {
    if (shape.anyOf || shape.oneOf) {
      for (const [i, branch] of (shape.anyOf ?? shape.oneOf)!.entries()) visit(branch, `${prefix}choice ${i + 1}.`);
    }
    if (shape.items) visit(shape.items, `${prefix.endsWith('.') ? prefix.slice(0, -1) : prefix}[].`);
    for (const [i, item] of (shape.prefixItems ?? []).entries()) visit(item, `${prefix.endsWith('.') ? prefix.slice(0, -1) : prefix}[${i}].`);
    if (typeof shape.additionalProperties === 'object') visit(shape.additionalProperties, `${prefix}*.`);
    for (const [name, prop] of Object.entries(shape.properties ?? {}).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)) {
      const meaning = prop.description ?? '';
      const constraints = ['minimum', 'maximum', 'exclusiveMinimum', 'exclusiveMaximum', 'minLength', 'maxLength', 'minItems', 'maxItems', 'pattern', 'default'] as const;
      const type = [typeOf(prop), ...constraints.filter((key) => prop[key] !== undefined)
        .map((key) => `${key}: ${JSON.stringify(prop[key])}`)].join('; ');
      rows.push(`| ${prefix}${name} | ${cell(type)} | ${shape.required?.includes(name) ? 'yes' : 'no'} | ${cell(meaning)} |`);
      visit(prop, `${prefix}${name}.`);
    }
  };
  visit(value);
  return rows.join('\n') + '\n';
}
