import express from 'express';
import { fileURLToPath } from 'node:url';
import { loadServerConfig } from './platform/config.ts';
import { gate1Page } from './api/routes-gate1.ts';
import { closeStorage } from './platform/database.ts';
import { specRouter } from './api/routes-spec.ts';
import { skillRouter } from './api/routes-skill.ts';
import { templateRouter } from './api/routes-templates.ts';
import { chatRouter } from './api/routes-chat.ts';
import { uploadRouter } from './api/routes-uploads.ts';
import { dataRoutes } from './api/routes-data.ts';
import { validateRouter } from './api/routes-validate.ts';
import { isSupportedNodeVersion } from '../scripts/runtime.mjs';
import { appRoutes } from './api/routes-apps.ts';
import { createScheduler } from './platform/scheduler.ts';

function main(): void {
  if (!isSupportedNodeVersion(process.version)) {
    console.error('The Blocks server requires Node.js 24.11.0 or later. Start it with npm start.');
    process.exitCode = 1;
    return;
  }

  let config;
  try {
    config = loadServerConfig();
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unable to read server configuration.');
    process.exitCode = 1;
    return;
  }

  const app = express();
  app.disable('x-powered-by');

  app.use((_request, response, next) => {
    response.set('X-Content-Type-Options', 'nosniff');
    next();
  });

  app.get(['/', '/apps', '/apps/:id', '/data', '/data/', '/chat', '/chat/', '/charts', '/screen-elements', '/examples', '/examples/'], (_request, response) => {
    response.set('Cache-Control', 'no-store');
    response.sendFile(fileURLToPath(new URL('../web/index.html', import.meta.url)));
  });

  app.get('/assets/theme.css', (_request, response) => {
    response.sendFile(fileURLToPath(new URL('../web/src/theme.css', import.meta.url)));
  });

  app.get('/assets/data-screen.css', (_request, response) => {
    response.sendFile(fileURLToPath(new URL('../web/src/data-screen.css', import.meta.url)));
  });

  app.get('/assets/chat.css', (_request, response) => {
    response.sendFile(fileURLToPath(new URL('../web/src/chat.css', import.meta.url)));
  });

  app.get('/assets/platform.css', (_request, response) => {
    response.sendFile(fileURLToPath(new URL('../web/src/platform.css', import.meta.url)));
  });

  for (const name of ['workspace-motion', 'theme-transition', 'desktop']) {
    app.get(`/assets/${name}.css`, (_request, response) => {
      response.sendFile(fileURLToPath(new URL(`../web/src/${name}.css`, import.meta.url)));
    });
  }

  /**
   * The vertical slice, on screen. Disposable: it is replaced by the real screen
   * elements and renderer, and it shares no code with them.
   */
  app.get('/gate1', (request, response) => {
    void gate1Page(request as never, response as never);
  });

  app.get('/assets/app.js', (_request, response) => {
    response.set('Cache-Control', 'no-cache');
    response.sendFile(fileURLToPath(new URL('../web/assets/app.js', import.meta.url)));
  });


  app.get('/assets/screen-elements.css', (_request, response) => {
    response.sendFile(fileURLToPath(new URL('../web/src/screen-elements.css', import.meta.url)));
  });

  for (const name of ['markdown-tables', 'ui-icon', 'appearance', 'pointer-motion', 'SplitText.min', 'workspace-ui', 'motion-runtime', 'motion-elements', 'workspace-motion', 'theme-transition', 'gsap.min', 'theme-init', 'screen-elements', 'screen-controls', 'upload-preview', 'screen-example', 'charts', 'echarts.esm.min', 'compare', 'data-screen', 'i18n', 'preferences', 'chat-stream', 'chat-screen', 'chat-upload', 'templates', 'list-actions', 'record-tools', 'record-state', 'monitor-panel', 'flagship-i18n']) {
    app.get(`/assets/${name}.js`, (_request, response) => {
      response.set('Cache-Control', 'no-cache');
      response.sendFile(fileURLToPath(new URL(`../web/assets/${name}.js`, import.meta.url)));
    });
  }


  app.get('/api/chart-example', async (_request, response) => {
    response.set('Cache-Control', 'no-store');
    try {
      const { buildChartExample } = await import('./platform/chart-example.ts');
      response.json(await buildChartExample());
    } catch {
      response.status(503).json({ error: { code: 'EXAMPLE_UNAVAILABLE', message: 'The chart example could not be loaded. Please try again.' } });
    }
  });

  app.get('/api/screen-example', async (_request, response) => {
    response.set('Cache-Control', 'no-store');
    try {
      const { buildScreenExample } = await import('./platform/screen-example.ts');
      response.json(await buildScreenExample());
    } catch {
      response.status(503).json({ error: { code: 'EXAMPLE_UNAVAILABLE', message: 'The example could not be loaded. Please try again.' } });
    }
  });

  app.get('/health', (_request, response) => {
    response.json({ status: 'ok', node: process.version });
  });

  app.use(specRouter);
  app.use(skillRouter);
  app.use(chatRouter);
  app.use(templateRouter);
  app.use(validateRouter);
  app.use(uploadRouter);
  app.use(...dataRoutes);
  app.use(...appRoutes);

  app.use((_request, response) => {
    response.status(404).json({
      error: { code: 'NOT_FOUND', message: 'The requested endpoint is not available.' },
    });
  });

  const server = app.listen(config.port, config.host);
  const scheduler = createScheduler({ onError: () => console.error('A scheduled execution could not be confirmed. Check task status and storage.') });
  server.once('listening', () => {
    scheduler.start();
    const address = server.address();
    if (address && typeof address !== 'string') {
      console.log(`Blocks is running at http://${config.host}:${address.port}`);
    }
    console.log('Open My Apps to import and browse applications.');
  });

  server.once('error', (error: NodeJS.ErrnoException) => {
    console.error(error.code === 'EADDRINUSE'
      ? `Port ${config.port} is already in use. Set CD80_PORT to another port.`
      : `Unable to start the server: ${error.message}`);
    process.exitCode = 1;
  });

  const shutdown = (): void => {
    const stopped = scheduler.stop();
    server.close(() => {
      void stopped.then(() => {
        try {
          closeStorage();
          process.exitCode = 0;
        } catch {
          console.error('Unable to close the storage database.');
          process.exitCode = 1;
        }
      });
    });
  };
  process.once('SIGINT', shutdown);
  process.once('SIGTERM', shutdown);
}

main();
