export const BANNED_WORDS = [
  'schema', 'JSON', 'document', 'field', 'parameter', 'dataset', 'query', 'SQL',
  'validate', 'deploy', 'endpoint', 'API', 'operation', 'compute', 'trigger',
  'component', 'expose', 'reference', 'cron', 'index', 'dataframe', 'pipeline',
] as const;
