import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { AppDocument, CURRENT_SPEC_VERSION, ExportEnvelope } from '../app-schema/document.ts';
import { BLOCK_INFO, COMPONENT_INFO, OPERATION_INFO } from '../app-schema/describe.ts';
import { OperationParams, OPERATION_SHAPE, type OperationName } from '../app-schema/operations.ts';
import { STEP_SCHEMA } from '../app-schema/compute.ts';
import { TriggerSpec } from '../app-schema/triggers.ts';
import { ELEMENT_SCHEMA } from '../app-schema/ui.ts';
import { FACTORS, SUPPORTED_FACTORS } from '../compute/ops/factor.ts';
import { listAllDatasets } from '../data/catalogue.ts';
import { ERROR_CODES, validateApplication } from '../validate/index.ts';
import { fenced, json, schema, propertyTable, typeOf, type Shape } from '../spec/render.ts';
import { BANNED_WORDS } from './vocabulary.ts';

export const SKILL_FAMILIES = [
  'ops-shaping', 'ops-time-series', 'ops-statistics', 'ops-finance',
  'screen-display', 'screen-charts', 'screen-controls', 'screen-layout',
  'blocks', 'data', 'errors',
] as const;

export function readSkillFamily(name: string): string | undefined {
  if (!(SKILL_FAMILIES as readonly string[]).includes(name)) return undefined;
  try {
    return readFileSync(new URL(`../../skill/references/${name}.md`, import.meta.url), 'utf8');
  } catch {
    return undefined;
  }
}

const read = (path: string): string => readFileSync(new URL(`../../${path}`, import.meta.url), 'utf8');
const ordered = <T>(items: Record<string, T>): [string, T][] => Object.entries(items).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0);

function reference(title: string, sections: string[]): string {
  const contents = sections.flatMap((section) => section.split('\n').filter((line) => line.startsWith('## ')))
    .map((line) => `- ${line.slice(3)}`);
  return [`# ${title}`, '', '## Contents', '', ...contents, '', ...sections].join('\n').trimEnd() + '\n';
}

export function skillRepairExample() {
  const fixed = JSON.parse(read('examples/ex-01-daily-movers.fin.json')) as AppDocument;
  const broken = structuredClone(fixed);
  const filter = broken.compute.find((step) => step.kind === 'operation' && step.op === 'filter')!;
  if (filter.kind !== 'operation' || filter.op !== 'filter') throw new Error('Example filter is missing.');
  const filterParams = filter.params as { where: string };
  filterParams.where = filterParams.where.replace('move_threshold', 'move_treshold');
  const sortIndex = broken.compute.findIndex((step) => step.kind === 'operation' && step.op === 'sort_limit');
  (broken.compute[sortIndex] as unknown as { op: string }).op = 'top_n';
  const tableElement = broken.ui.elements.table!;
  if (tableElement.type !== 'Table') throw new Error('Example table is missing.');
  tableElement.from = 'moverz';
  return { broken, fixed, sortIndex };
}

function repair(): string {
  const { broken, fixed, sortIndex } = skillRepairExample();
  const working = structuredClone(broken);
  const report = () => fenced(validateApplication(working).report.errors.map(({ pointer, code, message, hint }) => ({ pointer, code, message, hint: hint ?? null })));
  const lines = ['Three broken fragments:', fenced({
    filter: broken.compute.find((step) => step.id === 'unusual'),
    step: broken.compute[sortIndex], Table: broken.ui.elements.table,
  }), 'Actual errors from the first check:', report(),
  'Fix 1: change `top_n` back to `sort_limit`.'];
  working.compute[sortIndex] = structuredClone(fixed.compute[sortIndex]!);
  lines.push('Actual errors after fixing the step name:', report(),
    'Fix 2: change `$params.move_treshold` back to `$params.move_threshold`.',
    'Fix 3: change the Table\'s `from` from `moverz` back to `movers`.');
  const checked = validateApplication(fixed);
  if (!checked.ok) throw new Error('Repaired example is invalid.');
  lines.push('Checked again: valid');
  return lines.join('\n\n');
}

const errorHints: Record<keyof typeof ERROR_CODES, string> = {
  E_TOO_MANY_ERRORS: 'Fix the reported problems and check again to see the remaining problems.',
  E_INTERNAL: 'This is a fault in the checker, not in your application. Simplify the value at this location and check again.',
  E_PARSE_JSON: 'Fix the syntax and supply one complete JSON object.',
  E_PARSE_NOT_OBJECT: 'Supply an application object rather than a list or scalar.',
  E_PARSE_EMPTY: 'Supply the complete application instead of an empty file.',
  E_SCHEMA_TYPE: 'Use the type required by the named property.',
  E_SCHEMA_REQUIRED: 'Add the missing required property.',
  E_SCHEMA_UNKNOWN_KEY: 'Remove or correct the unrecognised key.',
  E_SCHEMA_ENUM: 'Choose one of the allowed values in the property table.',
  E_SCHEMA_RANGE: 'Keep the value or length within the stated bounds.',
  E_SCHEMA_PATTERN: 'Use the required spelling and identifier format.',
  E_SCHEMA_UNION: 'Use one complete allowed shape, without mixing alternatives.',
  E_SCHEMA_CUSTOM: 'Follow the specific rule in the report hint.',
  E_SCHEMA_SPEC_VERSION: `Set meta.spec_version to "${CURRENT_SPEC_VERSION}".`,
  E_REF_DUPLICATE_NAME: 'Give each data key and step id a distinct name.',
  E_REF_UNKNOWN_RELATION: 'Point at an existing data key or step id.',
  E_REF_UNKNOWN_PARAM: 'Use a declared params key, or declare the missing setting.',
  E_REF_UNKNOWN_ELEMENT: 'Use an existing element id in children.',
  E_REF_UNKNOWN_ROOT: 'Set ui.root to an existing element id.',
  E_CYCLE: 'Remove the circular dependencies between steps.',
  E_SELF_REFERENCE: 'Read a different input instead of the step’s own output.',
  E_BAD_CRON: 'Use five schedule parts with valid ranges and increments.',
  E_BAD_EXPRESSION: 'Correct the formula using supported syntax and functions.',
  E_BAD_SQL: 'Use one allowed SELECT or WITH statement over declared inputs.',
  E_NO_TRIGGER: 'Add a manual trigger or another supported trigger.',
  E_ELEMENT_CYCLE: 'Remove the loop in Section children.',
  E_LIMIT_STEPS: 'Reduce the application to at most 60 calculation steps.',
  E_LIMIT_CODE_STEPS: 'Combine custom logic into at most one code step.',
  E_LIMIT_AI_STEPS: 'Reduce the application to at most four ai steps.',
  E_LIMIT_ELEMENTS: 'Reduce the screen to at most 60 elements.',
  E_LIMIT_NESTING: 'Flatten nested Sections to the allowed depth in the report.',
  W_ORPHAN_ELEMENT: 'Include the element in a reachable Section or remove it.',
  W_UNUSED_PARAM: 'Read the setting in calculations or remove it.',
  W_DEAD_CONTROL: 'Connect the controlled setting to a calculation or remove the control.',
  W_UNUSED_STEP: 'Use the result in another step or on screen, or remove the step.',
  W_UNUSED_DATA: 'Read the data requirement in a step or remove it.',
  W_SQL_COULD_BE_OPERATION: 'Replace the SQL step with the suggested named operation.',
  W_CODE_COULD_BE_OPERATION: 'Replace the code step with the suggested named operation.',
  W_SURROUNDING_TEXT: 'Supply the application alone without fences or surrounding prose.',
  W_UNKNOWN_ICON: 'Choose an icon from the supported icon names or omit it.',
  W_NO_MANUAL_TRIGGER: 'Add a manual trigger so the person can run by hand.',
  W_SHORT_HISTORY: 'Connect a source with more history or shorten the requested window.',
};

const elementExamples: Record<string, unknown> = {
  Section: { type: 'Section', children: ['intro'] }, Text: { type: 'Text', text: 'Daily prices.' },
  Metric: { type: 'Metric', label: 'Total', from: 'totals', value: 'n' },
  Table: { type: 'Table', from: 'prices', columns: [{ col: 'close' }] },
  Chart: { type: 'Chart', chart: 'line', from: 'prices', x: 'trade_date', y: ['close'] },
  Callout: { type: 'Callout', text: 'Prices are delayed.' },
  List: { type: 'List', from: 'prices', itemTitle: 'name' },
  NumberInput: { type: 'NumberInput', param: 'limit', label: 'Rows' },
  SelectInput: { type: 'SelectInput', param: 'market', label: 'Market' },
  TextInput: { type: 'TextInput', param: 'watchlist', label: 'Companies' },
  DateRangeInput: { type: 'DateRangeInput', fromParam: 'start', toParam: 'end', label: 'Dates' },
  RunButton: { type: 'RunButton', label: 'Run' },
};

export function buildSkill(): Map<string, string> {
  const files = new Map<string, string>();
  const routing: string[] = ['| File | Read it when | Contains |', '| --- | --- | --- |'];
  const add = (name: string, when: string, items: string[], sections: string[]): void => {
    const path = `references/${name}.md`;
    files.set(path, reference(name, sections));
    routing.push(`| [${path}](${path}) | ${when} | ${items.join(', ')} |`);
  };
  for (const family of ['shaping', 'time_series', 'statistics', 'finance'] as const) {
    const items = ordered(OPERATION_INFO).filter(([, info]) => info.family === family);
    add(`ops-${family.replaceAll('_', '-')}`, `You need ${family.replaceAll('_', ' ')} calculations`, items.map(([name]) => name), items.map(([name, info]) => {
      const op = name as OperationName;
      const example = { id: 'result', kind: op === 'ai' ? 'ai' : 'operation', ...(op === 'ai' ? {} : { op }), input: 'source', params: info.example };
      const factors = op === 'factor' ? ['Supported factors (every factor also needs ts_code and trade_date):', '', '| Factor | Meaning | Needed columns |', '| --- | --- | --- |', ...SUPPORTED_FACTORS.map((factor) => `| ${factor} | ${FACTORS[factor]!.meaning} | ${FACTORS[factor]!.needs.join(', ')} |`)].join('\n') : '';
      return [`## ${name}`, '', info.summary, '', `Inputs: ${OPERATION_SHAPE[op].inputs}. Output shape: ${info.output}.`, '', propertyTable(schema(OperationParams[op]) as Shape), 'Example step:', '', fenced(example), factors].join('\n');
    }));
  }
  for (const [family, file] of [['display', 'display'], ['chart', 'charts'], ['control', 'controls'], ['layout', 'layout']] as const) {
    const items = ordered(COMPONENT_INFO).filter(([, info]) => info.family === family);
    add(`screen-${file}`, `You need ${file} on screen`, items.map(([name]) => name), items.map(([name, info]) => [`## ${name}`, '', info.summary, '', propertyTable(schema(ELEMENT_SCHEMA[name]!) as Shape), 'Example:', '', fenced(elementExamples[name])].join('\n')));
  }
  const blocks: string[] = [];
  for (const name of ['meta', 'params', 'data', 'triggers'] as const) {
    const shape = schema(AppDocument.shape[name]) as Shape;
    blocks.push([`## ${name}`, '', BLOCK_INFO.sections[name].en, '', propertyTable(shape.items ?? shape), 'Example:', '', fenced(BLOCK_INFO.sections[name].example)].join('\n'));
  }
  for (const name of ['sql', 'expression', 'ai', 'code'] as const) blocks.push([`## Step kind: ${name}`, '', BLOCK_INFO.steps[name].en, '', propertyTable(schema(STEP_SCHEMA[name]) as Shape), 'Example:', '', fenced(BLOCK_INFO.steps[name].example)].join('\n'));
  for (const option of TriggerSpec.options) {
    const name = option.shape.kind.value;
    blocks.push([`## ${name}`, '', BLOCK_INFO.triggers[name].en, '', propertyTable(schema(option) as Shape), 'Example:', '', fenced(BLOCK_INFO.triggers[name].example)].join('\n'));
  }
  add('blocks', 'You need application sections or special step kinds', ['meta', 'params', 'data', 'triggers', 'sql', 'expression', 'ai', 'code', ...Object.keys(BLOCK_INFO.triggers).sort()], blocks);
  const catalogue = listAllDatasets().filter((item) => item.source !== 'upload').sort((a, b) => a.id < b.id ? -1 : a.id > b.id ? 1 : 0);
  add('data', 'You need available tables or spreadsheet uploads', catalogue.map((item) => item.id), [
    'Choose a CSV or XLSX spreadsheet in the data connection screen and upload it. Review the detected column names and types, then connect the matching columns to the application.',
    ...catalogue.map((item) => [`## ${item.id}`, '', `Name: ${item.name}.`, '', `Coverage: ${item.coverageStart ?? 'not specified'} to ${item.coverageEnd ?? 'not specified'}.`, '', '| Name | Type |', '| --- | --- |', ...[...item.fields].sort((a, b) => a.name < b.name ? -1 : a.name > b.name ? 1 : 0).map((field) => `| ${field.name} | ${field.type} |`)].join('\n')),
  ]);
  add('errors', 'A check reports an error or warning', Object.keys(ERROR_CODES).sort(), ordered(ERROR_CODES).map(([code, meaning]) => [`## ${code}`, '', meaning, '', `Hint: ${errorHints[code as keyof typeof ERROR_CODES]}`].join('\n')));
  const skeleton = ['The comments are explanations, not part of the document.', '', '```jsonc', '{', ...Object.keys(AppDocument.shape).map((key, i, keys) => {
    const name = key as keyof typeof AppDocument.shape;
    const shape = schema(AppDocument.shape[name]) as Shape;
    const value = BLOCK_INFO.sections[name].example;
    return `  "${key}": ${JSON.stringify(value)}${i < keys.length - 1 ? ',' : ''} // ${typeOf(shape)}: ${BLOCK_INFO.sections[name].en}`;
  }), '}', '```'].join('\n');
  const example = JSON.parse(read('examples/ex-01-daily-movers.fin.json')) as AppDocument;
  const sentences = [
    `The meta section names “${example.meta.name}”: ${example.meta.description}`,
    `The params section offers ${example.params.map((item) => item.label.toLowerCase()).join(', ')}.`,
    `The data section asks for ${example.data.map((item) => item.purpose).join('; ')}.`,
    `The compute section runs the calculations titled ${example.compute.flatMap((step) => step.title ? [step.title] : []).join(', ')} and counts the unusual moves.`,
    'The triggers section allows running by hand and thirty minutes after market close.',
    'The ui section shows settings, the count of unusual moves and the Biggest movers table.',
  ];
  const replacements: Record<string, string> = {
    SPEC_VERSION: CURRENT_SPEC_VERSION, BANNED_WORDS: BANNED_WORDS.map((word) => `\`${word}\``).join(', '),
    SKELETON: skeleton, EXAMPLE: sentences.join('\n\n') + '\n\n```json\n' + read('examples/ex-01-daily-movers.fin.json') + '```',
    REPAIR_EXAMPLE: repair(), ROUTING_TABLE: routing.join('\n'),
  };
  files.set('SKILL.md', read('skill-src/SKILL.template.md').replace(/\{\{([A-Z_]+)\}\}/g, (_match, key: string) => {
    if (!(key in replacements)) throw new Error(`Unknown placeholder: ${key}`);
    return replacements[key]!;
  }).trimEnd() + '\n');
  files.set('examples/ex-01-daily-movers.json', read('examples/ex-01-daily-movers.fin.json'));
  files.set('application.schema.json', json(schema(ExportEnvelope)));
  const hashes = Object.fromEntries([...files].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0).map(([path, content]) => [path, createHash('sha256').update(content).digest('hex')]));
  files.set('skill.json', json({ spec_version: CURRENT_SPEC_VERSION, files: hashes }));
  return new Map([...files].sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0));
}
