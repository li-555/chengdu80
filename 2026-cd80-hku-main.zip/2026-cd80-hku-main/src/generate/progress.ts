/**
 * What the person sees while an application is being built.
 *
 * Every line is written here, never by the model, so a progress line can never contain
 * a technical word. Spec section 3.4: a line appears when a stage starts, and no stage may
 * go four seconds without a new line, so long stages repeat a "still" variant.
 */

export type Stage = 'understand' | 'pick_data' | 'shortlist' | 'draft' | 'check' | 'repair' | 'first_run' | 'done';

export const STAGE_LINES: Record<Stage, { first: string; still: string }> = {
  understand: { first: 'Reading what you asked for.', still: 'Still reading what you asked for.' },
  pick_data: { first: 'Looking for the right data.', still: 'Still looking for the right data.' },
  shortlist: { first: 'Found it. Checking what is in it.', still: 'Still checking what is in the data.' },
  draft: { first: 'Writing your application.', still: 'Still writing your application.' },
  check: { first: 'Checking it before it runs.', still: 'Still checking it.' },
  repair: { first: 'Fixing one small thing.', still: 'Still fixing it.' },
  first_run: { first: 'Running it for the first time.', still: 'Still running it.' },
  done: { first: 'Done. Your application is ready.', still: 'Done. Your application is ready.' },
};

export type ProgressEvent = { kind: 'progress'; stage: Stage; line: string };

/** The longest a stage may go without a new line. */
export const HEARTBEAT_MS = 4000;

/**
 * Emits stage lines, and repeats the "still" line while a stage runs long.
 * `stop()` must be called when the turn ends, or the timer keeps the process alive.
 */
export class ProgressReporter {
  #emit: (e: ProgressEvent) => void;
  #stage: Stage | undefined;
  #timer: ReturnType<typeof setInterval> | undefined;

  constructor(emit: (e: ProgressEvent) => void, heartbeatMs = HEARTBEAT_MS) {
    this.#emit = emit;
    this.#timer = setInterval(() => {
      if (this.#stage && this.#stage !== 'done') {
        this.#emit({ kind: 'progress', stage: this.#stage, line: STAGE_LINES[this.#stage].still });
      }
    }, heartbeatMs);
    this.#timer.unref?.();
  }

  stage(s: Stage): void {
    this.#stage = s;
    this.#emit({ kind: 'progress', stage: s, line: STAGE_LINES[s].first });
  }

  stop(): void {
    if (this.#timer) clearInterval(this.#timer);
    this.#timer = undefined;
  }
}
