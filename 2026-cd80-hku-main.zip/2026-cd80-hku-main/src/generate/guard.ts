/**
 * The check on words the person reads.
 *
 * Applied to the questions the builder asks and to the application's one-sentence
 * description, which are the only two places its own words reach the person. Matching is
 * by whole word and ignores case, so "fields" and "Field" are caught and "afield" is not.
 */

import { BANNED_WORDS } from '../skill/vocabulary.ts';

const PATTERNS = BANNED_WORDS.map((w) => ({
  word: w,
  re: new RegExp(`(^|[^A-Za-z])${w.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}(s|es)?(?![A-Za-z])`, 'i'),
}));

/** The banned words that appear in `text`, in list order, each once. */
export function bannedWordsIn(text: string): string[] {
  return PATTERNS.filter((p) => p.re.test(text)).map((p) => p.word);
}
