/**
 * What may reach the model from the person's own message.
 *
 * The model must never receive rows of data: an uploaded file reaches it only as column
 * names and types. A person can still paste rows straight into the chat, so a message
 * that looks like a table or a list of records is stopped here and the person is asked to
 * upload it as a file instead. Strings that look like keys or passwords are removed before
 * the message goes anywhere.
 *
 * Both checks are deliberately simple and err towards stopping: a person whose ordinary
 * sentence is refused can rephrase; a row that reached the model cannot be taken back.
 */

/** Long unbroken strings mixing letters and digits: API keys, tokens, passwords. */
const SECRET = /(?<![A-Za-z0-9_-])(?=[A-Za-z0-9_-]*[A-Za-z])(?=[A-Za-z0-9_-]*\d)[A-Za-z0-9_-]{24,}(?![A-Za-z0-9_-])/g;
/** `sk-...`, `key: ...`, `token=...` and similar, whatever their length. */
const LABELLED_SECRET = /\b(api[_ -]?key|token|password|passwd|secret)\b(\s*(?:is|was|are|[:=])\s*|\s+)[^\s,;]+/gi;

export function redactSecrets(text: string): string {
  return text
    .replace(LABELLED_SECRET, (m, label: string, joint: string) => {
      const value = m.slice(label.length + joint.length);
      // "token holders" is finance, not a secret: after a bare space, remove only what looks like a key.
      const explicit = /[:=]|\b(is|was|are)\b/i.test(joint);
      return explicit || /^(?=.*\d)[A-Za-z0-9_\-]{8,}$/.test(value) ? `${label}${joint}[removed]` : m;
    })
    .replace(SECRET, '[removed]');
}

/** True when the message carries rows of data rather than a request. */
export function looksLikeData(text: string): boolean {
  const lines = text.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  const tableLike = lines.filter((l) => (l.match(/[,\t;|]/g)?.length ?? 0) >= 2 && /\d/.test(l));
  if (tableLike.length >= 3) return true;

  // A record pasted as JSON: an object with several values, or a list of objects.
  for (const m of text.matchAll(/[[{][\s\S]*[\]}]/g)) {
    try {
      const v: unknown = JSON.parse(m[0]);
      if (Array.isArray(v) && v.some((x) => x && typeof x === 'object')) return true;
      if (v && typeof v === 'object' && !Array.isArray(v) && Object.keys(v).length >= 2) return true;
    } catch { /* not JSON: an ordinary sentence with brackets */ }
  }
  return false;
}

export const PASTED_DATA_REPLY =
  'That looks like rows of data. Please drop it into the chat as a file instead of pasting it. ' +
  'I only look at the column names of a file, never at its rows.';
