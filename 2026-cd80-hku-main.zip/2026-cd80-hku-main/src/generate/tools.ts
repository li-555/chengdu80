/**
 * The builder's five tools. Four only read; `submit_application` is the only one that
 * changes anything, and it saves through the same check every imported application goes
 * through, so the builder has no privilege an outside author lacks.
 *
 * No tool ever returns a row of data. The builder sees dataset names, column names, types
 * and coverage dates — never values. That is both a privacy rule and a competition rule.
 */

import { tool } from 'ai';
import { z } from 'zod';
import type { AppDocument } from '../app-schema/index.ts';
import { validateApplication } from '../validate/index.ts';
import type { Dataset } from '../data/types.ts';
import { SKILL_FAMILIES } from '../skill/build.ts';
import { bannedWordsIn } from './guard.ts';
import { MAX_QUESTIONS_PER_MESSAGE, MAX_QUESTIONS_TOTAL, MAX_SUBMISSIONS } from './prompt.ts';
import type { Stage } from './progress.ts';

/** The most errors fed back per failed submission (spec 3.5). */
export const MAX_ERRORS_FED_BACK = 12;

/** What the tools may touch. Tests pass their own. */
export type BuilderDeps = {
  listDatasets: () => Dataset[];
  readFamily: (name: string) => string | undefined;
  /** Saves a checked application and returns its id. */
  install: (doc: AppDocument) => Promise<{ id: string }>;
  modelName: string;
};

/** Everything the tools remember across one conversation. */
export type BuildSession = {
  questionsAsked: number;
  submissions: number;
  /** The sorted error codes and locations of the last failed submission. */
  lastErrorKey?: string;
  /** Each wording rule is enforced once per place, then accepted (spec 4.4 of the agent design). */
  rewroteQuestion: boolean;
  rewroteDescription: boolean;
  /** Set by a tool when the turn must end. */
  outcome?:
    | { kind: 'question'; questions: string[]; acceptsFile: boolean }
    | { kind: 'built'; appId: string; name: string; description: string; document: AppDocument }
    | { kind: 'gave_up'; reason: 'budget' | 'stalled'; draft: unknown; errors: unknown[] };
  /** The last document submitted, kept as the draft if building fails. */
  lastDraft?: unknown;
  /** Set before a passing application is saved, so a second one in the same reply is refused. */
  saving?: boolean;
};

export function newBuildSession(): BuildSession {
  return { questionsAsked: 0, submissions: 0, rewroteQuestion: false, rewroteDescription: false };
}

/** Questions in one string: each question mark counts, and a string with none counts once. */
export function countQuestions(text: string): number {
  return Math.max(1, (text.match(/[?？]/g) ?? []).length);
}

/** Once a tool has ended the turn, every later call in the same reply is refused. */
const TURN_OVER = { ok: false, error: 'This turn is already decided. Do nothing else.' } as const;

const words = (s: string) => s.toLowerCase().split(/[^a-z0-9一-鿿]+/).filter((w) => w.length > 1);

/** Score a dataset against the need by shared words in its id, name, notes and columns. */
function score(d: Dataset, need: string[]): number {
  const hay = words([d.id, d.name, d.notes ?? '', ...d.fields.flatMap((f) => [f.name, f.label])].join(' '));
  const set = new Set(hay);
  const joined = hay.join(' ');
  return need.reduce((s, w) => s + (set.has(w) ? 3 : joined.includes(w) ? 1 : 0), 0);
}

export function makeTools(session: BuildSession, deps: BuilderDeps, stage: (s: Stage) => void) {
  return {
    find_data: tool({
      description: 'Search the data catalogue. Returns at most 8 matching datasets with what they hold; never any rows.',
      inputSchema: z.object({ need: z.string().min(1).max(300).describe('What data is needed, in plain words.') }),
      execute: async ({ need }) => {
        stage('pick_data');
        const all = deps.listDatasets();
        const n = words(need);
        const ranked = all.map((d) => ({ d, s: score(d, n) })).filter((x) => x.s > 0)
          .sort((a, b) => b.s - a.s || a.d.id.localeCompare(b.d.id)).slice(0, 8);
        const shown = (ranked.length > 0 ? ranked.map((x) => x.d) : all.slice(0, 8)).map((d) => ({
          id: d.id, name: d.name, about: (d.notes ?? '').slice(0, 200),
          coverage: d.coverageStart || d.coverageEnd ? `${d.coverageStart ?? '?'} to ${d.coverageEnd ?? '?'}` : undefined,
          columns: d.fields.length,
        }));
        return {
          matches: shown,
          note: ranked.length === 0 ? 'Nothing matched those words; these are the first datasets in the catalogue.' : undefined,
          other_datasets: all.filter((d) => !shown.some((s) => s.id === d.id)).map((d) => d.id),
        };
      },
    }),

    describe_data: tool({
      description: 'The exact columns of up to 4 datasets: name, type, unit and meaning. Never any rows.',
      inputSchema: z.object({ ids: z.array(z.string().min(1)).min(1).max(4) }),
      execute: async ({ ids }) => {
        stage('shortlist');
        const all = deps.listDatasets();
        return ids.map((id) => {
          const d = all.find((x) => x.id === id);
          if (!d) {
            const close = all.filter((x) => x.id.includes(id.split(':').pop() ?? id)).map((x) => x.id).slice(0, 5);
            return { id, error: 'No dataset has this id.', did_you_mean: close };
          }
          return {
            id: d.id, name: d.name, coverage_start: d.coverageStart, coverage_end: d.coverageEnd, notes: d.notes,
            columns: d.fields.map((f) => ({ name: f.name, type: f.type, unit: f.unit, meaning: f.label })),
          };
        });
      },
    }),

    read_spec: tool({
      description: `Load reference families. Ask for all you need in one call. Families: ${SKILL_FAMILIES.join(', ')}.`,
      inputSchema: z.object({ families: z.array(z.string()).min(1).max(6) }),
      execute: async ({ families }) => {
        stage('draft');
        return families.map((name) => {
          const text = deps.readFamily(name);
          return text === undefined
            ? { family: name, error: `Unknown family. Available: ${SKILL_FAMILIES.join(', ')}` }
            : { family: name, text };
        });
      },
    }),

    ask_user: tool({
      description: `The only way to speak to the person. At most ${MAX_QUESTIONS_PER_MESSAGE} questions. Their answer arrives as their next message.`,
      inputSchema: z.object({
        questions: z.array(z.string().min(1).max(400)).min(1).max(MAX_QUESTIONS_PER_MESSAGE),
        accepts_file: z.boolean().optional().describe('True when a spreadsheet would be a good answer.'),
      }),
      execute: async ({ questions, accepts_file }) => {
        if (session.outcome) return TURN_OVER;
        const asked = questions.reduce((n, q) => n + countQuestions(q), 0);
        if (asked > MAX_QUESTIONS_PER_MESSAGE) {
          return { ok: false, error: `Ask at most ${MAX_QUESTIONS_PER_MESSAGE} questions at a time. Pick the most important.` };
        }
        if (session.questionsAsked + asked > MAX_QUESTIONS_TOTAL) {
          return {
            ok: false,
            error: `You have already asked ${session.questionsAsked} questions; the limit is ${MAX_QUESTIONS_TOTAL}. ` +
              'Build now with sensible defaults and state your assumptions in the description.',
          };
        }
        const banned = bannedWordsIn(questions.join(' '));
        if (banned.length > 0 && !session.rewroteQuestion) {
          session.rewroteQuestion = true;
          return { ok: false, error: `Rewrite this without the words: ${banned.join(', ')}.` };
        }
        session.questionsAsked += asked;
        session.outcome = { kind: 'question', questions, acceptsFile: accepts_file ?? false };
        return { ok: true, note: 'Shown to the person. Their answer will be their next message.' };
      },
    }),

    submit_application: tool({
      description: 'Check the whole application and, if it passes, save it for the person. Returns errors with fix hints if it fails.',
      inputSchema: z.object({ application: z.unknown().describe('The complete application object.') }),
      execute: async ({ application }) => {
        if (session.outcome) return TURN_OVER;
        if (session.submissions >= MAX_SUBMISSIONS) {
          return { ok: false, error: 'No submissions left.', final: true };
        }
        const doc = typeof application === 'string' ? safeParse(application) : application;
        session.lastDraft = doc;
        session.submissions += 1;
        stage(session.submissions === 1 ? 'check' : 'repair');

        const result = validateApplication(doc);
        if (!result.ok) {
          const key = result.errors.map((e) => `${e.code}@${e.pointer}`).sort().join('|');
          const stalled = key === session.lastErrorKey;
          session.lastErrorKey = key;
          const errors = result.errors.slice(0, MAX_ERRORS_FED_BACK)
            .map(({ pointer, code, message, hint }) => ({ pointer, code, message, hint }));
          if (stalled || session.submissions >= MAX_SUBMISSIONS) {
            session.outcome = { kind: 'gave_up', reason: stalled ? 'stalled' : 'budget', draft: doc, errors };
            return { ok: false, errors, final: true, note: 'No submissions left. Stop.' };
          }
          return {
            ok: false, errors,
            more_errors: Math.max(0, result.errors.length - MAX_ERRORS_FED_BACK),
            submissions_left: MAX_SUBMISSIONS - session.submissions,
            note: 'Fix exactly what these errors name. Fixing them may reveal errors from the next stage of checks.',
          };
        }

        const description = result.document.meta.description;
        const banned = bannedWordsIn(description);
        if (banned.length > 0 && !session.rewroteDescription) {
          session.rewroteDescription = true;
          session.submissions -= 1; // a wording fix does not cost a submission
          return { ok: false, errors: [{ pointer: '/meta/description', code: 'WORDING', message: `Rewrite the description without the words: ${banned.join(', ')}.` }] };
        }

        const document: AppDocument = {
          ...result.document,
          meta: { ...result.document.meta, provenance: { created_by: 'platform', model: deps.modelName } },
        };
        // Checked and set with no await in between, so two passing submissions in one
        // reply cannot both be saved.
        if (session.outcome || session.saving) return TURN_OVER;
        session.saving = true;
        const saved = await deps.install(document);
        session.outcome = { kind: 'built', appId: saved.id, name: document.meta.name, description, document };
        return { ok: true, warnings: result.report.warnings.map(({ code, message }) => ({ code, message })) };
      },
    }),
  };
}

function safeParse(text: string): unknown {
  try {
    return JSON.parse(text);
  } catch {
    return text; // the validator reports it as unreadable, with its own code
  }
}
