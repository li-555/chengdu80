import { z } from 'zod';
import { boundedRecord, ColumnName, Identifier } from './fields.ts';

/**
 * The 12 screen elements. This catalogue is the AI's entire vocabulary for the screen.
 * It is deliberately short: every extra element is one more thing to get wrong, which
 * makes every application less reliable.
 *
 * No element accepts a colour, a font or a pixel size. An element may carry `tone`,
 * which the active theme turns into real colours.
 */
export const Tone = z.enum(['default', 'positive', 'negative', 'warning', 'muted']);

const base = { tone: Tone.optional().describe('Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.') };

/** An element id, used as the key in `ui.elements` and in a Section's `children`. */
export const ElementId = z.string().max(40, { abort: true }).regex(/^[a-z][a-z0-9_]{0,39}$/, {
  error: 'must be lower-case letters, digits and underscores',
});

const Column = z.strictObject({
  col: ColumnName.describe('Result column to display in this table column.'),
  label: z.string().min(1).max(60).optional().describe('Optional display label for the column, with no label specified when omitted.'),
  format: z.enum(['text', 'number', 'money', 'percent', 'date', 'integer']).optional().describe('Optional display format for this column, with no format specified when omitted.'),
});

const ELEMENTS = [
  /** 1. the only container */
  z.strictObject({
    ...base,
    type: z.literal('Section').describe('Element type discriminator selecting the declared screen component.'),
    title: z.string().min(1).max(120).optional().describe('Optional heading text for this element, with no heading specified when omitted.'),
    columns: z.union([z.literal(1), z.literal(2), z.literal(3)]).default(1).describe('Number of section layout columns, defaulting to 1 when omitted.'),
    children: z.array(ElementId).max(32).describe('Ordered element ids contained by this section.'),
  }),

  /** 2. prose */
  z.strictObject({
    ...base,
    type: z.literal('Text').describe('Element type discriminator selecting the declared screen component.'),
    text: z.string().min(1).max(4000).describe('Text content displayed by the element.'),
    emphasis: z.enum(['heading', 'body', 'caption']).default('body').describe('Text presentation role, defaulting to body when omitted.'),
  }),

  /** 3. one big number */
  z.strictObject({
    ...base,
    type: z.literal('Metric').describe('Element type discriminator selecting the declared screen component.'),
    label: z.string().min(1).max(60).describe('Display label for this element.'),
    from: Identifier.describe('Data requirement key or step id providing the displayed result.'),
    value: ColumnName.describe('Result column providing the metric value.'),
    change: ColumnName.optional().describe('Optional result column providing the metric change, with no change column when omitted.'),
    format: z.enum(['number', 'money', 'percent', 'integer']).default('number').describe('Metric display format, defaulting to number when omitted.'),
    unit: z.string().min(1).max(16).optional().describe('Optional displayed unit label, with no unit label when omitted.'),
  }),

  /** 4. rows and typed columns */
  z.strictObject({
    ...base,
    type: z.literal('Table').describe('Element type discriminator selecting the declared screen component.'),
    title: z.string().min(1).max(120).optional().describe('Optional heading text for this element, with no heading specified when omitted.'),
    from: Identifier.describe('Data requirement key or step id providing the displayed result.'),
    columns: z.array(Column).min(1).max(40).describe('Ordered declarations of the result columns displayed in the table.'),
    emptyHint: z.string().min(1).max(200).optional().describe('Optional message for an empty result, with no custom message when omitted.'),
    pageSize: z.number().int().min(5).max(200).default(25).describe('Number of table rows per page, defaulting to 25 when omitted.'),
  }),

  /** 5. one chart element, four kinds. Daily data only: no intraday, no streaming. */
  z.strictObject({
    ...base,
    type: z.literal('Chart').describe('Element type discriminator selecting the declared screen component.'),
    title: z.string().min(1).max(120).optional().describe('Optional heading text for this element, with no heading specified when omitted.'),
    chart: z.enum(['line', 'bar', 'candlestick', 'heatmap']).describe('Chart kind, either line, bar, candlestick, or heatmap.'),
    from: Identifier.describe('Data requirement key or step id providing the displayed result.'),
    x: ColumnName.describe('Result column supplying the horizontal axis.'),
    /** `line` and `bar` take one or more series. */
    y: z.array(ColumnName).max(8).optional().describe('Result columns supplying line or bar series, required and non-empty for those chart kinds and otherwise optional.'),
    /** `candlestick` needs all four price columns. */
    ohlc: z.strictObject({ open: ColumnName.describe('Result column containing each candle opening price.'), high: ColumnName.describe('Result column containing each candle highest price.'), low: ColumnName.describe('Result column containing each candle lowest price.'), close: ColumnName.describe('Result column containing each candle closing price.') }).optional().describe('Open, high, low, and close result columns, required for candlestick charts and otherwise optional.'),
    /** `heatmap` needs a second axis and a value. */
    heat: z.strictObject({ y: ColumnName.describe('Result column supplying the heatmap second axis.'), value: ColumnName.describe('Result column supplying the heatmap cell value.') }).optional().describe('Second-axis and value result columns, required for heatmaps and otherwise optional.'),
    stacked: z.boolean().optional().describe('Optional request to stack chart series, with no stacking request when omitted.'),
    /**
     * Split one long table into one line or bar group per value of this column, e.g. one
     * line per company from rows of (company, day, price). Without it a long table is
     * drawn as one series and different companies are joined into one line.
     */
    series: ColumnName.optional().describe('Text result column whose distinct values each become their own line or bar group, for example one line per company; only for line and bar charts with exactly one y column; at most 20 groups are drawn, the rest are listed as hidden.'),
  })
    .refine((e) => e.chart !== 'candlestick' || e.ohlc !== undefined, {
      error: 'ohlc is required for a candlestick chart',
      path: ['ohlc'],
    })
    .refine((e) => e.chart !== 'heatmap' || e.heat !== undefined, {
      error: 'heat is required for a heatmap',
      path: ['heat'],
    })
    .refine((e) => !(e.chart === 'line' || e.chart === 'bar') || (e.y !== undefined && e.y.length > 0), {
      error: 'y needs at least one column for a line or bar chart',
      path: ['y'],
    })
    .refine((e) => e.series === undefined || e.chart === 'line' || e.chart === 'bar', {
      error: 'series only applies to a line or bar chart',
      path: ['series'],
    })
    .refine((e) => e.series === undefined || e.y?.length === 1, {
      error: 'with series, y must name exactly one column: the value to draw for each group',
      path: ['y'],
    })
    .refine((e) => e.series === undefined || (e.series !== e.x && !e.y?.includes(e.series)), {
      error: 'series must be a different column from x and y',
      path: ['series'],
    }),

  /** 6. a coloured note box — "this one is serious" */
  z.strictObject({
    ...base,
    type: z.literal('Callout').describe('Element type discriminator selecting the declared screen component.'),
    title: z.string().min(1).max(120).optional().describe('Optional heading text for this element, with no heading specified when omitted.'),
    text: z.string().min(1).max(2000).describe('Text content displayed by the element.'),
  }),

  /** 7. a grouped list, each item with a title, body, link and tone */
  z.strictObject({
    ...base,
    type: z.literal('List').describe('Element type discriminator selecting the declared screen component.'),
    title: z.string().min(1).max(120).optional().describe('Optional heading text for this element, with no heading specified when omitted.'),
    from: Identifier.describe('Data requirement key or step id providing the displayed result.'),
    itemTitle: ColumnName.describe('Result column supplying each list item title.'),
    itemBody: ColumnName.optional().describe('Optional result column supplying each list item body, with no body column when omitted.'),
    itemLink: ColumnName.optional().describe('Optional result column supplying each list item link, with no link column when omitted.'),
    itemTone: ColumnName.optional().describe('Optional result column supplying each list item tone, with no per-item tone column when omitted.'),
    groupBy: ColumnName.optional().describe('Optional result column used to group list items, with no grouping column when omitted.'),
    emptyHint: z.string().min(1).max(200).optional().describe('Optional message for an empty result, with no custom message when omitted.'),
  }),

  /** 8-11. controls. A control carries only the parameter it names and a label. */
  z.strictObject({ ...base, type: z.literal('NumberInput').describe('Element type discriminator selecting the declared screen component.'), param: Identifier.describe('Declared parameter key edited by this control.'), label: z.string().min(1).max(60).describe('Display label for this element.') }),
  z.strictObject({ ...base, type: z.literal('SelectInput').describe('Element type discriminator selecting the declared screen component.'), param: Identifier.describe('Declared parameter key edited by this control.'), label: z.string().min(1).max(60).describe('Display label for this element.') }),
  z.strictObject({
    ...base,
    type: z.literal('TextInput').describe('Element type discriminator selecting the declared screen component.'),
    param: Identifier.describe('Declared parameter key edited by this control.'),
    label: z.string().min(1).max(60).describe('Display label for this element.'),
    /** `true` shows one chip per value. This is the watchlist box. */
    list: z.boolean().default(false).describe('Whether text input displays a string list as chips, defaulting to false when omitted.'),
    placeholder: z.string().min(1).max(80).optional().describe('Optional text input hint, with no placeholder specified when omitted.'),
  }),
  z.strictObject({
    ...base,
    type: z.literal('DateRangeInput').describe('Element type discriminator selecting the declared screen component.'),
    fromParam: Identifier.describe('Declared parameter key edited as the start date of the range.'),
    toParam: Identifier.describe('Declared parameter key edited as the end date of the range.'),
    label: z.string().min(1).max(60).describe('Display label for this element.'),
  }),

  /** 12. re-run with the current settings */
  z.strictObject({ ...base, type: z.literal('RunButton').describe('Element type discriminator selecting the declared screen component.'), label: z.string().min(1).max(40).default('Run').describe('Button label, defaulting to Run when omitted.') }),
] as const;

/**
 * One schema per element type. The validator reports against exactly one of these
 * rather than against the union, so an element with a valid `type` and one bad
 * property is not also told it should have been a different element.
 */
export const ELEMENT_SCHEMA = Object.fromEntries(
  ELEMENTS.map((schema) => {
    const shape = (schema as unknown as { _zod?: unknown; def?: { shape?: Record<string, unknown> } }).def?.shape
      ?? (schema as unknown as { innerType?: () => { def: { shape: Record<string, unknown> } } }).innerType?.().def.shape;
    const literal = (shape as { type?: { def?: { values?: string[] } } } | undefined)?.type?.def?.values?.[0];
    return [literal as string, schema];
  }),
) as Record<string, (typeof ELEMENTS)[number]>;

export const UiElement = z.discriminatedUnion('type', ELEMENTS as unknown as [z.ZodObject, z.ZodObject, ...z.ZodObject[]]);
export type UiElement = z.infer<typeof UiElement>;

/** A flat map of elements plus the id of the outermost one. A Section's children make it a tree. */
export const UiSpec = z.strictObject({
  root: ElementId.describe('Element id of the outermost section in the screen tree.'),
  elements: boundedRecord(ElementId, UiElement, 60, 'screen elements').describe('Map from element ids to their screen definitions, with section children linking the tree.'),
});
export type UiSpec = z.infer<typeof UiSpec>;

export const ELEMENT_TYPES = [
  'Section', 'Text', 'Metric', 'Table', 'Chart', 'Callout', 'List',
  'NumberInput', 'SelectInput', 'TextInput', 'DateRangeInput', 'RunButton',
] as const;
