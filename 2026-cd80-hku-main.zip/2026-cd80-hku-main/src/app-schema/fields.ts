import { z } from 'zod';

/** The four data types. Matches docs/CONTRACTS.md section 1 exactly. */
export const FieldType = z.enum(['text', 'number', 'date', 'boolean']);
export type FieldType = z.infer<typeof FieldType>;

/** A column, as the data layer describes it. */
export const FieldSpec = z.strictObject({
  name: z.string().min(1).describe('Column name as exposed by the data layer.'),
  label: z.string().min(1).describe('Display label for the column.'),
  type: FieldType.describe('Column data type, either text, number, date, or boolean.'),
  unit: z.string().min(1).optional().describe('Optional unit label for the column values, with no unit specified when omitted.'),
  nullable: z.boolean().describe('Whether the column permits null values.'),
});
export type FieldSpec = z.infer<typeof FieldSpec>;

/**
 * Anything that looks like an address or a path.
 *
 * Applied to every machine-read string in the `data` section, which is what makes the
 * guarantee in spec section 20 true: a data requirement names fields, never addresses,
 * so it cannot be used to reach the network. Free prose shown to the person — a
 * description, a `Text` body, AI instructions — is deliberately NOT filtered: it is
 * never resolved, fetched or executed.
 */
const SCHEME = /[a-z][a-z0-9+.\-]*:\/\//i;
const ABSOLUTE_PATH = /^(\/|~\/|\.\.\/|[A-Za-z]:[\\/])/;
const DANGEROUS_SCHEME = /^\s*(javascript|data|file|blob|vbscript):/i;

export function noAddress<T extends z.ZodString>(schema: T) {
  const max = schema.maxLength;
  if (max === null) throw new Error('Address checks need a maximum string length.');
  return schema.refine((v) => v.length > max || (!SCHEME.test(v) && !ABSOLUTE_PATH.test(v) && !DANGEROUS_SCHEME.test(v)), {
    error: 'must not contain a URL, a scheme or a file path',
  });
}

/**
 * A map with a hard size cap. A plain `z.record` is unbounded, which lets a document
 * declare ten thousand derived columns or ten thousand screen elements and still parse.
 */
export function boundedRecord<K extends z.ZodType<string>, V extends z.ZodType>(
  key: K,
  value: V,
  max: number,
  what: string,
) {
  return z
    .record(key, value)
    .refine((o) => Object.keys(o).length <= max, { error: `at most ${max} ${what} are allowed` })
    .refine((o) => Object.keys(o).length > 0, { error: `at least one ${what.replace(/s$/, '')} is required` });
}

/**
 * A relation name, and also a step id and a data-requirement key.
 * One flat namespace: a requirement keyed `prices` and a step with id `prices`
 * both claim the table `prices`, which is a duplicate-name error.
 */
export const Identifier = z
  .string()
  .max(40, { abort: true })
  .regex(/^[a-z][a-z0-9_]{0,39}$/, {
    error: 'must be lower-case letters, digits and underscores, starting with a letter, 1-40 characters',
  });
export type Identifier = z.infer<typeof Identifier>;

/** A column name as written in the data. Looser than Identifier: real data has mixed case. */
export const ColumnName = noAddress(z.string().min(1).max(128));

/**
 * A whole number, or the name of a parameter that supplies it at run time.
 *
 * Without this, a control wired to "how many rows to show" would move and change
 * nothing, which is the silently dead control the specification sets out to avoid.
 * The value is substituted when the run starts, so changing it regenerates nothing.
 */
export function intOrParam(min: number, max: number) {
  return z.union([
    z.number().int().min(min).max(max),
    z.strictObject({ param: Identifier.describe('Declared parameter key supplying the integer value at run time.') }),
  ]);
}

/** A one-line formula, for example `(close - open) / open`. Parsed by jsep at validation time. */
export const Expr = z.string().min(1).max(2000);
export type Expr = z.infer<typeof Expr>;

/** An ISO date, `2026-10-13`. */
export const IsoDate = z.string().max(10, { abort: true }).regex(/^\d{4}-\d{2}-\d{2}$/, {
  error: 'must be YYYY-MM-DD',
});

/**
 * A value a parameter may hold. Deliberately only JSON scalars and a list of strings.
 *
 * This is the field that would otherwise be the hole in "an application contains no data
 * rows and no credentials": an unconstrained default could carry a whole table, a file
 * path or a token. Nothing nested is allowed, so it cannot.
 */
export const ParamScalar = z.union([z.string().max(500), z.number().finite(), z.boolean()]);
export const ParamValue = z.union([ParamScalar, z.array(z.string().max(500)).max(500)]);
export type ParamValue = z.infer<typeof ParamValue>;
