/**
 * The 24 icons we ship. `meta.icon` must be one of these names.
 * An unknown name is a warning, not an error, and falls back to `chart-line`.
 */
export const ICONS = [
  'chart-line', 'chart-bar', 'chart-candle', 'chart-pie',
  'table', 'list', 'calendar', 'clock',
  'bell', 'flag', 'star', 'bookmark',
  'coins', 'bank', 'receipt', 'wallet',
  'briefcase', 'building', 'globe', 'scales',
  'search', 'filter', 'shield', 'spark',
] as const;

export const DEFAULT_ICON = 'chart-line';
export type IconName = (typeof ICONS)[number];
