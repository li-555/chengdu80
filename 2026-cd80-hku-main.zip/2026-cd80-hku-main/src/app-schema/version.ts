import { createHash } from 'node:crypto';
import type { AppDocument } from './document.ts';

/**
 * Deterministic JSON: object keys sorted, so two documents that differ only in key
 * order always hash the same.
 *
 * Anything that JSON cannot represent faithfully is refused rather than quietly
 * flattened. `JSON.stringify` turns NaN and Infinity into `null` and a Date into `{}`
 * once key-sorting is involved, which would make two different documents hash the same.
 * A fingerprint that silently collides is worse than no fingerprint.
 */
export function canonicalJson(value: unknown): string {
  if (value === null || value === undefined) return 'null';

  const t = typeof value;
  if (t === 'bigint' || t === 'function' || t === 'symbol') {
    throw new TypeError(`cannot fingerprint a value of type ${t}`);
  }
  if (t === 'number') {
    if (!Number.isFinite(value as number)) {
      throw new TypeError(`cannot fingerprint the number ${String(value)}`);
    }
    return JSON.stringify(value);
  }
  if (t === 'string' || t === 'boolean') return JSON.stringify(value);

  if (value instanceof Date) {
    const ms = value.getTime();
    if (Number.isNaN(ms)) throw new TypeError('cannot fingerprint an invalid Date');
    return JSON.stringify(value.toISOString());
  }

  if (Array.isArray(value)) {
    // Array.from fills sparse holes, so a hole becomes null instead of producing `[,]`.
    return `[${Array.from(value, (v) => canonicalJson(v)).join(',')}]`;
  }

  if (t === 'object') {
    const entries = Object.entries(value as Record<string, unknown>)
      .filter(([, v]) => v !== undefined)
      .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
    return `{${entries.map(([k, v]) => `${JSON.stringify(k)}:${canonicalJson(v)}`).join(',')}}`;
  }

  throw new TypeError(`cannot fingerprint a value of type ${t}`);
}

/**
 * The application's content fingerprint: 12 hex characters of SHA-256 over the canonical
 * JSON of `{ params, data, compute, triggers, ui }` plus `meta` without `updated_at`.
 *
 * Parameters are included, so changing a default changes the version.
 * Exporting and re-importing gives the same fingerprint. That is how we prove an import
 * is the same application.
 */
export function appVersion(doc: AppDocument): string {
  const { updated_at: _ignored, ...meta } = doc.meta;
  const payload = canonicalJson({
    meta,
    params: doc.params,
    data: doc.data,
    compute: doc.compute,
    triggers: doc.triggers,
    ui: doc.ui,
  });
  return createHash('sha256').update(payload, 'utf8').digest('hex').slice(0, 12);
}

/** What the person sees: `v3-a1b2c3d4e5f6`. `rev` is a counter the platform keeps. */
export function appVersionLabel(rev: number, hash12: string): string {
  return `v${rev}-${hash12}`;
}
