import { z } from 'zod';
import { ColumnName, Expr, FieldType, Identifier } from './fields.ts';
import { OperationParams, type OperationName } from './operations.ts';

/**
 * One calculation step. Its `id` is also the name of the relation it produces,
 * in the one flat namespace shared with data-requirement keys.
 *
 * `key: true` marks a step as worth showing in the Inspect panel. The panel also
 * shows any step whose output the screen reads, which needs no cooperation from
 * the generating model — that is what guarantees a non-empty panel for an
 * application a stranger wrote.
 */
const base = {
  id: Identifier.describe('Unique step name that also names its output in the namespace shared with data requirement keys.'),
  title: z.string().min(1).max(120).optional().describe('Optional display title for the calculation, with no title specified when omitted.'),
  key: z.boolean().optional().describe('Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.'),
};

/**
 * Every named operation except `ai`, which has its own step kind below.
 *
 * Exported per operation as well as as a union. A union error reports the failures of
 * every branch at once -- a step with a valid `kind` but one bad parameter would come
 * back also claiming it should have been SQL. The validator routes a step to its exact
 * branch by `kind` and `op` first, so the repair cycle is fed only the real problem.
 */
const operationStep = <N extends Exclude<OperationName, 'ai'>>(name: N) =>
  z.strictObject({
    ...base,
    kind: z.literal('operation').describe('Step discriminator identifying a named operation.'),
    op: z.literal(name as Exclude<OperationName, 'ai'>).describe('Named operation selected by this schema branch.'),
    input: Identifier.describe('Data requirement key or step id of the primary input table, which is the first table for join.'),
    params: (OperationParams[name] as z.ZodType).describe('Parameters for the selected operation.'),
  });

type OperationStepSchema = ReturnType<typeof operationStep>;

const OPERATION_LIST: OperationStepSchema[] = (Object.keys(OperationParams) as OperationName[])
  .filter((name): name is Exclude<OperationName, 'ai'> => name !== 'ai')
  .map((name) => operationStep(name));

export const OPERATION_STEP: Record<string, OperationStepSchema> = Object.fromEntries(
  OPERATION_LIST.map((schema, i) => [
    (Object.keys(OperationParams) as OperationName[]).filter((n) => n !== 'ai')[i]!,
    schema,
  ]),
);

const NamedOperation = z.discriminatedUnion(
  'op',
  OPERATION_LIST as [OperationStepSchema, ...OperationStepSchema[]],
);

/** A raw SQL step. Checked by DuckDB's own parser at validation time, not by string matching. */
const SqlStep = z.strictObject({
  ...base,
  kind: z.literal('sql').describe('Step discriminator identifying a SQL calculation.'),
  /** Declared inputs. Rule 4 of the allow-list also derives these from the parse tree. */
  input: z.array(Identifier).max(8).optional().describe('Declared relation names available to the SQL query, with no relations declared when omitted.'),
  sql: z.string().min(1).max(20000).describe('Read-only SQL query checked by the SQL validator against declared inputs.'),
});

/** A one-line formula producing a single value, which later steps may use in expressions. */
const ExpressionStep = z.strictObject({
  ...base,
  kind: z.literal('expression').describe('Step discriminator identifying a scalar expression.'),
  input: Identifier.optional().describe('Optional data requirement key or step id declared as input, with no input declared when omitted.'),
  expr: Expr.describe('Formula intended to produce a single value addressable by this step id.'),
});

/** The AI working as one step of the running application. Spec section 10. */
const AiStep = z.strictObject({
  ...base,
  kind: z.literal('ai').describe('Step discriminator identifying a row interpretation step.'),
  input: Identifier.describe('Data requirement key or step id providing the input rows.'),
  params: OperationParams.ai.describe('Processing limits, instructions, output shape, and error policy for this step.'),
});

/**
 * The escape hatch: JavaScript in a QuickJS WebAssembly sandbox.
 * It exists for work that is a different shape — logic where each step depends on
 * the one before it, and bookkeeping carried from one run to the next.
 */
const CodeStep = z.strictObject({
  ...base,
  kind: z.literal('code').describe('Step discriminator identifying a sandboxed code calculation.'),
  input: z.array(Identifier).min(1).max(3).describe('One to three declared input relation names.'),
  output: z.strictObject({
    columns: z.array(z.strictObject({ name: ColumnName.describe('Output table column name.'), type: FieldType.describe('Output table column data type.') })).min(1).max(64).describe('One to 64 column declarations for the result table.'),
  }).describe('Declared columns and types for the result table.'),
  /** `true` gives the body a `state` object carried from the previous successful run. 64 KB cap. */
  carry_state: z.boolean().default(false).describe('Whether state from the previous successful run is available, capped at 64 KB and defaulting to false when omitted.'),
  body: z.string().min(1).max(40000).describe('Sandboxed JavaScript body containing 1 to 40000 characters.'),
});

export const ComputeStep = z.union([NamedOperation, SqlStep, ExpressionStep, AiStep, CodeStep]);
export type ComputeStep = z.infer<typeof ComputeStep>;

/** The schema for one step kind, so the validator can report against exactly one branch. */
export const STEP_SCHEMA = {
  operation: NamedOperation,
  sql: SqlStep,
  expression: ExpressionStep,
  ai: AiStep,
  code: CodeStep,
} as const;

export const STEP_KINDS = ['operation', 'sql', 'expression', 'ai', 'code'] as const;
export type StepKind = (typeof STEP_KINDS)[number];
