import type { z } from 'zod';
import { OperationParams, OPERATION_SHAPE, type OperationName } from './operations.ts';
import type { AppDocument } from './document.ts';
import type { STEP_SCHEMA } from './compute.ts';
import type { TriggerSpec } from './triggers.ts';
import type { ELEMENT_TYPES } from './ui.ts';

type OperationInfo<N extends OperationName> = {
  family: 'shaping' | 'time_series' | 'statistics' | 'finance';
  summary: string;
  output: (typeof OPERATION_SHAPE)[N]['output'];
  example: z.input<(typeof OperationParams)[N]>;
  notes?: string;
};

/** What each operation does, with invented column names in its parameter example. */
export const OPERATION_INFO = {
  filter: {
    family: 'shaping', summary: 'Keep matching rows with all input columns unchanged.',
    output: OPERATION_SHAPE.filter.output, example: { where: 'harbor_price > 20' },
  },
  derive: {
    family: 'shaping', summary: 'Keep input columns and append the named calculated columns.',
    output: OPERATION_SHAPE.derive.output, example: { columns: { harbor_gain: 'harbor_price - harbor_cost' } },
  },
  join: {
    family: 'shaping', summary: 'Combine matching rows, retaining left columns and non-key right columns, with right relation suffixes and numbered suffixes for name collisions.',
    output: OPERATION_SHAPE.join.output, example: { right: 'harbor_sectors', on: [['harbor_code', 'harbor_code']], how: 'left' },
  },
  aggregate: {
    family: 'shaping', summary: 'Return one row per group with the grouping columns and named summary columns.',
    output: OPERATION_SHAPE.aggregate.output, example: { by: ['harbor_sector'], metrics: [{ fn: 'mean', of: 'harbor_price', as: 'harbor_average' }] },
  },
  sort_limit: {
    family: 'shaping', summary: 'Sort rows and optionally skip or limit them while retaining all input columns.',
    output: OPERATION_SHAPE.sort_limit.output, example: { by: [{ col: 'harbor_price', dir: 'desc' }], limit: 10, offset: 0 },
  },
  pivot: {
    family: 'shaping', summary: 'Return index columns and one summary column per category in the pivot column.',
    output: OPERATION_SHAPE.pivot.output, example: { index: ['harbor_day'], on: 'harbor_sector', values: 'harbor_price', agg: 'mean' },
  },
  window: {
    family: 'time_series', summary: 'Keep input columns and append a named running or rolling summary over the ordered frame.',
    output: OPERATION_SHAPE.window.output, example: { fn: 'mean', of: 'harbor_price', partition_by: ['harbor_code'], order_by: [{ col: 'harbor_day', dir: 'asc' }], frame: { kind: 'rows', preceding: 4, following: 0 }, as: 'harbor_rolling' },
  },
  lag_change: {
    family: 'time_series', summary: 'Keep input columns and append a named difference, fractional change or logarithmic change from an earlier row.',
    output: OPERATION_SHAPE.lag_change.output, example: { of: 'harbor_price', periods: 1, mode: 'pct', partition_by: ['harbor_code'], order_by: [{ col: 'harbor_day', dir: 'asc' }], as: 'harbor_change' },
  },
  resample: {
    family: 'time_series', summary: 'Return grouping columns, the original date column set to each period start, and named summary columns.',
    output: OPERATION_SHAPE.resample.output, example: { date_col: 'harbor_day', by: ['harbor_code'], to: 'month', metrics: [{ fn: 'mean', of: 'harbor_price', as: 'harbor_average' }] },
  },
  adjust_price: {
    family: 'time_series', summary: 'Keep input columns and replace selected prices under their original names using cumulative split and dividend adjustment factors.',
    output: OPERATION_SHAPE.adjust_price.output, example: { price_cols: ['harbor_price'], factor_table: 'harbor_adjustments', key: ['harbor_code', 'harbor_security'], date: ['harbor_day', 'harbor_date'], factor_col: 'harbor_multiplier', mode: 'forward', base_date: '2026-01-30' },
  },
  rank: {
    family: 'statistics', summary: 'Keep input columns and append a named rank, dense rank, row number or percentile within each group.',
    output: OPERATION_SHAPE.rank.output, example: { by: 'harbor_price', direction: 'desc', within: ['harbor_sector'], method: 'dense', as: 'harbor_rank' },
  },
  zscore: {
    family: 'statistics', summary: 'Keep input columns and append a named distance from the mean in sample standard deviations, optionally over a full rolling window.',
    output: OPERATION_SHAPE.zscore.output, example: { of: 'harbor_price', within: ['harbor_code'], window: 20, order_by: [{ col: 'harbor_day', dir: 'asc' }], as: 'harbor_score' },
  },
  describe: {
    family: 'statistics', summary: 'Return a long table with one row per numeric column and columns column, count, mean, std, min, q25, median, q75 and max.',
    output: OPERATION_SHAPE.describe.output, example: { columns: ['harbor_price', 'harbor_volume'] },
  },
  correlate: {
    family: 'statistics', summary: 'Return a long table with one row per distinct column pair and columns col_a, col_b, corr and n.',
    output: OPERATION_SHAPE.correlate.output, example: { columns: ['harbor_price', 'harbor_volume'], method: 'pearson', min_periods: 5 },
  },
  regress: {
    family: 'statistics', summary: 'Return a long table of fitted intercept and predictor terms with grouping columns plus term, coefficient, r2 and n.',
    output: OPERATION_SHAPE.regress.output, example: { y: 'harbor_return', x: ['harbor_market', 'harbor_size'], by: ['harbor_sector'] },
  },
  irr: {
    family: 'finance', summary: 'Return one annual break-even rate as a scalar value, read from the single irr column.',
    output: OPERATION_SHAPE.irr.output, example: { amount_col: 'harbor_payment', date_col: 'harbor_day', guess: 0.1, max_iter: 100 },
  },
  factor: {
    family: 'finance', summary: 'Return one row per security on its latest eligible day with ts_code, trade_date and a column named after the chosen market factor.',
    output: OPERATION_SHAPE.factor.output, example: { factor: 'momentum_20d', universe: 'harbor_universe', as_of: '2026-01-30' },
    notes: 'The supported factor list, meanings and required columns are published in operations.json under factor.supported.',
  },
  ai: {
    family: 'finance', summary: 'Return model responses as a typed table for the whole input or individual rows using the declared text, enum or object output shape.',
    output: OPERATION_SHAPE.ai.output, example: { mode: 'whole', instructions: 'Summarize the pattern in harbor_price and harbor_volume.', max_rows: 50, max_input_chars: 20000, output: { kind: 'object', fields: { harbor_summary: 'string' } }, on_error: 'null' },
  },
} satisfies { [N in OperationName]: OperationInfo<N> };

type BlockInfo<T> = { en: string; zh: string; example: T };

/** Document sections, calculation steps and triggers each have their own vocabulary. */
export const BLOCK_INFO = {
  sections: {
    meta: { en: 'Name and describe the application and declare its specification version.', zh: '为应用命名并说明用途，同时声明所使用的规范版本。', example: { name: 'Harbor Prices', description: 'Review invented daily price changes.', spec_version: '1.0' } },
    params: { en: 'Declare settings that controls and calculations can read when the application runs.', zh: '声明运行时可供控件和计算读取的设置。修改设置后可重新运行应用。', example: [{ key: 'harbor_limit', label: 'Rows to show', type: 'number', default: 10, min: 1, max: 50 }] },
    data: { en: 'Declare required fields and optional windows or parameter filters without embedding data rows.', zh: '声明所需字段，以及可选的时间窗口和参数筛选条件。此部分不包含数据行。', example: [{ key: 'harbor_prices', grain: 'daily', fields: [{ name: 'harbor_price', type: 'number', required: true }] }] },
    compute: { en: 'Declare calculation steps whose ids name results available to later steps and the screen.', zh: '声明计算步骤，每个步骤的标识符也是其结果的名称。后续步骤和界面可以读取这些结果。', example: [{ id: 'harbor_positive', kind: 'operation', op: 'filter', input: 'harbor_prices', params: { where: 'harbor_price > 0' } }] },
    triggers: { en: 'Declare when the application runs, by hand, by schedule or around trading hours.', zh: '声明应用的运行时机，可选择手动运行、定时运行或在交易开收盘前后运行。', example: [{ kind: 'manual' }] },
    ui: { en: 'Declare a flat map of screen elements and the root section whose children form the screen.', zh: '声明界面元素映射和根容器。容器通过子元素标识符组成界面结构。', example: { root: 'harbor_page', elements: { harbor_page: { type: 'Section', children: ['harbor_intro'] }, harbor_intro: { type: 'Text', text: 'Invented price overview.' } } } },
  },
  steps: {
    operation: { en: 'Run a named operation with its own parameter shape over an input relation.', zh: '对输入表执行一个命名操作，并按该操作的参数结构填写参数。', example: { id: 'harbor_positive', kind: 'operation', op: 'filter', input: 'harbor_prices', params: { where: 'harbor_price > 0' } } },
    sql: { en: 'Run a single allowed SELECT or WITH query over declared input relations.', zh: '对声明的输入表执行一条允许的 SELECT 或 WITH 查询。', example: { id: 'harbor_total', kind: 'sql', input: ['harbor_prices'], sql: 'SELECT sum(harbor_price) AS harbor_total FROM harbor_prices' } },
    expression: { en: 'Evaluate a one-line formula to produce a single value for later calculations.', zh: '计算一个单行公式，得到可供后续计算使用的单个值。', example: { id: 'harbor_assumption', kind: 'expression', expr: '2 * 3' } },
    ai: { en: 'Ask the configured model about input rows and declare the shape of its response.', zh: '让已配置的模型分析输入行，并声明响应的数据结构。', example: { id: 'harbor_summary', kind: 'ai', input: 'harbor_prices', params: { mode: 'whole', instructions: 'Summarize harbor_price.', max_rows: 10, max_input_chars: 2000, output: { kind: 'text' }, on_error: 'null' } } },
    code: { en: 'Run sandboxed JavaScript with declared inputs and output columns, optionally carrying state across successful runs.', zh: '在沙箱中运行 JavaScript，并声明输入表和输出列。可选择在成功运行之间保留状态。', example: { id: 'harbor_constant', kind: 'code', input: ['harbor_prices'], output: { columns: [{ name: 'harbor_value', type: 'number' }] }, carry_state: false, body: 'return [{ harbor_value: 1 }];' } },
  },
  triggers: {
    manual: { en: 'Allow a person to run the application with its current settings.', zh: '允许用户按当前设置手动运行应用。', example: { kind: 'manual' } },
    schedule: { en: 'Run on a five-field cron schedule in the named time zone.', zh: '按五字段 cron 表达式定时运行，时间以指定时区为准。', example: { kind: 'schedule', cron: '0 8 * * 1-5', tz: 'Asia/Shanghai' } },
    market: { en: 'Run before or after market opening or closing on actual trading days in the SSE calendar.', zh: '按上交所交易日历，在实际交易日的开盘或收盘前后运行。', example: { kind: 'market', at: 'close', offsetMinutes: 15, calendar: 'SSE' } },
    alert: { en: 'Run on a schedule and raise a notification only when the result condition holds.', zh: '按计划运行，仅在结果满足条件时发出通知。', example: { kind: 'alert', cron: '0 16 * * 1-5', tz: 'Asia/Shanghai', condition: 'harbor_assumption > 5' } },
  },
} satisfies {
  sections: { [N in keyof AppDocument]: BlockInfo<z.input<typeof import('./document.ts').AppDocument>[N]> };
  steps: { [N in keyof typeof STEP_SCHEMA]: BlockInfo<z.input<(typeof STEP_SCHEMA)[N]>> };
  triggers: { [N in TriggerSpec['kind']]: BlockInfo<z.input<typeof import('./triggers.ts').TriggerSpec> & { kind: N }> };
};

/** The screen catalogue groups elements by the job they do on the page. */
export const COMPONENT_INFO = {
  Section: { family: 'layout', summary: 'Arrange child elements in one, two or three columns with an optional title.' },
  Text: { family: 'display', summary: 'Show prose as a heading, body or caption.' },
  Metric: { family: 'display', summary: 'Show one formatted result value with an optional change and unit.' },
  Table: { family: 'display', summary: 'Show result rows in named, formatted columns with pagination.' },
  Chart: { family: 'chart', summary: 'Plot daily results as a line, bar, candlestick or heatmap chart.' },
  Callout: { family: 'display', summary: 'Show a note with an optional title and semantic tone.' },
  List: { family: 'display', summary: 'Show result rows as items with titles and optional bodies, links, tones and groups.' },
  NumberInput: { family: 'control', summary: 'Edit a named numeric parameter.' },
  SelectInput: { family: 'control', summary: 'Choose among the declared options of a named text parameter.' },
  TextInput: { family: 'control', summary: 'Edit a named text parameter or list of text values.' },
  DateRangeInput: { family: 'control', summary: 'Edit the two named parameters that define a date range.' },
  RunButton: { family: 'control', summary: 'Run the application with its current settings.' },
} satisfies Record<(typeof ELEMENT_TYPES)[number], { family: 'display' | 'chart' | 'control' | 'layout'; summary: string }>;
