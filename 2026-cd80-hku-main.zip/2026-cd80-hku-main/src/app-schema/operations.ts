import { z } from 'zod';
import { boundedRecord, ColumnName, Expr, Identifier, intOrParam, IsoDate } from './fields.ts';

/** Summary functions available to `aggregate` and `resample`. */
export const AggFn = z.enum([
  'sum', 'mean', 'median', 'min', 'max',
  'count', 'count_distinct', 'stddev', 'var', 'quantile',
]);

const Metric = z
  .strictObject({
    fn: AggFn.describe('Summary function to apply, with stddev and var using sample statistics.'),
    of: ColumnName.optional().describe('Input column to summarise, required except for count, which counts all rows when omitted.'),          // omitted only for `count`
    as: ColumnName.describe('Name of the output column holding this summary.'),
    p: z.number().min(0).max(1).optional().describe('Quantile fraction from 0 to 1, required for quantile and unused by other summary functions.'), // the quantile, 0..1
  })
  .refine((m) => m.fn === 'count' || m.of !== undefined, {
    error: 'of is required for every function except count',
    path: ['of'],
  })
  .refine((m) => m.fn !== 'quantile' || m.p !== undefined, {
    error: 'p is required for quantile, between 0 and 1',
    path: ['p'],
  });

const OrderBy = z.array(z.strictObject({ col: ColumnName.describe('Input column used to order rows.'), dir: z.enum(['asc', 'desc']).describe('Sort direction, ascending for asc or descending for desc.') })).min(1).max(8);

/**
 * The 18 calculation operations, each with its own parameter shape.
 * Every one of them is required: see STATE.md, decision of 2026-10-13.
 *
 * The map is the single source of truth. `spec:build` turns it into
 * `operations.json`, so the published specification cannot drift from the code.
 */
export const OperationParams = {
  /** 1. keep only the rows that match a condition */
  filter: z.strictObject({ where: Expr.describe('Boolean expression that keeps only input rows for which it is true.') }),

  /** 2. add calculated columns */
  derive: z.strictObject({
    columns: boundedRecord(ColumnName, Expr, 64, 'derived columns').describe('Map from each new output column name to the expression calculated for every input row.'),
  }),

  /** 3. put two tables side by side on a matching key */
  join: z
    .strictObject({
      right: Identifier.describe('Data requirement key or step id of the second table, while the step input names the first table.'),
      on: z.array(z.tuple([ColumnName, ColumnName])).min(1).max(8).describe('Pairs of equality keys in the order [column in the input table, column in the right table].'),
      how: z.enum(['inner', 'left', 'asof']).describe('Join kind, retaining matching rows for inner or all input rows for left and asof.'),
      asof_on: z.tuple([ColumnName, ColumnName]).optional().describe('Ordered matching columns as [column in the input table, column in the right table], required for asof and adding no ordered match when omitted for other join kinds.'),
      direction: z.enum(['backward', 'forward', 'nearest']).optional().describe('As-of matching direction, defaulting to backward for the latest right row at or before the input row, with forward choosing the earliest at or after it and nearest currently unsupported.'),
    })
    .refine((p) => p.how !== 'asof' || p.asof_on !== undefined, {
      error: 'asof_on is required when how is asof',
      path: ['asof_on'],
    })
    .refine((p) => p.how === 'asof' || p.direction === undefined, {
      error: 'direction only applies when how is asof',
      path: ['direction'],
    }),

  /** 4. group rows and summarise each group */
  aggregate: z.strictObject({
    by: z.array(ColumnName).max(8).describe('Grouping columns, with an empty array producing one summary across the whole input.'),
    metrics: z.array(Metric).min(1).max(32).describe('Summary definitions producing one output column each per group.'),
  }),

  /** 5. sort, then take the top N */
  sort_limit: z.strictObject({
    by: OrderBy.describe('Sort columns and directions in priority order.'),
    limit: intOrParam(1, 200000).optional().describe('Maximum number of output rows, supplied as an integer or parameter reference, with no row limit when omitted.'),
    offset: intOrParam(0, 200000).optional().describe('Number of sorted rows to skip, supplied as an integer or parameter reference, defaulting to zero when omitted.'),
  }),

  /** 6. a running or rolling calculation, e.g. a 5-day average price */
  window: z.strictObject({
    fn: z.enum(['sum', 'mean', 'min', 'max', 'count', 'stddev', 'first', 'last']).describe('Calculation applied within each frame, with stddev using sample standard deviation and count counting non-null values.'),
    of: ColumnName.describe('Input column whose values are calculated within each frame.'),
    partition_by: z.array(ColumnName).max(4).optional().describe('Columns separating independent row groups, with all rows in one group when omitted.'),
    order_by: OrderBy.describe('Columns and directions defining row order within each partition.'),
    frame: z.strictObject({
      kind: z.enum(['rows', 'range']).describe('Frame measure, using row counts for rows or ordered-value distances for range, measured in days for date or timestamp order columns.'),
      preceding: intOrParam(0, 100000).describe('Distance before the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps.'),
      following: intOrParam(0, 100000).describe('Distance after the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps.'),
    }).describe('Inclusive frame around the current row using row counts or ordered-value distances.'),
    as: ColumnName.describe('Name of the new output column containing the window calculation.'),
  }),

  /** 7. compare a row with an earlier one — growth, momentum */
  lag_change: z.strictObject({
    of: ColumnName.describe('Input column compared with its earlier value.'),
    periods: intOrParam(1, 10000).describe('Number of ordered rows to look back within the partition, supplied as an integer or parameter reference.'),
    mode: z.enum(['diff', 'pct', 'log']).describe('Change calculation, using current minus earlier for diff, current divided by earlier minus one for pct as a fraction, or the natural logarithm of their positive ratio for log.'),
    partition_by: z.array(ColumnName).max(4).optional().describe('Columns separating independent histories, with all rows in one history when omitted.'),
    order_by: OrderBy.describe('Columns and directions determining which rows are earlier.'),
    as: ColumnName.describe('Name of the new output column containing the change.'),
  }),

  /** 8. position each row in an order */
  rank: z.strictObject({
    by: ColumnName.describe('Input column whose values determine the rank.'),
    direction: z.enum(['asc', 'desc']).describe('Ascending or descending order used to assign ranks.'),
    within: z.array(ColumnName).max(4).optional().describe('Columns separating independent ranking groups, with all rows ranked together when omitted.'),
    method: z.enum(['rank', 'dense', 'row_number', 'percentile']).describe('Ranking rule, using gaps for rank, no gaps for dense, distinct row numbers for row_number, or a fraction from 0 to 1 for percentile.'),
    as: ColumnName.describe('Name of the new output column containing the rank.'),
  }),

  /** 9. how unusual a value is, in standard deviations from the average */
  zscore: z
    .strictObject({
      of: ColumnName.describe('Input column standardised as its value minus the mean divided by sample standard deviation.'),
      within: z.array(ColumnName).max(4).optional().describe('Columns separating independent standardisation groups, with all rows in one group when omitted.'),
      window: intOrParam(2, 100000).optional().describe('Rolling frame size in rows including the current row, supplied as an integer or parameter reference, requiring that many non-null values and using the entire group when omitted.'),
      /** Which rows count as "earlier". A rolling window means nothing without it. */
      order_by: OrderBy.optional().describe('Columns and directions defining rolling row order, required when window is set and ignored otherwise.'),
      as: ColumnName.describe('Name of the new output column containing the dimensionless standard score.'),
    })
    .refine((p) => p.window === undefined || p.order_by !== undefined, {
      error: 'order_by is required when window is set',
      path: ['order_by'],
    }),

  /** 10. roll daily rows up to weeks, months, quarters or years */
  resample: z.strictObject({
    date_col: ColumnName.describe('Input date column whose name is preserved in the output and whose value becomes the first day of each period.'),
    /** Keep each company apart; without it forty companies are added together. */
    by: z.array(ColumnName).max(4).optional().describe('Additional grouping columns kept separate within each period, with no additional grouping when omitted.'),
    to: z.enum(['week', 'month', 'quarter', 'year']).describe('Calendar period to aggregate into, with weeks starting on Monday.'),
    metrics: z.array(Metric).min(1).max(32).describe('Summary definitions calculated for each period and additional group.'),
  }),

  /** 11. turn rows into columns, one column per category */
  pivot: z.strictObject({
    index: z.array(ColumnName).min(1).max(4).describe('Columns identifying each output row and grouping the pivoted values.'),
    on: ColumnName.describe('Input category column whose distinct values become output columns.'),
    values: ColumnName.describe('Input column whose values are summarised in each pivot cell.'),
    agg: AggFn.describe('Summary function for each pivot cell, with quantile currently unsupported.'),
  }),

  /** 12. the standard summary of each column */
  describe: z.strictObject({ columns: z.array(ColumnName).max(64).optional().describe('Numeric input columns to summarise, defaulting to all numeric input columns when omitted.') }),

  /** 13. how strongly two columns move together, between -1 and 1 */
  correlate: z.strictObject({
    columns: z.array(ColumnName).min(2).max(32).describe('Input columns for which each distinct pair receives a correlation result.'),
    method: z.enum(['pearson', 'spearman']).describe('Correlation method, using raw values for pearson or average ranks for spearman.'),
    min_periods: z.number().int().min(2).max(100000).optional().describe('Minimum count of rows with both values present before returning a correlation, with no additional count threshold when omitted.'),
  }),

  /** 14. fit a straight line and report its slope, intercept and fit quality */
  regress: z.strictObject({
    y: ColumnName.describe('Dependent input column to fit.'),
    x: z.array(ColumnName).min(1).max(16).describe('Predictor input columns for the regression, allowing 1 to 16 names in the schema.'),
    by: z.array(ColumnName).max(4).optional().describe('Columns separating independent regression groups, with one fit across the input when omitted.'),
  }),

  /**
   * 15. correct historical prices for share splits and dividends.
   * `factor_table` is a relation name: the adjustment factors must be bound as a
   * data requirement like anything else. There is no local table any more.
   */
  adjust_price: z.strictObject({
    price_cols: z.array(ColumnName).min(1).max(8).describe('Input price columns replaced by adjusted values under the same names and in the same price units.'),
    factor_table: Identifier.describe('Data requirement key or step id of the cumulative adjustment factor table, distinct from the input price table.'),
    /** [price column, factor column] naming the security, e.g. ['code', 'ts_code']. */
    key: z.tuple([ColumnName, ColumnName]).describe('Security key columns in the order [column in the input table, column in the factor table].'),
    /** [price column, factor column] naming the trading day. */
    date: z.tuple([ColumnName, ColumnName]).describe('Trading date columns in the order [column in the input table, column in the factor table], matching the latest factor on or before each input date.'),
    /** The column of `factor_table` holding the cumulative adjustment factor. */
    factor_col: ColumnName.describe('Column in the factor table containing the cumulative multiplicative adjustment factor.'),
    mode: z.enum(['forward', 'backward']).describe('Adjustment direction, with backward multiplying prices by their dated factor and forward dividing that product by the base factor, using the latest factor date for each security when base_date is omitted.'),
    base_date: IsoDate.optional().describe('Forward adjustment cutoff in YYYY-MM-DD form, using the latest factor on or before this date or the latest available factor date per security when omitted and disallowed for backward adjustment.'),
  }),

  /** 16. the annual return that makes a series of cash payments break even */
  irr: z.strictObject({
    amount_col: ColumnName.describe('Cash flow amount column in a consistent monetary unit, with payments out negative and receipts positive.'),
    date_col: ColumnName.describe('Cash flow date column used to count elapsed days over a 365-day year.'),
    guess: z.number().optional().describe('Initial annual rate as a fraction for the iterative solver, defaulting to 0.1 when omitted.'),
    max_iter: z.number().int().min(1).max(100).default(100).describe('Maximum number of Newton iterations before the fallback solver, defaulting to 100 when omitted.'),
  }),

  /** 17. evaluate a named market measure from the platform's supported list */
  factor: z.strictObject({
    factor: z.string().min(1).max(60).describe('Name of a supported market measure to calculate from the input daily rows.'),
    universe: Identifier.optional().describe('Data requirement key or step id whose ts_code column restricts the securities, with no universe restriction when omitted.'),
    as_of: IsoDate.optional().describe('Latest eligible trading date in YYYY-MM-DD form, returning each security latest row on or before it or its latest available row when omitted.'),
  }),

  /** 18. ask the configured AI model about the rows. See spec section 10. */
  ai: z.strictObject({
    mode: z.enum(['whole', 'per_row']).describe('Requested processing scope, either the whole input or each row separately.'),
    instructions: z.string().min(1).max(4000).describe('Instructions for interpreting the input rows, containing 1 to 4000 characters.'),
    max_rows: intOrParam(1, 200).default(50).describe('Maximum input row count as an integer or parameter reference, defaulting to 50 when omitted.'),
    max_input_chars: z.number().int().min(100).max(60000).default(20000).describe('Maximum input text length in characters, defaulting to 20000 when omitted.'),
    output: z.discriminatedUnion('kind', [
      z.strictObject({ kind: z.literal('text').describe('Result shape discriminator selecting text, enum, or object.') }),
      z.strictObject({ kind: z.literal('enum').describe('Result shape discriminator selecting text, enum, or object.'), values: z.array(z.string().min(1)).min(2).max(32).describe('Allowed non-empty string result values for an enum output, containing 2 to 32 entries.') }),
      z.strictObject({
        kind: z.literal('object').describe('Result shape discriminator selecting text, enum, or object.'),
        fields: boundedRecord(ColumnName, z.enum(['string', 'number', 'boolean']), 32, 'output fields').describe('Map of output column names to string, number, or boolean types, containing 1 to 32 fields.'),
      }),
    ]).describe('Declared result shape, either text, an enumerated string, or an object of typed fields.'),
    on_error: z.enum(['null', 'fail']).default('null').describe('Declared error policy, either null or fail, defaulting to null when omitted.'),
  }),
} as const;

export const OperationName = z.enum(
  Object.keys(OperationParams) as [keyof typeof OperationParams, ...(keyof typeof OperationParams)[]],
);
export type OperationName = z.infer<typeof OperationName>;

/** How many relations each operation consumes, and what it produces. */
export const OPERATION_SHAPE: Record<OperationName, { inputs: 1 | 2; output: 'table' | 'scalar' | 'object' }> = {
  filter: { inputs: 1, output: 'table' },
  derive: { inputs: 1, output: 'table' },
  join: { inputs: 2, output: 'table' },
  aggregate: { inputs: 1, output: 'table' },
  sort_limit: { inputs: 1, output: 'table' },
  window: { inputs: 1, output: 'table' },
  lag_change: { inputs: 1, output: 'table' },
  rank: { inputs: 1, output: 'table' },
  zscore: { inputs: 1, output: 'table' },
  resample: { inputs: 1, output: 'table' },
  pivot: { inputs: 1, output: 'table' },
  describe: { inputs: 1, output: 'table' },
  correlate: { inputs: 1, output: 'table' },
  regress: { inputs: 1, output: 'table' },
  adjust_price: { inputs: 1, output: 'table' },
  irr: { inputs: 1, output: 'scalar' },
  factor: { inputs: 1, output: 'table' },
  ai: { inputs: 1, output: 'table' },
};

export const OPERATION_COUNT = Object.keys(OperationParams).length;
