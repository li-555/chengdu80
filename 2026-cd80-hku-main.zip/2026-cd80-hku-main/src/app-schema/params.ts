import { z } from 'zod';
import { FieldType, Identifier, IsoDate, ParamValue } from './fields.ts';

/**
 * One of the application's settings. A control on screen names one of these by key.
 * Parameters are inputs to the application, never part of its structure: changing one
 * and pressing Run regenerates nothing.
 */
export const ParamDecl = z
  .strictObject({
    key: Identifier.describe('Unique parameter name used by controls, filters, and parameter references.'),
    label: z.string().min(1).max(80).describe('Display label for this setting.'),
    type: FieldType.describe('Value type of the setting, either text, number, date, or boolean.'),
    /** `true` turns a text parameter into a list, which is how a watchlist is held. */
    list: z.boolean().optional().describe('Whether a text setting holds a list of strings, treating it as a scalar when omitted.'),
    /** Only a JSON scalar, or a list of strings. See ParamValue: this is a deliberate limit. */
    default: ParamValue.optional().describe('Initial value used when no run value is supplied, leaving the value undefined when omitted.'),
    min: z.number().finite().optional().describe('Optional minimum numeric value in the parameter units, with no declared lower bound when omitted.'),
    max: z.number().finite().optional().describe('Optional maximum numeric value in the parameter units, with no declared upper bound when omitted.'),
    step: z.number().finite().positive().optional().describe('Optional positive numeric increment in the parameter units, with no increment declared when omitted.'),
    unit: z.string().min(1).max(16).optional().describe('Optional unit label of 1 to 16 characters, with no unit label when omitted.'),
    /** Present makes this a fixed-choice parameter, shown as a dropdown. */
    options: z
      .array(z.strictObject({ value: z.string().min(1).max(200).describe('Stored non-empty text value for this choice, unique within the setting.'), label: z.string().min(1).max(200).describe('Display label for this choice.') }))
      .min(1)
      .max(100)
      .optional().describe('Allowed text choices shown as a dropdown, with no fixed choices when omitted and disallowed for list settings.'),
  })
  .superRefine((p, ctx) => {
    const err = (message: string, path: (string | number)[]) =>
      ctx.addIssue({ code: 'custom', message, path });

    if (p.min !== undefined && p.max !== undefined && p.min > p.max) {
      err('min must not be greater than max', ['min']);
    }
    if (p.options !== undefined && p.type !== 'text') {
      err('options are only allowed on a text parameter', ['options']);
    }
    if (p.list === true && p.type !== 'text') {
      err('list is only allowed on a text parameter', ['list']);
    }
    if ((p.min !== undefined || p.max !== undefined || p.step !== undefined) && p.type !== 'number') {
      err('min, max and step are only allowed on a number parameter', ['min']);
    }
    if (p.options !== undefined && p.list === true) {
      err('a parameter cannot be both a fixed-choice list and a free list', ['options']);
    }
    if (p.options !== undefined) {
      const seen = new Set<string>();
      for (const [i, o] of p.options.entries()) {
        if (seen.has(o.value)) err(`duplicate option value "${o.value}"`, ['options', i, 'value']);
        seen.add(o.value);
      }
    }

    // --- the default must actually be usable as this parameter's value ---
    if (p.default === undefined) return;
    const d = p.default;
    const isList = p.list === true;

    if (isList) {
      if (!Array.isArray(d)) {
        err('a list parameter needs a list of text values as its default', ['default']);
        return;
      }
    } else if (Array.isArray(d)) {
      err('only a list parameter may have a list as its default', ['default']);
      return;
    } else {
      const expected =
        p.type === 'number' ? 'number' : p.type === 'boolean' ? 'boolean' : 'string';
      if (typeof d !== expected) {
        err(`the default must be a ${expected} to match type "${p.type}"`, ['default']);
        return;
      }
      if (p.type === 'date' && !IsoDate.safeParse(d).success) {
        err('a date default must be written as YYYY-MM-DD', ['default']);
      }
      if (p.type === 'number' && typeof d === 'number') {
        if (p.min !== undefined && d < p.min) err(`the default ${d} is below min ${p.min}`, ['default']);
        if (p.max !== undefined && d > p.max) err(`the default ${d} is above max ${p.max}`, ['default']);
      }
      if (p.options !== undefined && typeof d === 'string') {
        if (!p.options.some((o) => o.value === d)) {
          err('the default must be one of the option values', ['default']);
        }
      }
    }
  });
export type ParamDecl = z.infer<typeof ParamDecl>;
