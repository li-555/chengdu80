import { z } from 'zod';
import { Expr } from './fields.ts';

export const CRON_MAX_LENGTH = 256;

/** A five-field cron expression. The shape only; the field ranges are checked in the validator. */
const Cron = z
  .string()
  .max(CRON_MAX_LENGTH, { abort: true })
  .regex(/^\s*\S+(\s+\S+){4}\s*$/, {
    error: 'must be a five-field cron expression, for example `0 8 * * 1-5`',
  });

export const TriggerSpec = z.discriminatedUnion('kind', [
  /** Always available, whatever else is declared. */
  z.strictObject({ kind: z.literal('manual').describe('Trigger discriminator selecting manual, schedule, market, or alert.') }),

  /** A clock. */
  z.strictObject({
    kind: z.literal('schedule').describe('Trigger discriminator selecting manual, schedule, market, or alert.'),
    cron: Cron.describe('Five-field schedule in minute, hour, day-of-month, month, and weekday order.'),
    tz: z.string().min(1).max(64).default('Asia/Shanghai').describe('Schedule time zone, defaulting to Asia/Shanghai when omitted.'),
  }),

  /**
   * Fires only on real trading days, at or near the opening or closing bell.
   * This is the finance-native capability a general automation tool cannot express:
   * it knows the exchange is shut for a public holiday.
   */
  z.strictObject({
    kind: z.literal('market').describe('Trigger discriminator selecting manual, schedule, market, or alert.'),
    at: z.enum(['open', 'close']).describe('Market event to run near, either opening or closing.'),
    offsetMinutes: z.number().int().min(-240).max(240).default(0).describe('Signed offset in minutes from the market event, with negative values before it and zero when omitted.'),
    calendar: z.literal('SSE').default('SSE').describe('Trading calendar used for market events, restricted to SSE and defaulting to SSE when omitted.'),
  }),

  /** Runs on a schedule, but raises a notification only when the condition holds. */
  z.strictObject({
    kind: z.literal('alert').describe('Trigger discriminator selecting manual, schedule, market, or alert.'),
    cron: Cron.describe('Five-field schedule in minute, hour, day-of-month, month, and weekday order.'),
    tz: z.string().min(1).max(64).default('Asia/Shanghai').describe('Schedule time zone, defaulting to Asia/Shanghai when omitted.'),
    condition: Expr.describe('Expression that must hold for a scheduled alert to raise a notification.'),
  }),
]);
export type TriggerSpec = z.infer<typeof TriggerSpec>;
