import { z } from 'zod';
import { ICONS } from './icons.ts';
import { ParamDecl } from './params.ts';
import { DataRequirement } from './data.ts';
import { ComputeStep } from './compute.ts';
import { TriggerSpec } from './triggers.ts';
import { UiSpec } from './ui.ts';

/** The only specification version that exists today. `migrate()` is a hook that does nothing yet. */
export const CURRENT_SPEC_VERSION = '1.0';

/**
 * Where the document came from. Written for the audit trail and
 * NEVER read when deciding what to do with a document: there is exactly one install path,
 * and it does not branch on this field.
 */
export const Provenance = z.strictObject({
  created_by: z.enum(['platform', 'external']).describe('Audit origin category, either platform or external, which does not change document installation behaviour.'),
  model: z.string().min(1).max(120).optional().describe('Optional audit label of 1 to 120 characters, absent when omitted.'),
  tool: z.string().min(1).max(120).optional().describe('Optional audit label of 1 to 120 characters, absent when omitted.'),
  imported_at: z.string().min(1).max(40).optional().describe('Optional audit timestamp text of 1 to 40 characters, with no timestamp recorded when omitted.'),
});

export const Meta = z.strictObject({
  name: z.string().min(1).max(80).describe('Application name shown to the person.'),
  /** The one plain-language sentence shown on the app card and in the header. */
  description: z.string().min(1).max(400).describe('Plain-language application description shown on the card and in the header.'),
  spec_version: z.string().min(1).max(16).describe('Specification version string, required to match the supported version by the validator.'),
  icon: z.string().min(1).max(40).optional().describe('Optional icon name checked against the supported icon list, with no icon specified when omitted.'),
  theme: z.enum(['daylight', 'night', 'paper', 'desk']).optional().describe('Optional theme choice, with no application theme specified when omitted.'),
  provenance: Provenance.optional().describe('Optional audit metadata, with no provenance recorded when omitted.'),
  updated_at: z.string().min(1).max(40).optional().describe('Optional update timestamp text of 1 to 40 characters, with no timestamp recorded when omitted.'),
});
export type Meta = z.infer<typeof Meta>;

/**
 * An application. One JSON file, six top-level sections, nothing else allowed at the root.
 *
 * It contains no data rows, no dataset identifiers, no file paths, no credentials and no URLs.
 * There is no field in this schema that could hold one.
 */
export const AppDocument = z.strictObject({
  meta: Meta.describe('Application name, description, version, and optional presentation and audit metadata.'),
  params: z.array(ParamDecl).max(40).describe('Declared settings referenced by controls and calculations, allowing an empty array for no settings.'),
  data: z.array(DataRequirement).max(12).describe('Named data requirements to bind before running, allowing an empty array for no requirements.'),
  compute: z.array(ComputeStep).max(60).describe('Named calculation steps and their dependencies, allowing an empty array for no calculations.'),
  triggers: z.array(TriggerSpec).min(1).max(8).describe('One to eight declared ways to run the application, with manual running always available.'),
  ui: UiSpec.describe('Screen element definitions and the root of their section tree.'),
});
export type AppDocument = z.infer<typeof AppDocument>;

/** The exported envelope: the document plus one field naming the specification it follows. */
export const ExportEnvelope = AppDocument.extend({
  $schema: z.string().min(1).max(200).optional().describe('Optional specification identifier in an exported document, ignored by document validation when omitted or present.'),
});

export const ICON_NAMES = ICONS;
