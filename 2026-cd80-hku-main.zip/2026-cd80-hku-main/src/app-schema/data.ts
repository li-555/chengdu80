import { z } from 'zod';
import { ColumnName, FieldType, Identifier, noAddress } from './fields.ts';

/**
 * A filter on a data requirement.
 *
 * `param` names a declared parameter. There is deliberately no field that can hold a
 * literal value: that single rule is what keeps the person's own list of companies out
 * of the application document, and out of every export.
 */
export const RequirementFilter = z.strictObject({
  field: ColumnName.describe('Requirement column on which the filter operates.'),
  op: z.enum(['eq', 'neq', 'gt', 'gte', 'lt', 'lte', 'in', 'not_in', 'contains']).describe('Comparison applied between the field and the named parameter value.'),
  param: Identifier.describe('Declared parameter key supplying the filter value rather than a literal in the document.'),
});
export type RequirementFilter = z.infer<typeof RequirementFilter>;

/** How far back to read. Resolved against the trading calendar, not the wall clock. */
export const RequirementWindow = z.strictObject({
  field: ColumnName.describe('Requirement date column to which the requested lookback applies.'),
  lookbackDays: z.number().int().positive().max(3650).describe('Requested number of trading-calendar days rather than wall-clock days, from 1 to 3650, with 1 requesting a single trading day and no date-boundary resolution enforced by the schema.'),
});
export type RequirementWindow = z.infer<typeof RequirementWindow>;

/**
 * What an application says it needs. Holds NO data, no dataset id, no file path,
 * no credential and no URL. There is no field in this schema that could hold one.
 */
export const DataRequirement = z.strictObject({
  key: Identifier.describe('Unique relation name used to reference this data requirement from calculations.'),
  purpose: noAddress(z.string().min(1).max(200)).optional().describe('Optional explanation of why this data is needed, with no explanation when omitted.'),
  grain: z.enum(['daily', 'weekly', 'monthly', 'quarterly', 'yearly', 'snapshot']).optional().describe('Optional declared time granularity of the requested rows, with none specified when omitted.'),
  /** A hint only. Never a binding: the person or the resolver decides what it binds to. */
  datasetHint: noAddress(z.string().min(1).max(100)).optional().describe('Optional dataset suggestion for the person or resolver, with no suggestion when omitted and no binding established by this field.'),
  fields: z
    .array(
      z.strictObject({
        name: ColumnName.describe('Column name exposed to calculations after mapping the bound dataset.'),
        type: FieldType.describe('Required data type for the mapped column.'),
        required: z.boolean().describe('Whether this column is required for the data requirement.'),
        /** Join vocabulary, e.g. `security_code`, `trade_date`. Makes mapping mostly automatic. */
        semantic: noAddress(z.string().min(1).max(40)).optional().describe('Optional shared meaning such as security_code or trade_date used to help column mapping, with no semantic hint when omitted.'),
      }),
    )
    .min(1)
    .max(100).describe('Columns requested from the bound dataset with their types and mapping requirements.'),
  window: RequirementWindow.optional().describe('Optional trading-calendar lookback request, with no lookback request when omitted.'),
  filters: z.array(RequirementFilter).max(20).optional().describe('Parameter-based filter requests, with no filters requested when omitted.'),
});
export type DataRequirement = z.infer<typeof DataRequirement>;
