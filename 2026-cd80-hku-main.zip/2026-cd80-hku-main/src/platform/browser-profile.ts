import type { Request } from 'express';

/** The local browser library identity. This is profile separation, not authentication. */
export function browserProfileId(request: Request): string | undefined {
  const entries = (request.headers.cookie ?? '').split(';').map((part) => part.trim())
    .filter((part) => part.startsWith('blocks_profile='));
  if (entries.length !== 1) return undefined;
  const id = entries[0]!.slice('blocks_profile='.length);
  return /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/.test(id) ? id : undefined;
}

/** Keep the published non-browser profile API; a browser cookie always wins. */
export function datasetProfile(request: Request, fallback: unknown): string {
  return browserProfileId(request)
    ?? (typeof fallback === 'string' && /^[A-Za-z0-9_-]{1,40}$/.test(fallback) ? fallback : 'default');
}
