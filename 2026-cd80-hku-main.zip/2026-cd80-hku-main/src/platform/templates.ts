import { readFile } from 'node:fs/promises';
import { validateApplication } from '../validate/index.ts';
import { saveApp } from './storage.ts';

export const templates = [
  { id: 'alpha-vista', name: 'AlphaVista', category: 'Research', description: 'Tushare research and historical risk using your own holdings and disclosure evidence.' },
  { id: 'risk-rift', name: 'RiskRift', category: 'Risk review', description: 'Tushare financial checks with your own disclosure evidence and regulatory documents.' },
  { id: 'wealth-weave', name: 'WealthWeave', category: 'Client service', description: 'Your client, approved-product and activity records, with Tushare fund NAV references.' },
] as const;

/** Install only the portable definition. Private records must come from the user. */
export async function importTemplate(id: string, profile: string, _uploadProfile: string, mode: 'connect') {
  if (mode !== 'connect') throw new Error('Invented flagship inputs are no longer available. Connect Tushare and your own data.');
  const template = templates.find((item) => item.id === id);
  if (!template) return { kind: 'missing' as const };
  const raw = JSON.parse(await readFile(new URL(`../../examples/${template.id}.fin.json`, import.meta.url), 'utf8'));
  const checked = validateApplication(raw);
  if (!checked.ok) throw new Error('The bundled application definition is invalid.');
  const app = await saveApp(checked.document, profile);
  return { kind: 'imported' as const, appId: app.id, mode };
}
