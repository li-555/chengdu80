export type CheckResult = {
  name: string;
  ok: boolean;
  detail: string;
};

type JsonResult = { ok: true; payload: unknown } | { ok: false; detail: string };
const requestTimeoutMs = 30000;

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function isTimeout(error: unknown): boolean {
  return error instanceof Error && (error.name === 'TimeoutError' || error.name === 'AbortError');
}

async function requestJson(url: string, options: RequestInit): Promise<JsonResult> {
  try {
    const response = await fetch(url, {
      ...options,
      redirect: 'error',
      signal: AbortSignal.timeout(requestTimeoutMs),
    });

    if (!response.ok) {
      const detail = response.status === 401 || response.status === 403
        ? 'Access was denied. Check credentials, permissions, and available resources.'
        : response.status === 429
          ? 'The service rate limit was reached. Access was not verified.'
          : `The service returned HTTP ${response.status}. Access was not verified.`;
      await response.body?.cancel();
      return { ok: false, detail };
    }

    try {
      const payload: unknown = await response.json();
      return { ok: true, payload };
    } catch (error) {
      return {
        ok: false,
        detail: isTimeout(error)
          ? 'The request timed out after 30 seconds. Access was not verified.'
          : 'The service did not return a valid JSON response.',
      };
    }
  } catch (error) {
    return {
      ok: false,
      detail: isTimeout(error)
        ? 'The request timed out after 30 seconds. Access was not verified.'
        : 'The connection failed. Check network access, DNS, and proxy settings.',
    };
  }
}

export async function checkTushareAccess(token?: string): Promise<CheckResult> {
  const name = 'Tushare';
  if (!token) return { name, ok: false, detail: 'TUSHARE_TOKEN is missing; no request was sent.' };

  const result = await requestJson('http://api.tushare.pro', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      api_name: 'trade_cal',
      token,
      params: { exchange: 'SSE', start_date: '20260101', end_date: '20260101' },
      fields: 'cal_date',
    }),
  });
  if (!result.ok) return { name, ...result };

  const payload = result.payload;
  if (!isRecord(payload) || typeof payload.code !== 'number' || !Number.isFinite(payload.code)) {
    return { name, ok: false, detail: 'The service returned an unexpected response format.' };
  }
  if (payload.code === 2002) {
    return { name, ok: false, detail: 'The calendar query was denied. Check token permissions and expiry.' };
  }
  if (payload.code !== 0) {
    return { name, ok: false, detail: `The calendar query was rejected (code ${payload.code}).` };
  }
  if (!isRecord(payload.data) || !Array.isArray(payload.data.fields)
    || !payload.data.fields.includes('cal_date') || !Array.isArray(payload.data.items)) {
    return { name, ok: false, detail: 'The calendar query returned an unexpected response format.' };
  }
  return { name, ok: true, detail: 'trade_cal access verified. Other data interfaces were not checked.' };
}

export async function checkGlmAccess(apiKey?: string): Promise<CheckResult> {
  const name = 'GLM-5.3';
  if (!apiKey) return { name, ok: false, detail: 'GITEE_AI_API_KEY is missing; no request was sent.' };

  const result = await requestJson('https://ai.gitee.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${apiKey}`,
      'X-Failover-Enabled': 'false',
    },
    body: JSON.stringify({
      model: 'GLM-5.3',
      messages: [{ role: 'user', content: 'Say hello in one short sentence.' }],
      stream: false,
      max_tokens: 32,
    }),
  });
  if (!result.ok) return { name, ...result };

  const payload = result.payload;
  if (!isRecord(payload) || payload.object !== 'chat.completion'
    || typeof payload.model !== 'string' || payload.model.toUpperCase() !== 'GLM-5.3') {
    return { name, ok: false, detail: 'The response did not confirm the requested GLM-5.3 identity.' };
  }
  if (payload.error || !Array.isArray(payload.choices)
    || !payload.choices.some((choice: unknown) => isRecord(choice) && isRecord(choice.message)
      && (typeof choice.message.content === 'string' || choice.message.content === null
        || typeof choice.message.reasoning_content === 'string'))) {
    return { name, ok: false, detail: 'The completion request did not return a valid completion response.' };
  }
  return { name, ok: true, detail: 'A GLM-5.3 completion request succeeded.' };
}
