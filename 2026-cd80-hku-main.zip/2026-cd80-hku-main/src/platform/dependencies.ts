import { existsSync, readFileSync } from 'node:fs';
import type { CheckResult } from './service-checks.ts';

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function readRecord(path: URL): Record<string, unknown> {
  const value: unknown = JSON.parse(readFileSync(path, 'utf8'));
  if (!isRecord(value)) throw new Error('Unexpected dependency manifest format.');
  return value;
}

function matchingFields(left: unknown, right: unknown): boolean {
  if (!isRecord(left) || !isRecord(right)) return false;
  const keys = Object.keys(left);
  return keys.length === Object.keys(right).length && keys.every((key) => left[key] === right[key]);
}

export function checkRuntimeDependencies(): CheckResult {
  const name = 'Runtime dependencies';
  try {
    const manifest = readRecord(new URL('../../package.json', import.meta.url));
    const lock = readRecord(new URL('../../package-lock.json', import.meta.url));
    if (!isRecord(manifest.dependencies) || !isRecord(lock.packages)) {
      return { name, ok: false, detail: 'Dependency manifests are incomplete.' };
    }
    const packages = lock.packages;
    const root = packages[''];
    if (!isRecord(root)
      || !matchingFields(manifest.dependencies, root.dependencies)
      || !matchingFields(manifest.devDependencies, root.devDependencies)
      || !matchingFields(manifest.engines, root.engines)) {
      return { name, ok: false, detail: 'package.json and package-lock.json do not match.' };
    }

    const missing: string[] = [];
    for (const dependency of Object.keys(manifest.dependencies)) {
      const locked = packages[`node_modules/${dependency}`];
      try {
        const installed = readRecord(new URL(`../../node_modules/${dependency}/package.json`, import.meta.url));
        const entry = import.meta.resolve(dependency);
        if (!isRecord(locked) || installed.version !== locked.version
          || !entry.startsWith('file:') || !existsSync(new URL(entry))
          || (dependency === 'express'
            && (typeof installed.version !== 'string' || !installed.version.startsWith('5.')))) {
          missing.push(dependency);
        }
      } catch {
        missing.push(dependency);
      }
    }

    if (missing.length > 0) {
      return { name, ok: false, detail: `Missing or mismatched runtime dependencies: ${missing.join(', ')}. Run npm install manually.` };
    }
    return { name, ok: true, detail: `All ${Object.keys(manifest.dependencies).length} runtime dependencies match package-lock.json.` };
  } catch {
    return { name, ok: false, detail: 'Dependencies or their manifests are missing or unreadable. Run npm install manually.' };
  }
}
