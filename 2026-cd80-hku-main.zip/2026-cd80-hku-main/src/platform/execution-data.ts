import type { SourceRecord } from '../compute/slices.ts';
import type { Slice } from '../compute/run.ts';
import type { StoredApp } from './types.ts';

export type ResolvedExecutionData = {
  slices: Record<string, Slice>;
  datasetVersions: Record<string, string>;
  asOfDate?: string;
  sources?: SourceRecord[];
};

/** Platform-owned boundary converting resolved data into compute slices. */
export type ExecutionDataAdapter = {
  kind: 'invented' | 'real';
  id: string;
  label: string;
  resolve: (input: {
    app: StoredApp;
    params: Record<string, unknown>;
    bindings: Record<string, unknown>;
    mappings: Record<string, unknown>;
    signal?: AbortSignal;
    referenceTime: string;
  }) => Promise<ResolvedExecutionData>;
};

export type InventedDataAdapter = ExecutionDataAdapter & { kind: 'invented' };
