import type { AppDocument } from '../app-schema/index.ts';
import type { QueryResult } from '../compute/context.ts';
import { runApplication, type RunOutcome, type Slice } from '../compute/run.ts';
import { validateApplication } from '../validate/index.ts';

/** The fixed example's transport shape; relation entries retain the engine's row objects. */
export type ScreenExample = {
  document: AppDocument;
  status: RunOutcome['status'];
  warnings: string[];
  failure?: string;
  results: Array<[string, QueryResult]>;
};

/** This application declares its screen and calculations, but contains no data rows. */
const INVENTED_DOCUMENT: AppDocument = {
  meta: {
    name: 'Invented Company Review',
    description: 'Explore a fictional company snapshot with calculated moves and grouped notes.',
    spec_version: '1.0',
    provenance: { created_by: 'platform' },
  },
  params: [],
  data: [{
    key: 'invented_prices',
    purpose: 'Clearly invented company values for the screen element example',
    grain: 'snapshot',
    fields: [
      { name: 'code', type: 'text', required: true },
      { name: 'company', type: 'text', required: true },
      { name: 'd', type: 'date', required: true },
      { name: 'px', type: 'number', required: true },
      { name: 'prev_px', type: 'number', required: true },
      { name: 'group_name', type: 'text', required: true },
      { name: 'note', type: 'text', required: true },
      { name: 'link', type: 'text', required: true },
      { name: 'tone', type: 'text', required: true },
    ],
  }],
  compute: [
    {
      id: 'with_change',
      kind: 'operation',
      op: 'derive',
      input: 'invented_prices',
      title: 'Calculate each invented move',
      params: { columns: { pct_move: '(px - prev_px) / prev_px * 100' } },
    },
    {
      id: 'company_rows',
      kind: 'operation',
      op: 'sort_limit',
      input: 'with_change',
      title: 'Put the fictional companies in code order',
      params: { by: [{ col: 'code', dir: 'asc' }] },
    },
    {
      id: 'summary',
      kind: 'operation',
      op: 'aggregate',
      input: 'with_change',
      title: 'Summarise the invented snapshot',
      params: {
        by: [],
        metrics: [
          { fn: 'count', as: 'company_count' },
          { fn: 'mean', of: 'pct_move', as: 'average_move' },
        ],
      },
    },
  ],
  triggers: [{ kind: 'manual' }],
  ui: {
    root: 'page',
    elements: {
      page: {
        type: 'Section',
        columns: 1,
        children: ['introduction', 'notice', 'highlights', 'companies', 'notes'],
      },
      introduction: {
        type: 'Text',
        emphasis: 'body',
        text: 'Review eight fictional companies. The figures below are calculated from invented inputs, with a blank where an input is missing.',
      },
      notice: {
        type: 'Callout',
        tone: 'warning',
        title: 'Invented example',
        text: 'Every company, value and note in this example is fictional. Example links use a reserved domain and do not open real company pages.',
      },
      highlights: {
        type: 'Section',
        title: 'Snapshot',
        columns: 2,
        children: ['company_count', 'average_move'],
      },
      company_count: {
        type: 'Metric',
        label: 'Fictional companies',
        from: 'summary',
        value: 'company_count',
        format: 'integer',
      },
      average_move: {
        type: 'Metric',
        label: 'Average move with an available value',
        from: 'summary',
        value: 'average_move',
        format: 'percent',
      },
      companies: {
        type: 'Table',
        title: 'Fictional company snapshot',
        from: 'company_rows',
        columns: [
          { col: 'company', label: 'Company', format: 'text' },
          { col: 'd', label: 'Snapshot date', format: 'date' },
          { col: 'px', label: 'Illustrative close', format: 'money' },
          { col: 'pct_move', label: 'Daily move', format: 'percent' },
          { col: 'group_name', label: 'Review group', format: 'text' },
        ],
        emptyHint: 'No fictional companies are available in this example.',
        pageSize: 5,
      },
      notes: {
        type: 'List',
        title: 'Fictional review notes',
        from: 'company_rows',
        itemTitle: 'company',
        itemBody: 'note',
        itemLink: 'link',
        itemTone: 'tone',
        groupBy: 'group_name',
        emptyHint: 'There are no fictional review notes.',
      },
    },
  },
};

/** All rows are invented; they are supplied directly and never fetched or persisted. */
const INVENTED_PRICES: Slice = {
  columns: [
    { name: 'code', type: 'string' },
    { name: 'company', type: 'string' },
    { name: 'd', type: 'date' },
    { name: 'px', type: 'number' },
    { name: 'prev_px', type: 'number' },
    { name: 'group_name', type: 'string' },
    { name: 'note', type: 'string' },
    { name: 'link', type: 'string' },
    { name: 'tone', type: 'string' },
  ],
  rows: [
    {
      code: 'FIC_A', company: 'Fictional Amber Works', d: '2026-01-06', px: 12.5, prev_px: 10,
      group_name: 'Illustrative gains', note: 'An invented increase from 10 to 12.50.',
      link: 'https://invented.example/amber', tone: 'positive',
    },
    {
      code: 'FIC_B', company: 'Fictional Birch Labs', d: '2026-01-06', px: 45, prev_px: 50,
      group_name: 'Illustrative declines', note: 'An invented decrease from 50 to 45.',
      link: 'https://invented.example/birch', tone: 'negative',
    },
    {
      code: 'FIC_C', company: 'Fictional Cedar Studio', d: '2026-01-06', px: 10.2, prev_px: 10,
      group_name: 'Illustrative gains', note: 'An invented two percent increase.',
      link: 'https://invented.example/cedar', tone: 'positive',
    },
    {
      code: 'FIC_D', company: 'Fictional Dune Systems', d: '2026-01-06', px: 6, prev_px: 10,
      group_name: 'Illustrative declines', note: 'An invented larger decline for comparison.',
      link: 'https://invented.example/dune', tone: 'negative',
    },
    {
      code: 'FIC_E', company: 'Fictional Elm Workshop', d: '2026-01-06', px: null, prev_px: 20,
      group_name: 'Needs context', note: 'The invented closing value is missing; its move must remain blank.',
      link: 'https://invented.example/elm', tone: 'warning',
    },
    {
      code: 'FIC_F', company: 'Fictional Fern Company', d: '2026-01-06', px: 20, prev_px: 20,
      group_name: 'Needs context', note: 'An invented unchanged value demonstrates zero movement.',
      link: 'https://invented.example/fern', tone: 'muted',
    },
    {
      code: 'FIC_G', company: 'Fictional Grove House', d: '2026-01-06', px: 11.5, prev_px: 10,
      group_name: 'Illustrative gains', note: 'An invented increase on the second table page.',
      link: 'https://invented.example/grove', tone: 'positive',
    },
    {
      code: 'FIC_H', company: 'Fictional Harbor Office', d: '2026-01-06', px: 9.5, prev_px: 10,
      group_name: 'Illustrative declines', note: 'An invented smaller decline on the second table page.',
      link: 'https://invented.example/harbor', tone: 'negative',
    },
  ],
};

/** Run only the fixed screen example through the shared validator and real engine. */
export async function buildScreenExample(): Promise<ScreenExample> {
  const validated = validateApplication(INVENTED_DOCUMENT);
  if (!validated.ok) {
    throw new Error(`The invented screen example is invalid: ${validated.errors.map((issue) => `${issue.pointer}: ${issue.message}`).join('; ')}`);
  }

  // A display relation need not have key: true; explicitly request every screen source.
  const want = [...new Set(
    Object.values(validated.document.ui.elements)
      .map((element) => element.from)
      .filter((from): from is string => typeof from === 'string'),
  )];
  // The shared schema exposes operation params as unknown; validation has checked
  // the concrete shape before crossing the engine's narrower TypeScript boundary.
  const outcome = await runApplication(validated.document as Parameters<typeof runApplication>[0], {
    slices: { invented_prices: INVENTED_PRICES },
    want,
  });

  return {
    document: validated.document,
    status: outcome.status,
    warnings: [
      ...validated.report.warnings.map((warning) => warning.message),
      ...outcome.warnings,
    ],
    ...(outcome.failure === undefined ? {} : { failure: outcome.failure }),
    results: [...outcome.results],
  };
}
