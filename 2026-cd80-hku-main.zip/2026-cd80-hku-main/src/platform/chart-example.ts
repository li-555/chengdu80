import type { AppDocument } from '../app-schema/index.ts';
import { validateApplication } from '../validate/index.ts';
import { runApplication, type Slice } from '../compute/run.ts';
import type { ScreenExample } from './screen-example.ts';

/** Fixed fictional daily observations, shared by the line, stacked bars and candles. */
const DAILY: Slice = {
  columns: [
    { name: 'Day', type: 'date' }, { name: 'Actual', type: 'number' }, { name: 'Plan', type: 'number' },
    { name: 'Open', type: 'number' }, { name: 'High', type: 'number' },
    { name: 'Low', type: 'number' }, { name: 'Close', type: 'number' },
  ],
  rows: [
    { Day: '2026-01-05', Actual: 12, Plan: 8, Open: 10, High: 14, Low: 9, Close: 13 },
    { Day: '2026-01-06', Actual: 16, Plan: 10, Open: 13, High: 15, Low: 10, Close: 11 },
    { Day: '2026-01-07', Actual: null, Plan: 12, Open: 11, High: 13, Low: 10, Close: 11 },
    { Day: '2026-01-08', Actual: 0, Plan: 9, Open: null, High: null, Low: null, Close: null },
    { Day: '2026-01-09', Actual: 18, Plan: 11, Open: 12, High: 17, Low: 11, Close: 16 },
    { Day: '2026-01-12', Actual: 14, Plan: 13, Open: 16, High: 18, Low: 12, Close: 14 },
  ],
};

/** Fictional review scores; the zero cell is distinct from the missing cell. */
const SCORES: Slice = {
  columns: [{ name: 'Day', type: 'date' }, { name: 'Group', type: 'string' }, { name: 'Score', type: 'number' }],
  rows: [
    { Day: '2026-01-05', Group: 'Amber', Score: -3 },
    { Day: '2026-01-06', Group: 'Amber', Score: 0 },
    { Day: '2026-01-07', Group: 'Amber', Score: 4 },
    { Day: '2026-01-05', Group: 'Birch', Score: 2 },
    { Day: '2026-01-06', Group: 'Birch', Score: null },
    { Day: '2026-01-07', Group: 'Birch', Score: -1 },
    { Day: '2026-01-05', Group: 'Cedar', Score: -4 },
    { Day: '2026-01-06', Group: 'Cedar', Score: 1 },
    { Day: '2026-01-07', Group: 'Cedar', Score: 3 },
  ],
};

/** Fictional companies: different row order, a missing day, a null and a real zero. */
const COMPANIES: Slice = {
  columns: [{ name: 'Day', type: 'date' }, { name: 'Company', type: 'string' }, { name: 'Value', type: 'number' }],
  rows: [
    { Day: '2026-01-05', Company: 'Fictional Amber', Value: 12 },
    { Day: '2026-01-05', Company: 'Fictional Birch', Value: 8 },
    { Day: '2026-01-06', Company: 'Fictional Birch', Value: 0 },
    { Day: '2026-01-06', Company: 'Fictional Amber', Value: null },
    { Day: '2026-01-07', Company: 'Fictional Amber', Value: 18 },
    { Day: '2026-01-08', Company: 'Fictional Birch', Value: 10 },
    { Day: '2026-01-08', Company: 'Fictional Amber', Value: 16 },
  ],
};
const MANY_COMPANIES: Slice = {
  columns: COMPANIES.columns,
  rows: Array.from({ length: 21 }, (_, index) => ({
    Day: '2026-01-05', Company: `Fictional Company ${String(index + 1).padStart(2, '0')}`, Value: index + 1,
  })),
};

const DOCUMENT: AppDocument = {
  meta: {
    name: 'Invented Chart Review',
    description: 'Explore fictional observations and company series, with the source values close at hand.',
    spec_version: '1.0', provenance: { created_by: 'platform' },
  },
  params: [],
  data: [
    ...['companies', 'many_companies'].map((key) => ({ key, fields: [
      { name: 'Day', type: 'date' as const, required: true },
      { name: 'Company', type: 'text' as const, required: true },
      { name: 'Value', type: 'number' as const, required: true },
    ] })),
    { key: 'daily', fields: DAILY.columns.map((column) => ({ name: column.name, type: column.name === 'Day' ? 'date' as const : 'number' as const, required: true })) },
    { key: 'scores', fields: [
      { name: 'Day', type: 'date', required: true },
      { name: 'Group', type: 'text', required: true },
      { name: 'Score', type: 'number', required: true },
    ] },
  ],
  compute: [
    { id: 'daily_rows', kind: 'operation', op: 'sort_limit', input: 'daily',
      params: { by: [{ col: 'Day', dir: 'asc' }] } },
    { id: 'score_rows', kind: 'operation', op: 'sort_limit', input: 'scores',
      params: { by: [{ col: 'Day', dir: 'asc' }, { col: 'Group', dir: 'asc' }] } },
  ],
  triggers: [{ kind: 'manual' }],
  ui: { root: 'page', elements: {
    page: { type: 'Section', columns: 1, children: ['notice', 'charts', 'guide'] },
    notice: { type: 'Callout', title: 'Invented data only', tone: 'warning',
      text: 'These observations and scores are fictional. No market data is requested and nothing is saved to your library.' },
    charts: { type: 'Section', columns: 2, children: ['trend', 'totals', 'prices', 'scores', 'company_lines', 'company_bars', 'company_stacked', 'company_limit'] },
    trend: { type: 'Chart', title: 'Daily progress', chart: 'line', from: 'daily_rows', x: 'Day', y: ['Actual', 'Plan'] },
    totals: { type: 'Chart', title: 'Daily totals · stacked', chart: 'bar', from: 'daily_rows', x: 'Day', y: ['Actual', 'Plan'], stacked: true },
    prices: { type: 'Chart', title: 'Fictional daily prices', chart: 'candlestick', from: 'daily_rows', x: 'Day',
      ohlc: { open: 'Open', high: 'High', low: 'Low', close: 'Close' } },
    scores: { type: 'Chart', title: 'Fictional review scores', chart: 'heatmap', from: 'score_rows', x: 'Day', heat: { y: 'Group', value: 'Score' } },
    company_lines: { type: 'Chart', title: 'Fictional companies · lines', chart: 'line', from: 'companies', x: 'Day', y: ['Value'], series: 'Company' },
    company_bars: { type: 'Chart', title: 'Fictional companies · grouped bars', chart: 'bar', from: 'companies', x: 'Day', y: ['Value'], series: 'Company' },
    company_stacked: { type: 'Chart', title: 'Fictional companies · stacked bars', chart: 'bar', from: 'companies', x: 'Day', y: ['Value'], series: 'Company', stacked: true },
    company_limit: { type: 'Chart', title: 'Fictional companies · 20-series limit', chart: 'bar', from: 'many_companies', x: 'Day', y: ['Value'], series: 'Company' },
    guide: { type: 'Text', text: 'Hover to inspect values. Select a legend item to hide or show a series. Open “View chart data” to read the values with a keyboard. Missing values stay blank; zero remains zero. Price rises are red and falls are green under the default Chinese convention.' },
  } },
};

/** Validate and run only this fixed example; this is not an arbitrary application endpoint. */
export async function buildChartExample(): Promise<ScreenExample> {
  const validated = validateApplication(DOCUMENT);
  if (!validated.ok) throw new Error(`The invented chart example is invalid: ${validated.errors.map((issue) => issue.message).join('; ')}`);
  const want = [...new Set(Object.values(validated.document.ui.elements)
    .map((element) => element.from).filter((from): from is string => typeof from === 'string'))];
  const outcome = await runApplication(validated.document as Parameters<typeof runApplication>[0], {
    slices: { daily: DAILY, scores: SCORES, companies: COMPANIES, many_companies: MANY_COMPANIES }, want,
  });
  return {
    document: validated.document, status: outcome.status,
    warnings: [...validated.report.warnings.map((warning) => warning.message), ...outcome.warnings],
    ...(outcome.failure === undefined ? {} : { failure: outcome.failure }),
    results: [...outcome.results],
  };
}
