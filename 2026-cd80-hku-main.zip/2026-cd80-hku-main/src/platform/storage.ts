import { randomUUID } from 'node:crypto';
import { AppDocument as DocumentSchema, appVersion } from '../app-schema/index.ts';
import type { AppDocument } from '../app-schema/index.ts';
import type { RunRecord, StoredApp, StoredDraft } from './types.ts';
import { storageOperation, storageTransaction } from './database.ts';
import { decodeStoredValue, encodeStoredValue } from './json.ts';

export const STUB = false;

export async function saveApp(doc: AppDocument, profile: string): Promise<StoredApp> {
  const document = DocumentSchema.parse(decodeStoredValue<AppDocument>(encodeStoredValue(doc)));
  const now = new Date().toISOString();
  const app: StoredApp = {
    id: randomUUID(),
    doc: document,
    version: appVersion(document),
    createdAt: now,
    updatedAt: now,
    profile,
  };
  const record = encodeStoredValue(app);
  storageOperation((database) => {
    database.prepare('INSERT INTO apps (id, profile, record) VALUES (?, ?, ?)')
      .run(encodeStoredValue(app.id), encodeStoredValue(profile), record);
  });
  return decodeStoredValue<StoredApp>(record);
}

export async function listApps(profile: string): Promise<StoredApp[]> {
  return storageOperation((database) => database.prepare('SELECT record FROM apps WHERE profile = ? ORDER BY sequence')
    .all(encodeStoredValue(profile)).map((row) => decodeStoredValue<StoredApp>(row.record)));
}

export async function getApp(id: string): Promise<StoredApp | null> {
  return storageOperation((database) => {
    const row = database.prepare('SELECT record FROM apps WHERE id = ?').get(encodeStoredValue(id));
    return row ? decodeStoredValue<StoredApp>(row.record) : null;
  });
}

export async function deleteApp(id: string): Promise<void> {
  storageOperation((database) => { database.prepare('DELETE FROM apps WHERE id = ?').run(encodeStoredValue(id)); });
}

export async function saveRun(rec: RunRecord): Promise<void> {
  const record = encodeStoredValue(rec);
  const run = decodeStoredValue<RunRecord>(record);
  storageOperation((database) => storageTransaction(database, () => {
    if (!database.prepare('SELECT id FROM apps WHERE id = ?').get(encodeStoredValue(run.appId))) {
      throw new Error('Application not found.');
    }
    database.prepare(`INSERT INTO runs (id, app_id, started_at, record) VALUES (?, ?, ?, ?)
      ON CONFLICT (id) DO UPDATE SET app_id = excluded.app_id,
        started_at = excluded.started_at, record = excluded.record`)
      .run(encodeStoredValue(run.id), encodeStoredValue(run.appId), run.startedAt, record);
  }));
}

export async function listRuns(appId: string, limit?: number): Promise<RunRecord[]> {
  if (limit !== undefined && (!Number.isInteger(limit) || limit < 0)) {
    throw new Error('Run limit must be a non-negative integer.');
  }
  return storageOperation((database) => {
    const records = database.prepare('SELECT record FROM runs WHERE app_id = ? ORDER BY sequence')
      .all(encodeStoredValue(appId)).map((row) => decodeStoredValue<RunRecord>(row.record))
      .sort((left, right) => right.startedAt.localeCompare(left.startedAt));
    return limit === undefined ? records : records.slice(0, limit);
  });
}

export async function getState(appId: string, profile: string): Promise<Record<string, unknown>> {
  return storageOperation((database) => {
    const row = database.prepare('SELECT record FROM states WHERE app_id = ? AND profile = ?')
      .get(encodeStoredValue(appId), encodeStoredValue(profile));
    return row ? decodeStoredValue<Record<string, unknown>>(row.record) : {};
  });
}

export async function setState(appId: string, profile: string, v: Record<string, unknown>): Promise<void> {
  const record = encodeStoredValue(v);
  storageOperation((database) => storageTransaction(database, () => {
    if (!database.prepare('SELECT id FROM apps WHERE id = ? AND profile = ?')
      .get(encodeStoredValue(appId), encodeStoredValue(profile))) {
      throw new Error('Application not found for this profile.');
    }
    database.prepare(`INSERT INTO states (app_id, profile, record) VALUES (?, ?, ?)
      ON CONFLICT (app_id, profile) DO UPDATE SET record = excluded.record`)
      .run(encodeStoredValue(appId), encodeStoredValue(profile), record);
  }));
}

export async function updateApp(id: string, profile: string, doc: AppDocument): Promise<StoredApp> {
  const document = DocumentSchema.parse(decodeStoredValue<AppDocument>(encodeStoredValue(doc)));
  return storageOperation((database) => storageTransaction(database, () => {
    const row = database.prepare('SELECT record FROM apps WHERE id = ? AND profile = ?')
      .get(encodeStoredValue(id), encodeStoredValue(profile));
    if (!row) throw new Error('Application not found for this profile.');
    const previous = decodeStoredValue<StoredApp>(row.record);
    const app: StoredApp = {
      ...previous,
      doc: document,
      version: appVersion(document),
      rev: (previous.rev ?? 1) + 1,
      updatedAt: new Date().toISOString(),
      history: [...(previous.history ?? []), {
        version: previous.version, doc: previous.doc, updatedAt: previous.updatedAt,
      }].slice(-10),
    };
    const record = encodeStoredValue(app);
    database.prepare('UPDATE apps SET record = ? WHERE id = ? AND profile = ?')
      .run(record, encodeStoredValue(id), encodeStoredValue(profile));
    return decodeStoredValue<StoredApp>(record);
  }));
}

export async function saveDraft(profile: string, input: {
  doc: unknown; errors: unknown[]; reason: string; conversationId?: string; name?: string;
}): Promise<StoredDraft> {
  const doc = decodeStoredValue<unknown>(encodeStoredValue(input.doc));
  const meta = doc && typeof doc === 'object' && 'meta' in doc ? doc.meta : undefined;
  const name = meta && typeof meta === 'object' && 'name' in meta && typeof meta.name === 'string'
    ? meta.name : input.name ?? 'Untitled draft';
  const draft: StoredDraft = {
    id: randomUUID(), profile, name, reason: input.reason, doc, errors: input.errors,
    createdAt: new Date().toISOString(),
  };
  const record = encodeStoredValue({ ...draft,
    ...(input.conversationId !== undefined ? { conversationId: input.conversationId } : {}),
  });
  if (Buffer.byteLength(record, 'utf8') > 2 * 1024 * 1024) {
    throw new Error('Draft record exceeds the 2 MB storage limit.');
  }
  storageOperation((database) => {
    database.prepare('INSERT INTO drafts (id, profile, record) VALUES (?, ?, ?)')
      .run(encodeStoredValue(draft.id), encodeStoredValue(profile), record);
  });
  return decodeStoredValue<StoredDraft>(record);
}

export async function listDrafts(profile: string): Promise<StoredDraft[]> {
  return storageOperation((database) => database.prepare('SELECT record FROM drafts WHERE profile = ? ORDER BY sequence')
    .all(encodeStoredValue(profile)).map((row) => decodeStoredValue<StoredDraft>(row.record)));
}

export async function getDraft(id: string, profile: string): Promise<StoredDraft | null> {
  return storageOperation((database) => {
    const row = database.prepare('SELECT record FROM drafts WHERE id = ? AND profile = ?')
      .get(encodeStoredValue(id), encodeStoredValue(profile));
    return row ? decodeStoredValue<StoredDraft>(row.record) : null;
  });
}

export async function deleteDraft(id: string, profile: string): Promise<void> {
  storageOperation((database) => {
    database.prepare('DELETE FROM drafts WHERE id = ? AND profile = ?')
      .run(encodeStoredValue(id), encodeStoredValue(profile));
  });
}
