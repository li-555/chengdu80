import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

export type ServerConfig = {
  host: string;
  port: number;
};

export type ServiceCredentials = {
  tushareToken?: string;
  giteeApiKey?: string;
};

export type StorageConfig = {
  path: string;
};

export function loadStorageConfig(): StorageConfig {
  const root = fileURLToPath(new URL('../../', import.meta.url));
  const path = process.env.BLOCKS_DB_PATH ?? 'data/blocks.sqlite';
  if (!path.trim() || path.includes('\0') || path === ':memory:') {
    throw new Error('BLOCKS_DB_PATH must be a non-empty file path.');
  }
  return { path: resolve(root, path) };
}

export function loadServiceCredentials(): ServiceCredentials {
  return {
    tushareToken: process.env.TUSHARE_TOKEN?.trim() || undefined,
    giteeApiKey: process.env.GITEE_AI_API_KEY?.trim() || undefined,
  };
}

export function loadServerConfig(): ServerConfig {
  const portVariable = process.env.CD80_PORT !== undefined ? 'CD80_PORT' : 'BLOCKS_PORT';
  const rawPort = process.env.CD80_PORT ?? process.env.BLOCKS_PORT ?? '3000';
  const port = Number(rawPort);
  if (!/^\d+$/.test(rawPort) || !Number.isInteger(port) || port < 0 || port > 65535) {
    throw new Error(`${portVariable} must be an integer between 0 and 65535.`);
  }

  return { host: '127.0.0.1', port };
}
