import type { AppDocument, FieldType } from '../app-schema/index.ts';
import type { SourceRecord } from '../compute/slices.ts';
import type { RunTrace } from '../compute/result.ts';

export type StoredApp = {
  id: string;
  doc: AppDocument;
  version: string;
  createdAt: string;
  updatedAt: string;
  profile: string;
  /** Raised by one on every update; an app never updated is revision 1. */
  rev?: number;
  history?: { version: string; doc: AppDocument; updatedAt: string }[];
};

export type RunRecord = {
  id: string;
  appId: string;
  appVersion: string;
  startedAt: string;
  status: 'ok' | 'partial' | 'failed';
  params: Record<string, unknown>;
  result?: {
    status: 'ok' | 'partial' | 'failed';
    outputs: Record<string, {
      schema: {
        name: string;
        label: string;
        type: FieldType;
        unit?: string;
        nullable: boolean;
      }[];
      rows: unknown[][];
    }>;
    failure?: { code: string; message: string; stepId?: string };
    asOfDate?: string;
    startedAt: string;
    durationMs: number;
    warnings?: string[];
  };
  failure?: { code: string; message: string };
  asOfDate?: string;
  trace?: RunTrace;
  scheduledFor?: string;
  taskId?: string;
  completedAt?: string;
  dataSource?: { kind: 'invented' | 'real' | 'unavailable'; id: string; label: string };
  datasetVersions?: Record<string, string>;
  sources?: SourceRecord[];
};

export type StoredDraft = {
  id: string;
  profile: string;
  name: string;
  reason: string;
  doc: unknown;
  errors: unknown[];
  createdAt: string;
};
