import { cronProblem } from '../validate/index.ts';

const MINUTE = 60_000;
const HOUR = 60 * MINUTE;
const bounds = [[0, 59], [0, 23], [1, 31], [1, 12], [0, 7]] as const;

function field(raw: string, min: number, max: number): Set<number> {
  const values = new Set<number>();
  for (const item of raw.split(',')) {
    const [range, stepText] = item.split('/');
    const step = stepText === undefined ? 1 : Number(stepText);
    const parts = range!.split('-').map(Number);
    const start = range === '*' ? min : parts[0]!;
    const end = range === '*' ? max : parts[1] ?? (stepText === undefined ? start : max);
    for (let value = start; value <= end; value += step) values.add(value);
  }
  return values;
}

/** Strictly after the supplied instant. Local DST gaps are skipped; folds have two instants. */
export function nextCronTime(cron: string, timeZone: string, after: string): string {
  const problem = cronProblem(cron);
  if (problem) throw new Error(`Invalid schedule: ${problem}.`);
  const instant = Date.parse(after);
  if (!Number.isFinite(instant)) throw new Error('Choose a valid schedule reference time.');
  const raw = cron.trim().split(/\s+/);
  const [minutes, hours, days, months, weekdays] = bounds.map(([min, max], index) => field(raw[index]!, min, max));
  if (weekdays!.has(7)) weekdays!.add(0);
  let formatter: Intl.DateTimeFormat;
  try {
    formatter = new Intl.DateTimeFormat('en-GB', { timeZone, calendar: 'gregory', numberingSystem: 'latn',
      year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' });
  } catch { throw new Error('Choose a supported schedule time zone.'); }
  const local = (time: number) => {
    const parts = Object.fromEntries(formatter.formatToParts(time).map((part) => [part.type, part.value]));
    const year = Number(parts.year), month = Number(parts.month), day = Number(parts.day);
    const hour = Number(parts.hour), minute = Number(parts.minute);
    const date = Date.UTC(year, month - 1, day);
    return { month, day, hour, minute, date, weekday: new Date(date).getUTCDay(), offset: date + hour * HOUR + minute * MINUTE - time };
  };
  const matchesHour = (value: ReturnType<typeof local>): boolean => {
    const dom = days!.has(value.day), dow = weekdays!.has(value.weekday);
    // A wildcard day field restricts the other; two restricted day fields are ORed.
    const dayMatches = raw[2]!.startsWith('*') || raw[4]!.startsWith('*') ? dom && dow : dom || dow;
    return months!.has(value.month) && hours!.has(value.hour) && dayMatches;
  };
  const first = Math.floor(instant / MINUTE) * MINUTE + MINUTE;
  const limit = first + 8 * 366 * 24 * HOUR;
  for (let start = first; start < limit;) {
    const end = Math.floor(start / HOUR) * HOUR + HOUR;
    const a = local(start), b = local(end - MINUTE);
    const stable = a.date === b.date && a.hour === b.hour && a.offset === b.offset;
    if (!stable || matchesHour(a)) {
      for (let time = start; time < end; time += MINUTE) {
        const value = stable ? { ...a, minute: a.minute + (time - start) / MINUTE } : local(time);
        if (matchesHour(value) && minutes!.has(value.minute)) return new Date(time).toISOString();
      }
    }
    start = end;
  }
  throw new Error('The schedule has no occurrence within eight years.');
}
