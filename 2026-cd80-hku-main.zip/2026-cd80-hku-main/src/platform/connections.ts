import { createHash } from 'node:crypto';
import { canonicalJson, ParamDecl } from '../app-schema/index.ts';
import { storageOperation, storageTransaction } from './database.ts';
import { ownedApp } from './schedules.ts';
import { decodeStoredValue, encodeStoredValue } from './json.ts';

export type ConnectionSettings = {
  params: Record<string, unknown>;
  bindings: Record<string, string>;
  mappings: Record<string, Record<string, string>>;
};
export type ConnectionSnapshot = { settings: ConnectionSettings; revision: string };
function settingsOf(state: Record<string, unknown>): ConnectionSettings {
  return { params: (state.params ?? {}) as ConnectionSettings['params'],
    bindings: (state.bindings ?? {}) as ConnectionSettings['bindings'], mappings: (state.mappings ?? {}) as ConnectionSettings['mappings'] };
}
function snapshot(settings: ConnectionSettings): ConnectionSnapshot {
  return { settings, revision: createHash('sha256').update(canonicalJson(settings)).digest('hex') };
}

export async function getConnectionSettings(appId: string, profile: string): Promise<ConnectionSnapshot> {
  return storageOperation((database) => {
    ownedApp(database, appId, profile);
    const row = database.prepare('SELECT record FROM states WHERE app_id = ? AND profile = ?').get(encodeStoredValue(appId), encodeStoredValue(profile));
    return snapshot(settingsOf(row ? decodeStoredValue<Record<string, unknown>>(row.record) : {}));
  });
}

/** Compare only editable settings; preserve the latest carry and unrelated state atomically. */
export async function saveConnectionSettings(appId: string, profile: string, settings: ConnectionSettings, revision: string): Promise<
  { kind: 'saved'; snapshot: ConnectionSnapshot } | { kind: 'conflict' } | { kind: 'invalid'; message: string }
> {
  const value = decodeStoredValue<ConnectionSettings>(encodeStoredValue(settings));
  return storageOperation((database) => storageTransaction(database, () => {
    const app = ownedApp(database, appId, profile);
    const row = database.prepare('SELECT record FROM states WHERE app_id = ? AND profile = ?').get(encodeStoredValue(appId), encodeStoredValue(profile));
    const state = row ? decodeStoredValue<Record<string, unknown>>(row.record) : {};
    if (snapshot(settingsOf(state)).revision !== revision) return { kind: 'conflict' as const };
    for (const [key, raw] of Object.entries(value.params)) {
      const decl = app.doc.params.find((param) => param.key === key);
      if (!decl || !ParamDecl.safeParse({ ...decl, default: raw }).success) return { kind: 'invalid' as const, message: 'A saved parameter has an invalid value.' };
    }
    for (const key of new Set([...Object.keys(value.bindings), ...Object.keys(value.mappings)])) {
      const requirement = app.doc.data.find((req) => req.key === key);
      if (!requirement || Object.keys(value.mappings[key] ?? {}).some((field) => !requirement.fields.some((item) => item.name === field))) {
        return { kind: 'invalid' as const, message: 'Choose declared data requirements and fields.' };
      }
    }
    database.prepare(`INSERT INTO states (app_id, profile, record) VALUES (?, ?, ?)
      ON CONFLICT (app_id, profile) DO UPDATE SET record = excluded.record`).run(
      encodeStoredValue(appId), encodeStoredValue(profile), encodeStoredValue({ ...state, ...value }),
    );
    return { kind: 'saved' as const, snapshot: snapshot(value) };
  }));
}
