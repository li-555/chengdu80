import type { StoredApp } from './types.ts';
import type { ValidationIssue } from '../validate/errors.ts';

export type AppSummary = Pick<StoredApp, 'id' | 'createdAt' | 'updatedAt'> & {
  name: string;
  description: string;
  icon?: string;
};

export type LibraryApp = Omit<StoredApp, 'profile'>;
export type LibraryIssue = ValidationIssue;
export type LibraryErrorBody = {
  error: { code: string; message: string; issues?: LibraryIssue[] };
};
export type ImportAppResponse = { app: LibraryApp; warnings: LibraryIssue[] };
