import { nextCronTime } from './cron.ts';
import type { ScheduledTask } from './schedule-types.ts';

export type MarketCalendar = (date: string) => Promise<{ open: string; close: string } | null>;
export class CalendarUnavailableError extends Error {
  constructor() { super('The trading calendar is unavailable or incomplete. Check the data connection, then resume the task.'); }
}

/** SSE times are local Shanghai clock times returned by the shared calendar. */
export async function nextTriggerTime(trigger: ScheduledTask['trigger'], after: string, calendar?: MarketCalendar): Promise<string> {
  if (trigger.kind === 'schedule') return nextCronTime(trigger.cron, trigger.tz, after);
  const read = calendar ?? (async (date: string) => (await import('../data/index.ts')).marketTimes(date));
  const start = Date.parse(after);
  if (!Number.isFinite(start)) throw new Error('Choose a valid reference time.');
  let timeout: ReturnType<typeof setTimeout> | undefined;
  let cancelled = false;
  try {
    return await Promise.race([
      (async () => {
        const date = new Date(start + 8 * 3600_000).toISOString().slice(0, 10);
        for (let day = 0; day <= 31; day++) {
          if (cancelled) throw new CalendarUnavailableError();
          const current = new Date(Date.parse(`${date}T00:00:00Z`) + day * 86400_000).toISOString().slice(0, 10);
          const times = await read(current);
          if (cancelled) throw new CalendarUnavailableError();
          if (!times) continue;
          const clock = times[trigger.at];
          if (!/^([01]\d|2[0-3]):[0-5]\d$/.test(clock)) throw new CalendarUnavailableError();
          const time = Date.parse(`${current}T${clock}:00+08:00`) + trigger.offsetMinutes * 60_000;
          if (time > start) return new Date(time).toISOString();
        }
        throw new CalendarUnavailableError();
      })(),
      new Promise<never>((_, reject) => { timeout = setTimeout(() => { cancelled = true; reject(new CalendarUnavailableError()); }, 10_000); }),
    ]);
  } catch { throw new CalendarUnavailableError(); }
  finally { cancelled = true; if (timeout) clearTimeout(timeout); }
}
