import { createHash } from 'node:crypto';
import { z } from 'zod';
import { canonicalJson, ParamDecl } from '../app-schema/index.ts';
import type { StoredApp } from './types.ts';
import { ownedApp } from './schedules.ts';
import { storageOperation, storageTransaction } from './database.ts';
import { decodeStoredValue, encodeStoredValue } from './json.ts';

export const listActionRequest = z.strictObject({
  param: z.string().regex(/^[a-z][a-z0-9_]{0,39}$/),
  recordId: z.string().min(1).max(200).refine((value) => value.trim().length > 0),
  action: z.enum(['add', 'remove']), note: z.string().max(1000).default(''),
  requestId: z.string().regex(/^[A-Za-z0-9_-]{1,128}$/), revision: z.string().regex(/^[a-f0-9]{64}$/),
});
export type ListActionRequest = z.infer<typeof listActionRequest>;
export type ListActionEvent = {
  requestId: string; param: string; recordId: string; action: 'add' | 'remove'; note: string;
  appVersion: string; actor: string; time: string; before: string[]; after: string[];
};
export type ListActionSnapshot = {
  appVersion: string; revision: string; params: { key: string; label: string; values: string[] }[]; history: ListActionEvent[];
};
const HISTORY_LIMIT = 100;
function stateOf(database: Parameters<typeof ownedApp>[0], appId: string, profile: string): Record<string, unknown> {
  const row = database.prepare('SELECT record FROM states WHERE app_id = ? AND profile = ?').get(encodeStoredValue(appId), encodeStoredValue(profile));
  return row ? decodeStoredValue<Record<string, unknown>>(row.record) : {};
}
function snapshot(app: StoredApp, state: Record<string, unknown>): ListActionSnapshot {
  const values = (state.params ?? {}) as Record<string, unknown>;
  const history = (state.listActionHistory ?? []) as ListActionEvent[];
  const params = app.doc.params.filter((param) => param.type === 'text' && param.list === true).map((param) => {
    const current = Object.hasOwn(values, param.key) ? values[param.key] : param.default ?? [];
    if (!ParamDecl.safeParse({ ...param, default: current }).success || !Array.isArray(current)) throw new Error('Invalid saved list settings.');
    return { key: param.key, label: param.label, values: current as string[] };
  });
  return { appVersion: app.version, params, history,
    revision: createHash('sha256').update(canonicalJson({ appVersion: app.version, params: state.params ?? {}, bindings: state.bindings ?? {}, mappings: state.mappings ?? {}, history })).digest('hex') };
}
export async function getListActions(appId: string, profile: string): Promise<ListActionSnapshot> {
  return storageOperation((database) => snapshot(ownedApp(database, appId, profile), stateOf(database, appId, profile)));
}
export async function saveListAction(appId: string, profile: string, input: unknown): Promise<
  { kind: 'saved' | 'reused'; snapshot: ListActionSnapshot } | { kind: 'conflict' | 'request_conflict' | 'invalid' }
> {
  const parsed = listActionRequest.safeParse(input);
  if (!parsed.success) return { kind: 'invalid' };
  const request = parsed.data;
  return storageOperation((database) => storageTransaction(database, () => {
    const app = ownedApp(database, appId, profile);
    const state = stateOf(database, appId, profile);
    const current = snapshot(app, state);
    const previous = current.history.find((event) => event.requestId === request.requestId);
    // Retry recognition precedes revision checking, including after a later edit.
    if (previous) {
      if (previous.param !== request.param || previous.recordId !== request.recordId || previous.action !== request.action || previous.note !== request.note) return { kind: 'request_conflict' as const };
      return { kind: 'reused' as const, snapshot: current };
    }
    if (current.revision !== request.revision) return { kind: 'conflict' as const };
    const param = app.doc.params.find((decl) => decl.key === request.param && decl.type === 'text' && decl.list === true);
    const declaration = current.params.find((decl) => decl.key === request.param);
    if (!param || !declaration) return { kind: 'invalid' as const };
    const before = declaration.values;
    const after = request.action === 'add' ? [...new Set([...before, request.recordId])] : before.filter((value) => value !== request.recordId);
    if (!ParamDecl.safeParse({ ...param, default: after }).success) return { kind: 'invalid' as const };
    const event: ListActionEvent = { requestId: request.requestId, param: request.param, recordId: request.recordId, action: request.action, note: request.note,
      appVersion: app.version, actor: profile, time: new Date().toISOString(), before: [...before], after: [...after] };
    const updated = { ...state, params: { ...((state.params ?? {}) as Record<string, unknown>), [request.param]: after }, listActionHistory: [...current.history, event].slice(-HISTORY_LIMIT) };
    database.prepare(`INSERT INTO states (app_id, profile, record) VALUES (?, ?, ?)
      ON CONFLICT (app_id, profile) DO UPDATE SET record = excluded.record`).run(encodeStoredValue(appId), encodeStoredValue(profile), encodeStoredValue(updated));
    return { kind: 'saved' as const, snapshot: snapshot(app, updated) };
  }));
}
