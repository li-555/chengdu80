import { z } from 'zod';
import { AppDocument } from '../app-schema/index.ts';

// The published schema names every portable field, including nested operation
// parameters and element properties. Storage additions never become export fields.
type Shape = { propertyNames?: { pattern?: string }; type?: string; properties?: Record<string, Shape>; additionalProperties?: Shape | boolean; items?: Shape; prefixItems?: Shape[]; anyOf?: Shape[]; oneOf?: Shape[]; const?: unknown; enum?: unknown[] };
const shape = z.toJSONSchema(AppDocument, { reused: 'inline' }) as Shape;
function matches(value: unknown, schema: Shape): boolean {
  const alternatives = schema.anyOf ?? schema.oneOf;
  if (alternatives) return alternatives.some((item) => matches(value, item));
  if (schema.const !== undefined && value !== schema.const) return false;
  if (schema.enum && !schema.enum.includes(value)) return false;
  if (schema.properties && value && typeof value === 'object' && !Array.isArray(value)) {
    for (const [key, field] of Object.entries(schema.properties)) {
      if (Object.hasOwn(value, key) && (field.const !== undefined || field.enum) && !matches((value as Record<string, unknown>)[key], field)) return false;
    }
  }
  if (schema.type === 'object') return !!value && typeof value === 'object' && !Array.isArray(value);
  if (schema.type === 'array') return Array.isArray(value);
  if (schema.type === 'integer') return typeof value === 'number' && Number.isInteger(value);
  if (schema.type === 'null') return value === null;
  if (schema.type) return typeof value === schema.type;
  return true;
}
function project(value: unknown, schema: Shape): unknown {
  const alternatives = schema.anyOf ?? schema.oneOf;
  if (alternatives) {
    const branch = alternatives.find((item) => matches(value, item));
    if (!branch) throw new Error('Unsupported export value');
    return project(value, branch);
  }
  if (schema.type === 'object') {
    if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Invalid export object');
    const input = value as Record<string, unknown>;
    const output: Record<string, unknown> = Object.create(null);
    if (schema.properties) {
      for (const [key, field] of Object.entries(schema.properties)) if (Object.hasOwn(input, key)) output[key] = project(input[key], field);
    } else if (schema.additionalProperties && typeof schema.additionalProperties === 'object') {
      for (const [key, item] of Object.entries(input)) {
        if (schema.propertyNames?.pattern && !new RegExp(schema.propertyNames.pattern).test(key)) continue;
        if (!matches(item, schema.additionalProperties)) continue;
        output[key] = project(item, schema.additionalProperties);
      }
    }
    return output;
  }
  if (schema.type === 'array') {
    if (!Array.isArray(value)) throw new Error('Invalid export array');
    return value.map((item, index) => {
      const field = schema.prefixItems?.[index] ?? schema.items;
      if (!field) throw new Error('Unsupported export array');
      return project(item, field);
    });
  }
  if (value !== null && !['string', 'number', 'boolean'].includes(typeof value)) throw new Error('Invalid export scalar');
  return value;
}
export function exportApplication(document: AppDocument): string {
  const portable = AppDocument.parse(project(document, shape));
  // Catalogue hints travel; an upload or API identifier belongs to this machine.
  for (const requirement of portable.data) {
    if (requirement.datasetHint && !/^tushare:[A-Za-z0-9_]+$/.test(requirement.datasetHint)) delete requirement.datasetHint;
  }
  return JSON.stringify({ $schema: '/api/spec/schema', ...portable }, null, 2) + '\n';
}
export function exportFilename(name: string): string {
  const safe = name.normalize('NFKC').replace(/[^A-Za-z0-9_-]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80);
  return `${safe || 'application'}.fin.json`;
}
