import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { loadStorageConfig } from './config.ts';

let connection: DatabaseSync | undefined;

const publicErrors = new Set([
  'BLOCKS_DB_PATH must be a non-empty file path.',
  'Application not found.',
  'Application not found for this profile.',
  'Scheduled task not found for this profile.',
  'A scheduled task already exists for this application trigger.',
  'The scheduled task is disabled or its next execution time has changed.',
  'The scheduled task no longer matches the saved application.',
  'This trigger cannot be scheduled by the current execution entry point.',
  'The execution record is no longer running.',
  'The execution identifier belongs to a different request.',
  'The storage database contains an invalid record.',
  'The storage database version is not supported.',
  'The storage database schema is not supported.',
  'The file is not an initialized Blocks storage database.',
  'The file is not a Blocks storage database.',
  'The storage database is busy. The operation was not saved.',
  'Unable to access the storage database. Check its path, permissions and integrity.',
]);

const schema = `
  CREATE TABLE apps (
    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL UNIQUE,
    profile TEXT NOT NULL,
    record TEXT NOT NULL CHECK (json_valid(record) AND json_type(record) = 'object'),
    UNIQUE (id, profile)
  ) STRICT;
  CREATE INDEX apps_profile ON apps (profile, sequence);
  CREATE TABLE runs (
    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL UNIQUE,
    app_id TEXT NOT NULL REFERENCES apps (id) ON DELETE CASCADE,
    started_at TEXT NOT NULL,
    record TEXT NOT NULL CHECK (json_valid(record) AND json_type(record) = 'object')
  ) STRICT;
  CREATE INDEX runs_history ON runs (app_id, started_at DESC, sequence);
  CREATE TABLE states (
    app_id TEXT NOT NULL,
    profile TEXT NOT NULL,
    record TEXT NOT NULL CHECK (json_valid(record) AND json_type(record) = 'object'),
    PRIMARY KEY (app_id, profile),
    FOREIGN KEY (app_id, profile) REFERENCES apps (id, profile) ON DELETE CASCADE
  ) STRICT;
  PRAGMA application_id = 0x424c4b53;
  PRAGMA user_version = 1;
`;

// Version 2 adds scheduling metadata without replacing any version 1 records.
const schedulingSchema = `
  CREATE TABLE scheduled_tasks (
    id TEXT PRIMARY KEY,
    app_id TEXT NOT NULL,
    profile TEXT NOT NULL,
    trigger_index INTEGER NOT NULL CHECK (trigger_index >= 0),
    record TEXT NOT NULL CHECK (json_valid(record) AND json_type(record) = 'object'),
    FOREIGN KEY (app_id, profile) REFERENCES apps (id, profile) ON DELETE CASCADE,
    UNIQUE (app_id, trigger_index)
  ) STRICT;
  CREATE INDEX scheduled_tasks_profile ON scheduled_tasks (profile, app_id);
  CREATE TABLE executions (
    id TEXT PRIMARY KEY,
    app_id TEXT NOT NULL,
    profile TEXT NOT NULL,
    task_id TEXT REFERENCES scheduled_tasks (id) ON DELETE CASCADE,
    scheduled_for TEXT,
    status TEXT NOT NULL CHECK (status IN ('running', 'finished')),
    record TEXT NOT NULL CHECK (json_valid(record) AND json_type(record) = 'object'),
    FOREIGN KEY (app_id, profile) REFERENCES apps (id, profile) ON DELETE CASCADE,
    CHECK ((task_id IS NULL) = (scheduled_for IS NULL)),
    UNIQUE (task_id, scheduled_for)
  ) STRICT;
  CREATE UNIQUE INDEX executions_one_running_app ON executions (app_id) WHERE status = 'running';
  CREATE INDEX executions_profile ON executions (profile, app_id);
  PRAGMA user_version = 2;
`;

// Version 3 keeps invalid builder documents separate from installed applications.
const draftsSchema = `
  CREATE TABLE drafts (
    sequence INTEGER PRIMARY KEY AUTOINCREMENT,
    id TEXT NOT NULL UNIQUE,
    profile TEXT NOT NULL,
    record TEXT NOT NULL CHECK (json_valid(record) AND json_type(record) = 'object')
  ) STRICT;
  CREATE INDEX drafts_profile ON drafts (profile, sequence);
  PRAGMA user_version = 3;
`;

function storageError(error: unknown): Error {
  if (error && typeof error === 'object' && 'errcode' in error
    && typeof error.errcode === 'number' && [5, 6].includes(error.errcode & 0xff)) {
    return new Error('The storage database is busy. The operation was not saved.');
  }
  if (error instanceof Error && publicErrors.has(error.message)) return error;
  return new Error('Unable to access the storage database. Check its path, permissions and integrity.');
}

export function storageOperation<T>(action: (database: DatabaseSync) => T): T {
  try {
    return action(getDatabase());
  } catch (error) {
    throw storageError(error);
  }
}

function initialize(database: DatabaseSync): void {
  database.exec('BEGIN IMMEDIATE');
  try {
    const version = database.prepare('PRAGMA user_version').get()?.user_version;
    const applicationId = database.prepare('PRAGMA application_id').get()?.application_id;
    if (version !== 0 && version !== 1 && version !== 2 && version !== 3) {
      throw new Error('The storage database version is not supported.');
    }
    if (version === 0) {
      const existing = database.prepare("SELECT name FROM sqlite_schema WHERE name NOT GLOB 'sqlite_*'").get();
      if (existing || applicationId !== 0) throw new Error('The file is not an initialized Blocks storage database.');
      database.exec(schema);
    } else {
      if (applicationId !== 0x424c4b53) throw new Error('The file is not a Blocks storage database.');
      const tables = database.prepare("SELECT name FROM sqlite_schema WHERE type = 'table' AND name IN ('apps', 'runs', 'states')").all();
      if (tables.length !== 3) throw new Error('The storage database schema is not supported.');
      database.prepare('SELECT sequence, id, profile, record FROM apps LIMIT 0').all();
      database.prepare('SELECT sequence, id, app_id, started_at, record FROM runs LIMIT 0').all();
      database.prepare('SELECT app_id, profile, record FROM states LIMIT 0').all();
    }
    if (version === 0 || version === 1) database.exec(schedulingSchema);
    database.prepare('SELECT id, app_id, profile, trigger_index, record FROM scheduled_tasks LIMIT 0').all();
    database.prepare('SELECT id, app_id, profile, task_id, scheduled_for, status, record FROM executions LIMIT 0').all();
    if (version !== 3) database.exec(draftsSchema);
    database.prepare('SELECT sequence, id, profile, record FROM drafts LIMIT 0').all();
    database.exec('COMMIT');
  } catch (error) {
    database.exec('ROLLBACK');
    throw error;
  }
}

function getDatabase(): DatabaseSync {
  if (connection) return connection;
  let candidate: DatabaseSync | undefined;
  try {
    const config = loadStorageConfig();
    mkdirSync(dirname(config.path), { recursive: true });
    candidate = new DatabaseSync(config.path, {
      timeout: 0,
      enableForeignKeyConstraints: true,
      enableDoubleQuotedStringLiterals: false,
      allowExtension: false,
    });
    initialize(candidate);
    connection = candidate;
    return connection;
  } catch (error) {
    if (candidate?.isOpen) candidate.close();
    throw storageError(error);
  }
}

export function storageTransaction<T>(database: DatabaseSync, action: () => T): T {
  database.exec('BEGIN IMMEDIATE');
  try {
    const result = action();
    database.exec('COMMIT');
    return result;
  } catch (error) {
    database.exec('ROLLBACK');
    throw error;
  }
}

export function closeStorage(): void {
  if (!connection) return;
  connection.close();
  connection = undefined;
}
