import { fetchSlicesFor } from '../compute/slices.ts';
import type { ExecutionDataAdapter } from './execution-data.ts';

function stringMap(value: Record<string, unknown>): Record<string, string> {
  const entries = Object.entries(value);
  if (entries.some(([, item]) => typeof item !== 'string')) throw new Error('Data bindings and column mappings must contain text values.');
  return Object.fromEntries(entries) as Record<string, string>;
}

/** Thin platform wrapper around the team's shared data resolver. No duplicate data policy. */
export function realExecutionAdapter(options: { today?: string } = {}): ExecutionDataAdapter {
  const today = options.today;
  if (today !== undefined && (!/^\d{4}-\d{2}-\d{2}$/.test(today) || !Number.isFinite(Date.parse(today))
    || new Date(today).toISOString().slice(0, 10) !== today)) throw new Error('Choose a valid data reference date.');
  return {
    kind: 'real', id: `fetchSlicesFor:v1:${today ?? 'current-shanghai-day'}`, label: 'Application data sources',
    async resolve({ app, params, bindings, mappings, signal }) {
      signal?.throwIfAborted();
      const columns: Record<string, Record<string, string>> = Object.create(null);
      for (const [key, value] of Object.entries(mappings)) {
        if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Field mappings must be objects.');
        columns[key] = stringMap(value as Record<string, unknown>);
      }
      const { slices, sources } = await fetchSlicesFor(app.doc, {
        params, bindings: stringMap(bindings), mappings: columns,
        ...(today === undefined ? {} : { today }),
      });
      signal?.throwIfAborted();
      // Keep per-source dates exactly as returned; do not invent a common freshness date.
      return { slices, sources, datasetVersions: Object.fromEntries(sources.map((source) => [source.key, source.datasetVersion])) };
    },
  };
}
