const invalidValueMessage = 'Stored values must be JSON-compatible. Omit undefined properties and use only null, booleans, strings, finite numbers, dense arrays and plain objects.';

export function encodeStoredValue(value: unknown): string {
  const ancestors = new Set<object>();

  function encode(input: unknown): string {
    if (input === null) return 'null';
    if (typeof input === 'string' || typeof input === 'boolean') return JSON.stringify(input);
    if (typeof input === 'number' && Number.isFinite(input)) {
      return Object.is(input, -0) ? '-0' : JSON.stringify(input);
    }
    if (typeof input !== 'object' || ancestors.has(input)) throw new Error(invalidValueMessage);

    const array = Array.isArray(input);
    const prototype = Object.getPrototypeOf(input);
    if (!array && prototype !== Object.prototype && prototype !== null) {
      throw new Error(invalidValueMessage);
    }
    ancestors.add(input);
    try {
      const keys = Reflect.ownKeys(input);
      if (array) {
        if (keys.length !== input.length + 1) throw new Error(invalidValueMessage);
        const items: string[] = [];
        for (let index = 0; index < input.length; index += 1) {
          const descriptor = Object.getOwnPropertyDescriptor(input, String(index));
          if (!descriptor?.enumerable || !('value' in descriptor)) throw new Error(invalidValueMessage);
          items.push(encode(descriptor.value));
        }
        return `[${items.join(',')}]`;
      }
      const properties: string[] = [];
      for (const key of keys) {
        if (typeof key !== 'string') throw new Error(invalidValueMessage);
        const descriptor = Object.getOwnPropertyDescriptor(input, key);
        if (!descriptor?.enumerable || !('value' in descriptor)) throw new Error(invalidValueMessage);
        properties.push(`${JSON.stringify(key)}:${encode(descriptor.value)}`);
      }
      return `{${properties.join(',')}}`;
    } finally {
      ancestors.delete(input);
    }
  }

  return encode(value);
}

export function decodeStoredValue<T>(value: unknown): T {
  if (typeof value !== 'string') throw new Error('The storage database contains an invalid record.');
  try {
    const decoded: unknown = JSON.parse(value);
    encodeStoredValue(decoded);
    return decoded as T;
  } catch {
    throw new Error('The storage database contains an invalid record.');
  }
}
