import { randomUUID } from 'node:crypto';
import type { DatabaseSync } from 'node:sqlite';
import { storageOperation, storageTransaction } from './database.ts';
import { decodeStoredValue, encodeStoredValue } from './json.ts';
import { executionTime, type ScheduledTask } from './schedule-types.ts';
import type { StoredApp } from './types.ts';
import { CalendarUnavailableError, nextTriggerTime, type MarketCalendar } from './trigger-time.ts';

export function ownedApp(database: DatabaseSync, appId: string, profile: string): StoredApp {
  const row = database.prepare('SELECT record FROM apps WHERE id = ? AND profile = ?')
    .get(encodeStoredValue(appId), encodeStoredValue(profile));
  if (!row) throw new Error('Application not found for this profile.');
  return decodeStoredValue<StoredApp>(row.record);
}

export function ownedTask(database: DatabaseSync, id: string, profile: string): ScheduledTask {
  const row = database.prepare('SELECT record FROM scheduled_tasks WHERE id = ? AND profile = ?')
    .get(encodeStoredValue(id), encodeStoredValue(profile));
  if (!row) throw new Error('Scheduled task not found for this profile.');
  return decodeStoredValue<ScheduledTask>(row.record);
}

export function writeTask(database: DatabaseSync, task: ScheduledTask): void {
  database.prepare('UPDATE scheduled_tasks SET record = ? WHERE id = ? AND profile = ?')
    .run(encodeStoredValue(task), encodeStoredValue(task.id), encodeStoredValue(task.profile));
}

/** Persist a declared trigger, disabled initially. This does not calculate or start a timer. */
export async function createScheduledTask(appId: string, profile: string, triggerIndex: number): Promise<ScheduledTask> {
  if (!Number.isInteger(triggerIndex) || triggerIndex < 0) throw new Error('Choose a valid application trigger.');
  return storageOperation((database) => storageTransaction(database, () => {
    const app = ownedApp(database, appId, profile);
    const trigger = app.doc.triggers[triggerIndex];
    if (!trigger || (trigger.kind !== 'schedule' && trigger.kind !== 'market')) {
      throw new Error('This trigger cannot be scheduled by the current execution entry point.');
    }
    if (database.prepare('SELECT id FROM scheduled_tasks WHERE app_id = ? AND trigger_index = ?')
      .get(encodeStoredValue(appId), triggerIndex)) {
      throw new Error('A scheduled task already exists for this application trigger.');
    }
    const now = new Date().toISOString();
    const task: ScheduledTask = {
      id: randomUUID(), appId, profile, appVersion: app.version, triggerIndex, trigger,
      enabled: false, revision: randomUUID(), nextRunAt: null, lastScheduledFor: null, lastRunId: null,
      createdAt: now, updatedAt: now,
    };
    database.prepare('INSERT INTO scheduled_tasks (id, app_id, profile, trigger_index, record) VALUES (?, ?, ?, ?, ?)')
      .run(encodeStoredValue(task.id), encodeStoredValue(appId), encodeStoredValue(profile), triggerIndex, encodeStoredValue(task));
    return task;
  }));
}

export async function getScheduledTask(id: string, profile: string): Promise<ScheduledTask | null> {
  return storageOperation((database) => {
    const row = database.prepare('SELECT record FROM scheduled_tasks WHERE id = ? AND profile = ?')
      .get(encodeStoredValue(id), encodeStoredValue(profile));
    return row ? decodeStoredValue<ScheduledTask>(row.record) : null;
  });
}

export async function listScheduledTasks(profile: string): Promise<ScheduledTask[]> {
  return storageOperation((database) => database.prepare('SELECT record FROM scheduled_tasks WHERE profile = ? ORDER BY id')
    .all(encodeStoredValue(profile)).map((row) => decodeStoredValue<ScheduledTask>(row.record)));
}

/** Set one explicit occurrence, without opting the task into the automatic loop. */
export async function configureScheduledTask(
  id: string, profile: string, settings: { enabled: boolean; nextRunAt: string | null },
): Promise<ScheduledTask> {
  if (typeof settings.enabled !== 'boolean') throw new Error('Task enabled must be true or false.');
  const nextRunAt = settings.nextRunAt === null ? null : executionTime(settings.nextRunAt);
  if (settings.enabled && nextRunAt === null) throw new Error('An enabled task needs a next execution time.');
  return storageOperation((database) => storageTransaction(database, () => {
    const task = ownedTask(database, id, profile);
    const app = ownedApp(database, task.appId, profile);
    if (app.version !== task.appVersion) throw new Error('The scheduled task no longer matches the saved application.');
    const updated = { ...task, revision: randomUUID(), automatic: false, enabled: settings.enabled, nextRunAt, updatedAt: new Date().toISOString() };
    delete updated.schedulingIssue;
    writeTask(database, updated);
    return updated;
  }));
}

/** Enable a clock schedule, or pause it without cancelling an already claimed run. */
export async function setScheduleEnabled(id: string, profile: string, enabled: boolean,
  options: { confirmVersion?: string; calendar?: MarketCalendar } = {}): Promise<ScheduledTask> {
  if (typeof enabled !== 'boolean') throw new Error('Task enabled must be true or false.');
  const task = await getScheduledTask(id, profile);
  if (!task) throw new Error('Scheduled task not found for this profile.');
  const app = storageOperation((database) => ownedApp(database, task.appId, profile));
  if (enabled && app.version !== task.appVersion && options.confirmVersion !== app.version) throw new Error('Confirm the current application version before enabling this task.');
  const trigger = enabled ? app.doc.triggers[task.triggerIndex] : task.trigger;
  if (!trigger || (trigger.kind !== 'schedule' && trigger.kind !== 'market')) throw new Error('This trigger cannot be scheduled by the current execution entry point.');
  let nextRunAt: string | null = null;
  let issue: ScheduledTask['schedulingIssue'];
  if (enabled) {
    try { nextRunAt = await nextTriggerTime(trigger, new Date().toISOString(), options.calendar); }
    catch (error) { issue = { code: error instanceof CalendarUnavailableError ? 'calendar_unavailable' : 'invalid_schedule', message: error instanceof Error ? error.message : 'The next execution time could not be calculated.' }; }
  }
  return storageOperation((database) => storageTransaction(database, () => {
    const current = ownedTask(database, id, profile);
    const latestApp = ownedApp(database, current.appId, profile);
    if (latestApp.version !== app.version || current.revision !== task.revision) throw new Error('The scheduled task no longer matches the saved application.');
    const updated = { ...current, trigger, appVersion: enabled ? app.version : current.appVersion, revision: randomUUID(), automatic: true, enabled: enabled && !issue, nextRunAt, updatedAt: new Date().toISOString() };
    delete updated.schedulingIssue;
    if (issue) updated.schedulingIssue = issue;
    writeTask(database, updated);
    return updated;
  }));
}

/** Internal service scan across profiles; never exposed as an unscoped browser endpoint. */
export function dueAutomaticTasks(now: string): ScheduledTask[] {
  return storageOperation((database) => database.prepare('SELECT record FROM scheduled_tasks').all()
    .map((row) => decodeStoredValue<ScheduledTask>(row.record))
    .filter((task) => task.automatic && task.enabled && (task.nextRunAt === null || task.nextRunAt <= now))
    .sort((a, b) => (a.nextRunAt ?? '').localeCompare(b.nextRunAt ?? '') || a.id.localeCompare(b.id)));
}

/** Only pause the occurrence that was scanned, preserving a newer user configuration. */
export function pauseAutomaticTask(task: ScheduledTask, issue: NonNullable<ScheduledTask['schedulingIssue']>): void {
  storageOperation((database) => storageTransaction(database, () => {
    const current = ownedTask(database, task.id, task.profile);
    if (!current.automatic || !current.enabled || current.nextRunAt !== task.nextRunAt || current.revision !== task.revision) return;
    writeTask(database, { ...current, revision: randomUUID(), enabled: false, schedulingIssue: issue, updatedAt: new Date().toISOString() });
  }));
}

export function rescheduleTask(task: ScheduledTask, nextRunAt: string, note?: string): void {
  storageOperation((database) => storageTransaction(database, () => {
    const current = ownedTask(database, task.id, task.profile);
    if (!current.enabled || !current.automatic || current.revision !== task.revision || current.nextRunAt !== task.nextRunAt) return;
    writeTask(database, { ...current, nextRunAt, revision: randomUUID(), ...(note ? { schedulingNote: note } : {}), updatedAt: new Date().toISOString() });
  }));
}
