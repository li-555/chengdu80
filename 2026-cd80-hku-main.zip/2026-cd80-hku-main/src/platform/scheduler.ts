import { runSavedApplication, type RunSavedApplicationOptions } from './execute.ts';
import { dueAutomaticTasks, pauseAutomaticTask, rescheduleTask } from './schedules.ts';
import type { ExecutionReply } from './schedule-types.ts';
import { recoverInterruptedExecutions } from './execution-store.ts';
import { getApp } from './storage.ts';
import { CalendarUnavailableError, nextTriggerTime, type MarketCalendar } from './trigger-time.ts';

type SchedulerOptions = {
  intervalMs?: number;
  /** Dependency injection for offline checks; production uses the unified execution entry. */
  run?: (options: RunSavedApplicationOptions) => Promise<ExecutionReply>;
  onError?: () => void;
  calendar?: MarketCalendar;
};

/** A serial, non-overlapping scanner. Database claims arbitrate other server processes. */
export function createScheduler(options: SchedulerOptions = {}) {
  const intervalMs = options.intervalMs ?? 1000;
  if (!Number.isInteger(intervalMs) || intervalMs < 10) throw new Error('The scheduler interval must be at least 10 milliseconds.');
  const run = options.run ?? runSavedApplication;
  let timer: ReturnType<typeof setInterval> | undefined;
  let pending: Promise<void> | undefined;
  let stopped = false;
  const report = () => { try { options.onError?.(); } catch { /* Reporting must not stop the loop. */ } };
  async function scan(): Promise<void> {
    recoverInterruptedExecutions();
    for (const task of dueAutomaticTasks(new Date().toISOString())) {
      if (stopped) break;
      try {
        const app = await getApp(task.appId);
        if (!app || app.version !== task.appVersion) {
          pauseAutomaticTask(task, { code: 'version_changed', message: 'The application changed. Review and confirm its current version before resuming.' });
          continue;
        }
        const now = new Date().toISOString();
        if (task.nextRunAt === null || Date.parse(now) - Date.parse(task.nextRunAt) > 86400_000) {
          const next = await nextTriggerTime(task.trigger, now, options.calendar);
          rescheduleTask(task, next, task.nextRunAt ? 'An occurrence older than 24 hours was skipped. Historical backlogs are not replayed.' : undefined);
          continue;
        }
        if (task.trigger.kind === 'market') {
          const confirmed = await nextTriggerTime(task.trigger, new Date(Date.parse(task.nextRunAt) - 1).toISOString(), options.calendar);
          if (confirmed !== task.nextRunAt) { rescheduleTask(task, confirmed, 'The calendar changed; the pending market occurrence was rescheduled.'); continue; }
        }
        const reply = await run({ appId: task.appId, profile: task.profile,
          scheduled: { taskId: task.id, scheduledFor: task.nextRunAt! } });
        if (reply.kind === 'needs_data') pauseAutomaticTask(task, { code: 'needs_data', message: reply.issue.message, dataIssue: reply.issue });
        // busy/in_progress retain their occurrence until the current execution finishes.
      } catch (error) {
        pauseAutomaticTask(task, error instanceof CalendarUnavailableError
          ? { code: 'calendar_unavailable', message: error.message }
          : { code: 'execution_unconfirmed', message: 'The scheduled execution could not be confirmed. Review its status before enabling it again.' });
        report();
      }
    }
  }
  function tick(): Promise<void> {
    if (stopped) return Promise.resolve();
    if (pending) return pending;
    pending = scan().catch(report).finally(() => { pending = undefined; });
    return pending;
  }
  return {
    tick,
    start(): void {
      if (timer || stopped) return;
      timer = setInterval(() => { void tick(); }, intervalMs);
      timer.unref();
      void tick();
    },
    async stop(): Promise<void> {
      stopped = true;
      if (timer) clearInterval(timer);
      timer = undefined;
      await pending;
    },
  };
}
