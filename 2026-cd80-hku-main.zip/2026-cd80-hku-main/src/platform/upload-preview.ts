import { analyzeTable, type TableAnalysis } from '../data/analyze.ts';
import type { Dataset } from '../data/types.ts';

export type UploadDetails = {
  dataset: Dataset;
  blankCounts: number[];
  preview: { columns: string[]; rows: string[][] };
  analysis: TableAnalysis | null;
  analysisWarning?: 'ANALYSIS_UNAVAILABLE';
};
export type UploadedSheet = UploadDetails & { sheetName: string };
export type SkippedSheet = { sheetName: string; reason: 'NO_COLUMNS' | 'SAVE_FAILED' };
export type WorkbookUpload = UploadDetails & { sheets: UploadedSheet[]; skippedSheets: SkippedSheet[] };

/** Preview and derived values are a separate response, never catalogue metadata. */
export function describeUpload(dataset: Dataset, rows: string[][]): UploadDetails {
  const preview = { columns: dataset.fields.map((field) => field.name), rows: rows.slice(0, 5) };
  // Keep Abdur's whitespace-aware counts separate from Rachel's analysis nulls.
  const blankCounts = dataset.fields.map((_, index) => rows.reduce((total, row) => total + ((row[index] ?? '').trim() === '' ? 1 : 0), 0));
  try {
    const analysis = analyzeTable(dataset.fields, rows);
    // Non-finite statistics must not silently become null during JSON serialization.
    for (const column of analysis.columns) {
      if (column.stats && !Object.values(column.stats).every(Number.isFinite)) throw new Error('Non-finite analysis');
    }
    return { dataset, blankCounts, preview, analysis };
  } catch {
    // A statistics failure must not discard an otherwise readable table.
    return { dataset, blankCounts, preview, analysis: null, analysisWarning: 'ANALYSIS_UNAVAILABLE' };
  }
}
