import type { LanguageModel } from 'ai';
import { createHash, randomUUID } from 'node:crypto';
import { canonicalJson, IsoDate, ParamDecl, type AppDocument } from '../app-schema/index.ts';
import { validateApplication } from '../validate/index.ts';
import type { RunResult, RunTrace } from '../compute/result.ts';
import { claimExecution, finishExecution, releaseDataConnectionClaim, renewExecutionLease } from './execution-store.ts';
import type { ExecutionDataAdapter, ResolvedExecutionData } from './execution-data.ts';
import { realExecutionAdapter } from './real-execution.ts';
import { NeedsBindingError, NeedsMappingError } from '../compute/slices.ts';
import { decodeStoredValue, encodeStoredValue } from './json.ts';
import { executionTime, type ExecutionReply, type DataConnectionIssue } from './schedule-types.ts';
import type { RunRecord, StoredApp } from './types.ts';

export type RunSavedApplicationOptions = {
  appId: string;
  profile: string;
  /** Reuse this id when retrying a request whose completion is unknown. */
  runId?: string;
  params?: Record<string, unknown>;
  scheduled?: { taskId: string; scheduledFor: string };
  /** Defaults to the shared fetchSlicesFor adapter; invented fixtures require explicit opt-in. */
  adapter?: ExecutionDataAdapter;
  allowInventedData?: boolean;
  signal?: AbortSignal;
  /** Offline tests inject a model; production AI steps use the configured platform model. */
  model?: LanguageModel;
};

function object(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Expected a settings object.');
  return decodeStoredValue<Record<string, unknown>>(encodeStoredValue(value));
}

function settings(doc: AppDocument, saved: Record<string, unknown>, overrides: Record<string, unknown>): Record<string, unknown> {
  const declared = new Set(doc.params.map((param) => param.key));
  if (Object.keys({ ...saved, ...overrides }).some((key) => !declared.has(key))) throw new Error('An undeclared setting was supplied.');
  const values: Record<string, unknown> = Object.create(null);
  for (const param of doc.params) {
    const value = Object.hasOwn(overrides, param.key) ? overrides[param.key]
      : Object.hasOwn(saved, param.key) ? saved[param.key] : param.default;
    if (value === undefined || !ParamDecl.safeParse({ ...param, default: value }).success) {
      throw new Error('A required setting is missing or invalid.');
    }
    values[param.key] = value;
  }
  return values;
}

function checkedData(doc: AppDocument, raw: ResolvedExecutionData): ResolvedExecutionData {
  const data = decodeStoredValue<ResolvedExecutionData>(encodeStoredValue(raw));
  const slices = object(data.slices);
  const versions = object(data.datasetVersions);
  const names = new Set(doc.data.map((req) => req.key));
  if (Object.keys(slices).some((key) => !names.has(key)) || Object.keys(versions).some((key) => !names.has(key))) {
    throw new Error('The data adapter returned an undeclared relation.');
  }
  for (const req of doc.data) {
    const slice = data.slices[req.key];
    if (!slice || !Array.isArray(slice.columns) || !Array.isArray(slice.rows) || slice.rows.length > 200_000
      || typeof versions[req.key] !== 'string' || !versions[req.key]) throw new Error('A data requirement was not resolved.');
    const columnNames = new Set<string>();
    for (const column of slice.columns) {
      if (!column || typeof column.name !== 'string' || columnNames.has(column.name)
        || !['string', 'number', 'integer', 'boolean', 'date', 'timestamp'].includes(column.type)) {
        throw new Error('A data column is invalid.');
      }
      columnNames.add(column.name);
    }
    for (const field of req.fields) {
      const column = slice.columns.find((candidate) => candidate.name === field.name);
      if (!column) {
        if (field.required) throw new Error('A required data column is missing.');
        continue;
      }
      const compatible = field.type === 'text' ? column.type === 'string'
        : field.type === 'number' ? column.type === 'number' || column.type === 'integer'
        : field.type === 'date' ? column.type === 'date' || column.type === 'timestamp'
        : column.type === 'boolean';
      if (!compatible) throw new Error('A data column has the wrong type.');
    }
    if (slice.rows.some((row) => !row || typeof row !== 'object' || Array.isArray(row))) {
      throw new Error('Resolved data must contain field-keyed row objects.');
    }
  }
  if (data.asOfDate !== undefined && !IsoDate.safeParse(data.asOfDate).success) throw new Error('Invalid data date.');
  return data;
}

/** Omit undefined optional step metadata at the platform boundary, without changing the engine. */
function storedTrace(trace: RunTrace): RunTrace {
  const steps = trace.steps.map((step) => Object.fromEntries(
    Object.entries(step).filter(([key, value]) => value !== undefined || !['op', 'failed', 'model', 'warnings', 'logs'].includes(key)),
  ));
  return decodeStoredValue<RunTrace>(encodeStoredValue({ ...trace, steps }));
}

async function resolveData(
  adapter: ExecutionDataAdapter, input: Parameters<ExecutionDataAdapter['resolve']>[0], signal: AbortSignal,
): Promise<ResolvedExecutionData> {
  signal.throwIfAborted();
  let onAbort: () => void = () => {};
  const cancelled = new Promise<never>((_resolve, reject) => {
    onAbort = () => reject(new Error('Data resolution was cancelled.'));
    signal.addEventListener('abort', onAbort, { once: true });
    if (signal.aborted) onAbort();
  });
  try {
    return await Promise.race([Promise.resolve().then(() => {
      signal.throwIfAborted();
      return adapter.resolve(input);
    }), cancelled]);
  } finally {
    signal.removeEventListener('abort', onAbort);
  }
}

/** One saved run, explicitly invoked. No timer, automatic data fallback, or automatic retry. */
export async function runSavedApplication(options: RunSavedApplicationOptions): Promise<ExecutionReply> {
  const id = options.runId ?? randomUUID();
  if (typeof id !== 'string' || !/^[A-Za-z0-9_-]{1,128}$/.test(id)) throw new Error('Choose a valid execution identifier.');
  const overrides = options.params === undefined ? {} : object(options.params);
  const scheduled = options.scheduled ? {
    taskId: options.scheduled.taskId, scheduledFor: executionTime(options.scheduled.scheduledFor),
  } : undefined;
  const adapter = options.adapter ?? realExecutionAdapter();
  const dataSource: NonNullable<RunRecord['dataSource']> = adapter
    ? { kind: adapter.kind, id: adapter.id, label: adapter.label }
    : { kind: 'unavailable', id: 'unconfigured', label: 'No data adapter configured' };
  // Reject unsupported values before hashing rather than allowing JSON to drop them.
  encodeStoredValue(dataSource);
  const requestKey = createHash('sha256').update(canonicalJson({
    params: overrides, dataSource, allowInventedData: options.allowInventedData === true,
  })).digest('hex');
  const claim = claimExecution({
    id, appId: options.appId, profile: options.profile, requestKey,
    ...(scheduled ? { scheduled } : {}),
  });
  if (!('attempt' in claim)) return claim;

  const startedAt = claim.attempt.startedAt;
  const deadline = AbortSignal.timeout(60_000);
  const signal = options.signal ? AbortSignal.any([options.signal, deadline]) : deadline;
  const heartbeat = setInterval(() => {
    if (signal.aborted) return;
    try { renewExecutionLease(claim); } catch { /* Recovery fences an expired claim if storage remains unavailable. */ }
  }, 5000);
  heartbeat.unref();
  try {
  let params: Record<string, unknown> = {};
  let trace: RunTrace | undefined;
  let newState: Record<string, unknown> | undefined;
  let data: ResolvedExecutionData | undefined;
  let result: RunResult;
  let failure = { code: 'E_RUN_SETUP', message: 'The saved application or its settings are invalid.' };
  try {
    signal.throwIfAborted();
    const checked = validateApplication(claim.app.doc);
    if (!checked.ok) throw new Error('The saved application is invalid.');
    const state = object(claim.state);
    if (['AlphaVista', 'RiskRift', 'WealthWeave'].includes(checked.document.meta.name)
      && ((state.demo as { invented?: unknown } | undefined)?.invented === true
        || checked.document.meta.description.startsWith('Demo inputs — invented.'))) {
      failure = { code: 'E_LEGACY_DEMO', message: 'This saved flagship uses retired invented inputs. Open Flagship applications and connect Tushare and your own data in a new copy.' };
      throw new Error(failure.message);
    }
    params = settings(checked.document, state.params === undefined ? {} : object(state.params), overrides);
    const carry = state.carry === undefined ? undefined : object(state.carry);
    const bindings = state.bindings === undefined ? {} : object(state.bindings);
    const mappings = state.mappings === undefined ? {} : object(state.mappings);
    failure = { code: 'E_DATA_NOT_CONFIGURED', message: 'Choose a supported data adapter. Invented examples must be explicitly enabled.' };
    if (!adapter || (adapter.kind !== 'real' && adapter.kind !== 'invented') || (adapter.kind === 'invented' && options.allowInventedData !== true)) throw new Error(failure.message);
    failure = { code: 'E_DATA_RESOLUTION', message: 'The data adapter could not resolve this application.' };
    data = checkedData(checked.document, await resolveData(adapter, {
      app: decodeStoredValue<StoredApp>(encodeStoredValue(claim.app)), params: object(params), bindings, mappings, signal, referenceTime: scheduled?.scheduledFor ?? startedAt,
    }, signal));
    signal.throwIfAborted();
    failure = { code: 'E_RUN_FAILED', message: 'The application could not finish running.' };
    const { runForScreen } = await import('../compute/result.ts');
    signal.throwIfAborted();
    const outcome = await runForScreen(checked.document, {
      slices: data.slices, params, ...(options.model ? { model: options.model } : {}), ...(carry === undefined ? {} : { carriedState: carry }), signal,
    });
    signal.throwIfAborted();
    failure = { code: 'E_RUN_OUTPUT', message: 'The run returned values that cannot be saved.' };
    trace = storedTrace(outcome.trace);
    result = decodeStoredValue<RunResult>(encodeStoredValue(outcome.result));
    result.startedAt = startedAt;
    result.durationMs = Date.now() - Date.parse(startedAt);
    if ((result.status === 'ok' || result.status === 'partial') && outcome.newState !== undefined) {
      newState = object(outcome.newState);
    }
  } catch (error) {
    let issue: DataConnectionIssue | undefined;
    if (error instanceof NeedsBindingError) issue = { code: 'NeedsBindingError', message: error.message, problems: error.problems };
    else if (error instanceof NeedsMappingError) issue = { code: 'NeedsMappingError', message: error.message, problems: error.problems };
    if (issue && failure.code === 'E_DATA_RESOLUTION' && !signal.aborted) {
      const safeIssue = decodeStoredValue<DataConnectionIssue>(encodeStoredValue(issue));
      releaseDataConnectionClaim(claim);
      return { kind: 'needs_data', appId: claim.app.id, runId: id, issue: safeIssue };
    }
    newState = undefined;
    trace = undefined;
    if (signal.aborted) failure = deadline.aborted
      ? { code: 'E_RUN_TIMEOUT', message: 'The execution exceeded its time limit.' }
      : { code: 'E_RUN_CANCELLED', message: 'The execution was cancelled.' };
    result = { status: 'failed', outputs: {}, failure, warnings: [], startedAt, durationMs: Date.now() - Date.parse(startedAt) };
  }
  if (dataSource.kind === 'invented') result.warnings.push('Invented data only. This execution does not establish real data binding or market coverage.');
  const record: RunRecord = {
    id, appId: claim.app.id, appVersion: claim.app.version, startedAt, completedAt: new Date().toISOString(),
    status: result.status, params, result, dataSource,
    ...(trace ? { trace } : {}), ...(result.failure ? { failure: result.failure } : {}),
    ...(scheduled ? { taskId: scheduled.taskId, scheduledFor: scheduled.scheduledFor } : {}),
    ...(data ? { datasetVersions: data.datasetVersions } : {}),
    ...(data?.sources === undefined ? {} : { sources: data.sources }),
    ...(data?.asOfDate === undefined ? {} : { asOfDate: data.asOfDate }),
  };
  // A persistence failure must propagate. Leave the claim visible; never rerun the engine here.
  return { kind: 'completed', record: finishExecution(claim, record, newState), reused: false };
  } finally { clearInterval(heartbeat); }
}
