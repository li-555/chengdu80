import type { TriggerSpec } from '../app-schema/index.ts';
import type { RunRecord } from './types.ts';

export type ScheduledTask = {
  id: string;
  appId: string;
  profile: string;
  appVersion: string;
  triggerIndex: number;
  trigger: Extract<TriggerSpec, { kind: 'schedule' | 'market' }>;
  enabled: boolean;
  /** Explicit opt-in; old tasks configured for one invocation remain unchanged. */
  automatic?: boolean;
  schedulingIssue?: { code: 'needs_data' | 'invalid_schedule' | 'execution_unconfirmed' | 'calendar_unavailable' | 'interrupted' | 'version_changed'; message: string; dataIssue?: DataConnectionIssue };
  revision?: string;
  lastStatus?: RunRecord['status'];
  schedulingNote?: string;
  nextRunAt: string | null;
  lastScheduledFor: string | null;
  lastRunId: string | null;
  createdAt: string;
  updatedAt: string;
};

export type ExecutionAttempt = {
  id: string;
  appId: string;
  profile: string;
  appVersion: string;
  taskId?: string;
  requestKey: string;
  scheduledFor?: string;
  status: 'running' | 'finished';
  startedAt: string;
  completedAt?: string;
  leaseToken?: string;
  leaseUntil?: string;
  ownerPid?: number;
  ownerHost?: string;
};

/** A pre-run requirement for the person to act; never a failed RunRecord. */
export type DataConnectionIssue =
  | { code: 'NeedsBindingError'; message: string; problems: { key: string; datasetId?: string }[] }
  | { code: 'NeedsMappingError'; message: string; problems: { key: string; field: string; suggestions: string[] }[] };

export type ExecutionReply =
  | { kind: 'needs_data'; appId: string; runId: string; issue: DataConnectionIssue }
  | { kind: 'completed'; record: RunRecord; reused: boolean }
  | { kind: 'in_progress' | 'busy'; runId: string };

/** Canonical UTC instants make occurrence comparisons independent of host time zone. */
export function executionTime(value: string): string {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}\.\d{3}Z$/.test(value)
    || !Number.isFinite(Date.parse(value)) || new Date(value).toISOString() !== value) {
    throw new Error('Execution times must be valid UTC timestamps in YYYY-MM-DDTHH:mm:ss.sssZ format.');
  }
  return value;
}
