/**
 * The one place that knows how to reach the configured language model.
 *
 * Both callers — the builder that writes applications from a conversation, and the AI step
 * inside a running application — get their model here, so the endpoint, the model name
 * and the key are configured once. Tests pass their own model instead and never reach
 * the network.
 *
 * Forced tool choice is broken on the current endpoint (measured 2026-10-13: six of six
 * attempts aborted with no tool call), so callers must use `toolChoice: 'auto'` and name
 * the tool in their instructions.
 */

import { createOpenAICompatible } from '@ai-sdk/openai-compatible';
import type { LanguageModel } from 'ai';
import { loadServiceCredentials } from './config.ts';

export const DEFAULT_MODEL_BASE_URL = 'https://ai.gitee.com/v1';
export const DEFAULT_MODEL_NAME = 'GLM-5.3';

export class ModelNotConfiguredError extends Error {
  constructor() {
    super('No AI model key is configured. Set GITEE_AI_API_KEY and restart.');
    this.name = 'ModelNotConfiguredError';
  }
}

/** The model name in use, for the run record and the Inspect panel. Never the key. */
export function configuredModelName(): string {
  return process.env.CD80_LLM_MODEL?.trim() || DEFAULT_MODEL_NAME;
}

/** The configured model. Throws `ModelNotConfiguredError` when no key is set. */
export function configuredModel(): LanguageModel {
  const apiKey = loadServiceCredentials().giteeApiKey;
  if (!apiKey) throw new ModelNotConfiguredError();

  const provider = createOpenAICompatible({
    name: 'configured',
    baseURL: process.env.CD80_LLM_BASE_URL?.trim() || DEFAULT_MODEL_BASE_URL,
    apiKey,
  });
  return provider.chatModel(configuredModelName());
}
