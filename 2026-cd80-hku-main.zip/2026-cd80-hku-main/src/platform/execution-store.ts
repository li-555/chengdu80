import { applyMonitorRun } from './monitor.ts';
import type { DatabaseSync } from 'node:sqlite';
import { storageOperation, storageTransaction } from './database.ts';
import { decodeStoredValue, encodeStoredValue } from './json.ts';
import { ownedApp, ownedTask, writeTask } from './schedules.ts';
import type { ExecutionAttempt, ExecutionReply } from './schedule-types.ts';
import type { RunRecord, StoredApp } from './types.ts';
import { nextCronTime } from './cron.ts';
import { randomUUID } from 'node:crypto';
import { hostname } from 'node:os';

const LEASE_MS = 90_000;
const processToken = randomUUID();

export type ClaimedExecution = { attempt: ExecutionAttempt; app: StoredApp; state: Record<string, unknown> };
export type ExecutionRequest = {
  id: string; appId: string; profile: string; requestKey: string;
  scheduled?: { taskId: string; scheduledFor: string };
};

function stateFor(database: DatabaseSync, appId: string, profile: string): Record<string, unknown> {
  const row = database.prepare('SELECT record FROM states WHERE app_id = ? AND profile = ?')
    .get(encodeStoredValue(appId), encodeStoredValue(profile));
  return row ? decodeStoredValue<Record<string, unknown>>(row.record) : {};
}

function previousReply(database: DatabaseSync, attempt: ExecutionAttempt): ExecutionReply {
  if (attempt.status === 'running') return { kind: 'in_progress', runId: attempt.id };
  const row = database.prepare('SELECT record FROM runs WHERE id = ?').get(encodeStoredValue(attempt.id));
  if (!row) throw new Error('The storage database contains an invalid record.');
  return { kind: 'completed', record: decodeStoredValue<RunRecord>(row.record), reused: true };
}

/** Claim before doing async work. Unique indexes also protect callers in other processes. */
export function claimExecution(request: ExecutionRequest): ClaimedExecution | ExecutionReply {
  return storageOperation((database) => storageTransaction(database, () => {
    const app = ownedApp(database, request.appId, request.profile);
    const byId = database.prepare('SELECT record FROM executions WHERE id = ?').get(encodeStoredValue(request.id));
    if (byId) {
      const old = decodeStoredValue<ExecutionAttempt>(byId.record);
      if (old.appId !== app.id || old.profile !== request.profile || old.requestKey !== request.requestKey
        || old.taskId !== request.scheduled?.taskId || old.scheduledFor !== request.scheduled?.scheduledFor) {
        throw new Error('The execution identifier belongs to a different request.');
      }
      return previousReply(database, old);
    }
    if (database.prepare('SELECT id FROM runs WHERE id = ?').get(encodeStoredValue(request.id))) {
      throw new Error('The execution identifier belongs to a different request.');
    }
    if (request.scheduled) {
      const { taskId, scheduledFor } = request.scheduled;
      const task = ownedTask(database, taskId, request.profile);
      if (task.appId !== app.id || task.appVersion !== app.version) {
        throw new Error('The scheduled task no longer matches the saved application.');
      }
      const previous = database.prepare('SELECT record FROM executions WHERE task_id = ? AND scheduled_for = ?')
        .get(encodeStoredValue(taskId), scheduledFor);
      if (previous) {
        const old = decodeStoredValue<ExecutionAttempt>(previous.record);
        if (old.requestKey !== request.requestKey) throw new Error('The execution identifier belongs to a different request.');
        return previousReply(database, old);
      }
      if (!task.enabled || task.nextRunAt !== scheduledFor || Date.parse(scheduledFor) > Date.now()) {
        throw new Error('The scheduled task is disabled or its next execution time has changed.');
      }
    }
    const busy = database.prepare("SELECT record FROM executions WHERE app_id = ? AND status = 'running'")
      .get(encodeStoredValue(app.id));
    if (busy) return { kind: 'busy' as const, runId: decodeStoredValue<ExecutionAttempt>(busy.record).id };
    const attempt: ExecutionAttempt = {
      id: request.id, appId: app.id, profile: request.profile, appVersion: app.version,
      requestKey: request.requestKey, status: 'running', startedAt: new Date().toISOString(),
      leaseToken: processToken, leaseUntil: new Date(Date.now() + LEASE_MS).toISOString(), ownerPid: process.pid, ownerHost: hostname(),
      ...(request.scheduled ? { taskId: request.scheduled.taskId, scheduledFor: request.scheduled.scheduledFor } : {}),
    };
    const state = stateFor(database, app.id, request.profile);
    database.prepare(`INSERT INTO executions (id, app_id, profile, task_id, scheduled_for, status, record)
      VALUES (?, ?, ?, ?, ?, 'running', ?)`).run(
      encodeStoredValue(attempt.id), encodeStoredValue(app.id), encodeStoredValue(request.profile),
      attempt.taskId === undefined ? null : encodeStoredValue(attempt.taskId), attempt.scheduledFor ?? null,
      encodeStoredValue(attempt),
    );
    return { attempt, app, state };
  }));
}

/** Release only this unfinished pre-run claim; keep state, run history and task timing intact. */
export function releaseDataConnectionClaim(claim: ClaimedExecution): void {
  storageOperation((database) => storageTransaction(database, () => {
    const { attempt } = claim;
    ownedApp(database, attempt.appId, attempt.profile);
    const row = database.prepare('SELECT record FROM executions WHERE id = ?').get(encodeStoredValue(attempt.id));
    const current = row ? decodeStoredValue<ExecutionAttempt>(row.record) : undefined;
    if (!current || current.status !== 'running' || current.appId !== attempt.appId
      || current.profile !== attempt.profile || current.startedAt !== attempt.startedAt
      || current.requestKey !== attempt.requestKey || current.taskId !== attempt.taskId
      || current.scheduledFor !== attempt.scheduledFor
      || database.prepare('SELECT id FROM runs WHERE id = ?').get(encodeStoredValue(attempt.id))) {
      throw new Error('The execution record is no longer running.');
    }
    database.prepare("DELETE FROM executions WHERE id = ? AND status = 'running'").run(encodeStoredValue(attempt.id));
  }));
}

function carryStamp(state: Record<string, unknown>): string {
  return Object.hasOwn(state, 'carry') ? encodeStoredValue(state.carry) : '';
}

/** Result, carry and the occurrence completion marker succeed or roll back together. */
export function finishExecution(claim: ClaimedExecution, record: RunRecord, newState?: Record<string, unknown>): RunRecord {
  // Validate outside the transaction as well: no implicit JSON conversion of return values.
  const saved = decodeStoredValue<RunRecord>(encodeStoredValue(record));
  const carry = newState === undefined ? undefined : decodeStoredValue<Record<string, unknown>>(encodeStoredValue(newState));
  return storageOperation((database) => storageTransaction(database, () => {
    const { attempt } = claim;
    ownedApp(database, attempt.appId, attempt.profile);
    const row = database.prepare('SELECT record FROM executions WHERE id = ?').get(encodeStoredValue(attempt.id));
    const current = row ? decodeStoredValue<ExecutionAttempt>(row.record) : undefined;
    if (!current || current.status !== 'running' || current.requestKey !== attempt.requestKey || current.leaseToken !== attempt.leaseToken
      || saved.id !== attempt.id || saved.appId !== attempt.appId || saved.appVersion !== attempt.appVersion) {
      throw new Error('The execution record is no longer running.');
    }
    if (carry !== undefined && (saved.status === 'ok' || saved.status === 'partial')) {
      const latest = stateFor(database, attempt.appId, attempt.profile);
      if (!latest || typeof latest !== 'object' || Array.isArray(latest)
        || carryStamp(latest) !== carryStamp(claim.state)) {
        const failure = { code: 'E_STATE_CHANGED', message: 'The carried state changed during this run. Its new state was not saved.' };
        saved.status = 'failed';
        saved.failure = failure;
        if (saved.result) saved.result = { ...saved.result, status: 'failed', failure };
      } else {
        // Preserve the latest settings and bindings, even if they changed during the run.
        database.prepare(`INSERT INTO states (app_id, profile, record) VALUES (?, ?, ?)
          ON CONFLICT (app_id, profile) DO UPDATE SET record = excluded.record`)
          .run(encodeStoredValue(attempt.appId), encodeStoredValue(attempt.profile), encodeStoredValue({ ...latest, carry }));
      }
    }
    applyMonitorRun(database, claim.app, saved, claim.state);
    database.prepare('INSERT INTO runs (id, app_id, started_at, record) VALUES (?, ?, ?, ?)')
      .run(encodeStoredValue(saved.id), encodeStoredValue(saved.appId), saved.startedAt, encodeStoredValue(saved));
    const completedAt = saved.completedAt ?? new Date().toISOString();
    const finished: ExecutionAttempt = { ...current, status: 'finished', completedAt };
    database.prepare("UPDATE executions SET status = 'finished', record = ? WHERE id = ?")
      .run(encodeStoredValue(finished), encodeStoredValue(attempt.id));
    if (attempt.taskId !== undefined) {
      const task = ownedTask(database, attempt.taskId, attempt.profile);
      let nextRunAt = task.nextRunAt;
      if (nextRunAt === attempt.scheduledFor) {
        nextRunAt = null;
        if (task.automatic && task.enabled && task.trigger.kind === 'schedule') {
          try { nextRunAt = nextCronTime(task.trigger.cron, task.trigger.tz, completedAt > attempt.scheduledFor! ? completedAt : attempt.scheduledFor!); }
          catch {
            task.enabled = false;
            task.schedulingIssue = { code: 'invalid_schedule', message: 'The next execution time could not be calculated. Review the schedule before enabling it again.' };
          }
        }
      }
      writeTask(database, {
        ...task, lastRunId: attempt.id, lastStatus: saved.status, lastScheduledFor: attempt.scheduledFor!, updatedAt: completedAt,
        // Preserve a pause or newer occurrence configured while this run was active.
        nextRunAt,
      });
    }
    return saved;
  }));
}

/** Renew only this process's still-running claim. A recovered worker cannot write back. */
export function renewExecutionLease(claim: ClaimedExecution): void {
  storageOperation((database) => {
    const row = database.prepare('SELECT record FROM executions WHERE id = ? AND status = ?').get(encodeStoredValue(claim.attempt.id), 'running');
    if (!row) return;
    const attempt = decodeStoredValue<ExecutionAttempt>(row.record);
    if (attempt.leaseToken !== claim.attempt.leaseToken) return;
    const updated = { ...attempt, leaseUntil: new Date(Date.now() + LEASE_MS).toISOString() };
    database.prepare("UPDATE executions SET record = ? WHERE id = ? AND status = 'running'").run(encodeStoredValue(updated), encodeStoredValue(attempt.id));
  });
}

/** Recover abandoned work as an interrupted result, never by replaying its carry update. */
export function recoverInterruptedExecutions(): void {
  storageOperation((database) => storageTransaction(database, () => {
    for (const row of database.prepare("SELECT record FROM executions WHERE status = 'running'").all()) {
      const attempt = decodeStoredValue<ExecutionAttempt>(row.record);
      let abandoned = Date.parse(attempt.leaseUntil ?? new Date(Date.parse(attempt.startedAt) + LEASE_MS).toISOString()) <= Date.now();
      if (attempt.ownerHost === hostname() && attempt.ownerPid !== undefined) {
        if (attempt.ownerPid === process.pid && attempt.leaseToken !== processToken) abandoned = true;
        else {
          try { process.kill(attempt.ownerPid, 0); }
          catch (error) { if ((error as NodeJS.ErrnoException).code === 'ESRCH') abandoned = true; }
        }
      }
      if (!abandoned) continue;
      const completedAt = new Date().toISOString();
      const failure = { code: 'E_RUN_INTERRUPTED', message: 'The execution stopped before its result was saved. Its carried state was not updated. This occurrence will not be replayed automatically.' };
      const record: RunRecord = { id: attempt.id, appId: attempt.appId, appVersion: attempt.appVersion,
        startedAt: attempt.startedAt, completedAt, status: 'failed', params: {}, failure,
        ...(attempt.taskId ? { taskId: attempt.taskId, scheduledFor: attempt.scheduledFor! } : {}) };
      database.prepare('INSERT INTO runs (id, app_id, started_at, record) VALUES (?, ?, ?, ?)').run(
        encodeStoredValue(record.id), encodeStoredValue(record.appId), record.startedAt, encodeStoredValue(record));
      database.prepare("UPDATE executions SET status = 'finished', record = ? WHERE id = ?").run(
        encodeStoredValue({ ...attempt, status: 'finished', completedAt }), encodeStoredValue(attempt.id));
      if (attempt.taskId) {
        const task = ownedTask(database, attempt.taskId, attempt.profile);
        writeTask(database, { ...task, revision: randomUUID(), enabled: false, lastRunId: attempt.id, lastStatus: 'failed',
          lastScheduledFor: attempt.scheduledFor!, schedulingIssue: { code: 'interrupted', message: failure.message }, updatedAt: completedAt });
      }
    }
  }));
}

/** Running records remain visible after a restart; they are never silently retried. */
export async function listExecutionAttempts(profile: string): Promise<ExecutionAttempt[]> {
  return storageOperation((database) => database.prepare('SELECT record FROM executions WHERE profile = ? ORDER BY rowid')
    .all(encodeStoredValue(profile)).map((row) => decodeStoredValue<ExecutionAttempt>(row.record)));
}
