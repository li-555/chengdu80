import { createHash } from 'node:crypto';
import type { DatabaseSync } from 'node:sqlite';
import { z } from 'zod';
import { canonicalJson } from '../app-schema/index.ts';
import { storageOperation, storageTransaction } from './database.ts';
import { decodeStoredValue, encodeStoredValue } from './json.ts';
import { ownedApp } from './schedules.ts';
import type { RunRecord, StoredApp } from './types.ts';

export type MonitorChange = { id: string; title: string; kind: 'new' | 'changed' | 'cleared' | 'unknown'; before: string | null; after: string | null; detail: string };
export type MonitorAlert = { id: string; eventId: string; title: string; detail: string; value: string; status: 'active' | 'cleared' | 'unknown'; firstSeenAt: string; lastSeenAt: string; runId: string; acknowledgedAt?: string; sourceUrl?: string };
export type MonitorSnapshot = { enabled: boolean; notice: string; lastRunId?: string; lastRunAt?: string; previousRunId?: string; counts: { active: number; unacknowledged: number; acknowledged: number; unknown: number }; changes: MonitorChange[]; alerts: MonitorAlert[]; history?: MonitorAlert[] };
type Event = { eventId: string; title: string; status: 'active' | 'clear' | 'unknown'; value: string; detail: string; sourceUrl: string };
type Saved = { context?: string; settings?: string; baseline: Event[]; alerts: MonitorAlert[]; history?: MonitorAlert[]; changes: MonitorChange[]; notice: string; lastRunId?: string; lastRunAt?: string; previousRunId?: string; processed: string[]; acknowledgements?: Record<string, { actor: string; time: string; acknowledged: boolean }> };
const fields = ['event_id', 'title', 'status', 'value', 'detail', 'source_url'];
const hash = (value: unknown) => createHash('sha256').update(canonicalJson(value)).digest('hex');
const enabled = (app: StoredApp) => app.doc.compute.some((step) => step.id === 'monitor_events' && step.key === true);
const empty = (): Saved => ({ baseline: [], alerts: [], changes: [], notice: 'Run this application to establish a monitor baseline.', processed: [] });
function stateOf(db: DatabaseSync, app: StoredApp): Record<string, unknown> { const row = db.prepare('SELECT record FROM states WHERE app_id = ? AND profile = ?').get(encodeStoredValue(app.id), encodeStoredValue(app.profile)); return row ? decodeStoredValue<Record<string, unknown>>(row.record) : {}; }
function savedOf(state: Record<string, unknown>): Saved { return state.monitor ? state.monitor as Saved : empty(); }
function write(db: DatabaseSync, app: StoredApp, state: Record<string, unknown>, monitor: Saved): void { db.prepare('INSERT INTO states (app_id, profile, record) VALUES (?, ?, ?) ON CONFLICT (app_id, profile) DO UPDATE SET record = excluded.record').run(encodeStoredValue(app.id), encodeStoredValue(app.profile), encodeStoredValue({ ...state, monitor })); }
function paramsFor(app: StoredApp, params: Record<string, unknown>): Record<string, unknown> { return Object.fromEntries(Object.entries(params).filter(([key]) => !app.doc.params.some((p) => p.key === key && p.type === 'text' && p.list === true && app.doc.compute.some((step) => step.id === `act_${key}`)))); }
function context(app: StoredApp, state: Record<string, unknown>, params: Record<string, unknown>): string { return hash({ version: app.version, bindings: state.bindings ?? {}, mappings: state.mappings ?? {}, params: paramsFor(app, params) }); }
function settings(app: StoredApp, state: Record<string, unknown>): string { const params = Object.fromEntries(app.doc.params.filter((p) => p.default !== undefined).map((p) => [p.key, p.default])); return context(app, state, { ...params, ...state.params as Record<string, unknown> }); }
function snapshot(app: StoredApp, state: Record<string, unknown>): MonitorSnapshot {
  const data = savedOf(state); const stale = data.settings !== undefined && data.settings !== settings(app, state);
  const alerts = stale ? [] : data.alerts;
  return { enabled: enabled(app), notice: stale ? 'Monitor context changed. Run again to establish a new baseline.' : data.notice,
    ...(data.lastRunId ? { lastRunId: data.lastRunId, lastRunAt: data.lastRunAt } : {}), ...(data.previousRunId ? { previousRunId: data.previousRunId } : {}),
    counts: { active: alerts.filter((a) => a.status === 'active').length, unknown: alerts.filter((a) => a.status === 'unknown').length, unacknowledged: alerts.filter((a) => a.status !== 'cleared' && !a.acknowledgedAt).length, acknowledged: alerts.filter((a) => a.status !== 'cleared' && a.acknowledgedAt).length }, changes: stale ? [] : data.changes, alerts, history: [...(data.history ?? []), ...(stale ? data.alerts : [])].slice(-200) };
}
function events(run: RunRecord): Event[] | null {
  try { return validatedEvents(run); } catch { return null; }
}
function validatedEvents(run: RunRecord): Event[] | null {
  const output = run.result?.outputs.monitor_events;
  if (!output || output.rows.length > 200 || output.schema.length !== fields.length || fields.some((name) => !output.schema.some((column) => column.name === name && column.type === 'text'))) return null;
  const indices = fields.map((name) => output.schema.findIndex((column) => column.name === name)); const seen = new Set<string>(); const result: Event[] = [];
  for (const row of output.rows) { if (!Array.isArray(row) || row.length !== fields.length || row.some((v) => typeof v !== 'string' || v.length > 4000)) return null;
    const [eventId, title, status, value, detail, sourceUrl] = indices.map((i) => row[i] as string);
    if (!eventId?.trim() || !title?.trim() || !['active', 'clear', 'unknown'].includes(status!) || seen.has(eventId)) return null;
    seen.add(eventId); result.push({ eventId, title, status: status as Event['status'], value: value!, detail: detail!, sourceUrl: sourceUrl! });
  } return result;
}
/** Called within the run completion transaction; storage errors intentionally propagate. */
export function applyMonitorRun(db: DatabaseSync, app: StoredApp, run: RunRecord, capturedState: Record<string, unknown>): void {
  const installed = ownedApp(db, app.id, app.profile); const state = stateOf(db, installed); const old = savedOf(state);
  if (old.processed.includes(run.id)) return;
  const next: Saved = { ...old, processed: [...old.processed, run.id].slice(-200) };
  if (!enabled(installed)) return;
  if (installed.version !== run.appVersion) { next.notice = 'Application changed during this run. Monitor results were skipped.'; write(db, installed, state, next); return; }
  const rows = run.status === 'ok' && run.result?.status === 'ok' ? events(run) : null;
  if (!rows) { next.notice = 'Monitor result unavailable or invalid. The last good baseline and alerts were preserved.'; write(db, installed, state, next); return; }
  const key = hash({ settings: context(app, capturedState, run.params), dataSource: run.dataSource ?? null }); const reset = old.context !== key; const time = run.completedAt ?? run.startedAt;
  if (reset) delete next.previousRunId;
  const before = new Map((reset ? [] : old.baseline).map((e) => [e.eventId, e]));
  const current = new Map(rows.map((e) => [e.eventId, e]));
  for (const event of before.values()) if (!current.has(event.eventId)) current.set(event.eventId, { ...event, status: 'unknown' });
  if (current.size > 200) { next.notice = 'Monitor comparison exceeds the 200-condition limit. The last good baseline and alerts were preserved.'; write(db, installed, state, next); return; }
  const history = [...(old.history ?? []), ...(reset ? old.alerts : [])];
  const alerts: MonitorAlert[] = []; const changes: MonitorChange[] = [];
  for (const event of current.values()) {
    const previous = before.get(event.eventId); const priorAlert = reset ? undefined : old.alerts.find((a) => a.eventId === event.eventId);
    const changed = !previous || hash(previous) !== hash(event); const status = event.status === 'clear' ? 'cleared' : event.status;
    if (changed && priorAlert) history.push(priorAlert);
    const id = !changed && priorAlert ? priorAlert.id : hash({ context: key, runId: run.id, event });
    if (event.status !== 'clear' || priorAlert) alerts.push({ id, eventId: event.eventId, title: event.title, value: event.value, detail: event.detail, status, firstSeenAt: priorAlert?.firstSeenAt ?? time, lastSeenAt: time, runId: run.id, ...(!changed && priorAlert?.acknowledgedAt ? { acknowledgedAt: priorAlert.acknowledgedAt } : {}), ...(event.sourceUrl ? { sourceUrl: event.sourceUrl } : {}) });
    if (!reset && changed && (previous || event.status !== 'clear')) changes.push({ id, title: event.title, kind: event.status === 'unknown' ? 'unknown' : event.status === 'clear' ? previous?.status === 'clear' ? 'changed' : 'cleared' : !previous || previous.status === 'clear' ? 'new' : 'changed', before: previous?.value ?? null, after: event.status === 'unknown' ? null : event.value, detail: event.detail });
  }
  write(db, installed, state, { ...next, context: key, settings: settings(installed, capturedState), baseline: [...current.values()], alerts, history: history.slice(-200), changes: changes.slice(-200), ...( !reset && old.lastRunId ? { previousRunId: old.lastRunId } : {}), lastRunId: run.id, lastRunAt: time, notice: reset ? old.context ? 'Monitor context changed. A new baseline was established; current conditions are queued.' : 'Baseline established. Current active conditions are queued; no changes have been reported yet.' : 'Compared with the previous successful monitor run.' });
}
export async function getMonitorSnapshot(appId: string, profile: string): Promise<MonitorSnapshot> { return storageOperation((db) => { const app = ownedApp(db, appId, profile); return snapshot(app, stateOf(db, app)); }); }
export const monitorAcknowledgement = z.strictObject({ alertId: z.string().regex(/^[a-f0-9]{64}$/), acknowledged: z.boolean() });
export async function setMonitorAcknowledged(appId: string, profile: string, input: unknown): Promise<{ kind: 'saved'; snapshot: MonitorSnapshot } | { kind: 'conflict' | 'invalid' }> {
  const parsed = monitorAcknowledgement.safeParse(input); if (!parsed.success) return { kind: 'invalid' };
  return storageOperation((db) => storageTransaction(db, () => { const app = ownedApp(db, appId, profile); const state = stateOf(db, app); const data = savedOf(state); const alert = snapshot(app, state).alerts.find((a) => a.id === parsed.data.alertId && a.status !== 'cleared');
    if (!alert) return { kind: 'conflict' as const };
    if (!!alert.acknowledgedAt !== parsed.data.acknowledged) { if (parsed.data.acknowledged) alert.acknowledgedAt = new Date().toISOString(); else delete alert.acknowledgedAt;
      data.acknowledgements = Object.fromEntries([...Object.entries(data.acknowledgements ?? {}).filter(([id]) => id !== alert.id), [alert.id, { actor: profile, time: new Date().toISOString(), acknowledged: parsed.data.acknowledged }]].slice(-200)); write(db, app, state, data); }
    return { kind: 'saved' as const, snapshot: snapshot(app, state) };
  }));
}
