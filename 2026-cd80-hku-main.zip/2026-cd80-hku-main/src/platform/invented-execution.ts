import { appVersion, type AppDocument } from '../app-schema/index.ts';
import { validateApplication } from '../validate/index.ts';
import type { InventedDataAdapter } from './execution-data.ts';

/** An application definition only. The separate adapter supplies the fictional rows. */
export function inventedScheduledDocument(): AppDocument {
  const document = {
    meta: {
      name: 'Invented scheduled totals', description: 'A fictional total for demonstrating saved executions. No market data is used.',
      spec_version: '1.0', provenance: { created_by: 'platform' },
    },
    params: [{ key: 'scale', label: 'Illustrative scale', type: 'number', default: 1, min: 0, max: 10 }],
    data: [{ key: 'invented_values', fields: [
      { name: 'company', type: 'text', required: true }, { name: 'amount', type: 'number', required: true },
    ] }],
    compute: [
      { id: 'scaled', kind: 'operation', op: 'derive', input: 'invented_values', params: { columns: { value: 'amount * $params.scale' } } },
      { id: 'total', kind: 'operation', op: 'aggregate', input: 'scaled', params: { by: [], metrics: [{ fn: 'sum', of: 'value', as: 'value' }] } },
    ],
    triggers: [{ kind: 'manual' }, { kind: 'schedule', cron: '0 8 * * 1-5', tz: 'Asia/Shanghai' }],
    ui: { root: 'page', elements: {
      page: { type: 'Section', columns: 1, children: ['notice', 'total'] },
      notice: { type: 'Callout', tone: 'warning', text: 'All values are invented. This example does not resolve real data bindings.' },
      total: { type: 'Metric', label: 'Invented total', from: 'total', value: 'value', format: 'number' },
    } },
  };
  const checked = validateApplication(document);
  if (!checked.ok) throw new Error('The invented scheduled application is invalid.');
  return checked.document;
}

/** No network, filesystem, generated market values, or fallback for other applications. */
export function inventedExecutionAdapter(): InventedDataAdapter {
  const expectedVersion = appVersion(inventedScheduledDocument());
  return {
    kind: 'invented', id: 'invented:scheduler-v1', label: 'Invented scheduler example — no market data',
    async resolve({ app, signal }) {
      signal?.throwIfAborted();
      if (app.version !== expectedVersion) throw new Error('This invented adapter only accepts its matching example application.');
      return {
        slices: { invented_values: {
          columns: [{ name: 'company', type: 'string' }, { name: 'amount', type: 'number' }],
          rows: [{ company: 'Fictional Amber', amount: 12 }, { company: 'Fictional Birch', amount: 8 }],
        } },
        datasetVersions: { invented_values: 'invented-v1' },
      };
    },
  };
}
