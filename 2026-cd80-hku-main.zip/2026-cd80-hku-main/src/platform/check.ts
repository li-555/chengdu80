import { loadServerConfig, loadServiceCredentials } from './config.ts';
import { checkRuntimeDependencies } from './dependencies.ts';
import { checkGlmAccess, checkTushareAccess } from './service-checks.ts';
import type { CheckResult } from './service-checks.ts';
import { isSupportedNodeVersion } from '../../scripts/runtime.mjs';

function checkServerConfig(): CheckResult {
  const name = 'Server configuration';
  try {
    const config = loadServerConfig();
    return { name, ok: true, detail: `Host ${config.host}; port ${config.port === 0 ? 'automatic' : config.port}.` };
  } catch (error) {
    return {
      name,
      ok: false,
      detail: error instanceof Error ? error.message : 'Unable to read server configuration.',
    };
  }
}

function report(result: CheckResult): void {
  console.log(`[${result.ok ? 'PASS' : 'FAIL'}] ${result.name}: ${result.detail}`);
}

async function main(): Promise<void> {
  console.log('Blocks configuration check');
  const results: CheckResult[] = [
    { name: 'Runtime', ok: isSupportedNodeVersion(process.version), detail: `Node.js ${process.version}.` },
    checkRuntimeDependencies(),
    checkServerConfig(),
  ];
  results.forEach(report);

  const credentials = loadServiceCredentials();
  console.log('[INFO] Online checks: one request per configured service, 30-second timeout, no retries.');
  const onlineResults = await Promise.all([
    checkTushareAccess(credentials.tushareToken),
    checkGlmAccess(credentials.giteeApiKey),
  ]);
  onlineResults.forEach(report);
  results.push(...onlineResults);

  console.log('[INFO] Application integration is pending and is not validated by this check.');
  const passed = results.filter((result) => result.ok).length;
  console.log(`Result: ${passed}/${results.length} required checks passed.`);
  process.exitCode = passed === results.length ? 0 : 1;
}

main().catch(() => {
  console.error('[FAIL] Configuration check: unable to finish the check.');
  process.exitCode = 1;
});
