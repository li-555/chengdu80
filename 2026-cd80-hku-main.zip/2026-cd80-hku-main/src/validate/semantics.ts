import type { AppDocument } from '../app-schema/index.ts';
import { CRON_MAX_LENGTH } from '../app-schema/triggers.ts';
import { IssueCollector, listItems, issue, type ValidationIssue } from './errors.ts';
import { expressionsOf, inputsOf } from './references.ts';
import { validateExpressionAt } from '../compute/expr.ts';

/**
 * A five-field cron expression, checked field by field so the message says which field
 * is wrong. `*`, `*\/5`, `1-5`, `0,30` and plain numbers are accepted.
 */
const CRON_FIELDS = [
  { name: 'minute', min: 0, max: 59 },
  { name: 'hour', min: 0, max: 23 },
  { name: 'day of the month', min: 1, max: 31 },
  { name: 'month', min: 1, max: 12 },
  { name: 'day of the week', min: 0, max: 7 },
] as const;

export function cronProblem(cron: string): string | undefined {
  if (cron.length > CRON_MAX_LENGTH) return `a schedule has ${cron.length} characters, at most ${CRON_MAX_LENGTH} are allowed`;
  const parts = cron.trim().split(/\s+/);
  if (parts.length !== 5) return `a schedule needs exactly five fields, this has ${parts.length}`;
  for (const [i, field] of CRON_FIELDS.entries()) {
    const raw = parts[i]!;
    for (const piece of raw.split(',')) {
      const slashed = piece.split('/');
      if (slashed.length > 2) return `the ${field.name} field has more than one step value`;
      const [range, stepText] = slashed;
      if (stepText !== undefined) {
        if (!/^\d+$/.test(stepText) || Number(stepText) < 1) return `the step in the ${field.name} field must be a whole number of 1 or more`;
      }
      if (range === '*' || range === undefined) continue;
      const bounds = range.split('-');
      if (bounds.length > 2) return `the ${field.name} field has a malformed range`;
      for (const b of bounds) {
        if (!/^\d+$/.test(b)) return `the ${field.name} field must be a number, a range, a list or *`;
        const n = Number(b);
        if (n < field.min || n > field.max) return `the ${field.name} field must be between ${field.min} and ${field.max}, got ${n}`;
      }
      if (bounds.length === 2 && Number(bounds[0]) > Number(bounds[1])) {
        return `the ${field.name} range runs backwards`;
      }
    }
  }
  return undefined;
}

/**
 * Phase 4 — semantics. Everything resolves; does it also make sense?
 *
 * Cycles are found here rather than in the references phase because a forward reference
 * on its own is legal: steps are sorted by dependency before they run.
 */
export function semanticsPhase(doc: AppDocument): ValidationIssue[] {
  const out = new IssueCollector();

  // --- cron ---
  doc.triggers.forEach((t, i) => {
    if (t.kind === 'schedule' || t.kind === 'alert') {
      const problem = cronProblem(t.cron);
      if (problem) {
        out.add('error', () => issue('E_BAD_CRON', ['triggers', i, 'cron'], `This schedule cannot be read: ${problem}.`, {
          received: t.cron,
          hint: 'Use five fields: minute hour day month weekday. For every weekday at 08:00, write `0 8 * * 1-5`.',
        }));
      }
    }
  });
  if (!doc.triggers.some((t) => t.kind === 'manual')) {
    out.add('warning', () => issue('W_NO_MANUAL_TRIGGER', ['triggers'], 'This application cannot be run by hand.', {
      hint: 'Add { "kind": "manual" } so a person can press Run.',
    }));
  }

  // --- cycles among the calculation steps ---
  const stepIndex = new Map(doc.compute.map((s, i) => [s.id, i]));
  const edges = new Map<string, string[]>();
  doc.compute.forEach((s, i) => {
    edges.set(
      s.id,
      inputsOf(s, i).map((r) => r.name).filter((n) => stepIndex.has(n) && n !== s.id),
    );
  });

  /**
   * Depth-first search with three colours. The earlier version returned as soon as it
   * found a loop, which left nodes marked `open` for ever, so the next starting node
   * rediscovered the same loop by a different route and reported it again.
   * A node is now always finalised on the way out, and each loop is reported once.
   */
  const WHITE = 0, GREY = 1, BLACK = 2;
  const colour = new Map<string, number>();
  const stack: string[] = [];
  const reported = new Set<string>();

  const visit = (id: string): void => {
    colour.set(id, GREY);
    stack.push(id);
    for (const next of edges.get(id) ?? []) {
      const c = colour.get(next) ?? WHITE;
      if (c === GREY) {
        const cycle = [...stack.slice(stack.indexOf(next)), next];
        const signature = [...new Set(cycle)].sort().join('|');
        if (!reported.has(signature)) {
          reported.add(signature);
          const first = cycle[0]!;
          out.add('error', () => issue('E_CYCLE', ['compute', stepIndex.get(first)!, 'id'], `These steps depend on each other, so no order can run them: ${listItems(cycle, ' -> ')}.`, {
            hint: 'Break the loop: one of these steps must read something earlier instead.',
          }));
        }
      } else if (c === WHITE) {
        visit(next);
      }
    }
    stack.pop();
    colour.set(id, BLACK);
  };

  for (const s of doc.compute) {
    if ((colour.get(s.id) ?? WHITE) === WHITE) visit(s.id);
  }

  // --- formulas ---
  // Column names are not known yet: a requirement is bound to a dataset after this, and
  // only then does the relation have columns. So this checks the things that are knowable
  // now -- that it parses, that every operator and function is allowed, and that any
  // setting it names is declared -- and the columns are checked when the run starts.
  const declaredParams = doc.params.map((p) => p.key);
  doc.compute.forEach((step, i) => {
    for (const { expr, path } of expressionsOf(step, i)) {
      out.append(validateExpressionAt(expr, path, { params: declaredParams }));
    }
  });
  doc.triggers.forEach((t, i) => {
    if (t.kind === 'alert') {
      out.append(validateExpressionAt(t.condition, ['triggers', i, 'condition'], { params: declaredParams }));
    }
  });

  // --- the escape hatch should be the last resort, not the first ---
  doc.compute.forEach((s, i) => {
    if (s.kind === 'code') {
      const body = (s as unknown as { body: string }).body;
      if (body.length <= 40000 && /^return\s*\{\s*rows:\s*input\.[a-z_][a-z0-9_]*\s*\}(?:\s*;)?$/.test(body.trim())) {
        out.add('warning', () => issue('W_CODE_COULD_BE_OPERATION', ['compute', i, 'body'], 'This custom-code step just passes its input through.', {
          hint: 'Remove the step, or replace it with a named operation. Custom code is the last resort, not the first.',
        }));
      }
    }
    if (s.kind === 'sql') {
      const sql = (s as unknown as { sql: string }).sql;
      if (sql.length <= 20000 && /^select\s+\*\s+from\s+[a-z_][a-z0-9_]*(?:\s*;)?$/i.test(sql.trim())) {
        out.add('warning', () => issue('W_SQL_COULD_BE_OPERATION', ['compute', i, 'sql'], 'This SQL step selects everything from one table and changes nothing.', {
          hint: 'Remove the step and read that table directly.',
        }));
      }
    }
  });

  return out.finish();
}
