import type { AppDocument } from '../app-schema/index.ts';
import { IssueCollector, issue, type ValidationIssue } from './errors.ts';

/**
 * Phase 5 — limits. Everything is correct; is it within what one run may do?
 *
 * These are the document-shape limits only. The per-run limits (time, memory, rows)
 * are enforced while the run executes, not here.
 */
export const DOCUMENT_LIMITS = {
  steps: 60,
  codeSteps: 1,
  aiSteps: 4,
  elements: 60,
  sectionNesting: 4,
} as const;

export function limitsPhase(doc: AppDocument): ValidationIssue[] {
  const out = new IssueCollector();

  if (doc.compute.length > DOCUMENT_LIMITS.steps) {
    out.add('error', () => issue('E_LIMIT_STEPS', ['compute'], `An application may have at most ${DOCUMENT_LIMITS.steps} calculation steps, this has ${doc.compute.length}.`, {
      hint: 'Combine steps, or split this into two applications.',
    }));
  }

  const codeSteps = doc.compute.map((s, i) => [s, i] as const).filter(([s]) => s.kind === 'code');
  if (codeSteps.length > DOCUMENT_LIMITS.codeSteps) {
    for (const [, i] of codeSteps.slice(DOCUMENT_LIMITS.codeSteps)) {
      out.add('error', () => issue('E_LIMIT_CODE_STEPS', ['compute', i], `An application may have at most ${DOCUMENT_LIMITS.codeSteps} custom-code step, this has ${codeSteps.length}.`, {
        hint: 'Move this work into named operations, or merge it into the other custom-code step.',
      }));
    }
  }

  const aiSteps = doc.compute.map((s, i) => [s, i] as const).filter(([s]) => s.kind === 'ai');
  if (aiSteps.length > DOCUMENT_LIMITS.aiSteps) {
    for (const [, i] of aiSteps.slice(DOCUMENT_LIMITS.aiSteps)) {
      out.add('error', () => issue('E_LIMIT_AI_STEPS', ['compute', i], `An application may use the AI at most ${DOCUMENT_LIMITS.aiSteps} times in one run, this uses it ${aiSteps.length} times.`, {
        hint: 'Summarise once over more rows instead of several times over fewer.',
      }));
    }
  }

  const elements = doc.ui.elements as Record<string, { type: string; children?: string[] }>;
  const count = Object.keys(elements).length;
  if (count > DOCUMENT_LIMITS.elements) {
    out.add('error', () => issue('E_LIMIT_ELEMENTS', ['ui', 'elements'], `A screen may have at most ${DOCUMENT_LIMITS.elements} elements, this has ${count}.`, {
      hint: 'Show less on one screen.',
    }));
  }

  /**
   * How many Sections are nested inside each other, counted from the root.
   * Only a Section adds a level: a Text inside a Section is not another level.
   * Memoised, because without it a layout where each Section lists the same child twice
   * takes exponential time -- 31 such Sections is already minutes of work.
   */
  const memo = new Map<string, number>();
  const depthOf = (id: string, onPath: Set<string>): number => {
    const cached = memo.get(id);
    if (cached !== undefined) return cached;
    const el = elements[id];
    if (!el || el.type !== 'Section' || onPath.has(id)) return 0;
    onPath.add(id);
    let deepest = 0;
    for (const child of el.children ?? []) {
      const d = depthOf(child, onPath);
      if (d > deepest) deepest = d;
    }
    onPath.delete(id);
    const result = 1 + deepest;
    memo.set(id, result);
    return result;
  };
  const depth = elements[doc.ui.root] ? depthOf(doc.ui.root, new Set()) : 0;
  if (depth > DOCUMENT_LIMITS.sectionNesting) {
    out.add('error', () => issue('E_LIMIT_NESTING', ['ui', 'root'], `Sections are nested ${depth} deep, and at most ${DOCUMENT_LIMITS.sectionNesting} is allowed.`, {
      hint: 'Flatten the layout. A screen this deep is hard to read anyway.',
    }));
  }

  return out.finish();
}
