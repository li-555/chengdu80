import { z } from 'zod';
import {
  CURRENT_SPEC_VERSION, ELEMENT_SCHEMA, ICONS, Meta, OPERATION_STEP,
  ParamDecl, DataRequirement, STEP_SCHEMA, TriggerSpec,
} from '../app-schema/index.ts';
import { IssueCollector, listItems, ERROR_CODES, describeReceived, issue, type ErrorCode, type ValidationIssue } from './errors.ts';

type Path = (string | number)[];
const CODE = (c: ErrorCode) => ERROR_CODES[c];

/* ------------------------------------------------------------------ *
 * Mapping one Zod issue to one of our published error codes.
 * ------------------------------------------------------------------ */

/** Resolve the value a Zod issue points at, so "missing" and "wrong type" are told apart. */
function valueAt(root: unknown, path: ReadonlyArray<string | number>): unknown {
  let node: unknown = root;
  for (const key of path) {
    if (node === null || typeof node !== 'object') return undefined;
    node = (node as Record<string | number, unknown>)[key as string];
  }
  return node;
}

function codeFor(i: z.core.$ZodIssue, present: boolean): ErrorCode {
  switch (i.code) {
    case 'invalid_type':
      // Zod does not put the offending value on the issue, so asking whether the field
      // exists is the only way to tell "you forgot this" from "this is the wrong type".
      return present ? 'E_SCHEMA_TYPE' : 'E_SCHEMA_REQUIRED';
    case 'unrecognized_keys':
      return 'E_SCHEMA_UNKNOWN_KEY';
    case 'invalid_value':
      return 'E_SCHEMA_ENUM';
    case 'too_small':
    case 'too_big':
    case 'not_multiple_of':
      return 'E_SCHEMA_RANGE';
    case 'invalid_format':
      return 'E_SCHEMA_PATTERN';
    case 'invalid_union':
      return 'E_SCHEMA_UNION';
    default:
      return 'E_SCHEMA_CUSTOM';
  }
}

function hintFor(code: ErrorCode, i: z.core.$ZodIssue): string | undefined {
  switch (code) {
    case 'E_SCHEMA_REQUIRED':
      return 'Add this field.';
    case 'E_SCHEMA_UNKNOWN_KEY': {
      const keys = (i as { keys?: string[] }).keys ?? [];
      return `Remove ${listItems(keys, ', ', true)}. It is not part of the specification, so it is probably a typo.`;
    }
    case 'E_SCHEMA_ENUM':
      return 'Use one of the listed choices exactly as written.';
    case 'E_SCHEMA_TYPE':
      return `Change this value to a ${(i as { expected?: string }).expected ?? 'valid value'}.`;
    case 'E_SCHEMA_RANGE':
      return 'Bring this value inside the allowed range.';
    default:
      return undefined;
  }
}

/**
 * Turn Zod's issues into ours.
 *
 * `unrecognized_keys` reports at the PARENT path with the offending keys in a separate
 * field, so a naive mapping points at the object instead of the typo. Each key gets its
 * own issue at its own pointer here.
 */
export function fromZod(error: z.ZodError, base: Path = [], subject?: unknown): ValidationIssue[] {
  const out = new IssueCollector();
  collectZod(error, base, subject, out);
  return out.finish();
}

function collectZod(error: z.ZodError, base: Path, subject: unknown, out: IssueCollector): void {
  for (const i of error.issues) {
    if (i.code === 'unrecognized_keys') {
      const keep = Math.min(i.keys.length, out.remaining('error'));
      const at = [...base, ...i.path] as Path;
      const hint = keep > 0 ? hintFor('E_SCHEMA_UNKNOWN_KEY', i) : undefined;
      for (let n = 0; n < keep; n++) {
        const key = i.keys[n]!;
        out.add('error', () => issue('E_SCHEMA_UNKNOWN_KEY', [...at, key], `"${describeReceived(key)}" is not part of the specification.`, {
          received: describeReceived(key),
          hint,
        }));
      }
      if (i.keys.length > keep) out.count('error', i.keys.length - keep);
      continue;
    }
    out.add('error', () => {
      const path = i.path as Path;
      const actual = subject === undefined ? i.input : valueAt(subject, path);
      const present = actual !== undefined;
      const code = codeFor(i, present);
      return issue(code, [...base, ...path], i.message, {
        expected: (i as { expected?: string }).expected,
        received: typeof actual === 'string' && i.code === 'too_big'
          ? `a string of ${actual.length} characters`
          : present ? (Array.isArray(actual) ? 'a list' : actual === null ? 'null' : typeof actual) : 'nothing',
        hint: hintFor(code, i),
      });
    });
  }
}

/** Validate one value against one schema and report at `base`. */
function check(schema: z.ZodType, value: unknown, base: Path, out: IssueCollector): void {
  const r = schema.safeParse(value);
  if (!r.success) collectZod(r.error, base, value, out);
}

/* ------------------------------------------------------------------ *
 * Phase 1 — parse
 * ------------------------------------------------------------------ */

/**
 * Pull the JSON object out of text that may be wrapped in a code fence or surrounded by
 * prose, which is what happens when someone copies an answer out of a chat window.
 * C10's import path requires tolerating this and recording it as a warning.
 */
function unwrap(text: string): { json: string; wrapped: boolean } {
  // The whole text first. A valid document whose description happens to contain a code
  // fence must never be replaced by whatever is inside that fence.
  try {
    JSON.parse(text);
    return { json: text, wrapped: false };
  } catch {
    // not JSON on its own, so look for a document inside it
  }
  const fenceStart = text.indexOf('```');
  if (fenceStart !== -1) {
    let start = fenceStart + 3;
    const language = text.slice(start, start + 4);
    if (language === 'json' || language === 'JSON') start += 4;
    const end = text.indexOf('```', start);
    if (end !== -1) {
      const inner = text.slice(start, end).trim();
      try { JSON.parse(inner); return { json: inner, wrapped: true }; } catch { /* keep looking */ }
    }
  }
  const first = text.indexOf('{');
  const last = text.lastIndexOf('}');
  if (first !== -1 && last > first) {
    const inner = text.slice(first, last + 1);
    try { JSON.parse(inner); return { json: inner, wrapped: true }; } catch { /* fall through */ }
  }
  return { json: text, wrapped: false };
}

export function parsePhase(input: unknown): { issues: ValidationIssue[]; value?: Record<string, unknown> } {
  if (typeof input === 'string') {
    const text = input.trim();
    if (text === '') {
      return {
        issues: [issue('E_PARSE_EMPTY', [], CODE('E_PARSE_EMPTY'), {
          hint: 'Paste or save the application first. It should start with { and contain meta, params, data, compute, triggers and ui.',
        })],
      };
    }
    const { json, wrapped } = unwrap(text);
    let parsed: unknown;
    try {
      parsed = JSON.parse(json);
    } catch (e) {
      return {
        issues: [
          issue('E_PARSE_JSON', [], `The file is not valid JSON: ${(e as Error).message}`, {
            hint: 'Check for a missing comma, a trailing comma, or a missing closing brace.',
          }),
        ],
      };
    }
    const inner = parsePhase(parsed);
    if (wrapped && inner.value) {
      inner.issues.push(
        issue('W_SURROUNDING_TEXT', [], 'This was wrapped in a code fence or surrounded by text. It was read anyway.', {
          hint: 'No action needed. Saving the file on its own avoids the warning.',
        }),
      );
    }
    return inner;
  }
  if (input === null || typeof input !== 'object' || Array.isArray(input)) {
    return {
      issues: [
        issue('E_PARSE_NOT_OBJECT', [], CODE('E_PARSE_NOT_OBJECT'), {
          received: input === null ? 'null' : Array.isArray(input) ? 'a list' : typeof input,
          hint: 'Wrap everything in one object with the six sections: meta, params, data, compute, triggers, ui.',
        }),
      ],
    };
  }
  return { issues: [], value: input as Record<string, unknown> };
}

/* ------------------------------------------------------------------ *
 * Phase 2 — schema
 *
 * Each part of the document is checked against exactly one schema, chosen by its own
 * discriminator. Checking against a union instead would report every branch's failures
 * at once: a step with a valid `kind` and one bad parameter would also be told it should
 * have been SQL. The repair cycle consumes these objects, so the noise matters.
 * ------------------------------------------------------------------ */

const ROOT_KEYS = ['meta', 'params', 'data', 'compute', 'triggers', 'ui'] as const;

/**
 * The one envelope field an exported application carries. It is part of the export
 * format, so it must not be reported: otherwise every file we produce fails our own
 * check, which would break both export and the import demonstration.
 */
export const ENVELOPE_KEYS = ['$schema'] as const;

export function schemaPhase(doc: Record<string, unknown>): ValidationIssue[] {
  const out = new IssueCollector();

  // --- the specification version first, so a wrong one returns one error, not forty ---
  const meta = doc.meta;
  const version = (meta as { spec_version?: unknown } | undefined)?.spec_version;
  if (typeof meta !== 'object' || meta === null || Array.isArray(meta)) {
    out.add('error', () => issue('E_SCHEMA_REQUIRED', ['meta'], 'The meta section is missing.', { hint: 'Add meta with name, description and spec_version.' }));
    return out.finish();
  }
  if (typeof version !== 'string') {
    return [
      issue('E_SCHEMA_SPEC_VERSION', ['meta', 'spec_version'], 'The specification version is missing.', {
        expected: CURRENT_SPEC_VERSION,
        hint: `Set meta.spec_version to "${CURRENT_SPEC_VERSION}".`,
      }),
    ];
  }
  if (version !== CURRENT_SPEC_VERSION) {
    return [
      issue('E_SCHEMA_SPEC_VERSION', ['meta', 'spec_version'], `Specification version "${describeReceived(version, 16)}" is not supported.`, {
        expected: CURRENT_SPEC_VERSION,
        received: describeReceived(version, 16),
        hint: `This platform reads version ${CURRENT_SPEC_VERSION}.`,
      }),
    ];
  }

  // --- unknown and missing top-level sections ---
  for (const key of Object.keys(doc)) {
    if ((ENVELOPE_KEYS as readonly string[]).includes(key)) continue;
    if (!(ROOT_KEYS as readonly string[]).includes(key)) {
      out.add('error', () => issue('E_SCHEMA_UNKNOWN_KEY', [key], `"${describeReceived(key)}" is not one of the six sections of an application.`, {
        received: describeReceived(key),
        expected: listItems(ROOT_KEYS),
        hint: `Remove "${describeReceived(key)}". Only ${listItems(ROOT_KEYS)} are allowed.`,
      }));
    }
  }
  const expectArray = (key: 'params' | 'data' | 'compute' | 'triggers') => {
    const v = doc[key];
    if (!Array.isArray(v)) {
      out.add('error', () => issue(v === undefined ? 'E_SCHEMA_REQUIRED' : 'E_SCHEMA_TYPE', [key], `${describeReceived(key)} must be a list.`, {
        expected: 'a list',
        received: v === undefined ? 'nothing' : Array.isArray(v) ? 'a list' : typeof v,
        hint: `Set ${describeReceived(key)} to a list. An empty list is allowed for params and data.`,
      }));
      return undefined;
    }
    return v;
  };

  check(Meta, meta, ['meta'], out);
  const icon = (meta as { icon?: unknown }).icon;
  if (typeof icon === 'string' && icon.length <= 40 && !(ICONS as readonly string[]).includes(icon)) {
    out.add('warning', () => issue('W_UNKNOWN_ICON', ['meta', 'icon'], `"${describeReceived(icon)}" is not an icon we ship.`, {
      received: describeReceived(icon),
      hint: `Use one of: ${listItems(ICONS)}.`,
    }));
  }

  const params = expectArray('params');
  if (params) params.forEach((p, i) => check(ParamDecl, p, ['params', i], out));

  const data = expectArray('data');
  if (data) data.forEach((d, i) => check(DataRequirement, d, ['data', i], out));

  // --- compute: route each step to its exact branch ---
  const compute = expectArray('compute');
  if (compute) {
    compute.forEach((step, i) => {
      const at: Path = ['compute', i];
      if (typeof step !== 'object' || step === null || Array.isArray(step)) {
        out.add('error', () => issue('E_SCHEMA_TYPE', at, 'A calculation step must be an object.', { hint: 'Give it an id, a kind, and the fields that kind needs.' }));
        return;
      }
      const kind = (step as { kind?: unknown }).kind;
      if (typeof kind !== 'string' || !Object.hasOwn(STEP_SCHEMA, kind)) {
        out.add('error', () => issue(kind === undefined ? 'E_SCHEMA_REQUIRED' : 'E_SCHEMA_ENUM', [...at, 'kind'], 'A step needs a kind.', {
          expected: Object.keys(STEP_SCHEMA).join(' | '),
          received: describeReceived(kind),
          hint: `Set kind to one of ${listItems(Object.keys(STEP_SCHEMA))}.`,
        }));
        return;
      }
      if (kind === 'operation') {
        const op = (step as { op?: unknown }).op;
        if (typeof op !== 'string' || !Object.hasOwn(OPERATION_STEP, op)) {
          const names = Object.keys(OPERATION_STEP);
          out.add('error', () => issue(op === undefined ? 'E_SCHEMA_REQUIRED' : 'E_SCHEMA_ENUM', [...at, 'op'], 'A step of kind "operation" needs a supported operation name.', {
            expected: names.join(' | '),
            received: describeReceived(op),
            hint: op === 'ai'
              ? 'The AI step has its own kind. Use kind "ai" instead of kind "operation" with op "ai".'
              : `Use one of: ${listItems(names)}.`,
          }));
          return;
        }
        check(OPERATION_STEP[op]!, step, at, out);
        return;
      }
      check(STEP_SCHEMA[kind as keyof typeof STEP_SCHEMA] as unknown as z.ZodType, step, at, out);
    });
  }

  // --- triggers ---
  const triggers = expectArray('triggers');
  if (triggers) {
    if (triggers.length === 0) {
      out.add('error', () => issue('E_NO_TRIGGER', ['triggers'], CODE('E_NO_TRIGGER'), { hint: 'Add at least { "kind": "manual" }.' }));
    }
    triggers.forEach((t, i) => check(TriggerSpec, t, ['triggers', i], out));
  }

  // --- ui: route each element to its exact branch ---
  const ui = doc.ui;
  if (typeof ui !== 'object' || ui === null || Array.isArray(ui)) {
    out.add('error', () => issue(ui === undefined ? 'E_SCHEMA_REQUIRED' : 'E_SCHEMA_TYPE', ['ui'], 'The ui section must be an object with a root and a map of elements.', {
      hint: 'Set ui to { "root": "page", "elements": { "page": { "type": "Section", "children": [] } } }.',
    }));
    return out.finish();
  }
  const root = (ui as { root?: unknown }).root;
  const elements = (ui as { elements?: unknown }).elements;
  for (const key of Object.keys(ui)) {
    if (key !== 'root' && key !== 'elements') {
      out.add('error', () => issue('E_SCHEMA_UNKNOWN_KEY', ['ui', key], `"${describeReceived(key)}" is not part of the ui section.`, { received: describeReceived(key), hint: `Remove "${describeReceived(key)}". Only root and elements are allowed.` }));
    }
  }
  if (typeof root !== 'string') {
    out.add('error', () => issue(root === undefined ? 'E_SCHEMA_REQUIRED' : 'E_SCHEMA_TYPE', ['ui', 'root'], 'ui.root must name one element.', { hint: 'Set ui.root to the id of the outermost element.' }));
  }
  if (typeof elements !== 'object' || elements === null || Array.isArray(elements)) {
    out.add('error', () => issue(elements === undefined ? 'E_SCHEMA_REQUIRED' : 'E_SCHEMA_TYPE', ['ui', 'elements'], 'ui.elements must be a map of element id to element.', { hint: 'Use { "page": { "type": "Section", "children": [] } }.' }));
    return out.finish();
  }
  for (const [id, el] of Object.entries(elements as Record<string, unknown>)) {
    const at: Path = ['ui', 'elements', id];
    if (typeof el !== 'object' || el === null || Array.isArray(el)) {
      out.add('error', () => issue('E_SCHEMA_TYPE', at, 'An element must be an object.', { hint: 'Give it a type and the properties that type needs.' }));
      continue;
    }
    const type = (el as { type?: unknown }).type;
    if (typeof type !== 'string' || !Object.hasOwn(ELEMENT_SCHEMA, type)) {
      out.add('error', () => issue(type === undefined ? 'E_SCHEMA_REQUIRED' : 'E_SCHEMA_ENUM', [...at, 'type'], 'An element needs a supported type.', {
        expected: Object.keys(ELEMENT_SCHEMA).join(' | '),
        received: describeReceived(type),
        hint: `Use one of: ${listItems(Object.keys(ELEMENT_SCHEMA))}.`,
      }));
      continue;
    }
    check(ELEMENT_SCHEMA[type]! as unknown as z.ZodType, el, at, out);
  }

  return out.finish();
}
