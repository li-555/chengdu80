import { AppDocument, CURRENT_SPEC_VERSION } from '../app-schema/index.ts';
import {
  ERROR_CODES, IssueCollector, describeReceived, issue, VALIDATOR_VERSION, type Phase, type ValidationIssue, type ValidationReport, type ValidationResult,
} from './errors.ts';
import { ENVELOPE_KEYS, fromZod, parsePhase, schemaPhase } from './phases.ts';
import { referencesPhase } from './references.ts';
import { semanticsPhase } from './semantics.ts';
import { limitsPhase } from './limits.ts';

export * from './errors.ts';
export { DOCUMENT_LIMITS } from './limits.ts';
export { cronProblem } from './semantics.ts';

const split = (issues: ValidationIssue[]) => ({
  errors: issues.filter((i) => i.severity === 'error'),
  warnings: issues.filter((i) => i.severity === 'warning'),
});

/** One plain sentence for the person. Never jargon, never a code. */
function summarise(errors: ValidationIssue[], warnings: ValidationIssue[], phase: Phase): string {
  if (errors.length === 0) {
    if (warnings.length === 0) return 'This application is ready to run.';
    return warnings.length === 1
      ? 'This application is ready to run. There is one thing worth tidying up.'
      : `This application is ready to run. There are ${warnings.length} things worth tidying up.`;
  }
  const where = {
    parse: 'The file could not be read.',
    schema: 'Some parts of this application are not written correctly.',
    references: 'Some parts of this application point at something that does not exist.',
    semantics: 'Some parts of this application do not make sense together.',
    limits: 'This application asks for more than one run is allowed to do.',
  }[phase];
  const n = errors.length === 1 ? 'one problem' : `${errors.length} problems`;
  return `${where} ${n[0]!.toUpperCase()}${n.slice(1)} to fix.`;
}

/**
 * The one validity check. Everything else is a wrapper: the command line, the HTTP
 * route and the repair cycle all call this.
 *
 * Five phases, stopping at the first phase that produces an error, so a document with a
 * wrong specification version returns one error and not forty. Within a phase,
 * up to 200 errors and 200 warnings are reported. Warnings never block and are carried through from every phase
 * that ran.
 */
export function validateApplication(input: unknown): ValidationResult {
  try {
    return checkApplication(input);
  } catch {
    const errors = [issue('E_INTERNAL', [], ERROR_CODES.E_INTERNAL, {
      hint: 'This is a fault in the checker, not in your application. Simplify the value at this location and check again.',
    })];
    return {
      ok: false,
      errors,
      report: {
        valid: false,
        spec_version: null,
        validator_version: VALIDATOR_VERSION,
        checked_at: new Date().toISOString(),
        stopped_in: 'schema',
        errors,
        warnings: [],
        summary: ERROR_CODES.E_INTERNAL,
      },
    };
  }
}

function checkApplication(input: unknown): ValidationResult {
  const checked_at = new Date().toISOString();
  const carriedWarnings = new IssueCollector();

  const report = (phase: Phase, errors: ValidationIssue[], warnings: ValidationIssue[], specVersion: string | null): ValidationReport => ({
    valid: errors.length === 0,
    spec_version: specVersion,
    validator_version: VALIDATOR_VERSION,
    checked_at,
    stopped_in: phase,
    errors,
    warnings,
    summary: summarise(errors, warnings, phase),
  });

  // --- 1. parse ---
  // Only an ERROR stops a phase. A warning here (text around the JSON) must not, or
  // `ok` and `report.valid` disagree with each other.
  const parsed = parsePhase(input);
  {
    const { errors, warnings } = split(parsed.issues);
    carriedWarnings.append(warnings);
    if (errors.length > 0 || !parsed.value) {
      return { ok: false, errors, report: report('parse', errors, carriedWarnings.finish(), null) };
    }
  }
  const raw = parsed.value;
  const specVersion = typeof (raw.meta as { spec_version?: unknown } | undefined)?.spec_version === 'string'
    ? describeReceived((raw.meta as { spec_version: string }).spec_version, 16)
    : null;

  // --- 2. schema ---
  {
    const { errors, warnings } = split(schemaPhase(raw));
    carriedWarnings.append(warnings);
    if (errors.length > 0) {
      return { ok: false, errors, report: report('schema', errors, carriedWarnings.finish(), specVersion) };
    }
  }

  // The schema phase passed, so this must succeed. If it ever does not, the schema phase
  // and the document schema have drifted apart, and that is reported rather than thrown.
  // The envelope field is part of the export format, not part of the document.
  const body: Record<string, unknown> = { ...raw };
  for (const key of ENVELOPE_KEYS) delete body[key];

  const typed = AppDocument.safeParse(body);
  if (!typed.success) {
    const errors = fromZod(typed.error);
    return { ok: false, errors, report: report('schema', errors, carriedWarnings.finish(), specVersion) };
  }
  const doc = typed.data;

  // --- 3. references ---
  {
    const { errors, warnings } = split(referencesPhase(doc));
    carriedWarnings.append(warnings);
    if (errors.length > 0) {
      return { ok: false, errors, report: report('references', errors, carriedWarnings.finish(), specVersion) };
    }
  }

  // --- 4. semantics ---
  {
    const { errors, warnings } = split(semanticsPhase(doc));
    carriedWarnings.append(warnings);
    if (errors.length > 0) {
      return { ok: false, errors, report: report('semantics', errors, carriedWarnings.finish(), specVersion) };
    }
  }

  // --- 5. limits ---
  {
    const { errors, warnings } = split(limitsPhase(doc));
    carriedWarnings.append(warnings);
    if (errors.length > 0) {
      return { ok: false, errors, report: report('limits', errors, carriedWarnings.finish(), specVersion) };
    }
  }

  return { ok: true, document: doc, report: report('limits', [], carriedWarnings.finish(), specVersion) };
}

export const SUPPORTED_SPEC_VERSION = CURRENT_SPEC_VERSION;
