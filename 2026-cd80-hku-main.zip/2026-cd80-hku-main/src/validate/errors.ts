import type { AppDocument } from '../app-schema/document.ts';

/**
 * One problem with a document. Every field exists so that a machine can act on it.
 *
 * `hint` is not decoration: telling a model what to DO repairs far better than telling
 * it what is wrong, and the repair cycle feeds these objects straight back.
 */
export type Severity = 'error' | 'warning';

export type ValidationIssue = {
  severity: Severity;
  code: string;
  /** RFC 6901 JSON pointer, e.g. `/compute/2/params/window`. Any JSON tool can resolve it. */
  pointer: string;
  /** The same location as a readable path, e.g. `compute[2].params.window`. */
  path: string;
  section: 'root' | 'meta' | 'params' | 'data' | 'compute' | 'triggers' | 'ui';
  message: string;
  expected?: string;
  received?: string;
  hint?: string;
  docs?: string;
};

/** Which phase a run of the validator stopped in. */
export type Phase = 'parse' | 'schema' | 'references' | 'semantics' | 'limits';

export type ValidationReport = {
  valid: boolean;
  spec_version: string | null;
  validator_version: string;
  checked_at: string;
  /** The phase that produced the issues below, or `limits` when everything passed. */
  stopped_in: Phase;
  errors: ValidationIssue[];
  warnings: ValidationIssue[];
  /** One plain sentence for the person. Never jargon. */
  summary: string;
};

/** What the rest of the platform consumes. Matches docs/CONTRACTS.md section 2. */
export type ValidationResult =
  | { ok: true; document: AppDocument; report: ValidationReport }
  | { ok: false; errors: ValidationIssue[]; report: ValidationReport };

export const VALIDATOR_VERSION = '1';

/**
 * The closed, published set of error codes, in five families.
 * `errors.json` is generated from this object, so the published list cannot drift.
 */
export const ERROR_CODES = {
  E_TOO_MANY_ERRORS: 'More problems were found than one report can show.',
  E_INTERNAL: 'The checker could not finish checking this application.',

  // --- parse ---
  E_PARSE_JSON: 'The file is not valid JSON.',
  E_PARSE_NOT_OBJECT: 'The top level of an application must be a JSON object.',
  E_PARSE_EMPTY: 'The file is empty.',

  // --- shape ---
  E_SCHEMA_TYPE: 'A value is the wrong type.',
  E_SCHEMA_REQUIRED: 'A required field is missing.',
  E_SCHEMA_UNKNOWN_KEY: 'A key is not part of the specification. Usually a typo.',
  E_SCHEMA_ENUM: 'A value is not one of the allowed choices.',
  E_SCHEMA_RANGE: 'A number or a length is outside the allowed range.',
  E_SCHEMA_PATTERN: 'A value does not match the required form.',
  E_SCHEMA_UNION: 'A value does not match any allowed shape.',
  E_SCHEMA_CUSTOM: 'A value broke a rule specific to this field.',
  E_SCHEMA_SPEC_VERSION: 'The specification version is missing or unsupported.',

  // --- something names something that does not exist ---
  E_REF_DUPLICATE_NAME: 'Two things claim the same name. Data keys and step ids share one namespace.',
  E_REF_UNKNOWN_RELATION: 'A step reads a table that no data requirement or earlier step produces.',
  E_REF_UNKNOWN_PARAM: 'Something names a parameter that was never declared.',
  E_REF_UNKNOWN_ELEMENT: 'A section lists a child element that does not exist.',
  E_REF_UNKNOWN_ROOT: 'The screen names a root element that does not exist.',

  // --- meaning ---
  E_CYCLE: 'Two or more steps depend on each other, so no order can run them.',
  E_SELF_REFERENCE: 'A step reads its own output.',
  E_BAD_CRON: 'A schedule is not a valid five-field cron expression.',
  E_BAD_EXPRESSION: 'A formula could not be understood.',
  E_BAD_SQL: 'A SQL step is not a single SELECT or WITH, or uses something not allowed.',
  E_NO_TRIGGER: 'An application needs at least one trigger.',
  E_ELEMENT_CYCLE: 'Sections contain each other in a loop.',

  // --- limits ---
  E_LIMIT_STEPS: 'Too many calculation steps.',
  E_LIMIT_CODE_STEPS: 'More than one custom-code step in one application.',
  E_LIMIT_AI_STEPS: 'More than four AI steps in one application.',
  E_LIMIT_ELEMENTS: 'Too many screen elements.',
  E_LIMIT_NESTING: 'Sections are nested too deeply.',

  // --- warnings, which never block ---
  W_ORPHAN_ELEMENT: 'An element is declared but nothing on the screen shows it.',
  W_UNUSED_PARAM: 'A parameter is declared but nothing uses it.',
  W_DEAD_CONTROL: 'A parameter has a control on screen but nothing in the calculation reads it, so the control does nothing.',
  W_UNUSED_STEP: 'A step produces a table that nothing reads.',
  W_UNUSED_DATA: 'A data requirement is declared but no step reads it.',
  W_SQL_COULD_BE_OPERATION: 'A SQL step does something a named operation already does.',
  W_CODE_COULD_BE_OPERATION: 'A custom-code step does something a named operation already does.',
  W_SURROUNDING_TEXT: 'The application was wrapped in a code fence or surrounded by prose. It was read anyway.',
  W_UNKNOWN_ICON: 'The icon name is not one we ship. A default will be used.',
  W_NO_MANUAL_TRIGGER: 'The application cannot be run by hand.',
  W_SHORT_HISTORY: 'The data does not go back as far as this application asks for.',
} as const;

export type ErrorCode = keyof typeof ERROR_CODES;

/** `['compute', 2, 'params', 'window']` becomes `/compute/2/params/window`. */
export function toPointer(path: ReadonlyArray<string | number>): string {
  if (path.length === 0) return '';
  return '/' + path.map((p) => describeReceived(String(p), 500).replace(/~/g, '~0').replace(/\//g, '~1')).join('/');
}

/** `['compute', 2, 'params', 'window']` becomes `compute[2].params.window`. */
export function toReadablePath(path: ReadonlyArray<string | number>): string {
  let out = '';
  for (const p of path) {
    if (typeof p === 'number') out += `[${p}]`;
    else out += out === '' ? describeReceived(p, 500) : `.${describeReceived(p, 500)}`;
  }
  return out || '(the whole document)';
}

const SECTIONS = ['meta', 'params', 'data', 'compute', 'triggers', 'ui'] as const;

export function sectionOf(path: ReadonlyArray<string | number>): ValidationIssue['section'] {
  const first = path[0];
  return typeof first === 'string' && (SECTIONS as readonly string[]).includes(first)
    ? (first as ValidationIssue['section'])
    : 'root';
}

export function issue(
  code: ErrorCode,
  path: ReadonlyArray<string | number>,
  message: string,
  extra: Partial<Pick<ValidationIssue, 'expected' | 'received' | 'hint'>> = {},
): ValidationIssue {
  return {
    severity: code.startsWith('W_') ? 'warning' : 'error',
    code,
    pointer: boundedText(toPointer(path)),
    path: boundedText(toReadablePath(path)),
    section: sectionOf(path),
    message: boundedText(message),
    docs: `/api/spec/errors#${code}`,
    ...extra,
    ...(extra.expected === undefined ? {} : { expected: boundedText(extra.expected) }),
    ...(extra.received === undefined ? {} : { received: boundedText(extra.received) }),
    ...(extra.hint === undefined ? {} : { hint: boundedText(extra.hint) }),
  };
}

/** Describe an unchecked value without invoking its conversion methods or walking it. */
export function describeReceived(value: unknown, maxLength = 160): string {
  if (value === undefined) return 'nothing';
  if (value === null) return 'null';
  if (Array.isArray(value)) return 'a list';
  if (typeof value === 'object') return 'an object';
  if (typeof value === 'string') return value.length > maxLength ? `a string of ${value.length} characters` : value;
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  return typeof value;
}

export const REPORT_LIMIT = 200;

export function boundedText(text: string): string {
  return text.length <= 500 ? text : text.slice(0, 499) + '…';
}

/** Format only a small prefix, even when the list contains very large strings. */
export function listItems(items: readonly string[] | ReadonlySet<string>, separator = ', ', quote = false): string {
  const size = Array.isArray(items) ? items.length : (items as ReadonlySet<string>).size;
  const prefix: string[] = [];
  for (const item of items) {
    prefix.push(item);
    if (prefix.length === 10) break;
  }
  const shown = prefix.map((item) => {
    const text = item.length > 160 ? describeReceived(item) : item.length > 30 ? item.slice(0, 29) + '…' : item;
    return quote ? `"${text}"` : text;
  }).join(separator);
  return size > 10 ? `${shown}${separator}and ${size - 10} more` : shown;
}

/** Count every problem, but construct only the issues that the report can keep. */
export class IssueCollector {
  private errors: ValidationIssue[] = [];
  private warnings: ValidationIssue[] = [];
  private counts = { error: 0, warning: 0 };

  add(severity: Severity, make: () => ValidationIssue): void {
    const kept = severity === 'error' ? this.errors : this.warnings;
    this.counts[severity]++;
    if (kept.length < REPORT_LIMIT) kept.push(make());
  }

  count(severity: Severity, count: number): void {
    this.counts[severity] += count;
  }

  remaining(severity: Severity): number {
    return Math.max(0, REPORT_LIMIT - this.counts[severity]);
  }

  append(issues: ValidationIssue[]): void {
    for (const entry of issues) {
      const count = entry.code === 'E_TOO_MANY_ERRORS' ? Number(entry.received) : 1;
      if (this.remaining(entry.severity) > 0) this.add(entry.severity, () => entry);
      else this.count(entry.severity, 1);
      if (count > 1) this.count(entry.severity, count - 1);
    }
  }

  finish(): ValidationIssue[] {
    const finish = (severity: Severity, kept: ValidationIssue[]) => {
      if (this.counts[severity] <= REPORT_LIMIT) return kept;
      const omitted = this.counts[severity] - (REPORT_LIMIT - 1);
      const summary = issue('E_TOO_MANY_ERRORS', [], `${omitted} more ${severity === 'error' ? 'errors' : 'warnings'} were found.`, {
        received: String(omitted),
        hint: 'Fix the reported problems and check again to see the remaining problems.',
      });
      summary.severity = severity;
      return [...kept.slice(0, REPORT_LIMIT - 1), summary];
    };
    return [...finish('error', this.errors), ...finish('warning', this.warnings)];
  }
}
