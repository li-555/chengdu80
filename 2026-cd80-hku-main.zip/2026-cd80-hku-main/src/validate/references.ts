import type { AppDocument, ComputeStep } from '../app-schema/index.ts';
import { IssueCollector, listItems, issue, type ValidationIssue } from './errors.ts';

/**
 * Edit distance, capped so a long pair exits early.
 * A real typo is a transposition, an inserted letter or a doubled letter, none of which
 * a prefix test finds: `move_threshhold` shares no prefix boundary with `move_threshold`.
 */
function editDistance(a: string, b: string, cap: number): number {
  if (a.length > 64 || b.length > 64) return cap + 1;
  if (Math.abs(a.length - b.length) > cap) return cap + 1;
  let prev = Array.from({ length: b.length + 1 }, (_, i) => i);
  for (let i = 1; i <= a.length; i++) {
    const row = [i];
    let best = i;
    for (let j = 1; j <= b.length; j++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      const v = Math.min(prev[j]! + 1, row[j - 1]! + 1, prev[j - 1]! + cost);
      row.push(v);
      if (v < best) best = v;
    }
    if (best > cap) return cap + 1;
    prev = row;
  }
  return prev[b.length]!;
}

/** The closest declared name, if one is close enough to be worth suggesting. */
export function nearest(name: string, pool: Iterable<string>): string | undefined {
  if (name.length > 64) return undefined;
  const candidates = [...pool].filter((c) => c.length <= 64);
  const lower = name.toLowerCase();
  const exactCase = candidates.find((c) => c.toLowerCase() === lower);
  if (exactCase) return exactCase;
  const cap = name.length <= 4 ? 1 : name.length <= 8 ? 2 : 3;
  let best: string | undefined;
  let bestScore = cap + 1;
  for (const c of candidates) {
    const d = editDistance(name, c, cap);
    if (d < bestScore) { bestScore = d; best = c; }
  }
  return bestScore <= cap ? best : undefined;
}

/** `$params.move_threshold` inside a formula. The only member form an expression may use. */
const PARAM_IN_EXPR = /\$params\.([a-z][a-z0-9_]{0,39})/g;

/**
 * Strip single and double quoted strings, so `"$params.nope"` inside a formula is not
 * mistaken for a reference. Full parsing belongs to the expression evaluator; this is
 * enough to stop the reference phase inventing an error.
 */
function withoutStringLiterals(expr: string): string {
  return expr.replace(/'(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"/g, '""');
}

export function paramsUsedIn(expr: string): string[] {
  if (expr.length > 2000) return [];
  return [...withoutStringLiterals(expr).matchAll(PARAM_IN_EXPR)].map((m) => m[1]!);
}

/**
 * Relation names a SQL step reads, found by looking at FROM and JOIN and removing the
 * names the query defines itself in a WITH clause.
 *
 * Used ONLY to stop false "nothing reads this" warnings. It deliberately never raises an
 * error: a regular expression is not a SQL parser, and a wrong error is worse than a
 * missing one. The real dependency list comes from the parse tree in the SQL gate.
 */
export function relationsInSql(sql: string): string[] {
  if (sql.length > 20000) return [];
  const text = sql.replace(/--[^\n]*/g, ' ').replace(/\/\*[\s\S]*?\*\//g, ' ');
  const defined = new Set(
    [...text.matchAll(/\b(?:with|,)\s+([a-z][a-z0-9_]*)\s+as\s*\(/gi)].map((m) => m[1]!.toLowerCase()),
  );
  const found = [...text.matchAll(/\b(?:from|join)\s+([a-z][a-z0-9_]*)/gi)].map((m) => m[1]!);
  return found.filter((n) => !defined.has(n.toLowerCase()));
}

/** Every relation a step reads, with the pointer path of each reference. */
export function inputsOf(step: ComputeStep, index: number): { name: string; path: (string | number)[] }[] {
  const at = (...rest: (string | number)[]) => ['compute', index, ...rest];
  const s = step as unknown as Record<string, unknown>;
  const refs: { name: string; path: (string | number)[] }[] = [];

  if (typeof s.input === 'string') refs.push({ name: s.input, path: at('input') });
  if (Array.isArray(s.input)) {
    s.input.forEach((n, i) => { if (typeof n === 'string') refs.push({ name: n, path: at('input', i) }); });
  }
  const p = s.params as Record<string, unknown> | undefined;
  if (p) {
    if (typeof p.right === 'string') refs.push({ name: p.right, path: at('params', 'right') });
    if (typeof p.factor_table === 'string') refs.push({ name: p.factor_table, path: at('params', 'factor_table') });
    if (typeof p.universe === 'string') refs.push({ name: p.universe, path: at('params', 'universe') });
  }
  return refs;
}

/**
 * Every `{ param: 'name' }` reference inside a step's parameters, at any depth.
 * These are the numeric fields a control can be wired to.
 */
export function paramRefsOf(step: ComputeStep, index: number): { name: string; path: (string | number)[] }[] {
  const out: { name: string; path: (string | number)[] }[] = [];
  const walk = (node: unknown, path: (string | number)[]): void => {
    if (node === null || typeof node !== 'object') return;
    if (Array.isArray(node)) {
      node.forEach((v, i) => walk(v, [...path, i]));
      return;
    }
    const o = node as Record<string, unknown>;
    const keys = Object.keys(o);
    if (keys.length === 1 && keys[0] === 'param' && typeof o.param === 'string') {
      out.push({ name: o.param, path: [...path, 'param'] });
      return;
    }
    for (const [k, v] of Object.entries(o)) walk(v, [...path, k]);
  };
  walk((step as unknown as Record<string, unknown>).params, ['compute', index, 'params']);
  return out;
}

/** Every formula in a step, with where it lives. */
export function expressionsOf(step: ComputeStep, index: number): { expr: string; path: (string | number)[] }[] {
  const at = (...rest: (string | number)[]) => ['compute', index, ...rest];
  const s = step as unknown as Record<string, unknown>;
  const out: { expr: string; path: (string | number)[] }[] = [];
  if (s.kind === 'expression' && typeof s.expr === 'string') out.push({ expr: s.expr, path: at('expr') });
  const p = s.params as Record<string, unknown> | undefined;
  if (p) {
    if (typeof p.where === 'string') out.push({ expr: p.where, path: at('params', 'where') });
    if (p.columns && typeof p.columns === 'object') {
      for (const [name, e] of Object.entries(p.columns as Record<string, unknown>)) {
        if (typeof e === 'string') out.push({ expr: e, path: at('params', 'columns', name) });
      }
    }
  }
  return out;
}

/**
 * Phase 3 — references. Does everything that names something else actually find it?
 *
 * A forward reference is legal: steps are sorted by dependency before they run, so a
 * step may read a table declared later in the list. Only a cycle is an error, and that
 * is the semantics phase.
 */
export function referencesPhase(doc: AppDocument): ValidationIssue[] {
  const out = new IssueCollector();

  // --- one flat namespace: data keys and step ids together ---
  const owner = new Map<string, string>();
  doc.data.forEach((d, i) => {
    const prev = owner.get(d.key);
    if (prev) {
      out.add('error', () => issue('E_REF_DUPLICATE_NAME', ['data', i, 'key'], `The name "${d.key}" is already used by ${prev}.`, {
        received: d.key, hint: 'Data requirements and calculation steps share one namespace. Rename one of them.',
      }));
    } else owner.set(d.key, `data requirement ${i}`);
  });
  doc.compute.forEach((s, i) => {
    const prev = owner.get(s.id);
    if (prev) {
      out.add('error', () => issue('E_REF_DUPLICATE_NAME', ['compute', i, 'id'], `The name "${s.id}" is already used by ${prev}.`, {
        received: s.id, hint: 'Data requirements and calculation steps share one namespace. Rename one of them.',
      }));
    } else owner.set(s.id, `step ${i}`);
  });

  const relations = new Set(owner.keys());
  const declaredParams = new Set(doc.params.map((p) => p.key));
  const usedParams = new Set<string>();
  /** Used somewhere that actually changes the result, as opposed to only by a control. */
  const usedInLogic = new Set<string>();
  const readRelations = new Set<string>();

  const suggest = (name: string, pool: Iterable<string>) => out.remaining('error') > 0 ? nearest(name, pool) : undefined;

  // --- steps read relations, and formulas read parameters ---
  doc.compute.forEach((step, i) => {
    for (const ref of inputsOf(step, i)) {
      readRelations.add(ref.name);
      if (ref.name === step.id) {
        out.add('error', () => issue('E_SELF_REFERENCE', ref.path, `Step "${step.id}" reads its own output.`, {
          received: ref.name, hint: 'Point this at the step or data requirement that comes before it.',
        }));
      } else if (!relations.has(ref.name)) {
        const near = suggest(ref.name, relations);
        out.add('error', () => issue('E_REF_UNKNOWN_RELATION', ref.path, `Nothing produces a table called "${ref.name}".`, {
          received: ref.name,
          expected: listItems(relations) || 'nothing is declared yet',
          hint: near ? `Did you mean "${near}"?` : 'Name a data requirement key or an earlier step id.',
        }));
      }
    }
    if (step.kind === 'sql') {
      for (const name of relationsInSql((step as unknown as { sql: string }).sql)) {
        if (relations.has(name)) readRelations.add(name);
      }
    }
    for (const ref of paramRefsOf(step, i)) {
      usedParams.add(ref.name);
      usedInLogic.add(ref.name);
      if (!declaredParams.has(ref.name)) {
        const near = suggest(ref.name, declaredParams);
        out.add('error', () => issue('E_REF_UNKNOWN_PARAM', ref.path, `This step uses a setting called "${ref.name}", which is not declared.`, {
          received: ref.name,
          expected: listItems(declaredParams) || 'no settings are declared',
          hint: near ? `Did you mean "${near}"?` : `Add "${ref.name}" to params.`,
        }));
      }
    }
    for (const { expr, path } of expressionsOf(step, i)) {
      for (const name of paramsUsedIn(expr)) {
        usedParams.add(name);
        usedInLogic.add(name);
        if (!declaredParams.has(name)) {
          const near = suggest(name, declaredParams);
          out.add('error', () => issue('E_REF_UNKNOWN_PARAM', path, `The formula uses a setting called "${name}", which is not declared.`, {
            received: name,
            expected: listItems(declaredParams) || 'no settings are declared',
            hint: near ? `Did you mean "${near}"?` : `Add "${name}" to params, or remove it from the formula.`,
          }));
        }
      }
    }
  });

  // --- an alert condition is a formula too ---
  doc.triggers.forEach((t, i) => {
    if (t.kind !== 'alert') return;
    for (const name of paramsUsedIn(t.condition)) {
      usedParams.add(name);
      usedInLogic.add(name);
      if (!declaredParams.has(name)) {
        const near = suggest(name, declaredParams);
        out.add('error', () => issue('E_REF_UNKNOWN_PARAM', ['triggers', i, 'condition'], `The alert condition uses a setting called "${name}", which is not declared.`, {
          received: name,
          expected: listItems(declaredParams) || 'no settings are declared',
          hint: near ? `Did you mean "${near}"?` : `Add "${name}" to params, or remove it from the condition.`,
        }));
      }
    }
  });

  // --- a filter names a parameter ---
  doc.data.forEach((d, i) => {
    (d.filters ?? []).forEach((f, j) => {
      usedParams.add(f.param);
      usedInLogic.add(f.param);
      if (!declaredParams.has(f.param)) {
        const near = suggest(f.param, declaredParams);
        out.add('error', () => issue('E_REF_UNKNOWN_PARAM', ['data', i, 'filters', j, 'param'], `The filter uses a setting called "${f.param}", which is not declared.`, {
          received: f.param,
          expected: listItems(declaredParams) || 'no settings are declared',
          hint: near ? `Did you mean "${near}"?` : `Add "${f.param}" to params. A filter must name a setting, never hold a value.`,
        }));
      }
    });
  });

  // --- the screen ---
  const elements = doc.ui.elements as Record<string, { type: string } & Record<string, unknown>>;
  const ids = new Set(Object.keys(elements));
  if (!ids.has(doc.ui.root)) {
    out.add('error', () => issue('E_REF_UNKNOWN_ROOT', ['ui', 'root'], `There is no element called "${doc.ui.root}".`, {
      received: doc.ui.root,
      expected: listItems(ids) || 'no elements are declared',
      hint: 'Point ui.root at one of the declared elements, usually the outermost Section.',
    }));
  }

  // Every Section's children are checked, whether or not the screen reaches it. An
  // element nothing shows is only a warning, so its contents must still be correct --
  // otherwise adding it to the layout later turns a valid application invalid.
  for (const [id, el] of Object.entries(elements)) {
    if (el.type !== 'Section') continue;
    const children = (el.children as string[] | undefined) ?? [];
    children.forEach((child, j) => {
      if (!ids.has(child)) {
        const near = suggest(child, ids);
        out.add('error', () => issue('E_REF_UNKNOWN_ELEMENT', ['ui', 'elements', id, 'children', j], `Section "${id}" lists a child called "${child}", which does not exist.`, {
          received: child,
          hint: near ? `Did you mean "${near}"?` : `Add an element called "${child}", or remove it from this list.`,
        }));
      }
    });
  }

  // Containment loops, over every Section. Three-colour depth-first search, so each
  // loop is reported once and a node is never left half-visited.
  {
    const WHITE = 0, GREY = 1, BLACK = 2;
    const colour = new Map<string, number>();
    const stack: string[] = [];
    const seenLoops = new Set<string>();
    const visit = (id: string): void => {
      colour.set(id, GREY);
      stack.push(id);
      const el = elements[id];
      if (el?.type === 'Section') {
        for (const child of ((el.children as string[] | undefined) ?? [])) {
          if (!ids.has(child)) continue;
          const c = colour.get(child) ?? WHITE;
          if (c === GREY) {
            const loop = [...stack.slice(stack.indexOf(child)), child];
            const signature = [...new Set(loop)].sort().join('|');
            if (!seenLoops.has(signature)) {
              seenLoops.add(signature);
              out.add('error', () => issue('E_ELEMENT_CYCLE', ['ui', 'elements', id, 'children'], `Sections contain each other in a loop: ${listItems(loop, ' -> ')}.`, {
                hint: 'Remove one of these children so the screen is a tree.',
              }));
            }
          } else if (c === WHITE) {
            visit(child);
          }
        }
      }
      stack.pop();
      colour.set(id, BLACK);
    };
    for (const id of ids) if ((colour.get(id) ?? WHITE) === WHITE) visit(id);
  }

  // What the screen actually reaches, which is only used for the orphan warning.
  const reachable = new Set<string>();
  {
    const walk = (id: string): void => {
      if (reachable.has(id) || !ids.has(id)) return;
      reachable.add(id);
      const el = elements[id];
      if (el?.type !== 'Section') return;
      for (const child of ((el.children as string[] | undefined) ?? [])) walk(child);
    };
    if (ids.has(doc.ui.root)) walk(doc.ui.root);
  }

  for (const [id, el] of Object.entries(elements)) {
    const at = (...rest: (string | number)[]) => ['ui', 'elements', id, ...rest];

    if (!reachable.has(id)) {
      out.add('warning', () => issue('W_ORPHAN_ELEMENT', at(), `Element "${id}" is declared but nothing shows it.`, {
        hint: `Add "${id}" to a Section's children, or remove it.`,
      }));
    }

    // a display element reads a relation
    if (typeof el.from === 'string') {
      const from = el.from;
      readRelations.add(from);
      if (!relations.has(el.from)) {
        const near = suggest(el.from, relations);
        out.add('error', () => issue('E_REF_UNKNOWN_RELATION', at('from'), `Element "${id}" shows a table called "${el.from}", which nothing produces.`, {
          received: from,
          expected: listItems(relations) || 'nothing is declared yet',
          hint: near ? `Did you mean "${near}"?` : 'Point this at a data requirement key or a step id.',
        }));
      }
    }

    // a control names a parameter
    for (const key of ['param', 'fromParam', 'toParam'] as const) {
      const name = el[key];
      if (typeof name !== 'string') continue;
      usedParams.add(name);
      if (!declaredParams.has(name)) {
        const near = suggest(name, declaredParams);
        out.add('error', () => issue('E_REF_UNKNOWN_PARAM', at(key), `The control "${id}" names a setting called "${name}", which is not declared.`, {
          received: name,
          expected: listItems(declaredParams) || 'no settings are declared',
          hint: near ? `Did you mean "${near}"?` : `Add "${name}" to params, otherwise this control does nothing.`,
        }));
      }
    }
  }

  // --- warnings: declared but unused. Never blocking. ---
  doc.params.forEach((p, i) => {
    if (!usedParams.has(p.key)) {
      out.add('warning', () => issue('W_UNUSED_PARAM', ['params', i, 'key'], `The setting "${p.key}" is declared but nothing uses it.`, {
        hint: 'Either use it in a filter, a formula or a control, or remove it.',
      }));
    } else if (!usedInLogic.has(p.key)) {
      out.add('warning', () => issue('W_DEAD_CONTROL', ['params', i, 'key'], `The setting "${p.key}" has a control on screen, but nothing in the calculation reads it, so moving that control changes nothing.`, {
        hint: `Use "${p.key}" in a filter, a formula, or a numeric field such as a row limit — or remove its control.`,
      }));
    }
  });
  doc.data.forEach((d, i) => {
    if (!readRelations.has(d.key)) {
      out.add('warning', () => issue('W_UNUSED_DATA', ['data', i, 'key'], `The data requirement "${d.key}" is declared but nothing reads it.`, {
        hint: 'Either read it in a step or show it on screen, or remove it.',
      }));
    }
  });
  doc.compute.forEach((s, i) => {
    if (!readRelations.has(s.id)) {
      out.add('warning', () => issue('W_UNUSED_STEP', ['compute', i, 'id'], `Step "${s.id}" produces a table that nothing reads.`, {
        hint: 'Either show it on screen, read it in a later step, or remove it.',
      }));
    }
  });

  return out.finish();
}
