/**
 * Getting rows into the run's database.
 *
 * Every row that reaches a run — a resolved data slice, the output of a code step — comes
 * through here. The rows themselves are **bound as one JSON parameter**, never written
 * into SQL text, so nothing a person uploaded or a model produced is ever parsed as SQL.
 *
 * The column types in the `from_json` schema are written into the statement, because
 * DuckDB requires that argument to be a constant. That is safe for a different reason:
 * the type names come from a closed set defined here, and the column names are quoted
 * identifiers checked against the same declaration. Neither is user text passed through.
 */

import type { RunContext } from './context.ts';
import { quoteIdentifier } from './expr.ts';

/** The field types a declaration may use, and what each becomes in the database. */
const TYPE_SQL = {
  string: 'VARCHAR',
  number: 'DOUBLE',
  integer: 'BIGINT',
  boolean: 'BOOLEAN',
  date: 'DATE',
  timestamp: 'TIMESTAMP',
} as const;

export type IngestType = keyof typeof TYPE_SQL;
export type IngestColumn = { name: string; type: IngestType };

/** A relation name must be a plain identifier: it is written into the statement. */
const RELATION_NAME = /^[a-z][a-z0-9_]{0,63}$/;

export class IngestError extends Error {
  readonly hint?: string;
  constructor(message: string, hint?: string) {
    super(message);
    this.name = 'IngestError';
    this.hint = hint;
  }
}

/**
 * Build the `from_json` schema argument.
 *
 * A JSON string, so a column name containing a quote or a backslash must be escaped for
 * JSON rather than for SQL. `JSON.stringify` on the object does both correctly; doing it
 * by hand is how an injection gets in.
 */
export function jsonSchemaArgument(columns: readonly IngestColumn[]): string {
  /**
   * A null-prototype object, because `shape['__proto__'] = v` on an ordinary object
   * sets the prototype instead of creating a property, and the column vanished from
   * the schema. `__proto__` is a legal column name in a spreadsheet.
   */
  const shape: Record<string, string> = Object.create(null);
  for (const col of columns) {
    shape[col.name] = TYPE_SQL[col.type];
  }
  return JSON.stringify([shape]);
}

/**
 * Escape a string for a single-quoted SQL literal by doubling its quotes.
 *
 * `JSON.stringify` escapes for JSON, which does nothing to an apostrophe. A column named
 * `x'||error('INJECTED')||'` therefore closed the literal and the rest became SQL
 * expression text. Found in review, 2026-10-14. DuckDB does not process backslash
 * escapes inside an ordinary single-quoted string, so doubling the quote is enough.
 */
export function quoteSqlLiteral(value: string): string {
  return `'${value.replaceAll("'", "''")}'`;
}

export type IngestResult = {
  /** Rows the database holds afterwards, counted in the database, not assumed. */
  rows: number;
  /**
   * Per column, how many values arrived with a value and ended up null.
   *
   * `from_json` does not fail on a value it cannot read: it writes null and loads the
   * row anyway, so a malformed date silently becomes a gap and every later calculation
   * quietly works on it. Measured, 2026-10-14: a date of 'not a date at all' and a
   * number of 'also not a number' both loaded as null with no error. Counting them is
   * what turns that into something a run can report.
   */
  coercedToNull: Record<string, number>;
};

/** Create a relation from rows. */
export async function createRelationFromRows(
  ctx: RunContext,
  name: string,
  columns: readonly IngestColumn[],
  rows: readonly Record<string, unknown>[],
): Promise<IngestResult> {
  if (!RELATION_NAME.test(name)) {
    throw new IngestError(
      `'${name}' is not a usable relation name`,
      'lower-case letters, digits and underscores, starting with a letter',
    );
  }
  if (columns.length === 0) {
    throw new IngestError(`relation '${name}' declares no columns`);
  }

  const seen = new Set<string>();
  for (const col of columns) {
    if (!(col.type in TYPE_SQL)) {
      throw new IngestError(`column '${col.name}' has unknown type '${col.type}'`);
    }
    const key = col.name.toLowerCase();
    if (seen.has(key)) {
      throw new IngestError(`relation '${name}' declares two columns called '${col.name}'`);
    }
    seen.add(key);
  }

  const quoted = quoteIdentifier(name);
  const schema = jsonSchemaArgument(columns);

  /**
   * An empty input still has to produce a relation, with the right columns, or every
   * later step fails with a missing-table error instead of returning nothing. `from_json`
   * on an empty array yields no rows, so the typed empty relation is built directly.
   */
  if (rows.length === 0) {
    const decls = columns
      .map((c) => `${quoteIdentifier(c.name)} ${TYPE_SQL[c.type]}`)
      .join(', ');
    await ctx.query(`CREATE TABLE ${quoted} (${decls})`);
    return { rows: 0, coercedToNull: {} };
  }

  // Only the declared columns are carried over, in declaration order: a row object with
  // an extra key must not quietly add a column that nothing downstream expects.
  const projection = columns.map((c) => `r.${quoteIdentifier(c.name)}`).join(', ');

  // Counted while the payload is built, so it costs nothing extra.
  const suppliedNonNull: Record<string, number> = {};
  for (const col of columns) suppliedNonNull[col.name] = 0;

  const payload = JSON.stringify(
    rows.map((row) => {
      const out: Record<string, unknown> = {};
      for (const col of columns) {
        const v = row[col.name];
        if (v !== undefined && v !== null && v !== '') {
          suppliedNonNull[col.name] = (suppliedNonNull[col.name] ?? 0) + 1;
        }
        out[col.name] = v ?? null;
      }
      return out;
    }),
  );

  try {
    await ctx.query(
      `CREATE TABLE ${quoted} AS
       SELECT ${projection}
       FROM (SELECT unnest(from_json(?, ${quoteSqlLiteral(schema)})) AS r)`,
      [payload] as never[],
    );
  } catch (e) {
    throw new IngestError(
      `could not load rows into '${name}': ${e instanceof Error ? e.message.split('\n')[0] : String(e)}`,
      'check that every declared column type matches the values supplied',
    );
  }

  /**
   * One query gets the row count and, per column, how many values survived as non-null.
   * A value that was supplied and is now null was one the engine could not read.
   */
  const counts = columns
    .map((c, i) => `count(${quoteIdentifier(c.name)}) AS c${i}`)
    .join(', ');
  const measured = await ctx.query(`SELECT count(*) AS n, ${counts} FROM ${quoted}`);
  const row = measured.rows[0] ?? {};

  const coercedToNull: Record<string, number> = {};
  columns.forEach((col, i) => {
    const kept = Number(row[`c${i}`] ?? 0);
    const lost = (suppliedNonNull[col.name] ?? 0) - kept;
    if (lost > 0) coercedToNull[col.name] = lost;
  });

  return { rows: Number(row.n ?? 0), coercedToNull };
}
