import { DuckDBInstance, type DuckDBConnection, type DuckDBValue } from '@duckdb/node-api';

/**
 * One run gets one locked-down in-memory database.
 *
 * Be exact about what this does and does not stop, because an overstated claim costs
 * more than an honest one.
 *
 * **Enforced by the engine, verified by the tests in this file's companion:**
 * reading a host file, reading one as text, writing one, attaching a FILE-backed
 * database, installing an extension, loading an external extension, reaching the
 * network, listing a directory, and changing any of these settings afterwards.
 *
 * **Also enforced by the engine:** spilling to disk. DuckDB writes intermediate results
 * to a temporary directory when a query exceeds its memory limit, which is a host write
 * that no amount of `enable_external_access=false` prevents -- that flag locks the
 * temp directory's PATH but leaves its size at 90% of the disk. The temporary budget is
 * therefore set to zero, so a query that would spill fails with an out-of-memory error
 * instead of writing anything.
 *
 * **NOT stopped here, and stopped by the SQL allow-list instead:** `ATTACH ':memory:'`
 * creates another in-memory database, and `LOAD json` or `LOAD parquet` succeed because
 * those extensions are compiled in rather than loaded from disk. Neither reaches the
 * file system or the network, but neither is refused by configuration either. An
 * application's SQL may only ever be a single `SELECT` or `WITH`, which is what actually
 * excludes them.
 */

export type RunLimits = {
  /** Memory the run may use, in megabytes. */
  memoryMb: number;
  /** Threads the database may use. */
  threads: number;
  /** How long one statement may take before the connection is interrupted. */
  statementTimeoutMs: number;
  /** How long the whole run may take. */
  runTimeoutMs: number;
};

export const DEFAULT_LIMITS: RunLimits = {
  memoryMb: 512,
  threads: 2,
  statementTimeoutMs: 15_000,
  runTimeoutMs: 60_000,
};

/** A column of a result, with the type DuckDB reported. */
export type ResultColumn = { name: string; type: string };

export type QueryResult = {
  columns: ResultColumn[];
  rows: Record<string, unknown>[];
  durationMs: number;
};

export class RunTimeoutError extends Error {
  readonly code: string;
  readonly kind: 'statement' | 'run';

  constructor(kind: 'statement' | 'run', ms: number) {
    super(kind === 'statement'
      ? `A step took longer than ${ms} milliseconds and was stopped.`
      : `The run took longer than ${ms} milliseconds and was stopped.`);
    this.name = 'RunTimeoutError';
    this.kind = kind;
    this.code = kind === 'statement' ? 'E_STEP_TIMEOUT' : 'E_RUN_TIMEOUT';
  }
}

/**
 * DuckDB reports a BIGINT as a decimal string through the JSON reader, because it does not
 * fit a JavaScript number in general. A count of rows arriving on screen as the text "42"
 * is wrong, so an integer that really does fit is turned back into a number, and one that
 * does not is left as a string rather than silently losing digits.
 */
const INTEGER_TYPES = new Set([
  'TINYINT', 'SMALLINT', 'INTEGER', 'BIGINT', 'HUGEINT',
  'UTINYINT', 'USMALLINT', 'UINTEGER', 'UBIGINT', 'UHUGEINT',
]);

function coerce(value: unknown, type: string): unknown {
  if (value === null || value === undefined) return null;
  if (typeof value !== 'string') return value;

  const n = Number(value);
  if (!Number.isFinite(n)) return value;

  if (INTEGER_TYPES.has(type)) {
    // Exact text round trip. Merely checking that the number is finite is not enough:
    // 9007199254740993 came back as ...992, silently.
    return String(n) === value ? n : value;
  }

  // DECIMAL(precision, scale) always arrives with exactly `scale` decimal places, so
  // "1.50" is the normal form of 1.5 and must still become a number -- money on screen
  // cannot be a string. Comparing at the column's own scale accepts that while still
  // refusing a value whose digits do not survive the conversion.
  const decimal = /^DECIMAL\((\d+),\s*(\d+)\)$/.exec(type);
  if (decimal) {
    const scale = Number(decimal[2]);
    if (scale > 100) return value;                       // toFixed cannot express it
    return n.toFixed(scale) === value ? n : value;
  }

  return value;
}

export class RunContext {
  private closed = false;
  private readonly startedAt = Date.now();
  /** Queries run one at a time. See `query`. */
  private tail: Promise<unknown> = Promise.resolve();

  private readonly instance: DuckDBInstance;
  private readonly connection: DuckDBConnection;
  readonly limits: RunLimits;

  // Written out rather than using constructor parameter properties: Node strips types
  // at runtime and refuses that syntax outright.
  private constructor(instance: DuckDBInstance, connection: DuckDBConnection, limits: RunLimits) {
    this.instance = instance;
    this.connection = connection;
    this.limits = limits;
  }

  static async create(limits: Partial<RunLimits> = {}): Promise<RunContext> {
    const l: RunLimits = { ...DEFAULT_LIMITS, ...limits };

    // Set at creation, not afterwards: several of these cannot be changed once the
    // database is running, which is exactly the property we want.
    const instance = await DuckDBInstance.create(':memory:', {
      enable_external_access: 'false',
      autoinstall_known_extensions: 'false',
      autoload_known_extensions: 'false',
      allow_unsigned_extensions: 'false',
      allow_community_extensions: 'false',
      memory_limit: `${l.memoryMb}MB`,
      threads: String(l.threads),
      // No spilling to disk. Without this, a query that exceeds the memory limit writes
      // intermediate results to a temporary directory on the host, and the temp
      // directory's own path cannot be changed once external access is off.
      max_temp_directory_size: '0MB',
      // Last on purpose. After this nothing above can be changed, by us or by anything
      // a document contains.
      lock_configuration: 'true',
    });

    let connection: DuckDBConnection;
    try {
      connection = await instance.connect();
    } catch (e) {
      // Otherwise the instance is unreachable and never released: the caller gets an
      // error and no context to close.
      try { instance.closeSync(); } catch { /* nothing more to do */ }
      throw e;
    }
    return new RunContext(instance, connection, l);
  }

  /** Milliseconds left before the whole run is out of time. */
  get remainingMs(): number {
    return Math.max(0, this.limits.runTimeoutMs - (Date.now() - this.startedAt));
  }

  /** Throws if the run is already out of time. Called between steps. */
  checkDeadline(): void {
    if (this.remainingMs === 0) throw new RunTimeoutError('run', this.limits.runTimeoutMs);
  }

  /**
   * Run one statement.
   *
   * DuckDB has no statement timeout of its own, so the timer lives here and calls
   * `interrupt()` on the connection. The connection stays usable afterwards, which is
   * what lets a run report a failed step instead of the whole process dying.
   */
  async query(sql: string, bindings: readonly DuckDBValue[] = [], timeoutMs?: number): Promise<QueryResult> {
    // One at a time. `interrupt()` acts on the connection, not on a particular
    // statement, so two overlapping queries meant one query's timer could interrupt the
    // other one -- the slow query died and the fast one reported success. Runs are
    // serialised anyway; this makes that true of the context itself rather than a
    // convention a caller has to remember.
    const mine = this.tail.then(
      () => this.runOne(sql, bindings, timeoutMs),
      () => this.runOne(sql, bindings, timeoutMs),
    );
    this.tail = mine.catch(() => undefined);
    return mine;
  }

  private async runOne(
    sql: string,
    bindings: readonly DuckDBValue[],
    timeoutMs?: number,
  ): Promise<QueryResult> {
    if (this.closed) throw new Error('this run context is closed');
    this.checkDeadline();

    const budget = Math.min(timeoutMs ?? this.limits.statementTimeoutMs, this.remainingMs);
    const startedAt = Date.now();
    let timedOut = false;
    const timer = setTimeout(() => { timedOut = true; this.connection.interrupt(); }, budget);

    /**
     * Reading and converting a large result happens on this thread and blocks the event
     * loop, so the timer cannot fire during it. Without this check a query could finish
     * after its budget and still report success -- a 500,000 row select returned in 89 ms
     * under a 20 ms budget. The deadline is therefore also checked after the work.
     */
    const enforceAfterTheFact = () => {
      if (timedOut) return;
      if (this.remainingMs === 0) throw new RunTimeoutError('run', this.limits.runTimeoutMs);
      if (Date.now() - startedAt > budget) throw new RunTimeoutError('statement', budget);
    };

    try {
      const result = bindings.length > 0
        ? await this.connection.run(sql, [...bindings])
        : await this.connection.run(sql);

      const columns: ResultColumn[] = result.columnNames().map((name, i) => ({
        name,
        type: String(result.columnTypes()[i]),
      }));
      // A result can be read only once, so this is the single reader.
      const raw = await result.getRowObjectsJson();
      enforceAfterTheFact();
      const rows = raw.map((row) => {
        const out: Record<string, unknown> = {};
        for (const c of columns) out[c.name] = coerce((row as Record<string, unknown>)[c.name], c.type);
        return out;
      });
      enforceAfterTheFact();
      return { columns, rows, durationMs: Date.now() - startedAt };
    } catch (e) {
      if (timedOut) {
        throw new RunTimeoutError(
          this.remainingMs === 0 ? 'run' : 'statement',
          this.remainingMs === 0 ? this.limits.runTimeoutMs : budget,
        );
      }
      throw e;
    } finally {
      clearTimeout(timer);
    }
  }

  /** Stop whatever is running right now. */
  interrupt(): void {
    if (!this.closed) this.connection.interrupt();
  }

  close(): void {
    if (this.closed) return;
    this.closed = true;
    try { this.connection.closeSync(); } catch { /* already gone */ }
    try { this.instance.closeSync(); } catch { /* already gone */ }
  }
}
