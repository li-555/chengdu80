import jsep from 'jsep';
import { IssueCollector, listItems, issue, type ValidationIssue } from '../validate/errors.ts';

/**
 * A formula: one line, for example `(close - open) / open`.
 *
 * Used in `filter.where`, in `derive.columns` and in alert conditions. It is parsed with
 * jsep and then walked by us. Only seven node kinds are accepted, and a function call
 * only when the name is in the list below. Identifiers resolve from a plain Map, never by
 * reading a property off a JavaScript object, so there is no prototype-pollution shape to
 * defend against.
 */

/* ------------------------------------------------------------------ *
 * jsep configuration
 * ------------------------------------------------------------------ */

/**
 * `and`, `or` and `not` are what a person writes. jsep does not know them by default.
 *
 * jsep is a singleton shared with anything else that imports it, so this only ADDS
 * operators and never removes any. An earlier version removed the bitwise operators,
 * which broke every other consumer of the parser; they are refused by the walker
 * instead, which gives the same answer without reaching outside this module.
 *
 * It also re-applies on every call rather than guarding with a flag, so that if some
 * other code removes one of these operators, the next formula still parses correctly.
 */
export function configureJsep(): void {
  jsep.addBinaryOp('and', 2);
  jsep.addBinaryOp('or', 1);
  jsep.addUnaryOp('not');
}

/* ------------------------------------------------------------------ *
 * the allow-lists
 * ------------------------------------------------------------------ */

/** Function name to its allowed argument count, and how it is written in SQL. */
type Fn = { arity: number | [number, number]; sql: (args: string[]) => string };

export const FUNCTIONS: Record<string, Fn> = {
  abs: { arity: 1, sql: (a) => `abs(${a[0]})` },
  // SQL `min`/`max` are aggregates; the row-wise forms are `least` and `greatest`.
  min: { arity: [2, 8], sql: (a) => `least(${a.join(', ')})` },
  max: { arity: [2, 8], sql: (a) => `greatest(${a.join(', ')})` },
  round: { arity: [1, 2], sql: (a) => `round(${a.join(', ')})` },
  floor: { arity: 1, sql: (a) => `floor(${a[0]})` },
  ceil: { arity: 1, sql: (a) => `ceiling(${a[0]})` },
  sqrt: { arity: 1, sql: (a) => `sqrt(${a[0]})` },
  log: { arity: 1, sql: (a) => `ln(${a[0]})` },
  exp: { arity: 1, sql: (a) => `exp(${a[0]})` },
  pow: { arity: 2, sql: (a) => `power(${a[0]}, ${a[1]})` },
  coalesce: { arity: [2, 8], sql: (a) => `coalesce(${a.join(', ')})` },
  if_null: { arity: 2, sql: (a) => `coalesce(${a[0]}, ${a[1]})` },
  clamp: { arity: 3, sql: (a) => `least(greatest(${a[0]}, ${a[1]}), ${a[2]})` },
  len: { arity: 1, sql: (a) => `length(${a[0]})` },
  upper: { arity: 1, sql: (a) => `upper(${a[0]})` },
  lower: { arity: 1, sql: (a) => `lower(${a[0]})` },
  contains: { arity: 2, sql: (a) => `(strpos(${a[0]}, ${a[1]}) > 0)` },
  starts_with: { arity: 2, sql: (a) => `starts_with(${a[0]}, ${a[1]})` },
  /**
   * `date_diff(later, earlier)` is whole days from the earlier date to the later one.
   *
   * Written as a subtraction rather than as `date_diff('day', earlier, later)`, because
   * swapping the arguments in the SQL text does NOT swap the bound values that go with
   * them: the placeholders are filled in the order the arguments were compiled, so the
   * reordered version returned the right number with the wrong sign.
   * **No function here may reorder its arguments.**
   */
  date_diff: { arity: 2, sql: (a) => `(${a[0]}::DATE - ${a[1]}::DATE)` },
};

/** Binary and logical operators, and how each is written in SQL. */
const BINARY_SQL: Record<string, string> = {
  '+': '+', '-': '-', '*': '*', '/': '/', '%': '%', '**': '^',
  '==': '=', '===': '=', '!=': '<>', '!==': '<>',
  '<': '<', '>': '>', '<=': '<=', '>=': '>=',
  '&&': 'AND', 'and': 'AND', '||': 'OR', 'or': 'OR',
};

const UNARY_SQL: Record<string, string> = { '-': '-', '+': '+', '!': 'NOT ', 'not': 'NOT ' };

/**
 * `??` is allowed but is not an infix operator in SQL: it compiles to `coalesce`.
 * It is listed here so the check and the compiler agree about what is accepted.
 */
const ALLOWED_BINARY = new Set([...Object.keys(BINARY_SQL), '??']);

/** Comparison operators, which interact badly with a word-form `not`. See the walker. */
const COMPARISON = new Set(['==', '===', '!=', '!==', '<', '>', '<=', '>=']);

/** The parameter namespace. `$params.move_threshold` is the only member access allowed. */
export const PARAMS_OBJECT = '$params';

/* ------------------------------------------------------------------ *
 * what a formula is allowed to mention
 * ------------------------------------------------------------------ */

export type ExprScope = {
  /** Column names of the step's input relation. */
  columns?: Iterable<string>;
  /** Declared parameter keys. */
  params?: Iterable<string>;
  /** Ids of earlier steps that produce a single value. */
  scalars?: Iterable<string>;
};

type Resolved = {
  /** `undefined` means "not known yet, do not check". An empty set means "nothing is declared". */
  columns: Set<string> | undefined;
  params: Set<string> | undefined;
  scalars: Set<string> | undefined;
};

const resolve = (s: ExprScope): Resolved => ({
  columns: s.columns === undefined ? undefined : new Set(s.columns),
  params: s.params === undefined ? undefined : new Set(s.params),
  scalars: s.scalars === undefined ? undefined : new Set(s.scalars),
});

/* ------------------------------------------------------------------ *
 * validation
 * ------------------------------------------------------------------ */

export type ExprProblem = { message: string; hint?: string };

/**
 * Check one formula. Returns every problem found, or an empty list.
 *
 * Scope checking is skipped for a set that was not supplied: the validator knows the
 * declared parameters long before it knows a relation's columns, and half a check is
 * better than none.
 */
export function checkExpression(expr: string, scope: ExprScope = {}): ExprProblem[] {
  configureJsep();
  const known = resolve(scope);
  const problems: ExprProblem[] = [];

  if (expr.trim() === '') {
    return [{ message: 'This formula could not be read: it is empty.', hint: 'Write a formula, for example `(close - open) / open`.' }];
  }

  let tree: jsep.Expression;
  try {
    tree = jsep(expr);
  } catch (e) {
    return [{
      message: `This formula could not be read: ${(e as Error).message}`,
      hint: 'Check for an unclosed bracket or a missing operator.',
    }];
  }

  const say = (message: string, hint?: string) => problems.push({ message, hint });

  /** Deep enough for any real formula, shallow enough that the walk cannot blow the stack. */
  const MAX_DEPTH = 100;

  const walk = (node: jsep.Expression, depth = 0): void => {
    if (depth > MAX_DEPTH) {
      say(
        `This formula is nested more than ${MAX_DEPTH} levels deep, which is too complicated to check.`,
        'Split it into two steps.',
      );
      return;
    }
    switch (node.type) {
      case 'Literal':
        return;

      case 'Identifier': {
        const name = (node as unknown as { name: string }).name;
        // Both unknown means the relation's columns are not known yet, which is the
        // normal case at validation time: a requirement is bound to a dataset later.
        if (known.columns === undefined && known.scalars === undefined) return;
        if (known.columns?.has(name) || known.scalars?.has(name)) return;
        const pool = [...(known.columns ?? []), ...(known.scalars ?? [])];
        say(
          `This formula uses "${name}", which is not a column of its data and not an earlier step.`,
          pool.length > 0
            ? `Available: ${listItems(pool)}.`
            : 'Nothing is available to this formula.',
        );
        return;
      }

      case 'MemberExpression': {
        const m = node as unknown as { computed: boolean; object: jsep.Expression; property: jsep.Expression };
        const object = m.object as unknown as { type: string; name?: string };
        const property = m.property as unknown as { type: string; name?: string };
        const isParamRead =
          !m.computed && object.type === 'Identifier' && object.name === PARAMS_OBJECT && property.type === 'Identifier';
        if (!isParamRead) {
          say(
            'A formula cannot read a property of something.',
            `The only exception is a setting, written ${PARAMS_OBJECT}.name.`,
          );
          return;
        }
        const name = property.name!;
        if (known.params !== undefined && !known.params.has(name)) {
          say(
            `This formula uses a setting called "${name}", which is not declared.`,
            known.params.size > 0
              ? `Declared settings: ${listItems(known.params)}.`
              : 'No settings are declared.',
          );
        }
        return;
      }

      case 'UnaryExpression': {
        const u = node as unknown as { operator: string; argument: jsep.Expression };
        if (!Object.hasOwn(UNARY_SQL, u.operator)) {
          say(`The operator "${u.operator}" is not allowed in a formula.`, 'Use -, + or not.');
        }
        walk(u.argument, depth + 1);
        return;
      }

      case 'BinaryExpression':
      case 'LogicalExpression': {
        const b = node as unknown as { operator: string; left: jsep.Expression; right: jsep.Expression };
        if (!ALLOWED_BINARY.has(b.operator)) {
          say(`The operator "${b.operator}" is not allowed in a formula.`, `Allowed: ${listItems(ALLOWED_BINARY, ' ')}.`);
        }
        // `not` and `!` bind tighter than a comparison in this parser, and less tightly
        // in SQL. `not a > b` therefore means `(not a) > b` here and `not (a > b)` to
        // anyone reading it. Rather than silently answering the wrong question, demand
        // the brackets.
        if (COMPARISON.has(b.operator)) {
          for (const side of [b.left, b.right]) {
            const u = side as unknown as { type: string; operator?: string };
            if (u.type === 'UnaryExpression' && (u.operator === 'not' || u.operator === '!')) {
              say(
                `"${u.operator}" next to a comparison is ambiguous, so it is not allowed without brackets.`,
                `Write it as ${u.operator} ( ... ) so it is clear what is being reversed.`,
              );
            }
          }
        }
        walk(b.left, depth + 1);
        walk(b.right, depth + 1);
        return;
      }

      case 'ConditionalExpression': {
        const c = node as unknown as { test: jsep.Expression; consequent: jsep.Expression; alternate: jsep.Expression };
        walk(c.test, depth + 1); walk(c.consequent, depth + 1); walk(c.alternate, depth + 1);
        return;
      }

      case 'CallExpression': {
        const call = node as unknown as { callee: jsep.Expression; arguments: jsep.Expression[] };
        const callee = call.callee as unknown as { type: string; name?: string };
        if (callee.type !== 'Identifier') {
          say('Only a named function may be called in a formula.', `Allowed: ${listItems(Object.keys(FUNCTIONS))}.`);
          return;
        }
        const name = callee.name!;
        if (!Object.hasOwn(FUNCTIONS, name)) {
          say(`There is no function called "${name}".`, `Allowed: ${listItems(Object.keys(FUNCTIONS))}.`);
        } else {
          const { arity } = FUNCTIONS[name]!;
          const n = call.arguments.length;
          const ok = typeof arity === 'number' ? n === arity : n >= arity[0] && n <= arity[1];
          if (!ok) {
            const want = typeof arity === 'number' ? `${arity}` : `${arity[0]} to ${arity[1]}`;
            say(`"${name}" takes ${want} values, not ${n}.`);
          }
        }
        for (const a of call.arguments) walk(a, depth + 1);
        return;
      }

      case 'ThisExpression':
        say('A formula cannot use "this".');
        return;

      case 'ArrayExpression':
        say('A formula cannot contain a list.', 'Use a setting of the list kind instead, and a filter.');
        return;

      case 'Compound':
        say(
          'This formula looks like two expressions with nothing joining them.',
          'Join them with and, or, or an arithmetic operator.',
        );
        return;

      default:
        say(`"${node.type}" is not allowed in a formula.`);
        return;
    }
  };

  const dedupe = (list: ExprProblem[]): ExprProblem[] => {
    const seen = new Set<string>();
    return list.filter((p) => (seen.has(p.message) ? false : (seen.add(p.message), true)));
  };

  try {
    walk(tree);
  } catch (e) {
    // Belt and braces: the depth cap should prevent this, but a formula from a model is
    // untrusted input and must never be able to throw out of the check.
    if (e instanceof RangeError) {
      return [{
        message: 'This formula is too complicated to check.',
        hint: 'Split it into two steps.',
      }];
    }
    throw e;
  }
  return dedupe(problems);
}

/** The same check, reported as validation issues at a given location. */
export function validateExpressionAt(
  expr: string,
  path: (string | number)[],
  scope: ExprScope = {},
): ValidationIssue[] {
  const out = new IssueCollector();
  for (const p of checkExpression(expr, scope)) {
    out.add('error', () => issue('E_BAD_EXPRESSION', path, p.message, p.hint ? { hint: p.hint } : {}));
  }
  return out.finish();
}

/* ------------------------------------------------------------------ *
 * compiling to SQL
 * ------------------------------------------------------------------ */

/** A double-quoted SQL identifier. A quote inside a name is doubled, as SQL requires. */
export function quoteIdentifier(name: string): string {
  return `"${name.replace(/"/g, '""')}"`;
}

export type CompiledExpr = { sql: string; bindings: unknown[] };

export type CompileInput = {
  /** What the formula is allowed to mention. */
  scope?: ExprScope;
  /** Resolved values of the declared settings, for every `$params.name` used. */
  params?: ReadonlyMap<string, unknown>;
  /**
   * Resolved values of earlier steps that produce a single value.
   *
   * These must be bound, not written out as column names: a scalar step's output is not
   * a column of the relation this formula runs against, so emitting its id as an
   * identifier produced SQL that referred to a column which does not exist.
   */
  scalars?: ReadonlyMap<string, unknown>;
};

/**
 * Turn a checked formula into SQL.
 *
 * Every literal, every setting value and every earlier single value becomes a `?`
 * placeholder with its value in `bindings`, so nothing from a document and nothing from
 * a person is ever pasted into SQL text. Column names become quoted identifiers, and
 * they were checked against the relation's real columns first.
 */
export function compileExpression(expr: string, input: CompileInput = {}): CompiledExpr {
  configureJsep();
  const scope = input.scope ?? {};
  const params = input.params ?? new Map<string, unknown>();
  const scalars = input.scalars ?? new Map<string, unknown>();

  const problems = checkExpression(expr, scope);
  if (problems.length > 0) {
    throw new Error(`refusing to compile an invalid formula: ${problems[0]!.message}`);
  }

  const scalarNames = new Set(scope.scalars ?? scalars.keys());
  const bindings: unknown[] = [];
  const bind = (value: unknown): string => { bindings.push(value); return '?'; };

  const sqlFor = (node: jsep.Expression): string => {
    switch (node.type) {
      case 'Literal':
        return bind((node as unknown as { value: unknown }).value);

      case 'Identifier': {
        const name = (node as unknown as { name: string }).name;
        if (scalarNames.has(name)) {
          if (!scalars.has(name)) throw new Error(`no value supplied for the earlier step "${name}"`);
          return bind(scalars.get(name));
        }
        return quoteIdentifier(name);
      }

      case 'MemberExpression': {
        const name = ((node as unknown as { property: { name: string } }).property).name;
        if (!params.has(name)) throw new Error(`no value supplied for the setting "${name}"`);
        return bind(params.get(name));
      }

      case 'UnaryExpression': {
        const u = node as unknown as { operator: string; argument: jsep.Expression };
        return `(${UNARY_SQL[u.operator]}${sqlFor(u.argument)})`;
      }

      case 'BinaryExpression':
      case 'LogicalExpression': {
        const b = node as unknown as { operator: string; left: jsep.Expression; right: jsep.Expression };
        if (b.operator === '??') return `coalesce(${sqlFor(b.left)}, ${sqlFor(b.right)})`;
        return `(${sqlFor(b.left)} ${BINARY_SQL[b.operator]} ${sqlFor(b.right)})`;
      }

      case 'ConditionalExpression': {
        const c = node as unknown as { test: jsep.Expression; consequent: jsep.Expression; alternate: jsep.Expression };
        return `(CASE WHEN ${sqlFor(c.test)} THEN ${sqlFor(c.consequent)} ELSE ${sqlFor(c.alternate)} END)`;
      }

      case 'CallExpression': {
        const call = node as unknown as { callee: { name: string }; arguments: jsep.Expression[] };
        // Arguments are compiled left to right and each `sql` builder must use them in
        // that same order, because a placeholder is filled by position. See date_diff.
        return FUNCTIONS[call.callee.name]!.sql(call.arguments.map(sqlFor));
      }

      default:
        throw new Error(`cannot compile a ${node.type}`);
    }
  };

  return { sql: sqlFor(jsep(expr)), bindings };
}

/**
 * The bare names a formula reads: columns and earlier single-value steps.
 *
 * Read from the parsed tree, so a name inside quotes, a function name and the `x` of
 * `$params.x` are not counted. The run loop uses this to order a step after the
 * single-value steps it reads; matching names in the raw text had added false edges and
 * turned valid applications into circular ones. A formula that does not parse gives no
 * names: the validator reports it, and the step then fails on its own.
 */
export function identifiersOf(expr: string): string[] {
  configureJsep();
  let tree: jsep.Expression;
  try {
    tree = jsep(expr);
  } catch {
    return [];
  }

  const found = new Set<string>();
  const walk = (node: unknown, depth: number): void => {
    if (!node || typeof node !== 'object' || depth > 100) return;
    const n = node as Record<string, unknown>;
    switch (n.type) {
      case 'Identifier':
        found.add(String(n.name));
        return;
      case 'MemberExpression':
        return; // only `$params.x` is legal, and it names a setting, not a step
      case 'CallExpression':
        for (const a of (n.arguments as unknown[]) ?? []) walk(a, depth + 1);
        return;
      default:
        for (const key of ['left', 'right', 'argument', 'test', 'consequent', 'alternate']) {
          walk(n[key], depth + 1);
        }
        if (Array.isArray(n.body)) for (const b of n.body) walk(b, depth + 1);
    }
  };
  walk(tree, 0);
  return [...found];
}
