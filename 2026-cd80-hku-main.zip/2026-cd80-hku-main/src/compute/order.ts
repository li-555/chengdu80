/**
 * What order the steps run in.
 *
 * Every step produces a named relation and every reference is a relation name, so the
 * order is a topological sort of those references. Two properties matter beyond
 * correctness, and both are deliberate:
 *
 *  - **Steps with nothing left to wait for run in declaration order.** Without that tie
 *    break the order could differ between two runs of the same document, and comparing
 *    two runs — which C08 promises — would compare different things.
 *  - **A cycle is reported before anything runs**, naming the steps involved, so the
 *    person sees a located error rather than a run that half-finishes.
 */

export type OrderableStep = {
  id: string;
  /** Relation names this step reads. */
  deps: readonly string[];
};

export class OrderError extends Error {
  readonly ids: string[];
  constructor(message: string, ids: string[]) {
    super(message);
    this.name = 'OrderError';
    this.ids = ids;
  }
}

/**
 * Sort steps so that every step comes after the steps it reads.
 *
 * `provided` is the set of relation names that exist before any step runs — the data
 * requirements. A dependency that is neither provided nor produced by a step is an
 * error: it is a reference to something that will never exist.
 */
export function orderSteps(
  steps: readonly OrderableStep[],
  provided: Iterable<string> = [],
): OrderableStep[] {
  const produced = new Map<string, number>();
  steps.forEach((s, i) => {
    if (produced.has(s.id)) {
      throw new OrderError(`two steps are both called '${s.id}'`, [s.id]);
    }
    produced.set(s.id, i);
  });

  const available = new Set<string>();
  for (const name of provided) available.add(name);

  for (const s of steps) {
    if (available.has(s.id)) {
      throw new OrderError(
        `step '${s.id}' has the same name as a data requirement`,
        [s.id],
      );
    }
    for (const dep of s.deps) {
      if (dep === s.id) {
        throw new OrderError(`step '${s.id}' reads itself`, [s.id]);
      }
      if (!available.has(dep) && !produced.has(dep)) {
        throw new OrderError(
          `step '${s.id}' reads '${dep}', which nothing provides`,
          [s.id],
        );
      }
    }
  }

  const remaining = new Set(steps.map((s) => s.id));
  const done = new Set(available);
  const out: OrderableStep[] = [];

  while (remaining.size > 0) {
    /**
     * The FIRST ready step in declaration order, then readiness is recomputed.
     *
     * Taking a whole batch of ready steps before recomputing broke the very guarantee
     * above: with `a` depending on `b`, and `c` independent, finishing `b` made both `a`
     * and `c` ready, but the batch had already been fixed and `c` ran first. Found in
     * review, 2026-10-14.
     */
    const ready = steps.filter(
      (s) => remaining.has(s.id) && s.deps.every((d) => done.has(d)),
    ).slice(0, 1);

    if (ready.length === 0) {
      // Everything left is waiting on something else that is also left: a cycle.
      const stuck = steps.filter((s) => remaining.has(s.id)).map((s) => s.id);
      throw new OrderError(
        `these steps depend on each other in a circle: ${stuck.join(', ')}`,
        stuck,
      );
    }

    for (const s of ready) {
      out.push(s);
      remaining.delete(s.id);
      done.add(s.id);
    }
  }

  return out;
}
