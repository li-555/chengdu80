/** Bind application fields to datasets and return rows in the shape a run reads. */
import type { AppDocument } from '../app-schema/index.ts';
import type { DataRequirement, RequirementFilter } from '../app-schema/data.ts';
import type { FieldType } from '../app-schema/fields.ts';
import { getDataset, isTradingDay, resolveSlice, type Dataset, type FieldSpec } from '../data/index.ts';
import { resolveParams, type Slice } from './run.ts';

export type SourceRecord = {
  key: string;
  datasetId: string;
  datasetSource: Dataset['source'];
  fields: { app: string; dataset: string }[];
  filtersSentToProvider: Record<string, unknown>;
  filtersAppliedAfter: string[];
  dateFrom?: string;
  dateTo?: string;
  rows: number;
  asOfDate?: string;
  datasetVersion: string;
  durationMs: number;
  warnings: string[];
};

export class NeedsBindingError extends Error {
  readonly problems: { key: string; datasetId?: string }[];

  constructor(problems: { key: string; datasetId?: string }[]) {
    super(`Choose a dataset for: ${problems.map((p) => p.datasetId === undefined ? p.key : `${p.key} (unknown dataset '${p.datasetId}')`).join(', ')}`);
    this.name = 'NeedsBindingError';
    this.problems = problems;
  }
}

export class NeedsMappingError extends Error {
  readonly problems: { key: string; field: string; suggestions: string[] }[];

  constructor(problems: { key: string; field: string; suggestions: string[] }[]) {
    super(`Match required fields: ${problems.map((p) => `${p.key}.${p.field} (available: ${p.suggestions.join(', ') || 'none'})`).join('; ')}`);
    this.name = 'NeedsMappingError';
    this.problems = problems;
  }
}

export type FetchSlicesOptions = {
  params?: Record<string, unknown>;
  bindings?: Record<string, string>;
  mappings?: Record<string, Record<string, string>>;
  today?: string;
  deps?: {
    resolve?: typeof resolveSlice;
    getDataset?: typeof getDataset;
    isTradingDay?: typeof isTradingDay;
  };
};

const SEMANTIC_FIELDS: Record<string, string> = { security_code: 'ts_code', trade_date: 'trade_date' };

/** Check every binding and mapping before reading rows; read requirements in order. */
export async function fetchSlicesFor(
  doc: AppDocument,
  options: FetchSlicesOptions = {},
): Promise<{ slices: Record<string, Slice>; sources: SourceRecord[] }> {
  const resolve = options.deps?.resolve ?? resolveSlice;
  const lookup = options.deps?.getDataset ?? getDataset;
  const calendar = options.deps?.isTradingDay ?? isTradingDay;
  const params = resolveParams({ params: doc.params }, options.params);
  const bindings: { req: DataRequirement; dataset: Dataset }[] = [];
  const unbound: NeedsBindingError['problems'] = [];
  for (const req of doc.data) {
    const datasetId = options.bindings?.[req.key] ?? req.datasetHint;
    const dataset = datasetId === undefined ? null : await lookup(datasetId);
    if (!dataset) unbound.push({ key: req.key, ...(datasetId === undefined ? {} : { datasetId }) });
    else bindings.push({ req, dataset });
  }
  if (unbound.length) throw new NeedsBindingError(unbound);
  const unmatched: NeedsMappingError['problems'] = [];
  const matched = bindings.map(({ req, dataset }) => {
    const fields = req.fields.map((app) => {
      const explicit = options.mappings?.[req.key]?.[app.name];
      const field = explicit !== undefined
        ? dataset.fields.find((f) => f.name === explicit)
        : dataset.fields.find((f) => f.name.toLowerCase() === app.name.toLowerCase())
          ?? dataset.fields.find((f) => f.name === SEMANTIC_FIELDS[app.semantic ?? '']);
      if (!field && app.required) {
        unmatched.push({ key: req.key, field: app.name, suggestions: dataset.fields.map((f) => f.name) });
      }
      return { app, field };
    });
    return { req, dataset, fields };
  });
  if (unmatched.length) throw new NeedsMappingError(unmatched);

  const today = options.today ?? new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Asia/Shanghai', year: 'numeric', month: '2-digit', day: '2-digit',
  }).format(new Date());
  const plans = [];
  for (const match of matched) {
    const { req, fields } = match;
    const dates: { dateFrom?: string; dateTo?: string } = {};
    if (req.window) {
      if (!req.fields.some((f) => f.name === req.window!.field)) {
        throw new Error(`${req.key}: window field '${req.window.field}' is not a requirement field`);
      }
      dates.dateTo = today;
      dates.dateFrom = await windowStart(today, req.window.lookbackDays, calendar, req.key);
    }
    const filter: Record<string, string | number> = {};
    const after: { spec: RequirementFilter; value: unknown; type: FieldType }[] = [];
    const descriptions: string[] = [];
    for (const spec of req.filters ?? []) {
      const value = params.get(spec.param);
      if (value === undefined || value === null || (Array.isArray(value) && value.length === 0)) {
        if (spec.field === 'ts_code' && ['tushare:income', 'tushare:cashflow', 'tushare:balancesheet'].includes(match.dataset.id)) {
          throw new Error(`${req.key}: enter at least one Tushare stock code`);
        }
        descriptions.push(`skipped: ${spec.field} has no value`);
        continue;
      }
      const field = fields.find((f) => f.app.name === spec.field);
      if (!field) throw new Error(`${req.key}: filter field '${spec.field}' is not a requirement field`);
      if (spec.op === 'in' || spec.op === 'not_in') {
        if (!Array.isArray(value)) throw new Error(`${req.key}: ${spec.field} ${spec.op} needs a list`);
      }
      if (match.dataset.source === 'tushare' && field.field?.name === 'ts_code' && (spec.op === 'eq' || spec.op === 'in')) {
        const values = spec.op === 'in' ? value as unknown[] : [value];
        if (!values.every((v) => typeof v === 'string' && /^[0-9A-Za-z.]{1,20}$/.test(v))) {
          throw new Error(`${req.key}: ${spec.field} contains an invalid security code`);
        }
        if (values.length > 20 && ['tushare:income', 'tushare:cashflow', 'tushare:balancesheet'].includes(match.dataset.id)) throw new Error(`${req.key}: choose at most 20 security codes`);
        if (!Object.hasOwn(filter, 'ts_code')) {
          filter.ts_code = values.join(',');
          continue;
        }
      }
      // Tushare's statement bounds refer to publication dates, not period ends.
      // Keep the local predicate as well, including when a provider ignores a bound.
      const providerDate: Record<string, string> = {
        'tushare:daily': 'trade_date', 'tushare:adj_factor': 'trade_date',
        'tushare:daily_basic': 'trade_date', 'tushare:fund_nav': 'nav_date',
        'tushare:income': 'ann_date', 'tushare:cashflow': 'ann_date', 'tushare:balancesheet': 'ann_date',
      };
      if (field.app.type === 'date' && field.field?.name === providerDate[match.dataset.id]
        && (spec.op === 'gte' || spec.op === 'lte')) {
        const date = typeof value === 'string' ? dateValue(value) : null;
        if (!date) throw new Error(`${req.key}: ${spec.field} needs a valid date`);
        if (spec.op === 'gte' && (!dates.dateFrom || date > dates.dateFrom)) dates.dateFrom = date;
        if (spec.op === 'lte' && (!dates.dateTo || date < dates.dateTo)) dates.dateTo = date;
      }
      after.push({ spec, value, type: field.app.type });
      const op = { eq: '=', neq: '!=', gt: '>', gte: '>=', lt: '<', lte: '<=' };
      descriptions.push(`${spec.field} ${op[spec.op as keyof typeof op] ?? spec.op} ${Array.isArray(value) ? JSON.stringify(value) : String(value)}`);
    }
    if (dates.dateFrom && dates.dateTo && dates.dateFrom > dates.dateTo) throw new Error(`${req.key}: the start date must not follow the end date`);
    plans.push({ ...match, dates, filter, after, descriptions });
  }

  const slices: Record<string, Slice> = {};
  const sources: SourceRecord[] = [];
  for (const { req, dataset, fields, dates, filter, after, descriptions } of plans) {
    const started = Date.now();
    let fetched;
    try {
      const request = {
        datasetId: dataset.id,
        fields: [...new Set(fields.flatMap((f) => f.field ? [f.field.name] : []))],
        ...dates, ...(dataset.source === 'tushare' ? { filter } : {}),
      };
      // Statement and reference endpoints accept one code per request.
      const singleCode = ['tushare:income', 'tushare:cashflow', 'tushare:balancesheet',
        'tushare:stock_basic', 'tushare:adj_factor', 'tushare:daily_basic', 'tushare:fund_nav'].includes(dataset.id);
      const codes = String(filter.ts_code ?? '').split(',');
      if (singleCode && codes.length > 1) {
        if (codes.length > 20) throw new Error('Choose at most 20 security codes.');
        for (const code of codes) {
          const part = await resolve({ ...request, filter: { ...filter, ts_code: code } });
          if (!fetched) fetched = { ...part, rows: [...part.rows] };
          else {
            if (JSON.stringify(fetched.schema) !== JSON.stringify(part.schema)) throw new Error('Provider columns changed between security codes.');
            if (fetched.rows.length + part.rows.length > 200000) throw new Error('Too many rows; narrow the security codes or dates.');
            fetched.rows.push(...part.rows);
            if (part.asOfDate && (!fetched.asOfDate || part.asOfDate > fetched.asOfDate)) fetched.asOfDate = part.asOfDate;
          }
        }
      } else fetched = await resolve(request);
      if (!fetched) throw new Error('No data request could be made.');
    } catch (e) {
      throw new Error(`${req.key}: ${e instanceof Error ? e.message : String(e)}`, { cause: e });
    }
    const schema = new Map(fetched.schema.map((f, i) => [f.name, i]));
    const lost = new Map<string, number>();
    const rows = fetched.rows.map((row) => Object.fromEntries(fields.map(({ app, field }) => {
      const index = field ? schema.get(field.name) : undefined;
      const raw = index === undefined ? null : row[index];
      const value = convert(raw, app.type);
      if (raw !== undefined && raw !== null && value === null) lost.set(app.name, (lost.get(app.name) ?? 0) + 1);
      return [app.name, value];
    }))).filter((row) => after.every(({ spec, value, type }) => accepts(row[spec.field], value, spec.op, type)));
    slices[req.key] = {
      columns: fields.map(({ app }) => ({ name: app.name, type: app.type === 'text' ? 'string' : app.type })),
      rows,
    };
    sources.push({
      key: req.key, datasetId: dataset.id, datasetSource: dataset.source,
      fields: fields.flatMap(({ app, field }) => field ? [{ app: app.name, dataset: field.name }] : []),
      filtersSentToProvider: { ...filter }, filtersAppliedAfter: descriptions,
      ...dates, rows: rows.length,
      ...(fetched.asOfDate === undefined ? {} : { asOfDate: fetched.asOfDate }),
      datasetVersion: fetched.datasetVersion, durationMs: Date.now() - started,
      warnings: [...lost].map(([name, count]) => `${name}: ${count} value(s) could not be read as ${req.fields.find((f) => f.name === name)!.type}; converted to null`),
    });
  }
  return { slices, sources };
}

function dateValue(value: string): string | null {
  const date = /^\d{8}$/.test(value) ? `${value.slice(0, 4)}-${value.slice(4, 6)}-${value.slice(6)}` : value;
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return null;
  const time = Date.parse(`${date}T00:00:00Z`);
  return Number.isFinite(time) && new Date(time).toISOString().slice(0, 10) === date ? date : null;
}

function convert(value: unknown, type: FieldSpec['type']): string | number | boolean | null {
  if (value === undefined || value === null) return null;
  switch (type) {
    case 'text': return ['string', 'number', 'boolean'].includes(typeof value) ? String(value) : null;
    case 'number': {
      if (typeof value !== 'number' && typeof value !== 'string') return null;
      if (typeof value === 'string' && value.trim() === '') return null;
      const number = Number(value);
      return Number.isFinite(number) ? number : null;
    }
    case 'date': return typeof value === 'string' ? dateValue(value) : null;
    case 'boolean':
      if (typeof value === 'boolean') return value;
      if (value === 1 || value === '1' || value === 'true') return true;
      if (value === 0 || value === '0' || value === 'false') return false;
      return null;
  }
}

async function windowStart(today: string, count: number, calendar: typeof isTradingDay, key: string): Promise<string> {
  if (dateValue(today) !== today) throw new Error(`${key}: today must be a YYYY-MM-DD date`);
  if (!Number.isInteger(count) || count < 1 || count > 3650) throw new Error(`${key}: invalid window lookbackDays`);
  let cursor = today;
  const bound = count * 2 + 30;
  for (let i = 0; i < bound; i++) {
    if (await calendar(cursor) && --count === 0) return cursor;
    cursor = new Date(Date.parse(`${cursor}T00:00:00Z`) - 86_400_000).toISOString().slice(0, 10);
  }
  throw new Error(`${key}: could not find the window start within ${bound} calendar days`);
}

function accepts(raw: unknown, value: unknown, op: RequirementFilter['op'], type: FieldType): boolean {
  if (raw === null || raw === undefined) return false;
  const left = convert(raw, type);
  const right = convert(value, type);
  if (op === 'in' || op === 'not_in') {
    const found = (value as unknown[]).some((v) => left === convert(v, type));
    return op === 'in' ? found : !found;
  }
  if (op === 'contains') return String(raw).toLowerCase().includes(String(value).toLowerCase());
  if (left === null || right === null) return false;
  switch (op) {
    case 'eq': return left === right;
    case 'neq': return left !== right;
    case 'gt': return left > right;
    case 'gte': return left >= right;
    case 'lt': return left < right;
    case 'lte': return left <= right;
  }
}
