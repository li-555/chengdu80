/**
 * Carrying out an application.
 *
 * Data in, steps in dependency order, relations out. The run owns one locked-down
 * in-memory database and closes it whatever happens, so a failed run leaks neither
 * memory nor a connection.
 *
 * A step that fails does not abort the run silently: the failure is recorded against
 * that step, the run's status becomes `failed`, and every step that already succeeded
 * keeps its result so the Inspect panel has something to show.
 */

import { RunContext, type QueryResult, type ResultColumn } from './context.ts';
import { createRelationFromRows, type IngestColumn } from './ingest.ts';
import { orderSteps, OrderError, type OrderableStep } from './order.ts';
import { checkSqlStep } from './sql.ts';
import { OPERATIONS, RUNNERS, OpCompileError, type CompiledStep, type OpCompileInput } from './ops/index.ts';
import { OPERATION_SHAPE } from '../app-schema/operations.ts';
import { checkExpression, compileExpression, identifiersOf, quoteIdentifier } from './expr.ts';
import type { LanguageModel } from 'ai';
import type { FieldType } from '../app-schema/fields.ts';
import { runAi, type AiBudget } from './ai.ts';
import { runCode } from './code.ts';
import { configuredModelName } from '../platform/model.ts';

/** A resolved data slice: the rows a requirement bound to. */
export type Slice = { columns: readonly IngestColumn[]; rows: readonly Record<string, unknown>[] };

export type StepRecord = {
  id: string;
  kind: string;
  op?: string;
  rowsOut: number;
  durationMs: number;
  failed?: string;
  model?: string;
  warnings?: string[];
  logs?: string[];
};

export type RunOutcome = {
  status: 'ok' | 'partial' | 'failed';
  steps: StepRecord[];
  /** The columns of every relation the run created, for inspection and for the screen. */
  relations: Map<string, readonly ResultColumn[]>;
  /** The rows of the relations that were asked for. */
  results: Map<string, QueryResult>;
  params: Map<string, unknown>;
  warnings: string[];
  failure?: string;
  newState?: Record<string, unknown>;
};

type Doc = {
  params?: { key: string; type: string; default?: unknown; list?: boolean }[];
  data?: { key: string }[];
  compute?: {
    id: string;
    kind: string;
    op?: string;
    input?: string | string[];
    params?: Record<string, unknown>;
    sql?: string;
    expr?: string;
    body?: string;
    carry_state?: boolean;
    output?: { columns: { name: string; type: FieldType }[] };
    key?: boolean;
  }[];
};

/** Settings, resolved in the order the specification sets out: given, then default. */
export function resolveParams(
  doc: Doc,
  given: Record<string, unknown> = {},
): Map<string, unknown> {
  const out = new Map<string, unknown>();
  for (const decl of doc.params ?? []) {
    out.set(decl.key, decl.key in given ? given[decl.key] : decl.default);
  }
  return out;
}

/** The relations a step takes as inputs: `input`, plus `join`'s right side. */
function declaredInputs(step: NonNullable<Doc['compute']>[number]): string[] {
  const out = typeof step.input === 'string' ? [step.input] : Array.isArray(step.input) ? [...step.input] : [];
  const right = step.params?.right;
  if (step.op === 'join' && typeof right === 'string' && !out.includes(right)) out.push(right);
  return out;
}

/** What relations a step reads. */
function depsOf(step: NonNullable<Doc['compute']>[number]): string[] {
  const deps: string[] = [];
  if (typeof step.input === 'string') deps.push(step.input);
  else if (Array.isArray(step.input)) deps.push(...step.input);

  // `join`, `adjust_price` and `factor` name a second relation in their parameters
  // rather than in `input`.
  for (const key of ['right', 'factor_table', 'universe']) {
    const extra = step.params?.[key];
    if (typeof extra === 'string' && !deps.includes(extra)) deps.push(extra);
  }

  return deps;
}

/** Whether a relation also supplies a value to later formulas. */
function isScalarStep(step: NonNullable<Doc['compute']>[number]): boolean {
  return step.kind === 'expression'
    || (step.kind === 'ai' && step.params?.mode === 'whole' && (step.params?.output as { kind?: string })?.kind === 'text')
    || (step.kind === 'operation' && !!step.op && OPERATION_SHAPE[step.op as keyof typeof OPERATION_SHAPE]?.output === 'scalar');
}

/**
 * Single-value steps a step's formulas name. They are not inputs, but they must run first:
 * without this edge a formula declared before the `irr` it reads ran first and failed
 * with an unknown name. Only ids of single-value steps count, so a column that happens to
 * share a step's name adds no false dependency.
 */
function scalarRefs(
  step: NonNullable<Doc['compute']>[number],
  all: NonNullable<Doc['compute']>,
): string[] {
  const scalarIds = new Set(all.filter(isScalarStep).map((s) => s.id));
  if (scalarIds.size === 0) return [];

  const formulas: string[] = [];
  if (step.kind === 'expression' && typeof step.expr === 'string') formulas.push(step.expr);
  const where = step.params?.where;
  if (typeof where === 'string') formulas.push(where);
  const cols = step.params?.columns;
  if (cols && typeof cols === 'object' && !Array.isArray(cols)) {
    for (const v of Object.values(cols)) if (typeof v === 'string') formulas.push(v);
  }

  const found = new Set<string>();
  for (const f of formulas) {
    for (const name of identifiersOf(f)) {
      if (scalarIds.has(name)) found.add(name);
    }
  }
  return [...found];
}

export async function runApplication(
  doc: Doc,
  options: {
    slices: Record<string, Slice>;
    params?: Record<string, unknown>;
    /** Relation names whose rows the caller wants back. Defaults to every step marked `key`. */
    want?: string[];
    model?: LanguageModel;
    signal?: AbortSignal;
    carriedState?: Record<string, unknown>;
  },
): Promise<RunOutcome> {
  const params = resolveParams(doc, options.params);
  const steps = doc.compute ?? [];
  const warnings: string[] = [];
  const records: StepRecord[] = [];
  let newState: Record<string, unknown> | undefined;
  const relations = new Map<string, readonly ResultColumn[]>();
  const results = new Map<string, QueryResult>();

  const controller = new AbortController();
  const signal = options.signal ? AbortSignal.any([options.signal, controller.signal]) : controller.signal;
  const budget: AiBudget = { elapsedMs: 0, signal };
  const ctx = await RunContext.create();
  const runTimer = setTimeout(() => controller.abort(new Error('The run exceeded its time limit')), ctx.remainingMs);

  try {
    if (steps.filter((s) => s.kind === 'ai').length > 4) {
      return { status: 'failed', steps: records, relations, results, params, warnings,
        failure: 'E_LIMIT_AI_STEPS at compute: a run may have at most 4 AI steps' };
    }

    if (steps.filter((s) => s.kind === 'code').length > 1) {
      return { status: 'failed', steps: records, relations, results, params, warnings,
        failure: 'E_LIMIT_CODE_STEPS at compute: a run may have at most 1 code step' };
    }

    const scalarIds = steps.filter(isScalarStep).map((s) => s.id);
    for (const [index, step] of steps.entries()) {
      if (step.kind !== 'expression') continue;
      const problems = checkExpression(step.expr ?? '', { columns: [], params: [...params.keys()], scalars: scalarIds });
      if (problems.length > 0) {
        return { status: 'failed', steps: records, relations, results, params, warnings,
          failure: `step '${step.id}'.expr: expressions may read settings and single values only; ${problems[0]!.message} (compute[${index}].expr)` };
      }
    }

    // ---- data in
    for (const req of doc.data ?? []) {
      const slice = options.slices[req.key];
      if (!slice) {
        return {
          status: 'failed', steps: records, relations, results, params, warnings,
          failure: `no data was bound to '${req.key}'`,
        };
      }
      const loaded = await createRelationFromRows(ctx, req.key, slice.columns, slice.rows);
      relations.set(req.key, slice.columns.map((c) => ({ name: c.name, type: c.type })));
      for (const [column, lost] of Object.entries(loaded.coercedToNull)) {
        warnings.push(`${lost} value(s) in '${req.key}.${column}' could not be read and are blank`);
      }
    }

    // ---- order
    let ordered: OrderableStep[];
    try {
      ordered = orderSteps(
        steps.map((s) => ({ id: s.id, deps: [...depsOf(s), ...scalarRefs(s, steps)] })),
        relations.keys(),
      );
    } catch (e) {
      return {
        status: 'failed', steps: records, relations, results, params, warnings,
        failure: e instanceof OrderError ? e.message : String(e),
      };
    }

    // ---- run
    const byId = new Map(steps.map((s) => [s.id, s]));
    /** Single values produced so far (e.g. `irr`), usable by id in later formulas. */
    const scalars = new Map<string, unknown>();

    for (const { id } of ordered) {
      const step = byId.get(id);
      if (!step) continue;

      const t0 = Date.now();
      const detail: Pick<StepRecord, 'model' | 'warnings' | 'logs'> = step.kind === 'ai' ? { model: configuredModelName() } : {};
      if (step.kind === 'code') detail.logs = [];
      try {
        ctx.checkDeadline();
        signal.throwIfAborted();
        if (step.kind === 'ai') {
          const input = declaredInputs(step)[0];
          if (!input) throw new OpCompileError('a model step needs one input');
          const source = quoteIdentifier(input);
          const read = await ctx.query(`SELECT * FROM ${source} LIMIT 200`);
          const count = await ctx.query(`SELECT count(*) AS n FROM ${source}`);
          const answer = await runAi(step.params, read.rows, Number(count.rows[0]?.n ?? 0), params, budget, options.model);
          detail.model = answer.model;
          detail.warnings = answer.warnings;
          warnings.push(...answer.warnings.map((w) => `step '${id}': ${w}`));
          const perRow = step.params?.mode === 'per_row';
          if (perRow) {
            const names = new Set(read.columns.map((c) => c.name.toLowerCase()));
            if (answer.columns.some((c) => names.has(c.name.toLowerCase()))) throw new OpCompileError('output columns overlap input columns');
          }
          await createRelationFromRows(ctx, id, answer.columns, answer.rows);
          if (perRow) {
            // Match by position, so duplicate input keys cannot multiply rows.
            let scratch = 'step_output';
            while (relations.has(scratch) || steps.some((s) => s.id === scratch)) scratch += '_';
            await ctx.query(`ALTER TABLE ${quoteIdentifier(id)} RENAME TO ${quoteIdentifier(scratch)}`);
            let ordinal = '__row';
            while (read.columns.some((c) => c.name.toLowerCase() === ordinal) || answer.columns.some((c) => c.name.toLowerCase() === ordinal)) ordinal += '_';
            const q = quoteIdentifier(ordinal);
            const left = read.columns.map((c) => `a.${quoteIdentifier(c.name)}`);
            const right = answer.columns.map((c) => `b.${quoteIdentifier(c.name)}`);
            await ctx.query(`CREATE TABLE ${quoteIdentifier(id)} AS SELECT ${[...left, ...right].join(', ')}
              FROM (SELECT *, row_number() OVER () AS ${q} FROM ${source}) a
              LEFT JOIN (SELECT *, row_number() OVER () AS ${q} FROM ${quoteIdentifier(scratch)}) b USING (${q})
              ORDER BY a.${q}`);
            await ctx.query(`DROP TABLE ${quoteIdentifier(scratch)}`);
          }
        } else if (step.kind === 'code') {
          if (!step.body || !step.output) throw new OpCompileError('code body and output columns are required');
          const names = declaredInputs(step);
          if (names.length < 1 || names.length > 3) throw new OpCompileError('code needs one to three inputs');
          const input: Record<string, Record<string, unknown>[]> = Object.create(null);
          for (const name of names) {
            input[name] = (await ctx.query(`SELECT * FROM ${quoteIdentifier(name)} LIMIT 50001`)).rows;
          }
          const columns: IngestColumn[] = step.output.columns.map((c) => ({ name: c.name, type: c.type === 'text' ? 'string' : c.type }));
          const answer = await runCode({
            input, params, columns, body: step.body,
            carryState: step.carry_state ?? false, state: options.carriedState, signal, logs: detail.logs!,
          });
          detail.warnings = answer.warnings;
          warnings.push(...answer.warnings.map((w) => `step '${id}': ${w}`));
          const loaded = await createRelationFromRows(ctx, id, columns, answer.rows);
          for (const [column, lost] of Object.entries(loaded.coercedToNull)) {
            warnings.push(`${lost} value(s) in '${id}.${column}' could not be read and are blank`);
          }
          newState = answer.state;
        } else {
          const sql = await compileStep(ctx, step, relations, params, scalars);
          await ctx.query(`CREATE TABLE ${quoteIdentifier(id)} AS ${sql.sql}`, sql.bindings as never[]);
        }

        const shape = await ctx.query(`SELECT * FROM "${id.replace(/"/g, '""')}" LIMIT 0`);
        relations.set(id, shape.columns);

        const counted = await ctx.query(`SELECT count(*) AS n FROM "${id.replace(/"/g, '""')}"`);

        if (isScalarStep(step)) {
          const one = await ctx.query(`SELECT * FROM "${id.replace(/"/g, '""')}" LIMIT 2`);
          const col = one.columns[0]?.name;
          if (one.rows.length !== 1 || one.columns.length !== 1 || col === undefined) {
            throw new OpCompileError(`step '${id}' should produce one value, but produced ${one.rows.length} row(s) of ${one.columns.length} column(s)`);
          }
          scalars.set(id, one.rows[0]![col]);
        }
        records.push({
          id, kind: step.kind, op: step.op, ...detail,
          rowsOut: Number(counted.rows[0]?.n ?? 0),
          durationMs: Date.now() - t0,
        });
      } catch (e) {
        records.push({
          id, kind: step.kind, op: step.op, ...detail, rowsOut: 0,
          durationMs: Date.now() - t0,
          failed: e instanceof Error ? e.message : String(e),
        });
        return {
          status: 'failed', steps: records, relations, results, params, warnings,
          failure: `step '${id}' failed: ${e instanceof Error ? e.message : String(e)}`,
        };
      }
    }

    // ---- what the caller asked for
    const want = options.want ?? steps.filter((s) => s.key).map((s) => s.id);
    for (const name of want) {
      if (!relations.has(name)) {
        warnings.push(`nothing produced a relation called '${name}'`);
        continue;
      }
      results.set(name, await ctx.query(`SELECT * FROM "${name.replace(/"/g, '""')}"`));
    }

    return {
      status: warnings.length > 0 ? 'partial' : 'ok',
      steps: records, relations, results, params, warnings,
      ...(newState === undefined ? {} : { newState }),
    };
  } finally {
    clearTimeout(runTimer);
    controller.abort();
    ctx.close();
  }
}

/**
 * Check a step's SQL in a database that contains only the relations it declared.
 *
 * The tables are created empty and the statement is only prepared, never run, so this is
 * a parse-and-bind check and nothing more.
 */
async function checkSqlInIsolation(
  sql: string,
  declared: readonly string[],
  relations: Map<string, readonly ResultColumn[]>,
): Promise<{ message: string; hint?: string }[]> {
  const scratch = await RunContext.create();
  try {
    for (const name of declared) {
      const columns = relations.get(name);
      if (!columns) {
        return [{
          message: `step reads '${name}', which the run has not created`,
          hint: 'name a data requirement key or an earlier step id',
        }];
      }
      const decls = columns
        .map((c) => `"${c.name.replaceAll('"', '""')}" ${safeTypeName(c.type)}`)
        .join(', ');
      await scratch.query(`CREATE TABLE "${name.replaceAll('"', '""')}" (${decls})`);
    }
    return await checkSqlStep((scratch as unknown as { connection: never }).connection, sql);
  } finally {
    scratch.close();
  }
}

/**
 * A column type name, reduced to something that cannot carry syntax.
 *
 * The names come from the engine's own description of a relation it already built, but
 * they are written into a CREATE TABLE here, so anything unexpected becomes VARCHAR
 * rather than being trusted.
 */
function safeTypeName(type: string): string {
  if (type === 'number') return 'DOUBLE';
  if (type === 'string') return 'VARCHAR';
  return /^[A-Za-z][A-Za-z0-9 _]*(\(\d+(,\s*\d+)?\))?$/.test(type) ? type : 'VARCHAR';
}

async function compileStep(
  ctx: RunContext,
  step: NonNullable<Doc['compute']>[number],
  relations: Map<string, readonly ResultColumn[]>,
  params: Map<string, unknown>,
  scalars: Map<string, unknown>,
): Promise<{ sql: string; bindings: unknown[] }> {
  if (step.kind === 'expression') {
    if (typeof step.expr !== 'string') throw new OpCompileError(`step '${step.id}'.expr is missing`);
    try {
      const formula = compileExpression(step.expr, {
        scope: { columns: [], params: [...params.keys()], scalars: [...scalars.keys()] }, params, scalars,
      });
      return { sql: `SELECT ${formula.sql} AS value`, bindings: formula.bindings };
    } catch (e) {
      throw new OpCompileError(`step '${step.id}'.expr: expressions may read settings and single values only; ${e instanceof Error ? e.message : String(e)}`);
    }
  }

  if (step.kind === 'sql') {
    if (typeof step.sql !== 'string') {
      throw new OpCompileError(`step '${step.id}' is a SQL step but carries no SQL`);
    }

    /**
     * Checked against a context holding ONLY this step's declared relations, and holding
     * them empty.
     *
     * It used to be checked against the run's own connection, which holds every relation
     * loaded so far — so a step declaring `public` could read `secret` and the gate saw
     * nothing wrong. Found in review, 2026-10-14. The scratch database costs almost
     * nothing because the tables are created with no rows; all it has to do is make a
     * name either resolve or fail.
     */
    const declared = depsOf(step);
    const problems = await checkSqlInIsolation(step.sql, declared, relations);
    if (problems.length > 0) {
      throw new OpCompileError(problems[0]!.message, problems[0]!.hint);
    }
    return { sql: step.sql, bindings: [] };
  }

  if (step.kind !== 'operation') {
    throw new OpCompileError(
      `step '${step.id}' is of kind '${step.kind}', which is not implemented yet`,
      'use an operation or a SQL step',
    );
  }

  const input: OpCompileInput = {
    // The declared inputs, plus `join`'s right side. `adjust_price` and `factor` read
    // their extra relation by name. Built from `input` itself rather than by removing
    // names from the dependencies: a universe that is the input's own relation removed
    // the input as well.
    inputs: declaredInputs(step),
    columns: relations,
    params,
    scalars,
  };

  const runner = step.op ? RUNNERS[step.op] : undefined;
  if (runner) {
    return runner(step.params as never, input, (q: CompiledStep) => ctx.query(q.sql, q.bindings as never[]));
  }

  const compiler = step.op ? OPERATIONS[step.op] : undefined;
  if (!compiler) {
    throw new OpCompileError(
      `operation '${step.op}' is not implemented yet`,
      `available: ${Object.keys(OPERATIONS).sort().join(', ')}`,
    );
  }

  return compiler(step.params as never, input);
}
