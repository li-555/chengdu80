import { newQuickJSWASMModule } from 'quickjs-emscripten';
import type { IngestColumn } from './ingest.ts';

export type CodeInput = {
  input: Record<string, Record<string, unknown>[]>;
  params: ReadonlyMap<string, unknown>;
  columns: readonly IngestColumn[];
  body: string;
  carryState: boolean;
  state?: Record<string, unknown>;
  signal: AbortSignal;
  logs: string[];
};
export type CodeResult = {
  rows: Record<string, unknown>[];
  state?: Record<string, unknown>;
  warnings: string[];
};

const bytes = (text: string) => new TextEncoder().encode(text).length;
const object = (v: unknown): v is Record<string, unknown> => v !== null && typeof v === 'object' && !Array.isArray(v);

/** Execute with no host capabilities other than the bounded log sink. */
export async function runCode(p: CodeInput): Promise<CodeResult> {
  if (Object.keys(p.input).length > 3) throw new Error('code input allows at most 3 relations');
  for (const [name, rows] of Object.entries(p.input)) {
    if (rows.length > 50_000) throw new Error(`E_ROW_CAP: code input '${name}' exceeds 50000 rows`);
  }
  const stateJson = JSON.stringify(p.carryState ? p.state ?? {} : {});
  if (p.carryState && (!object(p.state ?? {}) || bytes(stateJson) > 64 * 1024)) throw new Error('carried state exceeds 64 KB or is not an object');
  p.signal.throwIfAborted();
  const module = await newQuickJSWASMModule();
  const runtime = module.newRuntime();
  runtime.setMemoryLimit(64 * 1024 * 1024);
  runtime.setMaxStackSize(512 * 1024);
  const deadline = Date.now() + 3_000;
  runtime.setInterruptHandler(() => Date.now() >= deadline || p.signal.aborted);
  const vm = runtime.newContext();
  let trapped = false;
  try {
    const inject = (name: string, value: unknown) => {
      const result = vm.evalCode(`JSON.parse(${JSON.stringify(JSON.stringify(value))})`, undefined, { type: 'global' });
      const handle = vm.unwrapResult(result);
      try { vm.setProp(vm.global, name, handle); } finally { handle.dispose(); }
    };
    inject('input', p.input);
    inject('params', Object.fromEntries(p.params));
    if (p.carryState) inject('state', JSON.parse(stateJson));
    const log = vm.newFunction('log', (value) => {
      if (p.logs.length >= 100) return;
      const text = vm.getString(value);
      for (const line of text.split(/\r?\n/)) {
        if (p.logs.length >= 100) break;
        p.logs.push(line);
      }
    });
    try { vm.setProp(vm.global, 'log', log); } finally { log.dispose(); }
    // String conversion and JSON serialization run under the same interrupt handler.
    let result;
    try {
      result = vm.evalCode(`(function () {
      const stringify = JSON.stringify;
      const sink = log;
      const keys = Object.keys;
      const isArray = Array.isArray;
      const finite = Number.isFinite;
      const declared = ${JSON.stringify(p.columns)};
      const create = Object.create;
      const own = Object.hasOwn;
      const integer = Number.isSafeInteger;
      globalThis.log = function (message) { sink(String(message)); };
      const result = (function () { "use strict";\n${p.body}\n})();
      if (!result || typeof result !== 'object' || !isArray(result.rows)) throw new Error('code must return { rows, state? }');
      for (const key of keys(result)) if (key !== 'rows' && key !== 'state') throw new Error('undeclared result key: ' + key);
      if (result.rows.length > 20000) throw new Error('E_ROW_CAP: code output exceeds 20000 rows');
      const cleaned = [];
      for (const row of result.rows) {
        if (!row || typeof row !== 'object' || isArray(row)) throw new Error('code row is not an object');
        for (const key of keys(row)) {
          let allowed = false;
          for (const column of declared) if (column.name === key) allowed = true;
          if (!allowed) throw new Error('undeclared output key: ' + key);
        }
        const cells = create(null);
        for (const column of declared) {
          const value = row[column.name];
          const valid = column.type === 'number' ? typeof value === 'number' && finite(value)
            : column.type === 'integer' ? typeof value === 'number' && integer(value)
              : column.type === 'boolean' ? typeof value === 'boolean' : typeof value === 'string';
          // An omitted field keeps the missing/type warning visible after JSON parsing.
          if (valid || value === null) cells[column.name] = value;
        }
        cleaned[cleaned.length] = cells;
      }
      const answer = create(null);
      answer.rows = cleaned;
      if (own(result, 'state')) answer.state = result.state;
      return stringify(answer);
    })()`, 'step.js', { type: 'global' });
    } catch (e) {
      trapped = e instanceof RangeError || e instanceof WebAssembly.RuntimeError;
      throw new Error(`code execution stopped: ${e instanceof Error ? e.message : String(e)}`);
    }
    if (result.error) {
      let message = 'sandbox error';
      try {
        const value = vm.getProp(result.error, 'message');
        try { if (vm.typeof(value) === 'string') message = vm.getString(value); } finally { value.dispose(); }
      } finally { result.error.dispose(); }
      if (Date.now() >= deadline) throw new Error('E_CODE_TIMEOUT: code exceeded 3 seconds');
      p.signal.throwIfAborted();
      throw new Error(`${message.includes('memory') ? 'E_CODE_MEMORY: ' : ''}code failed: ${message}`);
    }
    let json: string;
    try {
      if (vm.typeof(result.value) !== 'string') throw new Error('code must return { rows, state? }');
      json = vm.getString(result.value);
    } finally { result.value.dispose(); }
    if (Date.now() >= deadline) throw new Error('E_CODE_TIMEOUT: code exceeded 3 seconds');
    if (bytes(json) > 4 * 1024 * 1024) throw new Error('code output JSON exceeds 4 MB');
    const answer: unknown = JSON.parse(json);
    if (!object(answer) || !Array.isArray(answer.rows)) throw new Error('code must return { rows, state? }');
    if (Object.keys(answer).some((k) => k !== 'rows' && k !== 'state')) throw new Error('code returned an undeclared result key');
    if (answer.rows.length > 20_000) throw new Error('E_ROW_CAP: code output exceeds 20000 rows');
    if (Object.hasOwn(answer, 'state')) {
      if (!p.carryState) throw new Error('state requires carry_state');
      if (!object(answer.state) || bytes(JSON.stringify(answer.state)) > 64 * 1024) throw new Error('returned state exceeds 64 KB or is not an object');
    }
    const warnings: string[] = [];
    const names = new Set(p.columns.map((c) => c.name));
    const lost = new Map<string, number>();
    const rows = answer.rows.map((raw: unknown, i: number) => {
      if (!object(raw)) throw new Error(`code row ${i + 1} is not an object`);
      for (const key of Object.keys(raw)) {
        if (!names.has(key)) throw new Error(`code row ${i + 1} has undeclared output key '${key}'`);
      }
      return Object.fromEntries(p.columns.map((c) => {
        const v = raw[c.name];
        const valid = c.type === 'number' ? typeof v === 'number' && Number.isFinite(v)
          : c.type === 'integer' ? typeof v === 'number' && Number.isSafeInteger(v)
            : c.type === 'boolean' ? typeof v === 'boolean' : typeof v === 'string';
        if (v !== null && !valid) lost.set(c.name, (lost.get(c.name) ?? 0) + 1);
        return [c.name, valid ? v : null];
      }));
    });
    for (const [name, count] of lost) warnings.push(`${count} missing or wrongly typed value(s) in '${name}' are blank`);
    return { rows, warnings, ...(Object.hasOwn(answer, 'state') ? { state: answer.state as Record<string, unknown> } : {}) };
  } finally {
    // A host stack trap cannot unwind guest allocations safely. Its private module
    // is released as a whole instead of attempting to free an interrupted C stack.
    if (!trapped) {
      vm.dispose();
      runtime.dispose();
    }
  }
}
