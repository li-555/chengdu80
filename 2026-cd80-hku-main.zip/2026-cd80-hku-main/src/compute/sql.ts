/**
 * The gate every raw SQL step passes before it is allowed to run.
 *
 * A document may contain SQL written by a model or by a stranger, so this is a security
 * boundary and C12 rests on it. The checks are layered, cheapest first, and none of them
 * is string matching against a list of bad words — the first three ask the engine's own
 * parser what the statement is.
 *
 * What the spec proposed does not work. `json_serialize_sql` refuses a bound parameter,
 * so using it would mean interpolating the untrusted SQL into another statement, which is
 * the one thing we will not do. `extractStatements` is used instead. Note that it reports
 * only the statement *count*: the type comes from preparing the statement and reading
 * `statementType`, which the earlier note in STATE.md got wrong.
 *
 * The last check is the interesting one. Rather than extracting a parse tree to find which
 * tables a statement reads, the statement is prepared against a context that contains
 * only the relations the step declared. Anything else it names cannot resolve, so prepare
 * fails and the step is refused. That gives the spec's rule 4 with no parse tree at all.
 */

import type { DuckDBConnection } from '@duckdb/node-api';

/** `statementType` for a SELECT. A PRAGMA reports this too, which is why rule 3 exists. */
const STATEMENT_TYPE_SELECT = 1;

export type SqlProblem = { code: string; message: string; hint?: string };

/**
 * Table functions a step may call.
 *
 * All three generate rows from their arguments and touch nothing outside the query.
 * Everything else is refused, including the engine's own metadata functions: they expose
 * settings and schema, and a step has no business reading either.
 */
const ALLOWED_TABLE_FUNCTIONS = new Set(['range', 'generate_series', 'unnest']);

/**
 * Strip comments and string literals before any textual inspection.
 *
 * Without this, a table name inside a comment or a quoted string is mistaken for a real
 * one, and — worse — a keyword hidden in a comment slips past the leading-keyword check.
 */
export function stripCommentsAndStrings(sql: string): string {
  let out = '';
  let i = 0;

  while (i < sql.length) {
    const two = sql.slice(i, i + 2);

    if (two === '--') {
      const nl = sql.indexOf('\n', i);
      i = nl === -1 ? sql.length : nl;
      continue;
    }

    if (two === '/*') {
      /**
       * Block comments nest in DuckDB. Stopping at the first `*/` left the tail of an
       * outer comment in the text, so `/* outer /* inner *\/ SELECT *\/ PRAGMA version`
       * presented a SELECT to the keyword check while the engine saw only the PRAGMA.
       * Found in review, 2026-10-14.
       */
      let depth = 0;
      while (i < sql.length) {
        if (sql.slice(i, i + 2) === '/*') { depth++; i += 2; continue; }
        if (sql.slice(i, i + 2) === '*/') { depth--; i += 2; if (depth === 0) break; continue; }
        i++;
      }
      out += ' ';
      continue;
    }

    /**
     * A dollar-quoted string, `$$...$$` or `$tag$...$tag$`. Its contents are not escaped,
     * so an apostrophe inside one used to be read as the start of an ordinary string and
     * everything after it was stripped away, hiding the rest of the statement.
     */
    if (sql[i] === '$') {
      const tag = /^\$[A-Za-z_][A-Za-z0-9_]*\$|^\$\$/.exec(sql.slice(i));
      if (tag) {
        const close = sql.indexOf(tag[0], i + tag[0].length);
        i = close === -1 ? sql.length : close + tag[0].length;
        out += "''";
        continue;
      }
    }

    if (sql[i] === "'") {
      i++;
      while (i < sql.length) {
        if (sql[i] === "'" && sql[i + 1] === "'") { i += 2; continue; }
        if (sql[i] === "'") { i++; break; }
        i++;
      }
      out += "''";
      continue;
    }

    if (sql[i] === '"') {
      // A quoted identifier is a name, not a value, so it is kept -- but the quotes are
      // dropped so a name cannot hide from the checks below by being quoted.
      i++;
      let name = '';
      while (i < sql.length) {
        if (sql[i] === '"' && sql[i + 1] === '"') { name += '"'; i += 2; continue; }
        if (sql[i] === '"') { i++; break; }
        name += sql[i];
        i++;
      }
      out += name;
      continue;
    }

    out += sql[i];
    i++;
  }

  return out;
}

/**
 * Name patterns no step may mention, as a function or as a schema.
 *
 * Restricting the search to a FROM or JOIN position was not enough: a comma join,
 * LATERAL, a schema qualifier and a quoted name all walked straight past it, and
 * `information_schema` needs no function call at all. Found in review, 2026-10-14. These
 * are matched against every identifier in the statement instead.
 */
const FORBIDDEN_NAME = [
  /^duckdb_/,          // the engine's own metadata: settings, tables, extensions
  /^pg_/,              // the postgres compatibility catalog
  /^read_/,            // read_csv, read_parquet, read_json, ...
  /^scan_/,
  /^sniff_/,
  /^glob$/,
  /^parquet_/,
  /^iceberg_/,
  /^delta_/,
  /^postgres_/,
  /^mysql_/,
  /^sqlite_/,
  /^information_schema$/,
  /^pg_catalog$/,
  /^system$/,          // the system catalog
  /^temp$/,
];

/** Every identifier used as a function call or as a schema qualifier, lower-cased. */
export function referencedNames(sql: string): string[] {
  const clean = stripCommentsAndStrings(sql);
  const found = new Set<string>();

  // A call: `name(`
  for (const m of clean.matchAll(/([A-Za-z_][A-Za-z0-9_$]*)\s*\(/g)) {
    if (m[1]) found.add(m[1].toLowerCase());
  }
  // A qualifier: `name.`
  for (const m of clean.matchAll(/([A-Za-z_][A-Za-z0-9_$]*)\s*\./g)) {
    if (m[1]) found.add(m[1].toLowerCase());
  }

  return [...found];
}

/** The first forbidden name in the statement, if any. */
export function forbiddenNameIn(sql: string): string | undefined {
  for (const name of referencedNames(sql)) {
    if (FORBIDDEN_NAME.some((re) => re.test(name))) return name;
  }
  return undefined;
}

/**
 * Check one SQL step.
 *
 * `allowedRelations` is what the step declared as its input. The statement is prepared
 * against `connection`, which must be a context in which only those relations exist.
 */
export async function checkSqlStep(
  connection: DuckDBConnection,
  sql: string,
): Promise<SqlProblem[]> {
  const trimmed = sql.trim();
  if (trimmed === '') {
    return [{ code: 'E_BAD_SQL', message: 'the SQL is empty' }];
  }

  // 1. Does it parse at all, and is it one statement?
  let extracted: { count: number; prepare: (i: number) => Promise<unknown> };
  try {
    extracted = (await connection.extractStatements(trimmed)) as never;
  } catch (e) {
    return [{
      code: 'E_BAD_SQL',
      message: `the SQL could not be parsed: ${oneLine(e)}`,
      hint: 'a step is a single SELECT or WITH statement',
    }];
  }

  if (extracted.count === 0) {
    return [{ code: 'E_BAD_SQL', message: 'the SQL contains no statement' }];
  }
  if (extracted.count > 1) {
    return [{
      code: 'E_BAD_SQL',
      message: `a step must be one statement, but this is ${extracted.count}`,
      hint: 'split the work across steps, one statement each',
    }];
  }

  // 3. The leading keyword, before the type check, because a PRAGMA reports as a SELECT.
  const lead = stripCommentsAndStrings(trimmed).trimStart().slice(0, 12).toLowerCase();
  if (!/^(select|with)\b/.test(lead)) {
    return [{
      code: 'E_BAD_SQL',
      message: 'a step must begin with SELECT or WITH',
      hint: 'a PRAGMA reports itself to the parser as a SELECT, so the keyword is checked too',
    }];
  }

  // 4. No forbidden function or schema, anywhere in the statement.
  const forbidden = forbiddenNameIn(trimmed);
  if (forbidden !== undefined) {
    return [{
      code: 'E_BAD_SQL',
      message: `a step may not use '${forbidden}'`,
      hint: 'a step reads the relations it declared; it may not reach the engine\'s own catalogue, the file system or another database',
    }];
  }

  // 2 and 5. The engine's own verdict: the statement type, and whether every name it
  // uses resolves against a context holding only the step's declared relations.
  try {
    const prepared = (await extracted.prepare(0)) as { statementType: number; destroySync?: () => void };
    try {
      if (prepared.statementType !== STATEMENT_TYPE_SELECT) {
        return [{
          code: 'E_BAD_SQL',
          message: 'a step must be a query, not a statement that changes anything',
          hint: 'write a single SELECT or WITH',
        }];
      }
    } finally {
      prepared.destroySync?.();
    }
  } catch (e) {
    return [{
      code: 'E_BAD_SQL',
      message: `the SQL refers to something this step cannot use: ${oneLine(e)}`,
      hint: 'a step may read only the relations named in its own input',
    }];
  }

  return [];
}

function oneLine(e: unknown): string {
  const text = e instanceof Error ? e.message : String(e);
  return text.split('\n')[0]?.trim() ?? 'unknown error';
}
