/**
 * The run result in the shape storage and the screen use: plain JSON, row by row.
 *
 * `runApplication` keeps Maps internally, because the run loop looks relations up by name.
 * Nothing outside `src/compute/` should see those Maps. `runForScreen` is the one entry
 * point for running a saved application: it asks for every table the screen reads, runs,
 * and converts the outcome into `RunResult` and `RunTrace` as published in
 * `docs/CONTRACTS.md` section 3. Every value it returns is accepted by storage as is.
 */

import type { LanguageModel } from 'ai';
import type { AppDocument } from '../app-schema/index.ts';
import type { FieldType } from '../app-schema/fields.ts';
import { runApplication, type RunOutcome, type Slice } from './run.ts';

export type RunStatus = 'ok' | 'partial' | 'failed';

export type RunResult = {
  status: RunStatus;
  outputs: Record<string, {
    schema: { name: string; label: string; type: FieldType; nullable: boolean }[];
    rows: unknown[][];
  }>;
  failure?: { code: string; message: string; stepId?: string };
  warnings: string[];
  startedAt: string;
  durationMs: number;
};

export type RunTrace = {
  steps: { id: string; kind: string; op?: string; rowsOut: number; durationMs: number; failed?: string }[];
  params: Record<string, unknown>;
};

/** Every relation the screen reads, plus every step marked `key` for the Inspect panel. */
export function screenRelations(doc: AppDocument): string[] {
  const names = new Set<string>();
  for (const el of Object.values(doc.ui?.elements ?? {})) {
    const from = (el as { from?: unknown }).from;
    if (typeof from === 'string') names.add(from);
  }
  for (const s of doc.compute ?? []) if ((s as { key?: boolean }).key) names.add(s.id);
  return [...names];
}

/** A database column type, reduced to the four types the screen knows. */
export function fieldType(dbType: string): FieldType {
  const t = dbType.toUpperCase();
  if (t === 'BOOLEAN') return 'boolean';
  if (t.startsWith('DATE') || t.startsWith('TIMESTAMP')) return 'date';
  if (/INT|DOUBLE|FLOAT|DECIMAL|REAL|NUMERIC/.test(t)) return 'number';
  return 'text';
}

/** One cell, made safe for storage: no undefined, no NaN or Infinity, no BigInt. */
function cell(v: unknown): unknown {
  if (v === undefined) return null;
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (typeof v === 'bigint') return Number(v);
  if (v instanceof Date) return v.toISOString();
  if (v !== null && typeof v === 'object') return JSON.parse(JSON.stringify(v));
  return v;
}

export function toRunResult(outcome: RunOutcome, startedAt: Date): { result: RunResult; trace: RunTrace } {
  const outputs: RunResult['outputs'] = {};
  for (const [name, q] of outcome.results) {
    outputs[name] = {
      schema: q.columns.map((c) => ({ name: c.name, label: c.name, type: fieldType(c.type), nullable: true })),
      rows: q.rows.map((r) => q.columns.map((c) => cell(r[c.name]))),
    };
  }
  const failedStep = outcome.steps.find((s) => s.failed);
  return {
    result: {
      status: outcome.status,
      outputs,
      ...(outcome.failure ? { failure: { code: 'E_RUN_FAILED', message: outcome.failure, ...(failedStep ? { stepId: failedStep.id } : {}) } } : {}),
      warnings: [...outcome.warnings],
      startedAt: startedAt.toISOString(),
      durationMs: Date.now() - startedAt.getTime(),
    },
    trace: {
      steps: outcome.steps.map((s) => ({ ...s })),
      params: Object.fromEntries([...outcome.params].map(([k, v]) => [k, cell(v)])),
    },
  };
}

/** Run a saved application and return what storage and the screen need. */
export async function runForScreen(
  doc: AppDocument,
  options: {
    slices: Record<string, Slice>;
    params?: Record<string, unknown>;
    model?: LanguageModel;
    signal?: AbortSignal;
    carriedState?: Record<string, unknown>;
  },
): Promise<{ result: RunResult; trace: RunTrace; newState?: Record<string, unknown> }> {
  const startedAt = new Date();
  const outcome = await runApplication(doc as never, { ...options, want: screenRelations(doc) });
  return { ...toRunResult(outcome, startedAt), ...(outcome.newState ? { newState: outcome.newState } : {}) };
}
