import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { compileMetric } from './metric.ts';
import { checkedColumn, checkOutputNames, OpCompileError, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compilePivot: OpCompiler<z.infer<typeof OperationParams.pivot>> = (params, input) => {
  const relation = soleInput(input);
  const index = params.index.map((name) => checkedColumn(relation, name, input));
  checkOutputNames(index);
  if (params.agg === 'quantile') throw new OpCompileError('Pivot does not support quantile', 'Use an aggregate with p instead');
  const builder = new SqlBuilder().keyword('SELECT * FROM ( PIVOT').column(relation).keyword('ON').column(checkedColumn(relation, params.on, input)).keyword('USING');
  compileMetric({ fn: params.agg, of: params.values, as: '' }, relation, input, builder);
  return builder.keyword('GROUP BY').list(index, ',', (name, b) => b.column(name)).keyword(')').build();
};
