import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, checkOutputNames, OpCompileError, soleInput, SqlBuilder } from './contract.ts';
import { MAX_READ_ROWS, type OpRunner } from './runner.ts';

type Params = z.infer<typeof OperationParams.regress>;

/**
 * Least-squares regression of `y` on two or more columns, per group.
 *
 * The engine computes, per group, the mean of every column and the covariance of every
 * pair. That is a fixed number of values per group however many rows there are, so the
 * read is small. The slopes then solve `Cov(x, x) · b = Cov(x, y)` and the intercept is
 * `mean(y) - Σ b·mean(x)`. Using covariances rather than raw sums keeps large prices from
 * swamping the arithmetic.
 *
 * A group with too few rows, or whose columns are exact copies of each other, gets blank
 * coefficients rather than an error, so one bad group does not lose the others.
 *
 * Output: the same long shape as one-column `regress`: the `by` columns, then `term`
 * ('intercept' or a column name), `coefficient`, `r2` and `n`, one row per term per group.
 */
export const runRegressMulti: OpRunner<Params> = async (params, input, read) => {
  const relation = soleInput(input);
  const y = checkedColumn(relation, params.y, input);
  const xs = params.x.map((c) => checkedColumn(relation, c, input));
  const by = (params.by ?? []).map((c) => checkedColumn(relation, c, input));

  const lowered = [y, ...xs].map((c) => c.toLowerCase());
  if (new Set(lowered).size !== lowered.length) {
    throw new OpCompileError('each column may appear only once across y and x');
  }
  for (const g of by) {
    if (lowered.includes(g.toLowerCase())) {
      throw new OpCompileError(`'${g}' cannot be both a grouping column and a regression column`);
    }
  }

  checkOutputNames([...by, 'term', 'coefficient', 'r2', 'n']);
  // Helper names in the generated SQL start with `__`. A user column with that prefix
  // could be shadowed by one of them and silently match the wrong group.
  for (const c of [y, ...xs, ...by]) {
    if (c.startsWith('__')) {
      throw new OpCompileError(`column '${c}' starts with '__', which is reserved for the platform`, 'rename it first with derive');
    }
  }

  const k = xs.length;
  const vars = [...xs, y]; // index k is y

  // ---- read: one row per group of means and covariances
  // The group columns are not selected: the groups are matched back by their sorted
  // position, which the answer below recomputes in the same order.
  const q = new SqlBuilder().keyword('SELECT count(*) AS __n');
  vars.forEach((v, i) => {
    q.keyword(', avg(CAST(').column(v).keyword(`AS DOUBLE)) AS __m${i}`);
  });
  for (let i = 0; i <= k; i++) {
    for (let j = i; j <= k; j++) {
      q.keyword(', covar_pop(CAST(').column(vars[i]!).keyword('AS DOUBLE) , CAST(')
        .column(vars[j]!).keyword(`AS DOUBLE)) AS __c${i}_${j}`);
    }
  }
  q.keyword('FROM').column(relation);
  notNullWhere(q, vars);
  if (by.length > 0) {
    q.keyword('GROUP BY').list(by, ',', (g, b) => b.column(g));
    q.keyword('ORDER BY').list(by, ',', (g, b) => b.column(g).keyword('NULLS LAST'));
  }
  q.keyword('LIMIT').value(MAX_READ_ROWS + 1);
  const groups = (await read(q.build())).rows;
  if (groups.length > MAX_READ_ROWS) {
    throw new OpCompileError(`regress handles at most ${MAX_READ_ROWS} groups`, 'group by fewer columns, or filter first');
  }

  // ---- solve each group
  type Row = { gid: number; term: string; coefficient: number | null; r2: number | null; n: number };
  const out: Row[] = [];
  groups.forEach((g, gi) => {
    const n = Number(g.__n);
    const mean = (i: number) => Number(g[`__m${i}`]);
    const cov = (i: number, j: number) => Number(g[i <= j ? `__c${i}_${j}` : `__c${j}_${i}`]);

    // k slopes and an intercept need k + 1 rows; fewer cannot be solved.
    let slopes: number[] | null = n >= k + 1 ? solveSymmetric(
      Array.from({ length: k }, (_, i) => Array.from({ length: k }, (_, j) => cov(i, j))),
      Array.from({ length: k }, (_, i) => cov(i, k)),
    ) : null;
    if (slopes && slopes.some((b) => !Number.isFinite(b))) slopes = null;

    let intercept: number | null = null;
    let r2: number | null = null;
    if (slopes) {
      intercept = mean(k) - slopes.reduce((s, b, i) => s + b * mean(i), 0);
      const vy = cov(k, k);
      r2 = vy > 0 ? slopes.reduce((s, b, i) => s + b * cov(i, k), 0) / vy : null;
    }

    out.push({ gid: gi + 1, term: 'intercept', coefficient: intercept, r2, n });
    xs.forEach((x, i) => out.push({ gid: gi + 1, term: x, coefficient: slopes ? slopes[i]! : null, r2, n }));
  });

  // ---- answer: the group columns come back from the data itself, matched by position
  const b = new SqlBuilder().keyword('SELECT');
  b.list(by, ',', (g, bb) => bb.keyword('__g.').column(g));
  if (by.length > 0) b.keyword(',');
  b.keyword('CAST(__t.term AS VARCHAR) AS "term" , CAST(__t.coefficient AS DOUBLE) AS "coefficient" ,')
    .keyword('CAST(__t.r2 AS DOUBLE) AS "r2" , CAST(__t.n AS BIGINT) AS "n"');

  b.keyword('FROM (SELECT');
  if (by.length > 0) {
    b.list(by, ',', (g, bb) => bb.column(g));
    b.keyword(', row_number() OVER (ORDER BY');
    b.list(by, ',', (g, bb) => bb.column(g).keyword('NULLS LAST'));
    b.keyword(') AS __gid FROM (SELECT DISTINCT').list(by, ',', (g, bb) => bb.column(g));
    b.keyword('FROM').column(relation);
    notNullWhere(b, vars);
    b.keyword('))');
  } else {
    b.keyword('1 AS __gid )');
  }
  b.keyword('AS __g JOIN (');
  if (out.length === 0) {
    b.keyword('SELECT NULL AS __gid , NULL AS term , NULL AS coefficient , NULL AS r2 , NULL AS n WHERE false');
  } else {
    b.keyword('VALUES');
    b.list(out, ',', (r, bb) => {
      bb.keyword('(').value(r.gid).keyword(',').value(r.term).keyword(',').value(r.coefficient)
        .keyword(',').value(r.r2).keyword(',').value(r.n).keyword(')');
    });
  }
  b.keyword(') AS __t (__gid , term , coefficient , r2 , n) ON __g.__gid = __t.__gid ORDER BY __t.__gid');

  return b.build();
};

function notNullWhere(b: SqlBuilder, cols: readonly string[]): void {
  b.keyword('WHERE');
  b.list(cols, 'AND', (c, bb) => bb.column(c).keyword('IS NOT NULL'));
}

/**
 * Solve the covariance system `A·x = rhs` by Gaussian elimination with partial pivoting.
 * Returns null when it is singular: a constant column, or two columns carrying the same
 * information.
 *
 * The system is first rescaled to correlations (unit diagonal), so the singularity test
 * does not depend on units. Without that, a price in yuan next to a market value in yuan
 * made the small column look like zero and the whole fit came back blank.
 *
 * Exported for the tests only.
 */
export function solveSymmetric(a: number[][], rhs: number[]): number[] | null {
  const n = rhs.length;
  const s = a.map((row, i) => Math.sqrt(row[i]!));
  if (s.some((v) => !(v > 0) || !Number.isFinite(v))) return null;
  const m = a.map((row, i) => [...row.map((v, j) => v / (s[i]! * s[j]!)), rhs[i]! / s[i]!]);

  for (let col = 0; col < n; col++) {
    let pivot = col;
    for (let r = col + 1; r < n; r++) {
      if (Math.abs(m[r]![col]!) > Math.abs(m[pivot]![col]!)) pivot = r;
    }
    if (Math.abs(m[pivot]![col]!) < 1e-12) return null; // the diagonal is 1 after rescaling
    [m[col], m[pivot]] = [m[pivot]!, m[col]!];
    for (let r = 0; r < n; r++) {
      if (r === col) continue;
      const f = m[r]![col]! / m[col]![col]!;
      for (let c = col; c <= n; c++) m[r]![c]! -= f * m[col]![c]!;
    }
  }
  return m.map((row, i) => row[n]! / row[i]! / s[i]!);
}
