import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { compileExpression } from '../expr.ts';
import { OpCompileError, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compileFilter: OpCompiler<z.infer<typeof OperationParams.filter>> = (params, input) => {
  const relation = soleInput(input);
  const columns = input.columns.get(relation);
  if (!columns) throw new OpCompileError('Input relation is unavailable', 'Supply the input relation columns');
  try {
    const compiled = compileExpression(params.where, {
      scope: {
        columns: columns.map((c) => c.name),
        params: [...input.params.keys()],
        scalars: [...input.scalars.keys()],
      },
      params: input.params,
      scalars: input.scalars,
    });
    return new SqlBuilder().keyword('SELECT * FROM').column(relation)
      .keyword('WHERE').fragment(compiled.sql, compiled.bindings).build();
  } catch (error) {
    if (error instanceof OpCompileError) throw error;
    throw new OpCompileError(error instanceof Error ? error.message : String(error), 'Check the filter formula and available columns');
  }
};
