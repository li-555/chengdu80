import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, OpCompileError, SqlBuilder, type OpCompileInput } from './contract.ts';

const functions = {
  sum: 'sum', mean: 'avg', median: 'median', min: 'min', max: 'max',
  count: 'count', count_distinct: 'count', stddev: 'stddev_samp', var: 'var_samp', quantile: 'quantile_cont',
} as const;

/** The shared aggregate expression used by grouped summaries and pivots. */
export function compileMetric(
  metric: z.infer<typeof OperationParams.aggregate>['metrics'][number],
  relation: string,
  input: OpCompileInput,
  b: SqlBuilder,
): void {
  const fn = functions[metric.fn];
  if (!fn) throw new OpCompileError('Unsupported aggregate function');
  if (metric.fn !== 'count' && metric.of === undefined) {
    throw new OpCompileError('This aggregate requires of', 'Specify an input column');
  }
  b.keyword(fn).keyword('(');
  if (metric.fn === 'count_distinct') b.keyword('DISTINCT');
  if (metric.of === undefined) b.keyword('*');
  else b.column(checkedColumn(relation, metric.of, input));
  if (metric.fn === 'quantile') {
    if (metric.p === undefined || !Number.isFinite(metric.p) || metric.p < 0 || metric.p > 1) {
      throw new OpCompileError('Quantile requires p between 0 and 1');
    }
    b.keyword(',').value(metric.p);
  }
  b.keyword(')');
}
