import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, OpCompileError, SqlBuilder, type OpCompiler } from './contract.ts';

/**
 * Put two relations side by side on a matching key.
 *
 * The output columns are named explicitly rather than with `SELECT *`. Two relations
 * that share a key — which is the normal case, since that is what they are joined on —
 * would otherwise both contribute a column of that name, and a later step reading it
 * would get whichever the engine happened to return first. The rule is:
 *
 *   - every column of the left relation keeps its name;
 *   - the right relation's key columns are dropped, because the join has just asserted
 *     they equal the left's;
 *   - any remaining right column whose name collides with a left one is suffixed with
 *     `_<right relation>`.
 *
 * So joining `prices` to `sectors` on `code` gives `code, d, px, vol, sector`, and a
 * right-hand `d` would arrive as `d_sectors`. Deterministic, and it needs no new field
 * in the document.
 */
export const compileJoin: OpCompiler<z.infer<typeof OperationParams.join>> = (params, input) => {
  const left = input.inputs[0];
  const right = params.right;

  if (left === undefined || input.inputs.length !== 2 || input.inputs[1] !== right) {
    throw new OpCompileError(
      'a join takes exactly two inputs, with `right` as the second',
      'declare both relations in `input`, the right-hand one second',
    );
  }
  if (left === right) {
    throw new OpCompileError('a join cannot join a relation to itself');
  }
  if (params.on.length === 0) {
    throw new OpCompileError('a join needs at least one pair of key columns');
  }
  if (params.how !== 'asof' && params.direction !== undefined) {
    throw new OpCompileError(
      '`direction` applies only to an asof join',
      'remove `direction`, or set `how` to asof',
    );
  }
  if (params.how === 'asof' && params.asof_on === undefined) {
    throw new OpCompileError(
      'an asof join needs `asof_on`',
      'name the ordered column on each side, usually the date',
    );
  }
  if (params.how === 'asof' && params.direction === 'nearest') {
    throw new OpCompileError(
      'nearest asof matching is not supported',
      'use backward (the default) or forward',
    );
  }

  const joins = { inner: 'INNER JOIN', left: 'LEFT JOIN', asof: 'ASOF LEFT JOIN' } as const;
  const join = joins[params.how];
  if (!join) throw new OpCompileError(`unsupported join kind '${params.how}'`);

  // Checked here so a bad key column is reported before any SQL is built.
  const pairs = params.on.map(([l, r]) => [
    checkedColumn(left, l, input),
    checkedColumn(right, r, input),
  ] as const);

  const asof = params.asof_on
    ? ([
        checkedColumn(left, params.asof_on[0], input),
        checkedColumn(right, params.asof_on[1], input),
      ] as const)
    : undefined;

  const leftCols = (input.columns.get(left) ?? []).map((c) => c.name);
  const rightCols = (input.columns.get(right) ?? []).map((c) => c.name);
  if (leftCols.length === 0 || rightCols.length === 0) {
    throw new OpCompileError('both relations of a join must have columns');
  }

  /** The right-hand key columns, which the join has just asserted are equal to the left's. */
  const rightKeys = new Set(pairs.map(([, r]) => r.toLowerCase()));
  if (asof) rightKeys.add(asof[1].toLowerCase());

  /**
   * Output names are allocated against every name already taken, including aliases
   * allocated earlier in this same join.
   *
   * Checking only the left-hand names was not enough: with a left `px` and a right
   * holding both `px` and `px_notes`, the renamed `px` and the real `px_notes` both
   * claimed the name `px_notes`, and reading it returned the wrong column. Found in
   * review, 2026-10-14. Comparison is case-insensitive because the engine's own
   * duplicate handling is.
   */
  const taken = new Set(leftCols.map((n) => n.toLowerCase()));

  const allocate = (wanted: string): string => {
    if (!taken.has(wanted.toLowerCase())) {
      taken.add(wanted.toLowerCase());
      return wanted;
    }
    let candidate = `${wanted}_${right}`;
    let n = 2;
    while (taken.has(candidate.toLowerCase())) {
      candidate = `${wanted}_${right}_${n}`;
      n++;
    }
    taken.add(candidate.toLowerCase());
    return candidate;
  };

  const builder = new SqlBuilder().keyword('SELECT');

  const projected: { side: 'l' | 'r'; column: string; as?: string }[] = [];
  for (const name of leftCols) projected.push({ side: 'l', column: name });
  for (const name of rightCols) {
    if (rightKeys.has(name.toLowerCase())) continue;
    const alias = allocate(name);
    projected.push({ side: 'r', column: name, as: alias === name ? undefined : alias });
  }

  builder.list(projected, ',', (p, b) => {
    b.keyword(p.side === 'l' ? 'l.' : 'r.').column(p.column);
    if (p.as) b.keyword('AS').column(p.as);
  });

  builder.keyword('FROM').column(left).keyword('AS l').keyword(join).column(right).keyword('AS r').keyword('ON');
  builder.list(pairs, 'AND', ([l, r], b) => {
    b.keyword('l.').column(l).keyword('=').keyword('r.').column(r);
  });

  if (asof) {
    /**
     * Backward matching — the default — takes the most recent right-hand row at or
     * before the left-hand one, which is `l >= r`. Forward takes the earliest at or
     * after it.
     */
    builder
      .keyword('AND l.')
      .column(asof[0])
      .keyword(params.direction === 'forward' ? '<=' : '>=')
      .keyword('r.')
      .column(asof[1]);
  }

  return builder.build();
};
