import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, OpCompileError, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

/**
 * Correct historical prices for splits and dividends, using a bound table of cumulative
 * adjustment factors.
 *
 * - `backward` multiplies each price by the factor on its own day. Old prices stay as
 *   they were and recent prices grow.
 * - `forward` multiplies by the factor on its own day divided by the factor on the base
 *   day (the latest day, or the latest day on or before `base_date`). Recent prices stay
 *   as they were and old prices shrink. This is what a price chart normally shows.
 *
 * The factor for a day is the latest factor on or before that day, per security. A
 * factor table is published per trading day and a suspended security has no row, so an
 * exact-date join turned every suspended day into a blank price.
 *
 * Output: the input's columns, in their order, with each price column replaced by its
 * adjusted value under the same name. A price with no factor at or before its day is
 * blank rather than left unadjusted, because an unadjusted price sitting in an adjusted
 * series looks like a real jump.
 */
export const compileAdjustPrice: OpCompiler<z.infer<typeof OperationParams.adjust_price>> = (params, input) => {
  const prices = soleInput(input);
  const factors = params.factor_table;
  if (factors === prices) {
    throw new OpCompileError('the factor table must be a different relation from the prices');
  }

  const pKey = checkedColumn(prices, params.key[0], input);
  const pDate = checkedColumn(prices, params.date[0], input);
  const fKey = checkedColumn(factors, params.key[1], input);
  const fDate = checkedColumn(factors, params.date[1], input);
  const fVal = checkedColumn(factors, params.factor_col, input);

  const priceCols = params.price_cols.map((c) => checkedColumn(prices, c, input));
  const seen = new Set<string>();
  for (const c of priceCols) {
    if (seen.has(c.toLowerCase())) {
      throw new OpCompileError(`price column '${c}' is listed twice`);
    }
    if ([pKey, pDate].some((k) => k.toLowerCase() === c.toLowerCase())) {
      throw new OpCompileError(`'${c}' is the key or the date, and cannot also be a price column`);
    }
    seen.add(c.toLowerCase());
  }

  const b = new SqlBuilder().keyword('SELECT __p.* REPLACE (');
  b.list(priceCols, ',', (c, bb) => {
    bb.keyword('CAST(__p.').column(c).keyword('AS DOUBLE) * __f.').column(fVal);
    if (params.mode === 'forward') bb.keyword('/ NULLIF(__b.__base, 0)');
    bb.keyword('AS').column(c);
  });
  b.keyword(') FROM').column(prices).keyword('AS __p');
  b.keyword('ASOF LEFT JOIN').column(factors).keyword('AS __f ON __p.').column(pKey)
    .keyword('= __f.').column(fKey)
    .keyword('AND CAST(__p.').column(pDate).keyword('AS DATE) >= CAST(__f.').column(fDate).keyword('AS DATE)');

  if (params.mode === 'forward') {
    b.keyword('LEFT JOIN (SELECT').column(fKey).keyword('AS __k , arg_max(').column(fVal)
      .keyword(',').column(fDate).keyword(') AS __base FROM').column(factors);
    if (params.base_date !== undefined) {
      b.keyword('WHERE CAST(').column(fDate).keyword('AS DATE) <= CAST(').value(params.base_date).keyword('AS DATE)');
    }
    b.keyword('GROUP BY').column(fKey).keyword(') AS __b ON __p.').column(pKey).keyword('= __b.__k');
  } else if (params.base_date !== undefined) {
    throw new OpCompileError('base_date only applies to forward adjustment', 'remove base_date, or use mode forward');
  }

  return b.build();
};
