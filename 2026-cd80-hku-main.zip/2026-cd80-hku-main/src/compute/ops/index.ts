/**
 * The operation registry: the one place that maps an operation name to its compiler.
 *
 * An operation named in a document but absent here is a precise error rather than a
 * silent no-op, which is what `OPERATIONS` being a plain lookup gives us.
 */

import type { OpCompiler } from './contract.ts';
import { compileFilter } from './filter.ts';
import { compileDerive } from './derive.ts';
import { compileJoin } from './join.ts';
import { compileAggregate } from './aggregate.ts';
import { compileSortLimit } from './sort_limit.ts';

import { compileWindow } from './window.ts';
import { compileLagChange } from './lag_change.ts';
import { compileRank } from './rank.ts';
import { compileZscore } from './zscore.ts';
import { compileResample } from './resample.ts';
import { compilePivot } from './pivot.ts';
import { compileDescribe } from './describe.ts';
import { compileCorrelate } from './correlate.ts';
import { compileRegress } from './regress.ts';
import { compileAdjustPrice } from './adjust_price.ts';
import { compileFactor } from './factor.ts';
import { runIrr } from './irr.ts';
import { runRegressMulti } from './regress_multi.ts';
import type { OpRunner } from './runner.ts';

export * from './contract.ts';
export * from './runner.ts';

/** The operations that compile to one statement. `ai` is the one still missing (A12). */
export const OPERATIONS: Record<string, OpCompiler<never>> = {
  window: compileWindow as OpCompiler<never>,
  lag_change: compileLagChange as OpCompiler<never>,
  rank: compileRank as OpCompiler<never>,
  zscore: compileZscore as OpCompiler<never>,
  resample: compileResample as OpCompiler<never>,
  pivot: compilePivot as OpCompiler<never>,
  describe: compileDescribe as OpCompiler<never>,
  correlate: compileCorrelate as OpCompiler<never>,
  regress: compileRegress as OpCompiler<never>,
  filter: compileFilter as OpCompiler<never>,
  derive: compileDerive as OpCompiler<never>,
  join: compileJoin as OpCompiler<never>,
  aggregate: compileAggregate as OpCompiler<never>,
  sort_limit: compileSortLimit as OpCompiler<never>,
  adjust_price: compileAdjustPrice as OpCompiler<never>,
  factor: compileFactor as OpCompiler<never>,
};

/**
 * The operations that must read from the run's database before answering. The run loop
 * looks here first. `regress` is here because more than one column needs arithmetic the
 * engine has no function for; with one column it hands straight back to the SQL compiler.
 */
export const RUNNERS: Record<string, OpRunner<never>> = {
  irr: runIrr as OpRunner<never>,
  regress: (async (params, input, read) =>
    params.x.length === 1 ? compileRegress(params, input) : runRegressMulti(params, input, read)
  ) as OpRunner<Parameters<typeof compileRegress>[0]> as OpRunner<never>,
};

export const IMPLEMENTED_OPERATIONS = [...new Set([...Object.keys(OPERATIONS), ...Object.keys(RUNNERS)])].sort();
