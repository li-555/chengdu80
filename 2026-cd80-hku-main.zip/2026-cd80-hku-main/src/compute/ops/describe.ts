import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, isNumericType, OpCompileError, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compileDescribe: OpCompiler<z.infer<typeof OperationParams.describe>> = (params, input) => {
  const relation = soleInput(input);
  const columns = input.columns.get(relation);
  if (!columns) throw new OpCompileError('Input relation is unavailable');
  const names = (params.columns ?? columns.filter((c) => isNumericType(c.type)).map((c) => c.name))
    .map((name) => checkedColumn(relation, name, input));
  if (names.length === 0) throw new OpCompileError('Describe requires at least one numeric column');
  for (const name of names) {
    if (!isNumericType(columns.find((c) => c.name === name)!.type)) throw new OpCompileError(`column '${name}' is not numeric`);
  }
  const builder = new SqlBuilder();
  builder.list(names, 'UNION ALL', (name, b) => {
    b.keyword('SELECT').value(name).keyword('::VARCHAR AS').column('column')
      .keyword(', count (').column(name).keyword(')::BIGINT AS').column('count');
    for (const [fn, as] of [['avg', 'mean'], ['stddev_samp', 'std'], ['min', 'min'],
      ['quantile_cont', 'q25'], ['median', 'median'], ['quantile_cont', 'q75'], ['max', 'max']]) {
      b.keyword(',').keyword(fn!).keyword('(').column(name);
      if (as === 'q25' || as === 'q75') b.keyword(',').value(as === 'q25' ? 0.25 : 0.75);
      b.keyword(')::DOUBLE AS').column(as!);
    }
    b.keyword('FROM').column(relation);
  });
  return builder.build();
};
