/**
 * What every calculation operation is, and the only way it may build SQL.
 *
 * An operation turns its declared parameters into one `SELECT` over relations the run
 * has already created. It never executes anything itself, so each one is a pure
 * function and can be unit-tested without a database.
 *
 * Two rules are enforced by the shape of this file rather than by review, because both
 * have already cost us a wrong answer:
 *
 *  1. **Text and values move together.** A placeholder is filled by position, so
 *     appending SQL text in one place and its value in another lets the two drift out
 *     of step and the query then answers a different question from the one written.
 *     `SqlBuilder` is the only way to add either, and it adds both at once.
 *  2. **Nothing from a document or a person is ever pasted into SQL.** Every literal and
 *     every resolved setting becomes a `?` with its value in `bindings`. Only identifiers
 *     reach the text, and only after being checked against the relation's real columns
 *     and quoted.
 */

import { quoteIdentifier } from '../expr.ts';
import type { ResultColumn } from '../context.ts';

/** A compiled step: one statement, and the values its placeholders consume, in order. */
export type CompiledStep = { sql: string; bindings: unknown[] };

/** A whole number written in the document, or the name of a setting that supplies it. */
export type IntOrParam = number | { param: string };

/**
 * Everything an operation is allowed to know.
 *
 * `columns` carries the real columns of each input relation, so a column name is checked
 * before it becomes SQL text. Without it an operation would emit an identifier for a
 * column that does not exist and the failure would surface as a database error with no
 * location, instead of a located validation error.
 */
export type OpCompileInput = {
  /** The step's input relation names, in declaration order. Two entries only for `join`. */
  inputs: readonly string[];
  /** The columns of every relation this step may read, keyed by relation name. */
  columns: ReadonlyMap<string, readonly ResultColumn[]>;
  /** Resolved values of the declared settings. */
  params: ReadonlyMap<string, unknown>;
  /** Resolved values of earlier steps that produce a single value. */
  scalars: ReadonlyMap<string, unknown>;
};

/** One operation: its parameters plus what it may read, in; one statement, out. */
export type OpCompiler<P> = (params: P, input: OpCompileInput) => CompiledStep;

/** Raised when an operation cannot be compiled. The run loop turns it into a located error. */
export class OpCompileError extends Error {
  readonly hint?: string;

  constructor(message: string, hint?: string) {
    super(message);
    this.name = 'OpCompileError';
    this.hint = hint;
  }
}

/**
 * Builds one statement, keeping text and bindings in lockstep.
 *
 * There is deliberately no way to append text without its values, and no way to append a
 * value without the text that consumes it.
 */
export class SqlBuilder {
  #sql: string[] = [];
  #bindings: unknown[] = [];

  /**
   * Append SQL text that contains no placeholders.
   *
   * Use this only for keywords, punctuation and already-quoted identifiers. Passing a
   * value through here is the mistake the whole class exists to prevent, so a `?` in the
   * text is refused.
   */
  keyword(text: string): this {
    if (text.includes('?')) {
      throw new OpCompileError(
        'keyword() was given text containing a placeholder',
        'use value() or fragment() so the value travels with its placeholder',
      );
    }
    this.#sql.push(text);
    return this;
  }

  /** Append a checked column name as a quoted identifier. */
  column(name: string): this {
    this.#sql.push(quoteIdentifier(name));
    return this;
  }

  /** Append one bound value, emitting its placeholder at the same moment. */
  value(v: unknown): this {
    this.#sql.push('?');
    this.#bindings.push(v);
    return this;
  }

  /**
   * Append text with its own placeholders and the values that fill them.
   *
   * This is how a compiled formula from `expr.ts` is spliced in: it already carries its
   * own `?`s, so its bindings must arrive in the same call and in the same order.
   */
  fragment(sql: string, bindings: readonly unknown[] = []): this {
    const expected = countPlaceholders(sql);
    if (expected !== bindings.length) {
      throw new OpCompileError(
        `fragment has ${expected} placeholder(s) but ${bindings.length} binding(s)`,
        'pass a compiled fragment together with exactly its own bindings',
      );
    }
    this.#sql.push(sql);
    this.#bindings.push(...bindings);
    return this;
  }

  /** Append a list, separated by `sep`, by calling `each` for every item in order. */
  list<T>(items: readonly T[], sep: string, each: (item: T, b: this) => void): this {
    items.forEach((item, i) => {
      if (i > 0) this.keyword(sep);
      each(item, this);
    });
    return this;
  }

  build(): CompiledStep {
    return { sql: this.#sql.join(' '), bindings: this.#bindings };
  }
}

/**
 * Count the placeholders in a fragment, ignoring any inside a single-quoted string.
 *
 * A compiled formula should never contain a quoted literal, because literals are bound.
 * The check is here so that if one ever does, the lockstep assertion above does not
 * miscount it and reject a correct fragment.
 */
function countPlaceholders(sql: string): number {
  let count = 0;
  let inString = false;

  for (let i = 0; i < sql.length; i++) {
    const c = sql[i];
    if (c === "'") {
      if (inString && sql[i + 1] === "'") {
        i++; // an escaped quote inside a string
        continue;
      }
      inString = !inString;
      continue;
    }
    if (c === '?' && !inString) count++;
  }

  return count;
}

/**
 * Check that a column exists on a relation, and return it quoted.
 *
 * Comparison is case-insensitive because real data has mixed case, while the name that
 * reaches the SQL is the one the data actually uses.
 */
export function checkedColumn(
  relation: string,
  name: string,
  input: OpCompileInput,
): string {
  const cols = input.columns.get(relation);
  if (!cols) {
    throw new OpCompileError(
      `step reads relation '${relation}', which the run has not created`,
      'name a data requirement key or an earlier step id',
    );
  }

  const hit = cols.find((c) => c.name.toLowerCase() === name.toLowerCase());
  if (!hit) {
    const known = cols.map((c) => c.name).slice(0, 12).join(', ');
    throw new OpCompileError(
      `relation '${relation}' has no column '${name}'`,
      known ? `columns available: ${known}` : 'the relation has no columns',
    );
  }

  return hit.name;
}

/**
 * Resolve a whole number that may instead name a setting.
 *
 * The resolved value is returned so the caller binds it. It is range-checked here because
 * a saved setting value can be out of range by the time a scheduled run reads it, and a
 * negative `LIMIT` fails inside the database with no indication of which setting caused it.
 */
export function resolveCount(
  v: IntOrParam,
  label: string,
  min: number,
  max: number,
  input: OpCompileInput,
): number {
  const raw = typeof v === 'number' ? v : input.params.get(v.param);
  const from = typeof v === 'number' ? label : `setting '${v.param}'`;

  if (typeof raw !== 'number' || !Number.isInteger(raw)) {
    throw new OpCompileError(
      `${label} must be a whole number, but ${from} supplied ${describe(raw)}`,
      typeof v === 'number' ? undefined : `declare '${v.param}' as a number setting`,
    );
  }
  if (raw < min || raw > max) {
    throw new OpCompileError(
      `${label} must be between ${min} and ${max}, but ${from} supplied ${raw}`,
    );
  }

  return raw;
}

function describe(v: unknown): string {
  if (v === undefined) return 'no value';
  if (v === null) return 'null';
  if (typeof v === 'string') return `the text ${JSON.stringify(v)}`;
  return String(v);
}

/** The single input of a one-input operation. */
export function soleInput(input: OpCompileInput): string {
  const [only] = input.inputs;
  if (input.inputs.length !== 1 || only === undefined) {
    throw new OpCompileError(
      `this operation takes exactly one input, but ${input.inputs.length} were given`,
    );
  }
  return only;
}

/** Refuse ambiguous output names before the database silently renames them. */
export function checkOutputNames(names: readonly string[]): void {
  const taken = new Set<string>();
  for (const name of names) {
    const key = name.toLowerCase();
    if (taken.has(key)) {
      throw new OpCompileError(
        `two output columns would both be called '${name}'`,
        'give each output a name of its own, different from every other output column',
      );
    }
    taken.add(key);
  }
}

/** Check an added column against every column retained from the input. */
export function checkAddedColumn(relation: string, name: string, input: OpCompileInput): void {
  const columns = input.columns.get(relation);
  if (!columns) throw new OpCompileError('Input relation is unavailable');
  checkOutputNames([...columns.map((c) => c.name), name]);
}

/** The numeric scalar types supported by statistical operations. */
export function isNumericType(type: string): boolean {
  return /^(U?(TINYINT|SMALLINT|INTEGER|BIGINT|HUGEINT)|INT\d*|DOUBLE|FLOAT|DECIMAL|REAL|NUMERIC)(\(\d+(,\s*\d+)?\))?$/i.test(type);
}

/** Append the common partition and ordering clauses of a window. */
export function compileWindowOrder(
  b: SqlBuilder,
  relation: string,
  input: OpCompileInput,
  partition: readonly string[] = [],
  order: readonly { col: string; dir: 'asc' | 'desc' }[] = [],
): void {
  if (partition.length > 0) {
    b.keyword('PARTITION BY').list(partition, ',', (name, builder) => builder.column(checkedColumn(relation, name, input)));
  }
  if (order.length > 0) {
    b.keyword('ORDER BY').list(order, ',', ({ col, dir }, builder) => {
      if (dir !== 'asc' && dir !== 'desc') throw new OpCompileError('Unsupported sort direction');
      builder.column(checkedColumn(relation, col, input)).keyword(dir === 'asc' ? 'ASC' : 'DESC');
    });
  }
}
