/**
 * Operations whose arithmetic cannot be one SELECT: `irr` and `regress` over more than
 * one column.
 *
 * They follow the same contract as every other operation, with one addition: before
 * answering they may read from the run's database through `read`. What they hand back is
 * still a single `CompiledStep`, built with `SqlBuilder`, whose every computed number is a
 * bound value. The run loop therefore stores their result exactly as it stores any other
 * step, and nothing computed here is ever pasted into SQL text.
 *
 * Reads are bounded by `MAX_READ_ROWS`. These operations do their arithmetic on the main
 * thread, so an unbounded read is the one way they could stall a run.
 */

import type { QueryResult } from '../context.ts';
import type { CompiledStep, OpCompileInput } from './contract.ts';

export const MAX_READ_ROWS = 100_000;

/** Run one statement built by the operation itself and return its rows. */
export type OpRead = (step: CompiledStep) => Promise<QueryResult>;

export type OpRunner<P> = (params: P, input: OpCompileInput, read: OpRead) => Promise<CompiledStep>;
