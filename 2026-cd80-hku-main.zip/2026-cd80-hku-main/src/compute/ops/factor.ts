import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, OpCompileError, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

/**
 * A named market measure from a fixed list.
 *
 * Every supported factor is written out below as the arithmetic it is. A name that is not
 * on the list is refused with the list attached, never guessed at: the provided factor
 * definitions are prose, and turning prose into a formula is research, not a lookup.
 *
 * The input is daily rows keyed by `ts_code` and `trade_date`, with the price or
 * valuation columns the chosen factor needs. Rolling measures are blank until their window
 * is full, so a stock listed ten days ago has no 20-day volatility rather than a 10-day
 * one under a 20-day name.
 *
 * Output: one row per security, on its latest trading day — or its latest on or before
 * `as_of` — with columns `ts_code`, `trade_date` and one column named after the factor.
 * With `universe`, only securities listed in that relation's `ts_code` column are kept.
 */

const KEY = 'ts_code';
const DAY = 'trade_date';

type FactorDef = { needs: readonly string[]; meaning: string; sql: string };

/** The rolling frame over the last `n` rows of one security, ending today. */
const last = (n: number) =>
  `OVER (PARTITION BY "${KEY}" ORDER BY "${DAY}" ROWS BETWEEN ${n - 1} PRECEDING AND CURRENT ROW)`;
const byDay = `OVER (PARTITION BY "${KEY}" ORDER BY "${DAY}")`;

/** `expr`, but blank until `n` non-blank values of `col` are in the frame. */
const full = (col: string, n: number, expr: string) =>
  `CASE WHEN count("${col}") ${last(n)} = ${n} THEN ${expr} END`;

const momentum = (n: number): FactorDef => ({
  needs: ['close'],
  meaning: `price change over the last ${n} trading days`,
  sql: `"close" / NULLIF(lag("close", ${n}) ${byDay}, 0) - 1`,
});
const volatility = (n: number): FactorDef => ({
  needs: ['close'],
  meaning: `yearly-scaled spread of daily returns over the last ${n} trading days`,
  sql: full('__ret', n, `stddev_samp("__ret") ${last(n)} * sqrt(252)`),
});
const maGap = (n: number): FactorDef => ({
  needs: ['close'],
  meaning: `how far the price sits above its ${n}-day average`,
  sql: full('close', n, `"close" / NULLIF(avg("close") ${last(n)}, 0) - 1`),
});

export const FACTORS: Readonly<Record<string, FactorDef>> = {
  momentum_5d: momentum(5),
  momentum_20d: momentum(20),
  momentum_60d: momentum(60),
  momentum_120d: momentum(120),
  momentum_250d: momentum(250),
  volatility_20d: volatility(20),
  volatility_60d: volatility(60),
  ma_gap_20d: maGap(20),
  ma_gap_60d: maGap(60),
  high_gap_250d: {
    needs: ['close'],
    meaning: 'how far the price sits below its highest close of the last 250 trading days',
    sql: full('close', 250, `"close" / NULLIF(max("close") ${last(250)}, 0) - 1`),
  },
  avg_volume_20d: {
    needs: ['vol'],
    meaning: 'average daily volume over the last 20 trading days',
    sql: full('vol', 20, `avg("vol") ${last(20)}`),
  },
  avg_amount_20d: {
    needs: ['amount'],
    meaning: 'average daily traded value over the last 20 trading days',
    sql: full('amount', 20, `avg("amount") ${last(20)}`),
  },
  volume_ratio_5_20d: {
    needs: ['vol'],
    meaning: 'average volume of the last 5 days divided by that of the last 20',
    sql: full('vol', 20, `avg("vol") ${last(5)} / NULLIF(avg("vol") ${last(20)}, 0)`),
  },
  turnover_20d: {
    needs: ['turnover_rate'],
    meaning: 'average daily turnover rate over the last 20 trading days',
    sql: full('turnover_rate', 20, `avg("turnover_rate") ${last(20)}`),
  },
  earnings_yield: {
    needs: ['pe'],
    meaning: 'earnings per unit of price (1 / P/E), blank when earnings are negative',
    sql: `CASE WHEN "pe" > 0 THEN 1.0 / "pe" END`,
  },
  book_to_price: {
    needs: ['pb'],
    meaning: 'book value per unit of price (1 / P/B), blank when book value is negative',
    sql: `CASE WHEN "pb" > 0 THEN 1.0 / "pb" END`,
  },
  dividend_yield: {
    needs: ['dv_ttm'],
    meaning: 'dividends of the last 12 months per unit of price, as a fraction',
    sql: `"dv_ttm" / 100.0`,
  },
  log_size: {
    needs: ['total_mv'],
    meaning: 'natural logarithm of total market value',
    sql: `CASE WHEN "total_mv" > 0 THEN ln("total_mv") END`,
  },
};

export const SUPPORTED_FACTORS = Object.keys(FACTORS).sort();

export const compileFactor: OpCompiler<z.infer<typeof OperationParams.factor>> = (params, input) => {
  const relation = soleInput(input);
  const def = Object.hasOwn(FACTORS, params.factor) ? FACTORS[params.factor] : undefined;
  if (!def) {
    throw new OpCompileError(
      `factor '${params.factor}' is not supported`,
      `supported: ${SUPPORTED_FACTORS.join(', ')}`,
    );
  }

  // The column names are fixed by the factor definitions, so each must exist exactly.
  for (const col of [KEY, DAY, ...def.needs]) {
    const found = checkedColumn(relation, col, input);
    if (found !== col) {
      throw new OpCompileError(`factor '${params.factor}' needs a column named exactly '${col}', found '${found}'`);
    }
  }

  const b = new SqlBuilder().keyword('SELECT').column(KEY).keyword(',').column(DAY).keyword(',')
    .column(params.factor).keyword('FROM ( SELECT').column(KEY).keyword(',').column(DAY)
    .keyword(',').keyword(`CAST(${def.sql} AS DOUBLE)`).column(params.factor).keyword('FROM');

  // Daily returns are added only for a factor that reads them, so a valuation factor does
  // not demand a `close` column it never uses.
  const needsReturns = def.sql.includes('__ret');
  if (needsReturns) {
    // Only the columns the factor names are carried through, so a column the input
    // already calls `__ret` cannot shadow the return computed here.
    b.keyword('( SELECT').list([KEY, DAY, ...def.needs], ',', (c, bb) => bb.column(c))
      .keyword(', CAST("close" AS DOUBLE) / NULLIF(lag("close", 1)').keyword(byDay)
      .keyword(', 0) - 1 AS "__ret" FROM');
  }
  b.column(relation);
  universeFilter(b, params.universe, input);
  if (needsReturns) b.keyword(')');
  b.keyword(') AS __s');
  asOfFilter(b, params.as_of);
  return b.build();
};

function universeFilter(b: SqlBuilder, universe: string | undefined, input: Parameters<typeof checkedColumn>[2]): void {
  if (universe === undefined) return;
  const col = checkedColumn(universe, KEY, input);
  b.keyword('WHERE').column(KEY).keyword('IN (SELECT').column(col).keyword('FROM').column(universe).keyword(')');
}

function asOfFilter(b: SqlBuilder, asOf: string | undefined): void {
  if (asOf !== undefined) {
    b.keyword('WHERE CAST(').column(DAY).keyword('AS DATE) <= CAST(').value(asOf).keyword('AS DATE)');
  }
  b.keyword('QUALIFY row_number() OVER (PARTITION BY').column(KEY)
    .keyword('ORDER BY').column(DAY).keyword('DESC) = 1 ORDER BY').column(KEY);
}
