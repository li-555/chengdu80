import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { compileMetric } from './metric.ts';
import { checkedColumn, checkOutputNames, OpCompileError, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compileResample: OpCompiler<z.infer<typeof OperationParams.resample>> = (params, input) => {
  const relation = soleInput(input);
  const by = (params.by ?? []).map((name) => checkedColumn(relation, name, input));
  const date = checkedColumn(relation, params.date_col, input);
  checkOutputNames([...by, date, ...params.metrics.map((m) => m.as)]);
  if (params.metrics.length === 0) throw new OpCompileError('Resample requires at least one metric');
  const builder = new SqlBuilder().keyword('SELECT');
  builder.list(by, ',', (name, b) => b.column(name));
  if (by.length > 0) builder.keyword(',');
  builder.keyword('date_trunc (').value(params.to).keyword(',').column(date).keyword(')::DATE AS').column(date).keyword(',');
  builder.list(params.metrics, ',', (metric, b) => {
    compileMetric(metric, relation, input, b);
    b.keyword('AS').column(metric.as);
  });
  // GROUP BY ALL groups the projected keys and bucket without repeating a bound date part.
  builder.keyword('FROM').column(relation).keyword('GROUP BY ALL ORDER BY');
  builder.list([...by, date], ',', (name, b) => b.column(name));
  return builder.build();
};
