import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, checkOutputNames, OpCompileError, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compileRegress: OpCompiler<z.infer<typeof OperationParams.regress>> = (params, input) => {
  const relation = soleInput(input);
  const y = checkedColumn(relation, params.y, input);
  const xs = params.x.map((name) => checkedColumn(relation, name, input));
  if (xs.length > 1) throw new OpCompileError('regression on more than one column is not implemented yet');
  if (xs.length === 0) throw new OpCompileError('Regression requires an x column');
  const x = xs[0]!;
  const by = (params.by ?? []).map((name) => checkedColumn(relation, name, input));
  checkOutputNames([...by, 'term', 'coefficient', 'r2', 'n']);
  const builder = new SqlBuilder();
  builder.list([['intercept', 'regr_intercept'], [x, 'regr_slope']], 'UNION ALL', ([term, fn], b) => {
    b.keyword('SELECT').list(by, ',', (name, sql) => sql.column(name));
    if (by.length > 0) b.keyword(',');
    b.value(term).keyword('::VARCHAR AS term ,');
    b.list([[fn!, 'coefficient', 'DOUBLE'], ['regr_r2', 'r2', 'DOUBLE'], ['regr_count', 'n', 'BIGINT']], ',', ([func, as, type], sql) => {
      sql.keyword(func!).keyword('(').column(y).keyword(',').column(x).keyword(')::' + type).keyword('AS').column(as!);
    });
    b.keyword('FROM').column(relation);
    if (by.length > 0) b.keyword('GROUP BY').list(by, ',', (name, sql) => sql.column(name));
  });
  return builder.build();
};
