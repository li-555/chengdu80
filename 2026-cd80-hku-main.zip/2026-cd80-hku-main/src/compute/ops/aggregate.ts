import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { compileMetric } from './metric.ts';
import { checkedColumn, OpCompileError, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compileAggregate: OpCompiler<z.infer<typeof OperationParams.aggregate>> = (params, input) => {
  const relation = soleInput(input);
  if (!input.columns.has(relation)) throw new OpCompileError('Input relation is unavailable');
  if (params.metrics.length === 0) throw new OpCompileError('Aggregate requires at least one metric');

  /**
   * The output names must be distinct. A metric named after one of the grouping columns
   * produced two columns with one name, and a later step reading that name then silently
   * read whichever the engine returned first.
   */
  const taken = new Set<string>();
  for (const name of [...params.by, ...params.metrics.map((m) => m.as)]) {
    const key = name.toLowerCase();
    if (taken.has(key)) {
      throw new OpCompileError(
        `two output columns would both be called '${name}'`,
        'give each metric a name of its own, different from every grouping column',
      );
    }
    taken.add(key);
  }
  const builder = new SqlBuilder().keyword('SELECT');
  builder.list(params.by, ',', (name, b) => b.column(checkedColumn(relation, name, input)));
  if (params.by.length > 0) builder.keyword(',');
  builder.list(params.metrics, ',', (metric, b) => {
    compileMetric(metric, relation, input, b);
    b.keyword('AS').column(metric.as);
  });
  builder.keyword('FROM').column(relation);
  if (params.by.length > 0) {
    builder.keyword('GROUP BY').list(params.by, ',', (name, b) => b.column(checkedColumn(relation, name, input)));
  }
  return builder.build();
};
