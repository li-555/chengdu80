import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, checkAddedColumn, compileWindowOrder, resolveCount, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compileLagChange: OpCompiler<z.infer<typeof OperationParams.lag_change>> = (params, input) => {
  const relation = soleInput(input);
  checkAddedColumn(relation, params.as, input);
  const of = checkedColumn(relation, params.of, input);
  const periods = resolveCount(params.periods, 'periods', 1, 10000, input);
  const builder = new SqlBuilder().keyword('SELECT * ,');
  const current = () => builder.keyword('CAST (').column(of).keyword('AS DOUBLE )');
  const previous = () => {
    builder.keyword('LAG ( CAST (').column(of).keyword('AS DOUBLE ) ,').value(periods).keyword(') OVER (');
    compileWindowOrder(builder, relation, input, params.partition_by, params.order_by);
    builder.keyword(')');
  };
  if (params.mode === 'log') {
    builder.keyword('CASE WHEN');
    current();
    builder.keyword('>').value(0).keyword('AND');
    previous();
    builder.keyword('>').value(0).keyword('THEN ln (');
    current();
    builder.keyword('/');
    previous();
    builder.keyword(') END');
  } else {
    current();
    if (params.mode === 'diff') {
      builder.keyword('-');
      previous();
    } else {
      builder.keyword('/ NULLIF (');
      previous();
      builder.keyword(',').value(0).keyword(') -').value(1);
    }
  }
  return builder.keyword('AS').column(params.as).keyword('FROM').column(relation).build();
};
