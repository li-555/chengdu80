import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkAddedColumn, compileWindowOrder, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compileRank: OpCompiler<z.infer<typeof OperationParams.rank>> = (params, input) => {
  const relation = soleInput(input);
  checkAddedColumn(relation, params.as, input);
  const functions = { rank: 'rank', dense: 'dense_rank', row_number: 'row_number', percentile: 'percent_rank' } as const;
  const builder = new SqlBuilder().keyword('SELECT * ,').keyword(functions[params.method]).keyword('() OVER (');
  compileWindowOrder(builder, relation, input, params.within, [{ col: params.by, dir: params.direction }]);
  return builder.keyword(') AS').column(params.as).keyword('FROM').column(relation).build();
};
