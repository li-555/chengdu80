import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, checkAddedColumn, compileWindowOrder, OpCompileError, resolveCount, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compileZscore: OpCompiler<z.infer<typeof OperationParams.zscore>> = (params, input) => {
  const relation = soleInput(input);
  checkAddedColumn(relation, params.as, input);
  const of = checkedColumn(relation, params.of, input);
  const window = params.window === undefined ? undefined : resolveCount(params.window, 'window', 2, 100000, input);
  if (window !== undefined && !params.order_by?.length) throw new OpCompileError('order_by is required when window is set');
  const builder = new SqlBuilder().keyword('SELECT * ,');
  const over = () => {
    builder.keyword('OVER (');
    compileWindowOrder(builder, relation, input, params.within, window === undefined ? [] : params.order_by);
    if (window !== undefined) builder.keyword('ROWS BETWEEN').value(window - 1).keyword('PRECEDING AND CURRENT ROW');
    builder.keyword(')');
  };
  if (window !== undefined) {
    builder.keyword('CASE WHEN count (').column(of).keyword(')');
    over();
    builder.keyword('>=').value(window).keyword('THEN');
  }
  builder.keyword('( CAST (').column(of).keyword('AS DOUBLE ) - avg (').column(of).keyword(')');
  over();
  builder.keyword(') / NULLIF ( stddev_samp (').column(of).keyword(')');
  over();
  builder.keyword(',').value(0).keyword(')');
  if (window !== undefined) builder.keyword('END');
  return builder.keyword('AS').column(params.as).keyword('FROM').column(relation).build();
};
