import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, checkAddedColumn, compileWindowOrder, isNumericType, OpCompileError, resolveCount, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compileWindow: OpCompiler<z.infer<typeof OperationParams.window>> = (params, input) => {
  const relation = soleInput(input);
  checkAddedColumn(relation, params.as, input);
  const of = checkedColumn(relation, params.of, input);
  const preceding = resolveCount(params.frame.preceding, 'preceding', 0, 100000, input);
  const following = resolveCount(params.frame.following, 'following', 0, 100000, input);
  const functions = {
    sum: 'sum', mean: 'avg', min: 'min', max: 'max', count: 'count',
    stddev: 'stddev_samp', first: 'first_value', last: 'last_value',
  } as const;
  let days = false;
  if (params.frame.kind === 'range') {
    if (params.order_by.length !== 1) throw new OpCompileError('Range requires exactly one order_by column');
    const name = checkedColumn(relation, params.order_by[0]!.col, input);
    const type = input.columns.get(relation)!.find((c) => c.name === name)!.type;
    days = /^(DATE|TIMESTAMP)(\b|_)/i.test(type);
    if (!days && !isNumericType(type)) throw new OpCompileError('Range order_by must be numeric, DATE or TIMESTAMP');
  }
  const builder = new SqlBuilder().keyword('SELECT * ,').keyword(functions[params.fn]).keyword('(').column(of).keyword(') OVER (');
  compileWindowOrder(builder, relation, input, params.partition_by, params.order_by);
  builder.keyword(params.frame.kind === 'rows' ? 'ROWS BETWEEN' : 'RANGE BETWEEN');
  const bound = (n: number) => {
    if (days) builder.keyword('INTERVAL (').value(n).keyword(') DAY');
    else builder.value(n);
  };
  bound(preceding);
  builder.keyword('PRECEDING AND');
  bound(following);
  return builder.keyword('FOLLOWING ) AS').column(params.as).keyword('FROM').column(relation).build();
};
