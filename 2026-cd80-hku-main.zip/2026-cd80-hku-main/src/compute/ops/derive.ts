import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { compileExpression } from '../expr.ts';
import { checkedColumn, OpCompileError, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compileDerive: OpCompiler<z.infer<typeof OperationParams.derive>> = (params, input) => {
  const relation = soleInput(input);
  const columns = input.columns.get(relation);
  if (!columns) throw new OpCompileError('Input relation is unavailable', 'Supply the input relation columns');
  const entries = Object.entries(params.columns);
  const output = {
    ...input,
    columns: new Map([[relation, entries.map(([name]) => ({ name, type: 'UNKNOWN' }))]]),
  };
  const scope = {
    columns: columns.map((c) => checkedColumn(relation, c.name, input)),
    params: [...input.params.keys()],
    scalars: [...input.scalars.keys()],
  };
  const builder = new SqlBuilder().keyword('SELECT *');
  try {
    for (const [name, expr] of entries) {
      const compiled = compileExpression(expr, {
        scope,
        params: input.params,
        scalars: input.scalars,
      });
      builder.keyword(',').fragment(compiled.sql, compiled.bindings)
        .keyword('AS').column(checkedColumn(relation, name, output));
    }
    return builder.keyword('FROM').column(relation).build();
  } catch (error) {
    if (error instanceof OpCompileError) throw error;
    throw new OpCompileError(error instanceof Error ? error.message : String(error), 'Check the derived formulas and input columns');
  }
};
