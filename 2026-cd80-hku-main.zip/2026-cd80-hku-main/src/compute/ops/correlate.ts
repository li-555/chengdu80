import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, checkOutputNames, OpCompileError, resolveCount, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compileCorrelate: OpCompiler<z.infer<typeof OperationParams.correlate>> = (params, input) => {
  const relation = soleInput(input);
  const columns = params.columns.map((name) => checkedColumn(relation, name, input));
  checkOutputNames(columns);
  if (columns.length < 2) throw new OpCompileError('Correlate requires at least two columns');
  const minimum = params.min_periods === undefined ? undefined : resolveCount(params.min_periods, 'min_periods', 2, 100000, input);
  const pairs = columns.flatMap((a, i) => columns.slice(i + 1).map((b) => [a, b] as const));
  const builder = new SqlBuilder();
  builder.list(pairs, 'UNION ALL', ([a, b], sql) => {
    sql.keyword('SELECT').value(a).keyword('::VARCHAR AS col_a ,').value(b).keyword('::VARCHAR AS col_b ,');
    if (minimum !== undefined) sql.keyword('CASE WHEN count (*) >=').value(minimum).keyword('THEN');
    sql.keyword('corr (');
    if (params.method === 'spearman') sql.column('rank_a').keyword(',').column('rank_b');
    else sql.column(a).keyword(',').column(b);
    sql.keyword(')::DOUBLE');
    if (minimum !== undefined) sql.keyword('END');
    sql.keyword('AS corr , count (*)::BIGINT AS n FROM');
    if (params.method === 'spearman') {
      sql.keyword('( SELECT');
      sql.list([[a, 'rank_a'], [b, 'rank_b']], ',', ([name, as], rank) => {
        rank.keyword('rank () OVER ( ORDER BY').column(name!).keyword(') + ( count (*) OVER ( PARTITION BY')
          .column(name!).keyword(') -').value(1).keyword(') /').value(2.0).keyword('AS').column(as!);
      });
      sql.keyword('FROM').column(relation);
    } else sql.column(relation);
    sql.keyword('WHERE').column(a).keyword('IS NOT NULL AND').column(b).keyword('IS NOT NULL');
    if (params.method === 'spearman') sql.keyword(')');
  });
  return builder.build();
};
