import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, OpCompileError, resolveCount, soleInput, SqlBuilder, type OpCompiler } from './contract.ts';

export const compileSortLimit: OpCompiler<z.infer<typeof OperationParams.sort_limit>> = (params, input) => {
  const relation = soleInput(input);
  if (params.by.length === 0) throw new OpCompileError('Sort requires at least one column');
  const builder = new SqlBuilder().keyword('SELECT * FROM').column(relation).keyword('ORDER BY');
  builder.list(params.by, ',', ({ col, dir }, b) => {
    if (dir !== 'asc' && dir !== 'desc') throw new OpCompileError('Unsupported sort direction');
    b.column(checkedColumn(relation, col, input)).keyword(dir === 'asc' ? 'ASC' : 'DESC');
  });
  if (params.limit !== undefined) {
    builder.keyword('LIMIT').value(resolveCount(params.limit, 'limit', 1, 200000, input));
  }
  if (params.offset !== undefined) {
    builder.keyword('OFFSET').value(resolveCount(params.offset, 'offset', 0, 200000, input));
  }
  return builder.build();
};
