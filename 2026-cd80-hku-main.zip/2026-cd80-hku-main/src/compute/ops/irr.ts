import type { z } from 'zod';
import type { OperationParams } from '../../app-schema/operations.ts';
import { checkedColumn, OpCompileError, soleInput, SqlBuilder } from './contract.ts';
import { MAX_READ_ROWS, type OpRunner } from './runner.ts';

/**
 * The internal rate of return of dated cash flows: the yearly rate at which their value,
 * discounted to the first date, is zero. Money paid out is negative, money received is
 * positive. Time is counted in days over a 365-day year, so a result of 0.08 means 8% a
 * year.
 *
 * Solved by Newton's method from `guess` for at most `max_iter` steps. Newton can jump
 * past -100%, where the formula is undefined, or wander off on an awkward series, so if
 * it has not converged the rate is then found by halving an interval known to contain a
 * sign change. Both loops have a fixed cap; there is no open-ended loop in this file.
 *
 * Output: one row, one column `irr`. The run loop reads it as a single value that later
 * formulas may use by the step's id.
 */
export const runIrr: OpRunner<z.infer<typeof OperationParams.irr>> = async (params, input, read) => {
  const relation = soleInput(input);
  const amount = checkedColumn(relation, params.amount_col, input);
  const date = checkedColumn(relation, params.date_col, input);

  const result = await read(
    new SqlBuilder()
      .keyword('SELECT CAST(').column(amount).keyword('AS DOUBLE) AS a , CAST(').column(date)
      .keyword('AS DATE) AS d FROM').column(relation)
      .keyword('WHERE').column(amount).keyword('IS NOT NULL AND').column(date)
      .keyword('IS NOT NULL ORDER BY d LIMIT').value(MAX_READ_ROWS + 1)
      .build(),
  );

  if (result.rows.length > MAX_READ_ROWS) {
    throw new OpCompileError(`irr reads at most ${MAX_READ_ROWS} cash flows`, 'filter or aggregate the payments first');
  }

  const flows = result.rows.map((r) => ({ a: Number(r.a), t: dayNumber(r.d) }));
  if (flows.length < 2) {
    throw new OpCompileError('irr needs at least two dated payments');
  }
  if (!flows.some((f) => f.a < 0) || !flows.some((f) => f.a > 0)) {
    throw new OpCompileError(
      'irr needs at least one payment out (negative) and one payment in (positive)',
      'check the sign of the amounts',
    );
  }

  const t0 = flows[0]!.t;
  const years = flows.map((f) => ({ a: f.a, y: (f.t - t0) / 365 }));

  const rate = solve(years, params.guess ?? 0.1, params.max_iter);
  if (rate === undefined) {
    throw new OpCompileError('irr did not find a rate: these payments have no single break-even rate');
  }

  return new SqlBuilder().keyword('SELECT CAST(').value(rate).keyword('AS DOUBLE) AS "irr"').build();
};

type Flow = { a: number; y: number };

const TOLERANCE = 1e-10;
const BISECTION_STEPS = 200;

function npv(flows: readonly Flow[], r: number): number {
  let s = 0;
  for (const f of flows) s += f.a / Math.pow(1 + r, f.y);
  return s;
}

function dnpv(flows: readonly Flow[], r: number): number {
  let s = 0;
  for (const f of flows) s -= (f.y * f.a) / Math.pow(1 + r, f.y + 1);
  return s;
}

/** Exported for the tests only. */
export function solve(flows: readonly Flow[], guess: number, maxIter: number): number | undefined {
  let r = guess;
  for (let i = 0; i < maxIter; i++) {
    const f = npv(flows, r);
    const d = dnpv(flows, r);
    if (!Number.isFinite(f) || !Number.isFinite(d) || d === 0) break;
    const next = r - f / d;
    if (!Number.isFinite(next) || next <= -1) break;
    if (Math.abs(next - r) < TOLERANCE) return next;
    r = next;
  }

  // Bisection once a sign change is found on a fixed grid. The grid starts a hair above
  // -100%, where the formula is undefined, because a near-total loss is a real answer.
  const grid = [-1 + 1e-12, -1 + 1e-9, -1 + 1e-6, -0.999, -0.99, -0.9, -0.5, -0.2, 0, 0.1, 0.25, 0.5, 1, 2, 5, 10, 100, 1000, 10000];
  for (let i = 0; i + 1 < grid.length; i++) {
    let lo = grid[i]!;
    let hi = grid[i + 1]!;
    let flo = npv(flows, lo);
    const fhi = npv(flows, hi);
    if (!Number.isFinite(flo) || !Number.isFinite(fhi) || Math.sign(flo) === Math.sign(fhi)) continue;
    for (let k = 0; k < BISECTION_STEPS; k++) {
      const mid = (lo + hi) / 2;
      const fm = npv(flows, mid);
      if (Math.abs(hi - lo) < TOLERANCE) return mid;
      if (Math.sign(fm) === Math.sign(flo)) { lo = mid; flo = fm; } else { hi = mid; }
    }
    return (lo + hi) / 2;
  }
  return undefined;
}

/** A DATE read back from the engine, as a whole number of days. */
function dayNumber(v: unknown): number {
  const ms = Date.parse(String(v).slice(0, 10) + 'T00:00:00Z');
  if (!Number.isFinite(ms)) {
    throw new OpCompileError(`irr could not read the date ${JSON.stringify(v)}`);
  }
  return Math.round(ms / 86_400_000);
}
