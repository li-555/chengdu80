import { Router, json, type ErrorRequestHandler } from 'express';
import { z } from 'zod';
import { sameOrigin } from './same-origin.ts';
import { browserProfileId } from '../platform/browser-profile.ts';
import { importTemplate, templates } from '../platform/templates.ts';

export const templateRouter = Router();
templateRouter.use('/api/examples', sameOrigin, (_request, response, next) => { response.set('Cache-Control', 'no-store'); next(); });
templateRouter.get('/api/examples', (_request, response) => { response.json({ templates }); });
templateRouter.post('/api/examples/:id/import', json({ limit: '4kb' }), async (request, response) => {
  const id = browserProfileId(request);
  if (!id || request.get('X-Blocks-Request') !== '1') { response.status(403).json({ error: { code: 'PROFILE_REQUIRED', message: 'Open My Apps before importing a template.' } }); return; }
  const parsed = z.strictObject({ mode: z.literal('connect') }).safeParse(request.body);
  if (!parsed.success) { response.status(400).json({ error: { code: 'BAD_MODE', message: 'Connect Tushare and your own data. Invented flagship inputs are no longer available.' } }); return; }
  try {
    const result = await importTemplate(request.params.id as string, `browser:${id}`, id, parsed.data.mode);
    if (result.kind === 'missing') { response.status(404).json({ error: { code: 'TEMPLATE_NOT_FOUND', message: 'This template is not available.' } }); return; }
    response.status(201).json(result);
  } catch { response.status(503).json({ error: { code: 'TEMPLATE_UNAVAILABLE', message: 'The template could not be installed. Check storage and try again.' } }); }
});
templateRouter.use(((error, _request, response, next) => {
  if (error?.type === 'entity.too.large') { response.status(413).json({ error: { code: 'BODY_TOO_LARGE', message: 'The request is too large.' } }); return; }
  if (error?.type === 'entity.parse.failed') { response.status(400).json({ error: { code: 'BAD_JSON', message: 'Connect Tushare and your own data. Invented flagship inputs are no longer available.' } }); return; }
  next(error);
}) satisfies ErrorRequestHandler);
