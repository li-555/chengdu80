import express from 'express';
import { getApp } from '../platform/storage.ts';
import { getListActions, listActionRequest, saveListAction } from '../platform/list-actions.ts';

/** Mounted after the application router's origin, browser profile and write guards. */
export const listActionRouter = express.Router({ mergeParams: true });
function fail(response: express.Response, status: number, code: string, message: string): void { response.status(status).json({ error: { code, message } }); }
listActionRouter.use(async (request, response, next) => {
  try {
    const app = await getApp((request.params as Record<string, string>).id as string);
    if (!app || app.profile !== response.locals.profile) { fail(response, 404, 'APP_NOT_FOUND', 'This application is not in your library.'); return; }
    next();
  } catch { fail(response, 503, 'STORAGE_UNAVAILABLE', 'Saved list actions could not be loaded. Check storage and try again.'); }
});
listActionRouter.get('/', async (request, response) => {
  try { response.json(await getListActions((request.params as Record<string, string>).id as string, response.locals.profile as string)); }
  catch { fail(response, 503, 'STORAGE_UNAVAILABLE', 'Saved list actions could not be loaded. Check storage and try again.'); }
});
listActionRouter.post('/', express.json({ limit: '16kb', inflate: false }), async (request, response) => {
  const parsed = listActionRequest.safeParse(request.body);
  if (!parsed.success) { fail(response, 422, 'INVALID_LIST_ACTION', 'Choose a declared list setting, record ID and valid action.'); return; }
  try {
    const result = await saveListAction((request.params as Record<string, string>).id as string, response.locals.profile as string, parsed.data);
    if (result.kind === 'conflict') { fail(response, 409, 'SETTINGS_CHANGED', 'Settings changed. Refresh before saving another action.'); return; }
    if (result.kind === 'request_conflict') { fail(response, 409, 'REQUEST_CHANGED', 'This request ID belongs to another action.'); return; }
    if (result.kind === 'invalid') { fail(response, 422, 'INVALID_LIST_ACTION', 'Choose a declared text list setting and valid record ID.'); return; }
    response.json(result);
  } catch { fail(response, 503, 'ACTION_UNCONFIRMED', 'Saving could not be confirmed. Retry the same action or refresh its history.'); }
});
listActionRouter.use((error: unknown, _request: express.Request, response: express.Response, next: express.NextFunction) => {
  if (response.headersSent) { next(error); return; }
  const status = error && typeof error === 'object' && 'status' in error ? error.status : undefined;
  fail(response, status === 413 ? 413 : 400, 'INVALID_LIST_ACTION', 'The list action request could not be read.');
});
