/**
 * The vertical-slice page: a document validated, run, and rendered as a table.
 *
 * This is deliberately disposable. It exists so the pipeline can be seen working before
 * the real screen elements and renderer are ready, and it is replaced by them. It renders
 * from the run outcome only, with the platform's own theme, and it contains no element
 * catalogue, no React and no bundler.
 *
 * Every row it shows comes from a committed invented fixture, never from a data provider.
 */

import { readFileSync } from 'node:fs';
import { validateApplication } from '../validate/index.ts';
import { runApplication, type Slice } from '../compute/run.ts';

type Request = { query: Record<string, unknown> };
type Response = { type: (t: string) => Response; send: (body: string) => void };

/** An invented slice, the same one the Gate 1 test uses. No real market data. */
const INVENTED_PRICES: Slice = {
  columns: [
    { name: 'code', type: 'string' },
    { name: 'd', type: 'date' },
    { name: 'px', type: 'number' },
    { name: 'prev_px', type: 'number' },
  ],
  rows: [
    { code: 'AAA', d: '2026-01-06', px: 12.5, prev_px: 10 },
    { code: 'BBB', d: '2026-01-06', px: 45, prev_px: 50 },
    { code: 'CCC', d: '2026-01-06', px: 10.2, prev_px: 10 },
    { code: 'DDD', d: '2026-01-06', px: 6, prev_px: 10 },
  ],
};

function escapeHtml(v: unknown): string {
  return String(v ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#39;');
}

/** Two decimals for a number, left alone otherwise. A date arrives already formatted. */
function formatCell(v: unknown): string {
  if (typeof v === 'number') {
    return Number.isInteger(v) ? String(v) : v.toFixed(2);
  }
  return escapeHtml(v);
}

export async function gate1Page(request: Request, response: Response): Promise<void> {
  const threshold = Number(request.query.threshold ?? 3);
  const topN = Number(request.query.top_n ?? 10);

  const doc = JSON.parse(
    readFileSync(new URL('../../examples/ex-01-daily-movers.fin.json', import.meta.url), 'utf8'),
  );

  const check = validateApplication(doc);
  if (!check.ok) {
    response.type('html').send(shell('Gate 1', `
      <h1>The document did not pass the check</h1>
      <pre>${escapeHtml(JSON.stringify(check.report.errors, null, 2))}</pre>`));
    return;
  }

  const outcome = await runApplication(doc, {
    slices: { prices: INVENTED_PRICES },
    params: {
      move_threshold: Number.isFinite(threshold) ? threshold : 3,
      top_n: Number.isFinite(topN) ? topN : 10,
    },
  });

  if (outcome.status === 'failed') {
    response.type('html').send(shell('Gate 1', `
      <h1>${escapeHtml(doc.meta.name)}</h1>
      <p class="bad">The run failed: ${escapeHtml(outcome.failure)}</p>`));
    return;
  }

  const movers = outcome.results.get('movers');
  const count = outcome.results.get('unusual');

  const table = movers && movers.rows.length > 0
    ? `<table>
        <thead><tr>${movers.columns.map((c) => `<th>${escapeHtml(c.name)}</th>`).join('')}</tr></thead>
        <tbody>${movers.rows.map((row) =>
          `<tr>${movers.columns.map((c) => `<td>${formatCell(row[c.name])}</td>`).join('')}</tr>`,
        ).join('')}</tbody>
       </table>`
    : '<p class="muted">No company moved more than the threshold.</p>';

  const steps = outcome.steps
    .map((s) => `<li><code>${escapeHtml(s.id)}</code> — ${escapeHtml(s.op ?? s.kind)}, ${s.rowsOut} row(s), ${s.durationMs} ms</li>`)
    .join('');

  response.type('html').send(shell(doc.meta.name, `
    <header>
      <h1>${escapeHtml(doc.meta.name)}</h1>
      <p class="muted">${escapeHtml(doc.meta.description)}</p>
    </header>

    <form method="get" class="controls">
      <label>Unusual above (%)<input name="threshold" type="number" step="0.5" value="${escapeHtml(threshold)}"></label>
      <label>How many to show<input name="top_n" type="number" step="1" value="${escapeHtml(topN)}"></label>
      <button type="submit">Run</button>
    </form>

    <section class="metric">
      <span class="metric-label">Companies with an unusual move</span>
      <span class="metric-value">${count?.rows.length ?? 0}</span>
    </section>

    ${table}

    <details>
      <summary>Under the hood</summary>
      <p class="muted">Settings used: ${[...outcome.params].map(([k, v]) => `${escapeHtml(k)} = ${escapeHtml(JSON.stringify(v))}`).join(', ')}</p>
      <ul>${steps}</ul>
      ${outcome.warnings.length > 0 ? `<p class="bad">${outcome.warnings.map(escapeHtml).join('<br>')}</p>` : ''}
      <p class="muted">Every row shown comes from a committed invented fixture.</p>
    </details>`));
}

function shell(title: string, body: string): string {
  return `<!doctype html>
<html lang="en" data-theme="daylight" data-convention="cn">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapeHtml(title)}</title>
<link rel="stylesheet" href="/assets/theme.css">
<link rel="stylesheet" href="/assets/platform.css">
<style>
  main { max-width: 60rem; margin: 0 auto; padding: 2rem 1rem; }
  header h1 { margin-bottom: .25rem; }
  .muted { opacity: .7; }
  .bad { color: #b3261e; }
  .controls { display: flex; gap: 1rem; flex-wrap: wrap; align-items: flex-end; margin: 1.5rem 0; }
  .controls label { display: flex; flex-direction: column; gap: .25rem; font-size: .875rem; }
  .controls input { padding: .4rem .5rem; }
  .metric { display: flex; flex-direction: column; gap: .25rem; border: 1px solid rgba(0,0,0,.12);
            border-radius: .75rem; padding: 1rem; margin-bottom: 1.5rem; }
  .metric-label { font-size: .875rem; opacity: .7; }
  .metric-value { font-size: 2rem; font-variant-numeric: tabular-nums; }
  table { width: 100%; border-collapse: collapse; border: 1px solid rgba(0,0,0,.12); border-radius: .75rem; }
  th, td { padding: .5rem .75rem; text-align: left; border-bottom: 1px solid rgba(0,0,0,.08); }
  td { font-variant-numeric: tabular-nums; }
  tbody tr:last-child td { border-bottom: 0; }
  details { margin-top: 2rem; font-size: .875rem; }
</style>
</head>
<body><main>${body}</main></body>
</html>`;
}
