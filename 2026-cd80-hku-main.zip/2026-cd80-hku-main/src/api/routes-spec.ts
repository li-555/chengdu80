import { Router } from 'express';
import { readFileSync } from 'node:fs';

/** Read the published files once, so every endpoint serves the same specification. */
const read = (name: string): string => readFileSync(new URL(`../../spec/${name}`, import.meta.url), 'utf8');
const markdown = read('SPEC.md');
const documents = {
  schema: { file: 'application.schema.json', value: JSON.parse(read('application.schema.json')) as unknown },
  blocks: { file: 'blocks.json', value: JSON.parse(read('blocks.json')) as unknown },
  operations: { file: 'operations.json', value: JSON.parse(read('operations.json')) as unknown },
  components: { file: 'components.json', value: JSON.parse(read('components.json')) as unknown },
  errors: { file: 'errors.json', value: JSON.parse(read('errors.json')) as unknown },
};
const bundle = {
  ...Object.fromEntries(Object.values(documents).map(({ file, value }) => [file, value])),
  'SPEC.md': markdown,
};

export const specRouter = Router();
specRouter.get('/api/spec', (_request, response) => {
  response.type('text/markdown').send(markdown);
});
for (const [endpoint, { value }] of Object.entries(documents)) {
  specRouter.get(`/api/spec/${endpoint}`, (_request, response) => {
    response.json(value);
  });
}
specRouter.get('/api/spec/bundle', (_request, response) => {
  response.json(bundle);
});
