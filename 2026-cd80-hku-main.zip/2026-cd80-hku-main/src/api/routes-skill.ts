import { Router } from 'express';
import { readFileSync } from 'node:fs';

const read = (name: string): string => readFileSync(new URL(`../../skill/${name}`, import.meta.url), 'utf8');
const markdown = read('blocks-skill.md');
const manifest = JSON.parse(read('skill.json')) as { files: Record<string, string> };
const files = new Map(Object.keys(manifest.files).map((path) => [path, read(path)]));

export const skillRouter = Router();
skillRouter.get('/api/skill', (_request, response) => {
  response.type('text/markdown').send(markdown);
});
skillRouter.get('/api/skill/files/*path', (request, response) => {
  const parts = request.params.path;
  const path = Array.isArray(parts) ? parts.join('/') : parts;
  const content = typeof path === 'string' && !path.split('/').some((part) => part === '..' || part === '.')
    ? files.get(path) : undefined;
  if (content === undefined) {
    response.status(404).json({ error: { code: 'NOT_FOUND', message: 'The requested file is not available.' } });
    return;
  }
  response.type(path!.endsWith('.json') ? 'application/json' : 'text/markdown').send(content);
});
