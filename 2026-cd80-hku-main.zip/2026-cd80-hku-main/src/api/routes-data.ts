// src/api/routes-data.ts -- Rachel's API routes

import { Router, json } from 'express';
import type { ErrorRequestHandler, RequestHandler, Response } from 'express';
import { listDatasets, getDataset, resolveSlice } from '../data/index.ts';
import type { SliceRequest } from '../data/types.ts';
import { sameOrigin } from './same-origin.ts';
import { datasetProfile } from '../platform/browser-profile.ts';
import { listUploads } from '../data/upload-store.ts';

export const STUB = false;

const router = Router();

function fail(response: Response, status: number, code: string, message: string): void {
  response.status(status).json({ error: { code, message } });
}

router.get('/api/data/datasets', sameOrigin, async (request, response) => {
  try {
    response.set('Cache-Control', 'no-store');
    // Provider metadata is shared. Uploads must have a recorded owner; API sources
    // without an ownership record are not exposed through the browser catalogue.
    const shared = (await listDatasets()).filter((dataset) => dataset.source === 'tushare');
    response.json({ datasets: [...shared, ...listUploads(datasetProfile(request, request.query.profile))] });
  } catch {
    fail(response, 503, 'DATA_UNAVAILABLE', 'Datasets could not be listed. Check the data service and try again.');
  }
});

router.get('/api/data/datasets/:id', sameOrigin, async (request, response) => {
  try {
    response.set('Cache-Control', 'no-store');
    const id = request.params.id as string;
    const candidate = await getDataset(id);
    const dataset = candidate?.source === 'tushare' ? candidate
      : listUploads(datasetProfile(request, request.query.profile)).find((upload) => upload.id === id);
    if (!dataset) {
      fail(response, 404, 'DATASET_NOT_FOUND', 'The requested dataset is not available.');
      return;
    }
    response.json({ dataset });
  } catch {
    fail(response, 503, 'DATA_UNAVAILABLE', 'The dataset could not be loaded. Check the data service and try again.');
  }
});

router.post(
  '/api/data/slice',
  sameOrigin,
  json({ limit: '1mb', inflate: false }),
  async (request, response) => {
    try {
      const slice = await resolveSlice(request.body as SliceRequest);
      response.json({ slice });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'The slice could not be resolved.';
      fail(response, 400, 'INVALID_SLICE_REQUEST', message);
    }
  },
);

const handleError: ErrorRequestHandler = (error, _request, response, next) => {
  if (response.headersSent) {
    next(error);
    return;
  }
  const status = error && typeof error === 'object' && 'status' in error ? error.status : undefined;
  if (status === 413) {
    fail(response, 413, 'REQUEST_TOO_LARGE', 'Send a slice request no larger than 1 MB.');
  } else {
    fail(response, 400, 'INVALID_REQUEST', 'The slice request could not be read.');
  }
};
router.use('/api/data', handleError);

export const dataRoutes: RequestHandler[] = [router];
