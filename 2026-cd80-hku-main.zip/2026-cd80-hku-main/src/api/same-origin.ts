import type { RequestHandler } from 'express';

export const sameOrigin: RequestHandler = (request, response, next) => {
  const origin = request.get('Origin');
  if (origin && origin !== `${request.protocol}://${request.get('Host')}`) {
    response.status(403).json({ error: { code: 'ORIGIN_NOT_ALLOWED', message: 'Open My Apps in this browser before continuing.' } });
    return;
  }
  next();
};
