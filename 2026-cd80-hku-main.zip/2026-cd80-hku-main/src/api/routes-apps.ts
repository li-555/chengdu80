import { monitorRouter } from './routes-monitor.ts';
import { randomUUID } from 'node:crypto';
import express from 'express';
import { z } from 'zod';
import type { ErrorRequestHandler, Request, RequestHandler, Response } from 'express';
import { getDraft, listDrafts, deleteDraft, getApp, listApps, saveApp, getState, listRuns, runSavedApplication } from '../platform/index.ts';
import type { StoredApp } from '../platform/types.ts';
import type { AppSummary, LibraryApp, LibraryErrorBody } from '../platform/library-types.ts';
import { listDatasets } from '../data/index.ts';
import { listUploads } from '../data/upload-store.ts';
import { browserProfileId } from '../platform/browser-profile.ts';
import { getConnectionSettings, saveConnectionSettings } from '../platform/connections.ts';
import { exportApplication, exportFilename } from '../platform/export.ts';
import { listActionRouter } from './routes-list-actions.ts';
import { sameOrigin } from './same-origin.ts';
import { validateApplication } from '../validate/index.ts';
import { createScheduledTask, listScheduledTasks, setScheduleEnabled } from '../platform/schedules.ts';
import { listExecutionAttempts } from '../platform/execution-store.ts';

export const STUB = false;
const router = express.Router();
const cookieName = 'blocks_profile';

function fail(response: Response, status: number, code: string, message: string): void {
  const body: LibraryErrorBody = { error: { code, message } };
  response.status(status).json(body);
}

function summary(app: StoredApp): AppSummary {
  return {
    id: app.id,
    name: app.doc.meta.name,
    description: app.doc.meta.description,
    ...(app.doc.meta.icon ? { icon: app.doc.meta.icon } : {}),
    createdAt: app.createdAt,
    updatedAt: app.updatedAt,
  };
}

function publicApp(app: StoredApp): LibraryApp {
  return { id: app.id, doc: app.doc, version: app.version, createdAt: app.createdAt, updatedAt: app.updatedAt };
}

router.use(['/api/apps', '/api/drafts'], (_request, response, next) => {
  response.set('Cache-Control', 'no-store');
  next();
}, sameOrigin, (request, response, next) => {
  let profile = browserProfileId(request);
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    if (!profile || request.get('X-Blocks-Request') !== '1') {
      fail(response, 403, 'PROFILE_REQUIRED', 'Open My Apps in this browser before continuing.');
      return;
    }
  } else if (!profile) {
    profile = randomUUID();
    response.cookie(cookieName, profile, {
      httpOnly: true,
      sameSite: 'strict',
      secure: request.secure,
      maxAge: 365 * 24 * 60 * 60 * 1000,
      path: '/',
    });
  }
  response.locals.profile = `browser:${profile}`;
  next();
});

router.use('/api/apps/:id/list-actions', listActionRouter);
router.use('/api/apps/:id/monitor', monitorRouter);

router.get('/api/drafts', async (_request, response) => {
  try {
    const drafts = await listDrafts(response.locals.profile as string);
    response.json({ drafts: drafts.map(({ id, name, reason, createdAt }) => ({ id, name, reason, createdAt })).reverse() });
  } catch {
    fail(response, 503, 'STORAGE_UNAVAILABLE', 'Your drafts could not be loaded. Check storage and try again.');
  }
});

router.get('/api/drafts/:id', async (request, response) => {
  try {
    const draft = await getDraft(request.params.id as string, response.locals.profile as string);
    if (!draft) { fail(response, 404, 'DRAFT_NOT_FOUND', 'This draft is not in your library.'); return; }
    const { id, name, reason, doc, errors, createdAt } = draft;
    response.json({ draft: { id, name, reason, doc, errors, createdAt } });
  } catch {
    fail(response, 503, 'STORAGE_UNAVAILABLE', 'This draft could not be loaded. Check storage and try again.');
  }
});

router.delete('/api/drafts/:id', async (request, response) => {
  try {
    const profile = response.locals.profile as string;
    if (!await getDraft(request.params.id as string, profile)) {
      fail(response, 404, 'DRAFT_NOT_FOUND', 'This draft is not in your library.'); return;
    }
    await deleteDraft(request.params.id as string, profile);
    response.json({ deleted: true });
  } catch {
    fail(response, 503, 'STORAGE_UNAVAILABLE', 'This draft could not be deleted. Check storage and try again.');
  }
});

router.get('/api/apps', async (_request, response) => {
  try {
    const apps = await listApps(response.locals.profile as string);
    response.json({ apps: apps.map(summary).reverse() });
  } catch {
    fail(response, 503, 'STORAGE_UNAVAILABLE', 'Your applications could not be loaded. Check storage and try again.');
  }
});

router.get('/api/apps/:id', async (request, response) => {
  try {
    const app = await getApp(request.params.id as string);
    if (!app || app.profile !== response.locals.profile) {
      fail(response, 404, 'APP_NOT_FOUND', 'This application is not in your library.');
      return;
    }
    response.json({ app: publicApp(app) });
  } catch {
    fail(response, 503, 'STORAGE_UNAVAILABLE', 'This application could not be loaded. Check storage and try again.');
  }
});

router.get('/api/apps/:id/export', async (request, response) => {
  try {
    const app = await getApp(request.params.id as string);
    if (!app || app.profile !== response.locals.profile) {
      fail(response, 404, 'APP_NOT_FOUND', 'This application is not in your library.'); return;
    }
    const content = exportApplication(app.doc);
    response.set('Content-Disposition', `attachment; filename="${exportFilename(app.doc.meta.name)}"`);
    response.type('application/json').send(content);
  } catch {
    fail(response, 503, 'EXPORT_UNAVAILABLE', 'This application could not be exported. Check storage and try again.');
  }
});

// Ownership is checked before returning any settings, result rows or source filters.
router.get('/api/apps/:id/runs', async (request, response) => {
  try {
    const app = await getApp(request.params.id as string);
    if (!app || app.profile !== response.locals.profile) {
      fail(response, 404, 'APP_NOT_FOUND', 'This application is not in your library.');
      return;
    }
    const state = await getState(app.id, app.profile);
    response.json({ runs: await listRuns(app.id, 10), params: state.params ?? {} });
  } catch {
    fail(response, 503, 'STORAGE_UNAVAILABLE', 'Run history could not be loaded. Check storage and try again.');
  }
});

router.get('/api/apps/:id/schedules', async (request, response) => {
  try {
    const app = await getApp(request.params.id as string);
    if (!app || app.profile !== response.locals.profile) { fail(response, 404, 'APP_NOT_FOUND', 'This application is not in your library.'); return; }
    response.json({ appVersion: app.version, triggers: app.doc.triggers,
      tasks: (await listScheduledTasks(app.profile)).filter((task) => task.appId === app.id),
      running: (await listExecutionAttempts(app.profile)).filter((attempt) => attempt.appId === app.id && attempt.status === 'running')
        .map(({ id, taskId, startedAt }) => ({ id, taskId, startedAt })),
    });
  } catch { fail(response, 503, 'SCHEDULE_UNAVAILABLE', 'Scheduled tasks could not be loaded.'); }
});
const scheduleRequest = z.strictObject({ triggerIndex: z.number().int().min(0), action: z.enum(['enable', 'pause', 'resume', 'confirm']), appVersion: z.string().min(1).max(128) });
router.post('/api/apps/:id/schedules', express.json({ limit: '8kb', inflate: false }), async (request, response) => {
  const input = scheduleRequest.safeParse(request.body);
  if (!input.success) { fail(response, 400, 'INVALID_SCHEDULE', 'Choose a declared task and action.'); return; }
  try {
    const app = await getApp(request.params.id as string);
    if (!app || app.profile !== response.locals.profile) { fail(response, 404, 'APP_NOT_FOUND', 'This application is not in your library.'); return; }
    const { action, triggerIndex, appVersion } = input.data;
    if (action !== 'pause' && app.version !== appVersion) { fail(response, 409, 'APP_CHANGED', 'The application changed. Refresh tasks and review its current version.'); return; }
    let task = (await listScheduledTasks(app.profile)).find((item) => item.appId === app.id && item.triggerIndex === triggerIndex);
    if (!task) {
      const trigger = app.doc.triggers[triggerIndex];
      if (action === 'pause' || !trigger || !['schedule', 'market'].includes(trigger.kind)) { fail(response, 400, 'INVALID_SCHEDULE', 'Choose a clock or market trigger declared by this application.'); return; }
      task = await createScheduledTask(app.id, app.profile, triggerIndex);
    }
    if (action !== 'pause' && task.appVersion !== app.version && action !== 'confirm') { fail(response, 409, 'VERSION_CONFIRMATION_REQUIRED', 'Review and confirm the current application version before resuming.'); return; }
    response.json({ task: await setScheduleEnabled(task.id, app.profile, action !== 'pause', action === 'confirm' ? { confirmVersion: app.version } : {}) });
  } catch { fail(response, 409, 'SCHEDULE_CHANGED', 'The task could not be updated. Refresh tasks and check its status before trying again.'); }
});

const connectionRequest = z.strictObject({
  revision: z.string().regex(/^[a-f0-9]{64}$/),
  settings: z.strictObject({
    params: z.record(z.string().max(128), z.unknown()),
    bindings: z.record(z.string().max(128), z.string().max(500)),
    mappings: z.record(z.string().max(128), z.record(z.string().max(128), z.string().max(500))),
  }),
});
router.get('/api/apps/:id/connection', async (request, response) => {
  try {
    const app = await getApp(request.params.id as string);
    if (!app || app.profile !== response.locals.profile) {
      fail(response, 404, 'APP_NOT_FOUND', 'This application is not in your library.'); return;
    }
    // Catalogue metadata only, scoped to this browser library.
    const datasets = [...(await listDatasets()).filter((dataset) => dataset.source === 'tushare'),
      ...listUploads(browserProfileId(request)!)]
      .map(({ id, name, fields }) => ({ id, name, fields }));
    response.json({ ...(await getConnectionSettings(app.id, app.profile)), datasets });
  } catch { fail(response, 503, 'CONNECTION_UNAVAILABLE', 'Data connection settings could not be loaded. Try again.'); }
});
router.post('/api/apps/:id/connection', express.json({ limit: '64kb', inflate: false }), async (request, response) => {
  const input = connectionRequest.safeParse(request.body);
  if (!input.success) { fail(response, 400, 'INVALID_CONNECTION', 'Check the data connection settings.'); return; }
  try {
    const app = await getApp(request.params.id as string);
    if (!app || app.profile !== response.locals.profile) {
      fail(response, 404, 'APP_NOT_FOUND', 'This application is not in your library.'); return;
    }
    const result = await saveConnectionSettings(app.id, app.profile, input.data.settings, input.data.revision);
    if (result.kind === 'conflict') { fail(response, 409, 'CONNECTION_CHANGED', 'Settings changed in another session. Reload saved settings before saving again.'); return; }
    if (result.kind === 'invalid') { fail(response, 422, 'INVALID_CONNECTION', result.message); return; }
    response.json(result.snapshot);
  } catch { fail(response, 503, 'CONNECTION_UNCONFIRMED', 'Saving could not be confirmed. Your draft is retained; reload saved settings to check.'); }
});

const runRequest = z.strictObject({
  runId: z.string().regex(/^[A-Za-z0-9_-]{1,128}$/),
  params: z.record(z.string(), z.unknown()).optional(),
});
router.post('/api/apps/:id/run', express.json({ limit: '64kb', inflate: false }), async (request, response) => {
  const input = runRequest.safeParse(request.body);
  if (!input.success) {
    fail(response, 400, 'INVALID_RUN_REQUEST', 'Choose valid run settings and a run identifier.');
    return;
  }
  try {
    const app = await getApp(request.params.id as string);
    if (!app || app.profile !== response.locals.profile) {
      fail(response, 404, 'APP_NOT_FOUND', 'This application is not in your library.');
      return;
    }
    const reply = await runSavedApplication({ appId: app.id, profile: app.profile, ...input.data });
    response.json(reply);
  } catch {
    fail(response, 503, 'RUN_UNCONFIRMED', 'The run could not be confirmed. Retry the same request or check run history.');
  }
});

router.post('/api/apps/import',
  (request, response, next) => {
    const charset = /(?:^|;)\s*charset\s*=\s*"?([^";\s]+)/i.exec(request.get('Content-Type') ?? '')?.[1];
    if (charset && !['utf-8', 'utf8'].includes(charset.toLowerCase())) {
      fail(response, 415, 'UNSUPPORTED_FILE', 'Choose a UTF-8 JSON application file.');
      return;
    }
    next();
  },
  express.text({ type: ['text/plain', 'application/json'], limit: '1mb', inflate: false }),
  async (request, response) => {
    if (!request.is(['text/plain', 'application/json'])) {
      fail(response, 415, 'UNSUPPORTED_FILE', 'Choose a JSON application file.');
      return;
    }
    if (typeof request.body !== 'string' || !request.body.trim()) {
      fail(response, 400, 'EMPTY_FILE', 'Choose an application file with content.');
      return;
    }
    const validation = validateApplication(request.body);
    if (!validation.ok) {
      response.status(422).json({ error: {
        code: 'INVALID_APPLICATION',
        message: validation.report.summary,
        issues: validation.errors,
      } });
      return;
    }
    try {
      const app = await saveApp(validation.document, response.locals.profile as string);
      response.status(201).json({ app: publicApp(app), warnings: validation.report.warnings });
    } catch {
      fail(response, 503, 'STORAGE_UNAVAILABLE', 'The application was not saved. Check storage and try again.');
    }
  });

const handleError: ErrorRequestHandler = (error: unknown, _request, response, next) => {
  if (response.headersSent) { next(error); return; }
  const status = error && typeof error === 'object' && 'status' in error ? error.status : undefined;
  if (status === 413) fail(response, 413, 'FILE_TOO_LARGE', 'Choose an application file no larger than 1 MB.');
  else if (status === 415) fail(response, 415, 'UNSUPPORTED_FILE', 'Choose an uncompressed UTF-8 JSON application file.');
  else if (status === 400) fail(response, 400, 'INVALID_REQUEST', 'The application request could not be read.');
  else fail(response, 500, 'REQUEST_FAILED', 'The application request could not be completed.');
};
router.use(handleError);

export const appRoutes: RequestHandler[] = [router];
