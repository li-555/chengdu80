import { Router, raw } from 'express';
import type { ErrorRequestHandler } from 'express';
import { mkdtemp, rm, writeFile } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { basename, extname, join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { sameOrigin } from './same-origin.ts';
import { datasetProfile } from '../platform/browser-profile.ts';
import { parseUploadFile } from '../data/file-upload.ts';
import { MarkdownTableError } from '../data/markdown-tables.ts';
import { addUpload, getUploadRows } from '../data/catalogue.ts';
import { listUploads, saveUpload } from '../data/upload-store.ts';
import { describeUpload, type UploadedSheet, type SkippedSheet } from '../platform/upload-preview.ts';
import type { Dataset } from '../data/types.ts';

export const uploadRouter = Router();

uploadRouter.use('/api/uploads', (_request, response, next) => {
  response.set('Cache-Control', 'no-store'); next();
}, sameOrigin);

uploadRouter.get('/api/uploads', (request, response) => {
  response.json({ datasets: listUploads(datasetProfile(request, request.query.profile)) });
});

uploadRouter.get('/api/uploads/:id/preview', (request, response) => {
  const dataset = listUploads(datasetProfile(request, request.query.profile))
    .find((item) => item.id === request.params.id);
  if (!dataset) {
    response.status(404).json({ error: { code: 'UPLOAD_NOT_FOUND', message: 'This uploaded table is not available in your workspace.' } }); return;
  }
  const rows = getUploadRows(dataset.id);
  if (!rows) {
    response.status(404).json({ error: { code: 'UPLOAD_NOT_FOUND', message: 'This uploaded table is not available in your workspace.' } }); return;
  }
  response.json(describeUpload(dataset, rows));
});

uploadRouter.post('/api/uploads', sameOrigin, raw({ type: () => true, limit: '20mb' }), async (request, response) => {
  const filename = request.query.filename;
  const extension = typeof filename === 'string' ? extname(filename).toLowerCase() : '';
  if (!['.csv', '.tsv', '.xlsx', '.xls', '.xlsm', '.md'].includes(extension)) {
    response.status(400).json({ error: { code: 'UNSUPPORTED_FILE_TYPE', message: 'Upload a CSV, TSV, Excel or Markdown file.' } });
    return;
  }
  const name = request.query.name ?? basename(filename as string, extname(filename as string));
  if (typeof name !== 'string' || !name.trim() || name.length > 80) {
    response.status(400).json({ error: { code: 'INVALID_NAME', message: 'Use a dataset name between 1 and 80 characters.' } });
    return;
  }
  if (!Buffer.isBuffer(request.body) || request.body.length === 0) {
    response.status(400).json({ error: { code: 'EMPTY_FILE', message: 'Upload a file containing columns and data.' } });
    return;
  }

  const directory = await mkdtemp(join(tmpdir(), 'blocks-upload-'));
  let parsed;
  try {
    const path = join(directory, `file${extension}`);
    await writeFile(path, request.body);
    try {
      parsed = parseUploadFile(path);
    } catch (error) {
      response.status(400).json({ error: { code: 'INVALID_FILE', message: error instanceof MarkdownTableError ? error.message : 'The file could not be read as a table.' } });
      return;
    }
  } finally {
    await rm(directory, { recursive: true, force: true });
  }
  const usable = parsed.filter((sheet) => sheet.fields.some((field) => field.name.trim()));
  if (!usable.length) {
    response.status(400).json({ error: { code: 'NO_COLUMNS', message: 'The file must have column headers.' } });
    return;
  }
  const skippedSheets: SkippedSheet[] = parsed.filter((sheet) => !sheet.fields.some((field) => field.name.trim()))
    .map((sheet) => ({ sheetName: sheet.name, reason: 'NO_COLUMNS' }));
  const sheets: UploadedSheet[] = [];
  const profile = datasetProfile(request, request.query.profile);
  for (const sheet of usable) {
    const dataset: Dataset = {
      id: `user:${randomUUID()}`, name: parsed.length === 1 ? name : `${name.slice(0, 40)} · ${sheet.name}`.slice(0, 80),
      source: 'upload', fields: sheet.fields, rowCount: sheet.rows.length,
    };
    try { saveUpload(dataset, sheet.rows, profile); }
    catch { skippedSheets.push({ sheetName: sheet.name, reason: 'SAVE_FAILED' }); continue; }
    addUpload(dataset, sheet.rows);
    sheets.push({ sheetName: sheet.name, ...describeUpload(dataset, sheet.rows) });
  }
  if (!sheets.length) {
    response.status(500).json({ error: { code: 'UPLOAD_FAILED', message: 'The upload could not be stored or read. Please try again.' } }); return;
  }
  // The first usable sheet keeps the existing single-table response contract.
  const { dataset, blankCounts, preview, analysis, analysisWarning } = sheets[0]!;
  response.status(201).json({ dataset, blankCounts, preview, analysis, ...(analysisWarning ? { analysisWarning } : {}), sheets, skippedSheets });
});

const handleError: ErrorRequestHandler = (error: unknown, _request, response, next) => {
  if (response.headersSent) { next(error); return; }
  const status = error && typeof error === 'object' && 'status' in error ? error.status : undefined;
  if (status === 413) {
    response.status(413).json({ error: { code: 'FILE_TOO_LARGE', message: 'Upload a file no larger than 20 MB.' } });
  } else if (status === 400) {
    response.status(400).json({ error: { code: 'INVALID_REQUEST', message: 'The upload request could not be read.' } });
  } else {
    response.status(500).json({ error: { code: 'UPLOAD_FAILED', message: 'The upload could not be stored or read. Please try again.' } });
  }
};
uploadRouter.use('/api/uploads', handleError);
