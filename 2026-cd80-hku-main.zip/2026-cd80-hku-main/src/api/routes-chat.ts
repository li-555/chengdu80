/**
 * The chat that builds applications.
 *
 * POST /api/chat  { conversationId?, message, profile?, uploads? }
 * `uploads` lists dataset ids returned by POST /api/uploads; the builder sees their column
 * names and types, never their rows. A message may be empty when it carries uploads.
 * answers as a stream of server-sent events, one JSON object per `data:` line:
 *   { kind: 'conversation', conversationId }   first, always
 *   { kind: 'progress', stage, line }          zero or more, written by the platform
 *   { kind: 'question', questions, acceptsFile }
 *   | { kind: 'built', appId, name, description, updated }
 *   | { kind: 'failed', reason, summary, draftId? }   exactly one, last
 *
 * The first build in a conversation saves a new application; later builds in the same
 * conversation change that application (same id, a new revision). A failed build that got
 * as far as a draft keeps it in My Apps as "Needs attention".
 *
 * Conversations live in memory: a restart forgets an unfinished conversation, but never an
 * application, which is saved the moment it is built. A conversation is dropped after an
 * hour without a message, and at most MAX_CONVERSATIONS are kept.
 */

import { Router, json } from 'express';
import type { LanguageModel } from 'ai';
import { randomUUID } from 'node:crypto';
import { newConversation, runTurn, type Conversation } from '../generate/agent.ts';
import type { BuilderDeps } from '../generate/tools.ts';
import { configuredModel, configuredModelName, ModelNotConfiguredError } from '../platform/model.ts';
import { findDataset, listAllDatasets } from '../data/catalogue.ts';
import type { Attachment } from '../generate/agent.ts';
import { readSkillFamily } from '../skill/build.ts';
import { saveApp, saveDraft, updateApp } from '../platform/storage.ts';
import { sameOrigin } from './same-origin.ts';
import { browserProfileId, datasetProfile } from '../platform/browser-profile.ts';
import { listUploads } from '../data/upload-store.ts';

const MAX_CONVERSATIONS = 200;
const IDLE_MS = 60 * 60 * 1000;
const MAX_MESSAGE_CHARS = 4000;
const MAX_UPLOADS = 5;

/** A conversation belongs to the profile that started it; another profile never continues it. */
const conversations = new Map<string, { conv: Conversation; profile: string; lastSeen: number; busy: boolean }>();

function sweep(now: number): void {
  for (const [id, c] of conversations) if (now - c.lastSeen > IDLE_MS && !c.busy) conversations.delete(id);
  while (conversations.size > MAX_CONVERSATIONS) {
    const oldest = [...conversations.entries()].filter(([, c]) => !c.busy).sort((a, b) => a[1].lastSeen - b[1].lastSeen)[0];
    if (!oldest) break;
    conversations.delete(oldest[0]);
  }
}

/** `model` replaces the configured model; tests use it to script the builder. */
export function createChatRouter(options: { model?: () => LanguageModel } = {}): Router {
  const router = Router();
  router.post('/api/chat', sameOrigin, json({ limit: '64kb' }), async (request, response) => {
    const body = (request.body ?? {}) as { conversationId?: unknown; message?: unknown; profile?: unknown; uploads?: unknown };
    const ids = body.uploads === undefined ? [] : body.uploads;
    if (!Array.isArray(ids) || ids.length > MAX_UPLOADS || !ids.every((id) => typeof id === 'string')) {
      response.status(400).json({ error: { code: 'BAD_UPLOADS', message: `Attach at most ${MAX_UPLOADS} uploaded files.` } });
      return;
    }
    const browserId = browserProfileId(request);
    const uploadProfile = datasetProfile(request, body.profile);
    const profile = browserId ? `browser:${browserId}` : uploadProfile;
    const ownedUploads = browserId ? new Set(listUploads(uploadProfile).map((dataset) => dataset.id)) : undefined;
    const attachments: Attachment[] = [];
    for (const id of new Set(ids as string[])) {
      const dataset = findDataset(id);
      if (!dataset || dataset.source !== 'upload' || (ownedUploads && !ownedUploads.has(id))) {
        response.status(400).json({ error: { code: 'UNKNOWN_UPLOAD', message: 'That file is no longer available. Please upload it again.' } });
        return;
      }
      attachments.push({
        id: dataset.id, name: dataset.name, fields: dataset.fields, rowCount: dataset.rowCount,
        coverageStart: dataset.coverageStart, coverageEnd: dataset.coverageEnd,
      });
    }
    // A message is always a string; it may be empty only when it carries a file.
    const typed = typeof body.message === 'string' ? body.message.trim() : undefined;
    const message = typed || (typed !== undefined && attachments.length ? 'I attached a file.' : '');
    if (!message || message.length > MAX_MESSAGE_CHARS) {
      response.status(400).json({ error: { code: 'BAD_MESSAGE', message: `Send a message of 1 to ${MAX_MESSAGE_CHARS} characters.` } });
      return;
    }

    const now = Date.now();
    sweep(now);
    const found = typeof body.conversationId === 'string' ? conversations.get(body.conversationId) : undefined;
    const wanted = found?.profile === profile ? found : undefined;
    const entry = wanted ?? { conv: newConversation(randomUUID()), profile, lastSeen: now, busy: false };
    if (entry.busy) {
      response.status(409).json({ error: { code: 'BUSY', message: 'Still working on your last message.' } });
      return;
    }
    entry.busy = true;
    entry.lastSeen = now;
    conversations.set(entry.conv.id, entry);

    response.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' });
    const send = (e: unknown) => response.write(`data: ${JSON.stringify(e)}\n\n`);
    send({ kind: 'conversation', conversationId: entry.conv.id });

    const abort = new AbortController();
    response.on('close', () => { if (!response.writableEnded) abort.abort(); });

    try {
      let model;
      try {
        model = options.model ? options.model() : configuredModel();
      } catch (e) {
        if (!(e instanceof ModelNotConfiguredError)) throw e;
        send({ kind: 'failed', reason: 'error', summary: 'The AI is not set up on this computer yet. Ask whoever installed Blocks to add the AI key.' });
        return;
      }
      const deps: BuilderDeps = {
        listDatasets: () => browserId
          ? listAllDatasets().filter((dataset) => dataset.source === 'tushare' || ownedUploads!.has(dataset.id))
          : listAllDatasets(),
        readFamily: readSkillFamily,
        install: async (doc) => {
          const current = entry.conv.current;
          if (current) {
            try {
              return { id: (await updateApp(current.appId, profile, doc)).id };
            } catch (e) {
              // The person deleted it meanwhile: save the change as a new application.
              if (!(e instanceof Error && /not found/i.test(e.message))) throw e;
            }
          }
          return { id: (await saveApp(doc, profile)).id };
        },
        modelName: configuredModelName(),
      };
      try {
        const updating = entry.conv.current?.appId;
        const result = await runTurn(entry.conv, message, {
          model, deps, today: new Date().toISOString().slice(0, 10), onEvent: send, signal: abort.signal, attachments,
        });
        if (result.kind === 'built') {
          send({ ...result, updated: result.appId === updating });
        } else if (result.kind === 'failed') {
          // The draft and its errors go to storage for the "download details" button, never to the screen.
          const { draft, errors, ...shown } = result;
          let draftId: string | undefined;
          if (draft !== undefined) {
            try {
              draftId = (await saveDraft(profile, { doc: draft, errors: errors ?? [], reason: result.reason, conversationId: entry.conv.id })).id;
            } catch { /* too large or storage failed: the failure itself is still reported */ }
          }
          // Never claim a draft was kept when it was not.
          const summary = draft !== undefined && !draftId
            ? 'I could not build this application, and I could not keep my draft this time.'
            : shown.summary;
          send({ ...shown, summary, ...(draftId ? { draftId } : {}) });
        } else {
          send(result);
        }
      } catch {
        // runTurn returns its own failures; this is the last guard so the stream always ends
        // with a final event, and no internal message reaches the screen or the log.
        send({ kind: 'failed', reason: 'error', summary: 'Something went wrong while building. Please try again in a moment.' });
      }
    } finally {
      entry.busy = false;
      entry.lastSeen = Date.now();
      response.end();
    }
  });
  return router;
}

export const chatRouter = createChatRouter();
