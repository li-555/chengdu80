import { Router, text } from 'express';
import type { ErrorRequestHandler } from 'express';
import { sameOrigin } from './same-origin.ts';
import { validateApplication } from '../validate/index.ts';

export const validateRouter = Router();

validateRouter.post('/api/validate', sameOrigin, text({ type: () => true, limit: '1mb' }), (request, response) => {
  response.json(validateApplication(request.body ?? '').report);
});

const handleError: ErrorRequestHandler = (error: unknown, _request, response, next) => {
  if (response.headersSent) { next(error); return; }
  const status = error && typeof error === 'object' && 'status' in error ? error.status : undefined;
  if (status === 413) {
    response.status(413).json({ error: { code: 'FILE_TOO_LARGE', message: 'Send an application no larger than 1 MB.' } });
  } else {
    response.status(400).json({ error: { code: 'INVALID_REQUEST', message: 'The application request could not be read.' } });
  }
};
validateRouter.use(handleError);
