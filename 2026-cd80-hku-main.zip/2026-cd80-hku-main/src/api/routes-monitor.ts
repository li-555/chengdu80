import express from 'express';
import { getApp } from '../platform/storage.ts';
import { getMonitorSnapshot, monitorAcknowledgement, setMonitorAcknowledged } from '../platform/monitor.ts';

/** Mounted after the application router's origin, browser profile and write guards. */
export const monitorRouter = express.Router({ mergeParams: true });
function fail(response: express.Response, status: number, code: string, message: string): void { response.status(status).json({ error: { code, message } }); }
monitorRouter.use(async (request, response, next) => {
  try {
    const app = await getApp((request.params as Record<string, string>).id as string);
    if (!app || app.profile !== response.locals.profile) { fail(response, 404, 'APP_NOT_FOUND', 'This application is not in your library.'); return; }
    next();
  } catch { fail(response, 503, 'STORAGE_UNAVAILABLE', 'Monitor results could not be loaded. Check storage and try again.'); }
});
monitorRouter.get('/', async (request, response) => {
  try { response.json(await getMonitorSnapshot((request.params as Record<string, string>).id as string, response.locals.profile as string)); }
  catch { fail(response, 503, 'STORAGE_UNAVAILABLE', 'Monitor results could not be loaded. Check storage and try again.'); }
});
monitorRouter.post('/ack', express.json({ limit: '4kb', inflate: false }), async (request, response) => {
  const parsed = monitorAcknowledgement.safeParse(request.body);
  if (!parsed.success) { fail(response, 422, 'INVALID_MONITOR_ACK', 'Choose an alert and an acknowledgement value.'); return; }
  try {
    const result = await setMonitorAcknowledged((request.params as Record<string, string>).id as string, response.locals.profile as string, parsed.data);
    if (result.kind === 'conflict') { fail(response, 409, 'ALERT_CHANGED', 'This alert changed or closed. Refresh before acknowledging it.'); return; }
    if (result.kind === 'invalid') { fail(response, 422, 'INVALID_MONITOR_ACK', 'Choose an alert and an acknowledgement value.'); return; }
    response.json(result);
  } catch { fail(response, 503, 'ACTION_UNCONFIRMED', 'Saving could not be confirmed. Refresh the monitor and try again.'); }
});
monitorRouter.use((error: unknown, _request: express.Request, response: express.Response, next: express.NextFunction) => {
  if (response.headersSent) { next(error); return; }
  const status = error && typeof error === 'object' && 'status' in error ? error.status : undefined;
  fail(response, status === 413 ? 413 : 400, 'INVALID_MONITOR_ACK', 'The acknowledgement request could not be read.');
});
