// src/data/index.ts -- Rachel's data layer

export { callTushare, fetchTable, getCallStats, resetCallHistory } from './tushare-client.ts';
export { parseCSV, inferSchema, parseUploadFile, type ParsedSheet } from './file-upload.ts';
export { parseMarkdownTables, parseMarkdownDocument, type MarkdownTable, type MarkdownDocument } from './markdown-tables.ts';
export { registerUpload } from './register-upload.ts';
export { analyzeTable, type TableAnalysis, type ColumnAnalysis, type NumericStats } from './analyze.ts';
export { registerExternalApi } from './register-external-api.ts';
export { readApiRows, assertSafeUrl, extractRows, ApiError, type ApiAuth, type ApiReadOptions } from './api-client.ts';
export { inferApiSchema, normalizeJsonToTable } from './infer-api-schema.ts';
import { listAllDatasets, findDataset } from './catalogue.ts';
import { checkRequirements as doCheckRequirements } from './field-matcher.ts';
import { isTradingDay as doIsTradingDay, nextTradingDay as doNextTradingDay, marketTimes as doMarketTimes, getCacheStats, clearCalendarCache } from './trading-cal.ts';
import type { FieldType, FieldSpec, Dataset, DataRequirement, RequirementReport, SliceRequest, Slice } from './types.ts';
export type { FieldType, FieldSpec, Dataset, DataRequirement, RequirementReport, SliceRequest, Slice };

export async function listDatasets(): Promise<Dataset[]> {
  return listAllDatasets();
}

export async function getDataset(id: string): Promise<Dataset | null> {
  return findDataset(id);
}

export { resolveSlice, clearSliceCache } from './resolve-slice.ts';

export async function checkRequirements(
  reqs: DataRequirement[],
  bindings?: Record<string, string>,
  mappings?: Record<string, Record<string, string>>,
): Promise<RequirementReport[]> {
  return doCheckRequirements(reqs, bindings, mappings);
}

export async function isTradingDay(date: string): Promise<boolean> {
  return doIsTradingDay(date);
}

export async function nextTradingDay(after: string): Promise<string> {
  return doNextTradingDay(after);
}

export async function marketTimes(date: string): Promise<{ open: string; close: string } | null> {
  return doMarketTimes(date);
}