import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, resolve } from 'node:path';
import type { Dataset } from './types.ts';
import { loadUploads } from './upload-store.ts';
import type { ApiSourceDescriptor } from './api-client.ts';

const __dirname = dirname(fileURLToPath(import.meta.url));

let _tushareCatalogue: Dataset[] | null = null;

function loadTushareCatalogue(): Dataset[] {
  if (_tushareCatalogue) return _tushareCatalogue;
  const jsonPath = resolve(__dirname, '../../fixtures/catalogue.json');
  const raw = readFileSync(jsonPath, 'utf-8');
  _tushareCatalogue = JSON.parse(raw) as Dataset[];
  return _tushareCatalogue;
}

/** Datasets registered at runtime: uploaded files and user-supplied APIs. */
const runtimeRegistry: Dataset[] = [];
const uploadRows = new Map<string, string[][]>();
const apiSources = new Map<string, ApiSourceDescriptor>();

let uploadsLoaded = false;

function ensureUploadsLoaded(): void {
  if (uploadsLoaded) return;
  loadUploads();
  uploadsLoaded = true;
}

/** Test-only: simulate a fresh process without touching stored uploads. */
export function resetUploadsForTests(): void {
  for (let i = runtimeRegistry.length - 1; i >= 0; i--) if (runtimeRegistry[i]!.source === 'upload') runtimeRegistry.splice(i, 1);
  uploadRows.clear();
  uploadsLoaded = false;
}

export function addUpload(dataset: Dataset, rows: string[][] = []): void {
  const index = runtimeRegistry.findIndex((existing) => existing.id === dataset.id);
  if (index === -1) runtimeRegistry.push(dataset);
  else runtimeRegistry[index] = dataset;
  uploadRows.set(dataset.id, rows);
}

export function getUploadRows(id: string): string[][] {
  ensureUploadsLoaded();
  return uploadRows.get(id) ?? [];
}

export function addApiSource(dataset: Dataset, source: ApiSourceDescriptor): void {
  runtimeRegistry.push(dataset);
  apiSources.set(dataset.id, source);
}

export function getApiSource(id: string): ApiSourceDescriptor | undefined {
  return apiSources.get(id);
}

export function listAllDatasets(): Dataset[] {
  ensureUploadsLoaded();
  return [...loadTushareCatalogue(), ...runtimeRegistry];
}

export function findDataset(id: string): Dataset | null {
  ensureUploadsLoaded();
  const tushare = loadTushareCatalogue().find((d) => d.id === id);
  if (tushare) return tushare;
  return runtimeRegistry.find((d) => d.id === id) ?? null;
}
