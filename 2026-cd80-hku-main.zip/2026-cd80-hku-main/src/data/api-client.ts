// src/data/api-client.ts
// Secure, paginated JSON reader for user-supplied data APIs (REST + JSON).
// Uses Node's built-in fetch; no third-party HTTP client. Credentials are passed in
// by the caller and never stored or logged here.

import { isIP } from 'node:net';

export type ApiAuth =
  | { kind: 'none' }
  | { kind: 'bearer'; token: string }
  | { kind: 'apiKey'; header: string; value: string };

export type ApiReadOptions = {
  allowList?: string[];
  pageSize?: number;
  pageParam?: string;
  offsetParam?: string;
  timeoutMs?: number;
  maxRetries?: number;
  maxRows?: number;
};

export type ApiSourceDescriptor = {
  url: string;
  auth: ApiAuth;
  options: ApiReadOptions;
};

const DEFAULT_PAGE_SIZE = 100;
const DEFAULT_TIMEOUT_MS = 5000;
const DEFAULT_MAX_RETRIES = 2;
const DEFAULT_MAX_ROWS = 200000;
const RETRYABLE_STATUS = new Set([408, 425, 429, 500, 502, 503, 504]);

export class ApiError extends Error {
  readonly status?: number;
  constructor(message: string, status?: number) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function isLoopbackHost(hostname: string): boolean {
  return hostname === 'localhost' || hostname === '127.0.0.1' || hostname === '::1' || hostname === '[::1]';
}

/**
 * Reject URLs the platform must not call: anything but https (except loopback http for
 * local development), direct IP addresses, and hosts outside the allow-list.
 */
export function assertSafeUrl(rawUrl: string, allowList: string[]): URL {
  const url = new URL(rawUrl);

  if (url.protocol === 'http:') {
    if (!isLoopbackHost(url.hostname)) {
      throw new ApiError(`http is only allowed for localhost (got ${url.hostname})`);
    }
  } else if (url.protocol !== 'https:') {
    throw new ApiError(`unsupported protocol ${url.protocol}`);
  }

  if (url.protocol === 'https:' && isIP(url.hostname)) {
    throw new ApiError(`direct IP addresses are not allowed (${url.hostname})`);
  }

  if (allowList.length > 0) {
    const allowed = allowList.some((h) => h === url.hostname || url.hostname.endsWith(`.${h}`));
    if (!allowed) throw new ApiError(`host "${url.hostname}" is not on the allow-list`);
  }

  return url;
}

function authHeaders(auth: ApiAuth): Record<string, string> {
  if (auth.kind === 'bearer') return { Authorization: `Bearer ${auth.token}` };
  if (auth.kind === 'apiKey') return { [auth.header]: auth.value };
  return {};
}

/** Locate the row array in a response: a top-level array or a well-known envelope key. */
export function extractRows(data: unknown): unknown[] {
  if (Array.isArray(data)) return data;
  if (data && typeof data === 'object') {
    const obj = data as Record<string, unknown>;
    for (const key of ['data', 'items', 'results', 'records', 'list']) {
      if (Array.isArray(obj[key])) return obj[key];
    }
  }
  throw new ApiError('could not find a row array in the API response');
}

async function fetchJson(
  url: string,
  auth: ApiAuth,
  timeoutMs: number,
  fetchImpl: typeof fetch,
): Promise<unknown> {
  const response = await fetchImpl(url, {
    method: 'GET',
    headers: { Accept: 'application/json', ...authHeaders(auth) },
    signal: AbortSignal.timeout(timeoutMs),
  });

  const text = await response.text();
  let data: unknown = null;
  if (text !== '') {
    try {
      data = JSON.parse(text);
    } catch {
      throw new ApiError(`non-JSON response (HTTP ${response.status})`, response.status);
    }
  }
  if (!response.ok) {
    const message =
      typeof data === 'object' && data !== null && 'message' in data
        ? String((data as { message: unknown }).message)
        : `HTTP ${response.status}`;
    throw new ApiError(`API request failed: ${message}`, response.status);
  }
  return data;
}

async function fetchPageWithRetry(
  url: string,
  auth: ApiAuth,
  timeoutMs: number,
  maxRetries: number,
  fetchImpl: typeof fetch,
): Promise<unknown[]> {
  for (let attempt = 0; ; attempt++) {
    try {
      return extractRows(await fetchJson(url, auth, timeoutMs, fetchImpl));
    } catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      const retryable =
        err.name === 'TimeoutError' ||
        err.name === 'AbortError' ||
        err instanceof TypeError ||
        (err instanceof ApiError && err.status !== undefined && RETRYABLE_STATUS.has(err.status));
      if (!retryable || attempt >= maxRetries) throw err;
      await sleep(1000 * 2 ** attempt);
    }
  }
}

/**
 * Read every row a paginated API exposes, with timeout, retry and a hard row cap.
 * Pagination is offset/limit (`pageParam`/`offsetParam`); a cursor style needs a small
 * change here. `fetchImpl` is injectable for tests and defaults to the global fetch.
 */
export async function readApiRows(
  rawUrl: string,
  auth: ApiAuth,
  options: ApiReadOptions = {},
  fetchImpl: typeof fetch = fetch,
): Promise<unknown[]> {
  const allowList = options.allowList ?? [];
  const pageSize = options.pageSize ?? DEFAULT_PAGE_SIZE;
  const pageParam = options.pageParam ?? 'limit';
  const offsetParam = options.offsetParam ?? 'offset';
  const timeoutMs = options.timeoutMs ?? DEFAULT_TIMEOUT_MS;
  const maxRetries = options.maxRetries ?? DEFAULT_MAX_RETRIES;
  const maxRows = options.maxRows ?? DEFAULT_MAX_ROWS;

  const base = assertSafeUrl(rawUrl, allowList);

  const all: unknown[] = [];
  for (let offset = 0; ; offset += pageSize) {
    const url = new URL(base.toString());
    url.searchParams.set(pageParam, String(pageSize));
    url.searchParams.set(offsetParam, String(offset));

    const page = await fetchPageWithRetry(url.toString(), auth, timeoutMs, maxRetries, fetchImpl);
    if (page.length === 0) break;
    all.push(...page);
    if (all.length >= maxRows) {
      all.length = maxRows;
      break;
    }
    if (page.length < pageSize) break;
  }
  return all;
}
