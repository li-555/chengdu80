// src/data/tushare-client.ts
// Tushare HTTP API client with token auth, retries, and rate limiting.
// Token is read from TUSHARE_TOKEN environment variable.

const TUSHARE_BASE = 'https://api.tushare.pro';

const DEFAULT_MAX_RETRIES = 3;
const DEFAULT_BASE_DELAY_MS = 1000;

const RATE_LIMIT_WINDOW_MS = 60_000;
const DEFAULT_MAX_CALLS_PER_WINDOW = 180;

type TushareParams = Record<string, unknown>;

type TushareResponse = {
  code: number;
  msg: string;
  data?: {
    fields: string[];
    items: unknown[][];
    has_more: number;
  };
};

type CallRecord = {
  timestamp: number;
};

const callHistory: CallRecord[] = [];

function getToken(): string {
  const token = process.env.TUSHARE_TOKEN;
  if (!token) {
    throw new Error('TUSHARE_TOKEN environment variable is not set');
  }
  return token;
}

function pruneCallHistory(now: number): void {
  const cutoff = now - RATE_LIMIT_WINDOW_MS;
  for (;;) {
    const oldest = callHistory[0];
    if (!oldest || oldest.timestamp >= cutoff) break;
    callHistory.shift();
  }
}

async function waitForRateLimit(maxCalls: number): Promise<void> {
  const now = Date.now();
  pruneCallHistory(now);

  const oldest = callHistory[0];
  if (callHistory.length >= maxCalls && oldest) {
    const waitMs = oldest.timestamp + RATE_LIMIT_WINDOW_MS - now + 50;
    if (waitMs > 0) {
      await sleep(waitMs);
      pruneCallHistory(Date.now());
    }
  }

  callHistory.push({ timestamp: Date.now() });
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function isRetryableError(code: number): boolean {
  return code !== 0 && code !== 2001 && code !== 2002;
}

export async function callTushare(
  apiName: string,
  params: TushareParams = {},
  fields: string[] = [],
  maxRetries: number = DEFAULT_MAX_RETRIES,
  maxCallsPerWindow: number = DEFAULT_MAX_CALLS_PER_WINDOW,
): Promise<TushareResponse> {
  const token = getToken();

  await waitForRateLimit(maxCallsPerWindow);

  const body: Record<string, unknown> = {
    api_name: apiName,
    token,
    params,
  };
  if (fields.length > 0) {
    body.fields = fields.join(',');
  }

  let lastError: Error | null = null;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await fetch(TUSHARE_BASE, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(15000),
      });

      if (!response.ok) {
        const delay = DEFAULT_BASE_DELAY_MS * Math.pow(2, attempt);
        await sleep(delay);
        continue;
      }

      const json = (await response.json()) as TushareResponse;

      if (json.code === 0) {
        return json;
      }

      if (json.code === 2001 || json.code === 2002) {
        throw new Error(`Tushare auth error (code ${json.code}): ${json.msg}`);
      }

      if (attempt < maxRetries && isRetryableError(json.code)) {
        const delay = DEFAULT_BASE_DELAY_MS * Math.pow(2, attempt);
        await sleep(delay);
        continue;
      }

      throw new Error(`Tushare API error (code ${json.code}): ${json.msg}`);
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));

      /**
       * An error we raised ourselves after deciding not to retry must not then be
       * retried here. Only the auth case used to be re-thrown, so a permanent API
       * error was tried four times and took four times as long to report.
       */
      if (err instanceof Error && err.message.startsWith('Tushare ')) {
        throw err;
      }

      if (attempt < maxRetries) {
        const delay = DEFAULT_BASE_DELAY_MS * Math.pow(2, attempt);
        await sleep(delay);
        continue;
      }
    }
  }

  throw lastError ?? new Error('Unknown Tushare error');
}

export async function fetchTable(
  apiName: string,
  params: TushareParams = {},
  fields: string[] = [],
  maxRows?: number,
): Promise<{ fields: string[]; rows: unknown[][] }> {
  const allFields: string[] = [];
  const allRows: unknown[][] = [];
  let hasMore = true;

  /**
   * Paginate over a copy. Advancing `offset` on the caller's own object left an
   * `offset` key behind on it, so a second call with the same params object started
   * part-way through the data.
   */
  const page: TushareParams = { ...params };

  while (hasMore) {
    const resp = await callTushare(apiName, page, fields);

    if (!resp.data) {
      return { fields: allFields, rows: allRows };
    }

    if (allFields.length === 0 && resp.data.fields.length > 0) {
      allFields.push(...resp.data.fields);
    }

    allRows.push(...resp.data.items);

    if (maxRows !== undefined && allRows.length >= maxRows) {
      allRows.length = maxRows;
      break;
    }

    hasMore = resp.data.has_more === 1;

    if (hasMore) {
      const lastRow = resp.data.items[resp.data.items.length - 1];
      if (lastRow && lastRow.length > 0) {
        page.offset = typeof page.offset === 'number'
          ? page.offset + resp.data.items.length
          : resp.data.items.length;
      } else {
        hasMore = false;
      }
    }
  }

  return { fields: allFields, rows: allRows };
}

export function getCallStats(): { callsInWindow: number; windowMs: number } {
  pruneCallHistory(Date.now());
  return {
    callsInWindow: callHistory.length,
    windowMs: RATE_LIMIT_WINDOW_MS,
  };
}

export function resetCallHistory(): void {
  callHistory.length = 0;
}