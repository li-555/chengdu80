// Types shared across the data layer.
// No runtime code here — only type definitions.

export type FieldType = 'text' | 'number' | 'date' | 'boolean';

export type FieldSpec = {
  name: string;
  label: string;
  type: FieldType;
  unit?: string;
  nullable: boolean;
};

export type Dataset = {
  id: string;
  name: string;
  source: 'tushare' | 'upload' | 'api';
  fields: FieldSpec[];
  coverageStart?: string;
  coverageEnd?: string;
  rowCount?: number;
  notes?: string;
};

export type DataRequirement = {
  key: string;
  fields: { name: string; type: FieldType; required: boolean }[];
  datasetHint?: string;
  window?: { start?: string; end?: string };
  filters?: Record<string, string>;
};

export type RequirementReport = {
  key: string;
  status: 'satisfied' | 'needs_mapping' | 'unsatisfiable';
  boundDatasetId?: string;
  mapping?: Record<string, string>;
  problems: { field: string; code: string; message: string }[];
};

export type SliceRequest = {
  datasetId: string;
  fields: string[];
  dateFrom?: string;
  dateTo?: string;
  filter?: Record<string, string | number>;
  limit?: number;
};

export type Slice = {
  schema: FieldSpec[];
  rows: unknown[][];
  asOfDate?: string;
  datasetVersion: string;
};