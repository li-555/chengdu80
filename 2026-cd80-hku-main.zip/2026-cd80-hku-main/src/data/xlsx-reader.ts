import { readFileSync } from 'node:fs';
import { inflateRawSync } from 'node:zlib';
import { Buffer } from 'node:buffer';

export type Sheet = { name: string; rows: string[][] };

type Entry = { method: number; offset: number; size: number; rawSize: number };
type Xml = { name: string; attrs: Record<string, string>; children: Xml[]; text: string };

function openZip(filePath: string): (name: string, optional?: boolean) => string | undefined {
  const data = readFileSync(filePath);
  const invalid = () => new Error('Invalid ZIP archive');
  let end = -1;
  for (let i = data.length - 22; i >= Math.max(0, data.length - 22 - 65535); i--) {
    if (data.readUInt32LE(i) === 0x06054b50 && i + 22 + data.readUInt16LE(i + 20) === data.length) {
      end = i;
      break;
    }
  }
  if (end < 0) throw new Error('File is not a ZIP archive');
  const count = data.readUInt16LE(end + 10);
  const directorySize = data.readUInt32LE(end + 12);
  let cursor = data.readUInt32LE(end + 16);
  if (data.readUInt16LE(end + 4) !== 0 || data.readUInt16LE(end + 6) !== 0 ||
      data.readUInt16LE(end + 8) !== count || count === 0xffff ||
      directorySize === 0xffffffff || cursor === 0xffffffff) {
    throw new Error('Unsupported ZIP64 or multi-disk ZIP archive');
  }
  const directoryEnd = cursor + directorySize;
  if (directoryEnd > end) throw invalid();
  const entries = new Map<string, Entry>();
  for (let i = 0; i < count; i++) {
    if (cursor + 46 > directoryEnd || data.readUInt32LE(cursor) !== 0x02014b50) throw invalid();
    const method = data.readUInt16LE(cursor + 10);
    const nameSize = data.readUInt16LE(cursor + 28);
    const next = cursor + 46 + nameSize + data.readUInt16LE(cursor + 30) + data.readUInt16LE(cursor + 32);
    if (next > directoryEnd) throw invalid();
    const name = data.toString('utf8', cursor + 46, cursor + 46 + nameSize);
    if (method !== 0 && method !== 8) throw new Error(`Unknown ZIP compression method ${method} for "${name}"`);
    if (data.readUInt16LE(cursor + 8) & 1) throw new Error(`Encrypted ZIP entry "${name}" is unsupported`);
    const entry = {
      method, offset: data.readUInt32LE(cursor + 42),
      size: data.readUInt32LE(cursor + 20), rawSize: data.readUInt32LE(cursor + 24),
    };
    if (entry.offset === 0xffffffff || entry.size === 0xffffffff || entry.rawSize === 0xffffffff ||
        data.readUInt16LE(cursor + 34) !== 0 || entries.has(name)) throw invalid();
    entries.set(name, entry);
    cursor = next;
  }
  if (cursor !== directoryEnd) throw invalid();
  return (name, optional = false) => {
    const entry = entries.get(name);
    if (!entry) {
      if (optional) return undefined;
      throw new Error(`Missing workbook part: ${name}`);
    }
    const offset = entry.offset;
    if (offset + 30 > data.length || data.readUInt32LE(offset) !== 0x04034b50 ||
        data.readUInt16LE(offset + 8) !== entry.method) throw invalid();
    const start = offset + 30 + data.readUInt16LE(offset + 26) + data.readUInt16LE(offset + 28);
    if (start + entry.size > data.length) throw invalid();
    const compressed = data.subarray(start, start + entry.size);
    let contents: Buffer;
    try {
      contents = entry.method === 0 ? compressed : inflateRawSync(compressed);
    } catch {
      throw new Error(`Invalid compressed ZIP entry: ${name}`);
    }
    if (contents.length !== entry.rawSize) throw new Error(`Truncated ZIP entry: ${name}`);
    return contents.toString('utf8');
  };
}

function unescapeXml(text: string): string {
  return text.replace(/&(#x[\da-f]+|#\d+|amp|lt|gt|quot|apos);/gi, (_, entity: string) => {
    if (entity.startsWith('#')) {
      const code = entity[1]?.toLowerCase() === 'x'
        ? parseInt(entity.slice(2), 16) : parseInt(entity.slice(1), 10);
      if (code > 0x10ffff || (code >= 0xd800 && code <= 0xdfff)) throw new Error('Invalid XML character entity');
      return String.fromCodePoint(code);
    }
    return ({ amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" } as Record<string, string>)[entity] ?? _;
  });
}

function parseXml(source: string | undefined, rootName: string): Xml {
  if (source === undefined) throw new Error(`Missing workbook part: ${rootName}`);
  const root: Xml = { name: '', attrs: {}, children: [], text: '' };
  const stack = [root];
  const tokens = /<!--[\s\S]*?-->|<\?[\s\S]*?\?>|<!\[CDATA\[[\s\S]*?\]\]>|<[^>"']*(?:"[^"]*"[^>"']*|'[^']*'[^>"']*)*>|[^<]+/g;
  let position = 0;
  for (const match of source.matchAll(tokens)) {
    if (match.index !== position) throw new Error('Malformed workbook XML');
    const token = match[0];
    position += token.length;
    const parent = stack[stack.length - 1]!;
    if (token.startsWith('<!--') || token.startsWith('<?')) continue;
    if (token.startsWith('<![CDATA[')) {
      parent.text += token.slice(9, -3);
    } else if (token.startsWith('</')) {
      if (stack.length === 1 || token.slice(2, -1).trim() !== parent.name) throw new Error('Malformed workbook XML');
      stack.pop();
    } else if (token.startsWith('<')) {
      const tag = /^<([\w:.-]+)([\s\S]*?)\/?\s*>$/.exec(token);
      if (!tag) throw new Error('Malformed workbook XML');
      const attrs: Record<string, string> = {};
      const attributes = tag[2]!.replace(/([\w:.-]+)\s*=\s*(?:"([^"]*)"|'([^']*)')/g,
        (_, key: string, double: string | undefined, single: string | undefined) => {
          attrs[key] = unescapeXml(double ?? single ?? '');
          return '';
        });
      if (attributes.trim()) throw new Error('Malformed XML attributes');
      const node: Xml = { name: tag[1]!, attrs, children: [], text: '' };
      parent.children.push(node);
      if (!/\/\s*>$/.test(token)) stack.push(node);
    } else {
      parent.text += unescapeXml(token);
    }
  }
  const document = root.children[0];
  if (position !== source.length || stack.length !== 1 || root.children.length !== 1 ||
      !document || localName(document) !== rootName || root.text.trim()) throw new Error(`Malformed ${rootName} XML`);
  return document;
}

function localName(node: Xml): string {
  return node.name.split(':').at(-1)!;
}

function children(node: Xml, name: string): Xml[] {
  return node.children.filter((child) => localName(child) === name);
}

function textRuns(node: Xml): string {
  return node.children.map((child) => localName(child) === 't' ? child.text :
    localName(child) === 'r' ? textRuns(child) : '').join('');
}

function workbook(read: ReturnType<typeof openZip>): { name: string; id: string }[] {
  const book = parseXml(read('xl/workbook.xml'), 'workbook');
  const sheets = children(book, 'sheets')[0];
  if (!sheets) throw new Error('Workbook contains no sheets');
  return children(sheets, 'sheet').map((sheet) => {
    const name = sheet.attrs.name;
    const id = sheet.attrs['r:id'];
    if (name === undefined || !id) throw new Error('Invalid workbook sheet name or relationship id');
    return { name, id };
  });
}

export function listSheets(filePath: string): string[] {
  return workbook(openZip(filePath)).map((sheet) => sheet.name);
}

export function readSheet(filePath: string, sheetName?: string): Sheet {
  const read = openZip(filePath);
  const sheets = workbook(read);
  const sheet = sheetName === undefined ? sheets[0] : sheets.find((item) => item.name === sheetName);
  if (!sheet) throw new Error(sheetName === undefined ? 'Workbook contains no sheets' : `Sheet "${sheetName}" does not exist`);
  const relationships = parseXml(read('xl/_rels/workbook.xml.rels'), 'Relationships');
  const relationship = children(relationships, 'Relationship').find((item) => item.attrs.Id === sheet.id);
  const target = relationship?.attrs.Target;
  if (!target || relationship?.attrs.TargetMode === 'External') throw new Error(`Missing worksheet relationship: ${sheet.id}`);
  const parts: string[] = [];
  for (const part of (target.startsWith('/') ? target.slice(1) : `xl/${target}`).split('/')) {
    if (part === '..') {
      if (!parts.length) throw new Error('Invalid worksheet target path');
      parts.pop();
    } else if (part && part !== '.') parts.push(part);
  }
  const worksheet = parseXml(read(parts.join('/')), 'worksheet');
  const sharedXml = read('xl/sharedStrings.xml', true);
  const strings = sharedXml === undefined ? [] : children(parseXml(sharedXml, 'sst'), 'si').map(textRuns);
  const rows: string[][] = [];
  let width = 0;
  const sheetData = children(worksheet, 'sheetData')[0];
  if (!sheetData) throw new Error('Missing worksheet sheetData');
  for (const row of children(sheetData, 'row')) {
    if (row.attrs.r !== undefined) {
      const rowNumber = Number(row.attrs.r);
      if (!Number.isInteger(rowNumber) || rowNumber < 1 || rowNumber > 1048576) throw new Error('Invalid worksheet row reference');
      rows.length = Math.max(rows.length, rowNumber);
    }
    for (const cell of children(row, 'c')) {
      const reference = /^([A-Z]+)([1-9]\d*)$/.exec(cell.attrs.r ?? '');
      if (!reference) throw new Error(`Invalid cell reference: ${cell.attrs.r ?? '(missing)'}`);
      let column = 0;
      for (const letter of reference[1]!) column = column * 26 + letter.charCodeAt(0) - 64;
      const rowNumber = Number(reference[2]);
      if (column > 16384 || rowNumber > 1048576) throw new Error('Cell reference outside worksheet bounds');
      let value = children(cell, 'v')[0]?.text ?? '';
      const type = cell.attrs.t;
      if (type === 's' && value !== '') {
        if (!/^\d+$/.test(value) || strings[Number(value)] === undefined) throw new Error(`Invalid shared string index: ${value}`);
        value = strings[Number(value)]!;
      } else if (type === 'inlineStr') {
        const inline = children(cell, 'is')[0];
        value = inline ? textRuns(inline) : '';
      } else if (type === 'b' && value !== '') {
        if (value !== '0' && value !== '1') throw new Error(`Invalid boolean cell value: ${value}`);
        value = value === '1' ? 'TRUE' : 'FALSE';
      }
      const output = rows[rowNumber - 1] ?? (rows[rowNumber - 1] = []);
      output[column - 1] = value;
      width = Math.max(width, column);
    }
  }
  return { name: sheet.name, rows: Array.from({ length: rows.length }, (_, r) =>
    Array.from({ length: width }, (_, c) => rows[r]?.[c] ?? '')) };
}
