import { mkdirSync, readdirSync, readFileSync, renameSync, rmSync, writeFileSync } from 'node:fs';
import { dirname, join } from 'node:path';
import { randomUUID } from 'node:crypto';
import { z } from 'zod';
import { loadStorageConfig } from '../platform/config.ts';
import { addUpload } from './catalogue.ts';
import type { Dataset } from './types.ts';

const storedUpload = z.object({
  profile: z.string().regex(/^[A-Za-z0-9_-]{1,40}$/),
  dataset: z.object({
    id: z.string().regex(/^user:[A-Za-z0-9_-]+$/),
    name: z.string().min(1).max(80),
    source: z.literal('upload'),
    fields: z.array(z.object({
      name: z.string(), label: z.string(),
      type: z.enum(['text', 'number', 'date', 'boolean']),
      nullable: z.boolean(), unit: z.string().optional(),
    })).min(1),
    rowCount: z.number().int().nonnegative(),
    coverageStart: z.string().optional(), coverageEnd: z.string().optional(),
    notes: z.string().optional(),
  }),
  rows: z.array(z.array(z.string())),
}).refine(({ dataset, rows }) => dataset.rowCount === rows.length);

function uploadDirectory(): string {
  return join(dirname(loadStorageConfig().path), 'uploads');
}

/** Persist the parsed upload before publishing it in the catalogue. */
export function saveUpload(dataset: Dataset, rows: string[][], profile: string): void {
  const value = storedUpload.parse({ dataset, rows, profile });
  const directory = uploadDirectory();
  mkdirSync(directory, { recursive: true });
  const target = join(directory, `${dataset.id.slice(5)}.json`);
  const temporary = join(directory, `.${randomUUID()}.tmp`);
  try {
    writeFileSync(temporary, JSON.stringify(value), { flag: 'wx', mode: 0o600 });
    renameSync(temporary, target);
  } finally {
    rmSync(temporary, { force: true });
  }
}

function readUploads(): z.infer<typeof storedUpload>[] {
  const directory = uploadDirectory();
  let files: string[];
  try {
    files = readdirSync(directory);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') return [];
    throw error;
  }
  const uploads: z.infer<typeof storedUpload>[] = [];
  for (const file of files.sort()) {
    if (!file.endsWith('.json')) continue;
    try {
      const parsed = storedUpload.safeParse(JSON.parse(readFileSync(join(directory, file), 'utf8')));
      if (parsed.success) uploads.push(parsed.data);
    } catch {
      // An unreadable or corrupt upload must not hide the other datasets.
    }
  }
  return uploads;
}

export function loadUploads(): void {
  for (const { dataset, rows } of readUploads()) addUpload(dataset, rows);
}

/** Metadata only; parsed rows stay on the server. */
export function listUploads(profile: string): Dataset[] {
  return readUploads().filter((upload) => upload.profile === profile).map((upload) => upload.dataset);
}
