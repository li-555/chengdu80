// src/data/register-external-api.ts
// Register a user-supplied data API as a Dataset. Only a bounded sample is fetched to
// infer the schema; the full read happens lazily in resolveSlice.

import { randomUUID } from 'node:crypto';
import { readApiRows, type ApiAuth, type ApiReadOptions } from './api-client.ts';
import { inferApiSchema } from './infer-api-schema.ts';
import { addApiSource } from './catalogue.ts';
import type { Dataset } from './types.ts';

export async function registerExternalApi(
  url: string,
  auth: ApiAuth,
  name: string,
  options: ApiReadOptions = {},
): Promise<Dataset> {
  const sample = await readApiRows(url, auth, { ...options, maxRows: options.maxRows ?? 500 });
  const { schema } = inferApiSchema(sample);

  const id = `api:${randomUUID().slice(0, 8)}`;
  const dataset: Dataset = { id, name, source: 'api', fields: schema };

  addApiSource(dataset, { url, auth, options });
  return dataset;
}
