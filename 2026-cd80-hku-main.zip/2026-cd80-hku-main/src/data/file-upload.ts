import { readFileSync } from 'node:fs';
import { randomUUID } from 'node:crypto';
import { readSheet, listSheets } from './xlsx-reader.ts';
import { parseMarkdownTables } from './markdown-tables.ts';
import type { FieldType, FieldSpec, Dataset } from './types.ts';

// ============================================================
// CSV Parser (RFC 4180 compliant, zero dependencies)
// ============================================================

export function parseCSV(content: string): string[][] {
  const rows: string[][] = [];
  let currentRow: string[] = [];
  let currentField = '';
  let inQuotes = false;

  for (let i = 0; i < content.length; i++) {
    const ch = content[i];
    const next = content[i + 1];

    if (inQuotes) {
      if (ch === '"') {
        if (next === '"') {
          currentField += '"';
          i++;
        } else {
          inQuotes = false;
        }
      } else {
        currentField += ch;
      }
    } else {
      if (ch === '"') {
        inQuotes = true;
      } else if (ch === ',') {
        currentRow.push(currentField);
        currentField = '';
      } else if (ch === '\r') {
        if (next === '\n') {
          currentRow.push(currentField);
          rows.push(currentRow);
          currentRow = [];
          currentField = '';
          i++;
        } else {
          currentRow.push(currentField);
          rows.push(currentRow);
          currentRow = [];
          currentField = '';
        }
      } else if (ch === '\n') {
        currentRow.push(currentField);
        rows.push(currentRow);
        currentRow = [];
        currentField = '';
      } else {
        currentField += ch;
      }
    }
  }

  if (currentField !== '' || currentRow.length > 0) {
    currentRow.push(currentField);
  }
  if (currentRow.length > 0) {
    rows.push(currentRow);
  }

  return rows;
}

// ============================================================
// BOM handling
// ============================================================

function stripBOM(content: string): string {
  if (content.charCodeAt(0) === 0xFEFF) {
    return content.slice(1);
  }
  return content;
}

// ============================================================
// Type Detection
// ============================================================

const DATE_PATTERN_YYYYMMDD = /^\d{8}$/;
const DATE_PATTERN_ISO = /^\d{4}-\d{2}-\d{2}$/;
const DATE_PATTERN_SLASH = /^\d{4}\/\d{2}\/\d{2}$/;

function isValidDateStr(s: string): boolean {
  if (DATE_PATTERN_YYYYMMDD.test(s)) {
    const y = parseInt(s.slice(0, 4), 10);
    const m = parseInt(s.slice(4, 6), 10);
    const d = parseInt(s.slice(6, 8), 10);
    return isValidDate(y, m, d);
  }
  if (DATE_PATTERN_ISO.test(s)) {
    const y = parseInt(s.slice(0, 4), 10);
    const m = parseInt(s.slice(5, 7), 10);
    const d = parseInt(s.slice(8, 10), 10);
    return isValidDate(y, m, d);
  }
  if (DATE_PATTERN_SLASH.test(s)) {
    const y = parseInt(s.slice(0, 4), 10);
    const m = parseInt(s.slice(5, 7), 10);
    const d = parseInt(s.slice(8, 10), 10);
    return isValidDate(y, m, d);
  }
  return false;
}

function isValidDate(y: number, m: number, d: number): boolean {
  if (m < 1 || m > 12 || d < 1 || d > 31) return false;
  if (y < 1900 || y > 2100) return false;
  const daysInMonth = new Date(y, m, 0).getDate();
  return d <= daysInMonth;
}

function isNumeric(s: string): boolean {
  const trimmed = s.trim();
  if (trimmed === '') return false;
  return !isNaN(Number(trimmed)) && isFinite(Number(trimmed));
}

function classifyValue(v: string): FieldType | null {
  const trimmed = v.trim();
  if (trimmed === '') return null;
  const lower = trimmed.toLowerCase();
  if (lower === 'true' || lower === 'false' || lower === 'yes' || lower === 'no') return 'boolean';
  if (isNumeric(trimmed)) return 'number';
  if (isValidDateStr(trimmed)) return 'date';
  return 'text';
}

const TYPE_PRECEDENCE: FieldType[] = ['text', 'boolean', 'date', 'number'];

function mergeType(current: FieldType | null, candidate: FieldType | null): FieldType | null {
  if (candidate === null) return current;
  if (current === null) return candidate;
  if (current === candidate) return current;
  const curIdx = TYPE_PRECEDENCE.indexOf(current);
  const candIdx = TYPE_PRECEDENCE.indexOf(candidate);
  return curIdx < candIdx ? current : candidate;
}

// ============================================================
// Schema Inference
// ============================================================

export type InferSchemaResult = {
  fields: FieldSpec[];
  rows: string[][];
  coverageStart?: string;
  coverageEnd?: string;
};

/**
 * A column name that names an identifier rather than a quantity.
 *
 * Such a column is text even when every value is a digit, because arithmetic on it is
 * never meaningful and the leading zero is part of the identifier.
 */
const CODE_NAME = /(^|_)(code|symbol|ticker|id|no|number)$|^(ts_code|con_code|fund_code)$/i;

/** Eight digits, the shape a date takes when a spreadsheet stores it as a number. */
const EIGHT_DIGITS = /^\d{8}$/;

/** Digits with a leading zero, the shape of a six-digit mainland security code. */
const LEADING_ZERO = /^0\d+$/;

export function inferSchema(headers: string[], rawRows: string[][]): InferSchemaResult {
  const colCount = headers.length;
  const fieldTypes: (FieldType | null)[] = new Array(colCount).fill(null);
  const fieldHasEmpty: boolean[] = new Array(colCount).fill(false);
  const fieldHasValue: boolean[] = new Array(colCount).fill(false);

  // Per column, whether EVERY non-empty value seen so far had the given shape.
  const allLeadingZero: boolean[] = new Array(colCount).fill(true);
  const allEightDigits: boolean[] = new Array(colCount).fill(true);

  for (const row of rawRows) {
    for (let c = 0; c < colCount; c++) {
      const trimmed = (row[c] ?? '').trim();
      if (trimmed === '') {
        fieldHasEmpty[c] = true;
        continue;
      }
      fieldHasValue[c] = true;
      if (!LEADING_ZERO.test(trimmed)) allLeadingZero[c] = false;
      if (!EIGHT_DIGITS.test(trimmed)) allEightDigits[c] = false;
      fieldTypes[c] = mergeType(fieldTypes[c] ?? null, classifyValue(trimmed));
    }
  }

  const fields: FieldSpec[] = headers.map((rawName, c) => {
    const name = rawName.replace(/^\uFEFF/, '');

    /**
     * Two overrides applied BEFORE the inferred type is trusted. Each one would
     * otherwise corrupt mainland market data silently rather than noisily.
     *
     *  1. A code column read as a number loses its leading zero, so the invented code
     *     `000001` becomes the number `1` and never matches anything again.
     *  2. A date written as eight digits is numeric by every test, so `20260114` would
     *     be averaged and compared as twenty million.
     *
     * Both are column-level decisions: they depend on the column's name and on every
     * sampled value, which is why they live here and not in classifyValue().
     */
    let type: FieldType;
    const seenAny = fieldHasValue[c] === true;

    if (CODE_NAME.test(name) || (seenAny && allLeadingZero[c] === true)) {
      type = 'text';
    } else if (/date/i.test(name) && seenAny && allEightDigits[c] === true) {
      type = 'date';
    } else {
      type = fieldTypes[c] ?? 'text';
    }

    return { name, label: name, type, nullable: !seenAny || fieldHasEmpty[c] === true };
  });

  return { fields, rows: rawRows };
}

// ============================================================
// Excel Parsing
// ============================================================

function parseExcel(filePath: string): InferSchemaResult {
  const { rows } = readSheet(filePath);
  return inferSchema(rows[0] ?? [], rows.slice(1));
}

// ============================================================
// File Upload: registerUpload
// ============================================================

const CSV_EXTENSIONS = ['.csv', '.tsv'];
const EXCEL_EXTENSIONS = ['.xlsx', '.xls', '.xlsm'];

function isCSV(filePath: string): boolean {
  const lower = filePath.toLowerCase();
  return CSV_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

function isExcel(filePath: string): boolean {
  const lower = filePath.toLowerCase();
  return EXCEL_EXTENSIONS.some((ext) => lower.endsWith(ext));
}

function isMarkdown(filePath: string): boolean {
  return filePath.toLowerCase().endsWith('.md');
}

export type UploadResult = { dataset: Dataset; rows: string[][] };

function emptyUpload(name: string): UploadResult {
  return {
    dataset: { id: `user:${randomUUID().slice(0, 8)}`, name, source: 'upload', fields: [], rowCount: 0 },
    rows: [],
  };
}

export async function registerUpload(filePath: string, name: string): Promise<UploadResult> {
  let result: InferSchemaResult;

  if (isCSV(filePath)) {
    const raw = readFileSync(filePath, 'utf-8');
    const cleaned = stripBOM(raw);
    const isTSV = filePath.toLowerCase().endsWith('.tsv');
    if (isTSV) {
      const lines = cleaned.split('\n').filter((l) => l.trim() !== '');
      const rows = lines.map((l) => l.split('\t'));
      if (rows.length === 0) {
        return emptyUpload(name);
      }
      result = inferSchema(rows[0] ?? [], rows.slice(1));
    } else {
      const parsed = parseCSV(cleaned);
      if (parsed.length === 0) {
        return emptyUpload(name);
      }
      result = inferSchema(parsed[0] ?? [], parsed.slice(1));
    }
  } else if (isExcel(filePath)) {
    result = await parseExcel(filePath);
  } else if (isMarkdown(filePath)) {
    const tables = parseMarkdownTables(readFileSync(filePath, 'utf-8'));
    const first = tables[0];
    if (!first) {
      return emptyUpload(name);
    }
    result = inferSchema(first.headers, first.rows);
  } else {
    throw new Error(
      `Unsupported file type: "${filePath}". Supported types: .csv, .tsv, .xlsx, .xls, .xlsm, .md`
    );
  }

  if (result.fields.length === 0) {
    return emptyUpload(name);
  }

  const id = `user:${randomUUID().slice(0, 8)}`;

  return {
    dataset: {
      id,
      name,
      source: 'upload',
      fields: result.fields,
      rowCount: result.rows.length,
    },
    rows: result.rows,
  };
}

// ============================================================
// Multi-sheet parsing for upload previews
// ============================================================

export type ParsedSheet = {
  name: string;
  headers: string[];
  rows: string[][];
  fields: FieldSpec[];
};

function sheetFromRows(name: string, rows: string[][]): ParsedSheet {
  const headers = rows[0] ?? [];
  const body = rows.slice(1);
  const { fields } = inferSchema(headers, body);
  return { name, headers, rows: body, fields };
}

export function parseUploadFile(filePath: string): ParsedSheet[] {
  if (isExcel(filePath)) {
    return listSheets(filePath).map((name) => sheetFromRows(name, readSheet(filePath, name).rows));
  }

  if (isCSV(filePath)) {
    const raw = readFileSync(filePath, 'utf-8');
    const cleaned = stripBOM(raw);
    const rows = filePath.toLowerCase().endsWith('.tsv')
      ? cleaned.split('\n').filter((l) => l.trim() !== '').map((l) => l.split('\t'))
      : parseCSV(cleaned);
    return rows.length === 0 ? [] : [sheetFromRows('Sheet1', rows)];
  }

  if (isMarkdown(filePath)) {
    const tables = parseMarkdownTables(readFileSync(filePath, 'utf-8'));
    return tables.map((table) => sheetFromRows(table.name, [table.headers, ...table.rows]));
  }

  throw new Error(
    `Unsupported file type: "${filePath}". Supported types: .csv, .tsv, .xlsx, .xls, .xlsm, .md`
  );
}