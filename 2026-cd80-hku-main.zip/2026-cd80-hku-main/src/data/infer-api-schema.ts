// src/data/infer-api-schema.ts
// Turn the rows an external API returns into a flat table and infer its schema.
// Reuses the same type inference as CSV/Excel uploads.

import { inferSchema } from './file-upload.ts';
import type { FieldSpec } from './types.ts';

export type NormalizedTable = { headers: string[]; rows: string[][] };

/** Nested objects become `a.b` dot paths; arrays and other shapes become JSON text. */
function flattenRecord(value: unknown, prefix = ''): Record<string, unknown> {
  if (value === null || value === undefined) return {};
  if (typeof value !== 'object' || Array.isArray(value)) {
    return { [prefix || 'value']: value };
  }
  const out: Record<string, unknown> = {};
  for (const [key, v] of Object.entries(value as Record<string, unknown>)) {
    const path = prefix ? `${prefix}.${key}` : key;
    if (v !== null && typeof v === 'object' && !Array.isArray(v)) {
      Object.assign(out, flattenRecord(v, path));
    } else {
      out[path] = v;
    }
  }
  return out;
}

function cellString(value: unknown): string {
  if (value === null || value === undefined) return '';
  if (typeof value === 'string') return value;
  if (typeof value === 'number' || typeof value === 'boolean') return String(value);
  return JSON.stringify(value);
}

export function normalizeJsonToTable(rows: unknown[]): NormalizedTable {
  const headers: string[] = [];
  const seen = new Set<string>();
  const flatRows: Record<string, unknown>[] = [];

  for (const raw of rows) {
    const flat = flattenRecord(raw);
    flatRows.push(flat);
    for (const key of Object.keys(flat)) {
      if (!seen.has(key)) {
        seen.add(key);
        headers.push(key);
      }
    }
  }

  return {
    headers,
    rows: flatRows.map((flat) => headers.map((h) => cellString(flat[h]))),
  };
}

export function inferApiSchema(rows: unknown[]): { schema: FieldSpec[]; table: NormalizedTable } {
  const table = normalizeJsonToTable(rows);
  const { fields } = inferSchema(table.headers, table.rows);
  return { schema: fields, table };
}
