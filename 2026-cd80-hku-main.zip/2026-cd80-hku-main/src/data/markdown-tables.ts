// Shared by the data layer and browser; keep this module free of Node imports.
// One pipe table becomes one dataset sheet. The same scan removes table rows
// from the builder description, so extraction and redaction cannot disagree.
export type MarkdownTable = { name: string; headers: string[]; rows: string[][] };
export type MarkdownDocument = { description: string; tables: MarkdownTable[] };
export class MarkdownTableError extends Error {}

function splitRow(line: string): { cells: string[]; pipe: boolean } {
  const content = line.trim();
  const cells: string[] = [];
  let current = '', lastDelimiter = -1;
  for (let index = 0; index < content.length; index++) {
    const ch = content[index]!;
    if (ch === '\\' && index + 1 < content.length) {
      // Preserve escapes for cleanCell, while keeping escaped pipes in a cell.
      current += ch + content[++index];
    } else if (ch === '|') {
      cells.push(current); current = ''; lastDelimiter = index;
    } else current += ch;
  }
  cells.push(current);
  if (content.startsWith('|')) cells.shift();
  if (lastDelimiter === content.length - 1 && lastDelimiter >= 0) cells.pop();
  return { cells, pipe: lastDelimiter >= 0 };
}
function isSeparator(cells: string[]): boolean {
  return cells.length > 0 && cells.every((cell) => /^:?-{3,}:?$/.test(cell.trim()));
}
function cleanCell(cell: string): string {
  // Only ASCII punctuation can be escaped in Markdown. In particular, do not
  // turn a path such as C:\new\file into C:newfile or drop a trailing backslash.
  const escaped: string[] = [];
  return cell.trim()
    .replace(/\\([!-/:-@\[-`{-~])/g, (_, value: string) => `\u0000${escaped.push(value) - 1}\u0000`)
    .replace(/\*\*([^*]+)\*\*/g, '$1')
    .replace(/(?<!\*)\*([^*]+)\*(?!\*)/g, '$1')
    .replace(/`([^`]+)`/g, '$1')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/~~([^~]+)~~/g, '$1')
    .replace(/\u0000(\d+)\u0000/g, (match, index: string) => escaped[Number(index)] ?? match);
}

/** Split prose from pipe tables. Fenced and indented code are not descriptions. */
export function parseMarkdownDocument(markdown: string): MarkdownDocument {
  const lines = markdown.replace(/^\uFEFF/, '').split(/\r\n?|\n/);
  const tables: MarkdownTable[] = [], prose: string[] = [];
  let fence: { marker: string; length: number } | undefined;
  let index = 0;
  while (index < lines.length) {
    const line = lines[index]!;
    const opening = /^ {0,3}(`{3,}|~{3,})(.*)$/.exec(line);
    if (fence) {
      if (opening && opening[1]![0] === fence.marker && opening[1]!.length >= fence.length && !opening[2]!.trim()) fence = undefined;
      index++; continue;
    }
    if (opening) { fence = { marker: opening[1]![0]!, length: opening[1]!.length }; index++; continue; }
    if (/^( {4}|\t)/.test(line)) { index++; continue; }
    const header = splitRow(line);
    const separator = splitRow(lines[index + 1] ?? '');
    if (!header.pipe || !isSeparator(separator.cells)) { prose.push(line); index++; continue; }
    if (header.cells.length !== separator.cells.length) {
      throw new MarkdownTableError(`Markdown table at line ${index + 1} has different header and separator column counts.`);
    }
    const headers = header.cells.map(cleanCell), rows: string[][] = [];
    index += 2;
    while (index < lines.length) {
      const row = lines[index]!;
      if (!row.trim() || /^ {0,3}(`{3,}|~{3,})/.test(row) || /^( {4}|\t)/.test(row)) break;
      const parsed = splitRow(row);
      if (!parsed.pipe) break;
      if (parsed.cells.length > headers.length) {
        // Reject the whole file before saving anything instead of discarding
        // rows or silently truncating extra values.
        throw new MarkdownTableError(`Markdown table row at line ${index + 1} has more cells than its header. Escape a literal pipe as \\|.`);
      }
      rows.push(Array.from({ length: headers.length }, (_, column) => cleanCell(parsed.cells[column] ?? '')));
      index++;
    }
    tables.push({ name: `Table ${tables.length + 1}`, headers, rows });
  }
  return { description: prose.join('\n').replace(/\n{3,}/g, '\n\n').trim(), tables };
}
export function parseMarkdownTables(markdown: string): MarkdownTable[] {
  return parseMarkdownDocument(markdown).tables;
}
