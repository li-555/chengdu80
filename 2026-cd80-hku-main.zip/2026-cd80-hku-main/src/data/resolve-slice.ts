// src/data/resolve-slice.ts
// Turn a SliceRequest into rows from Tushare, an uploaded file, or a user-supplied API.
//
// The public entry point is `resolveSlice`. `resolveSliceWith` exists so the slice
// can be tested offline against a supplied fetcher instead of the live service.

import { findDataset, getUploadRows, getApiSource } from './catalogue.ts';
import { fetchTable } from './tushare-client.ts';
import { readApiRows } from './api-client.ts';
import { normalizeJsonToTable } from './infer-api-schema.ts';
import type { Slice, SliceRequest, FieldSpec, Dataset } from './types.ts';

/** `resolveSlice` never returns more rows than this, whatever the request asks for. */
const MAX_ROWS = 200000;

/** Bumped whenever the shape of a returned slice changes. */
const SLICE_VERSION = '1.0.0';

/** Upper bound on cached slices, so a long session cannot grow the cache without end. */
const MAX_CACHE_ENTRIES = 64;

const cache = new Map<string, Slice>();

type Fetcher = (
  apiName: string,
  params: Record<string, unknown>,
  fields: string[],
  maxRows?: number,
) => Promise<{ fields: string[]; rows: unknown[][] }>;

function toTushareDate(value: string): string {
  return value.replace(/-/g, '');
}

function formatAsOfDate(value: string): string {
  return value.length === 8
    ? `${value.slice(0, 4)}-${value.slice(4, 6)}-${value.slice(6, 8)}`
    : value;
}

function normalizeDate(value: string): string | null {
  const digits = value.replace(/[-\/]/g, '');
  return /^\d{8}$/.test(digits) ? digits : null;
}

function cacheKey(req: SliceRequest): string {
  return JSON.stringify({
    datasetId: req.datasetId,
    fields: req.fields,
    dateFrom: req.dateFrom,
    dateTo: req.dateTo,
    filter: req.filter,
    limit: req.limit,
  });
}

/** The column that names the day a row belongs to, or -1 when there is none. */
function dateColumn(schema: FieldSpec[]): number {
  const tradeDate = schema.findIndex((f) => f.name === 'trade_date');
  if (tradeDate !== -1) return tradeDate;
  return schema.findIndex((f) => f.name === 'cal_date');
}

function latestAsOfDate(schema: FieldSpec[], rows: unknown[][]): string | undefined {
  const col = dateColumn(schema);
  if (col === -1) return undefined;
  let latest = '';
  for (const row of rows) {
    const value = row[col];
    if (typeof value === 'string' && value > latest) latest = value;
  }
  return latest ? formatAsOfDate(latest) : undefined;
}

function storeSlice(key: string, slice: Slice): Slice {
  if (cache.size >= MAX_CACHE_ENTRIES) {
    const oldest = cache.keys().next().value;
    if (oldest !== undefined) cache.delete(oldest);
  }
  cache.set(key, slice);
  return slice;
}

/**
 * Build a slice from a flat table: map requested fields by name, apply equality and
 * date filters, cap rows, and derive asOfDate. Shared by uploads and external APIs.
 */
function buildSlice(
  dataset: Dataset,
  req: SliceRequest,
  key: string,
  table: string[][],
  headers: string[],
): Slice {
  const headerIndex = new Map(headers.map((name, i) => [name, i]));

  const fieldNames = req.fields && req.fields.length > 0
    ? req.fields
    : dataset.fields.map((f) => f.name);

  const schema: FieldSpec[] = fieldNames.map((name) => {
    const spec = dataset.fields.find((f) => f.name === name);
    if (!spec) {
      throw new Error(`field "${name}" is not in dataset "${dataset.id}"`);
    }
    return spec;
  });

  const columnIndex = fieldNames.map((name) => headerIndex.get(name) ?? -1);

  // Column equality filters; a comma-joined value means "any of these".
  const filters = Object.entries(req.filter ?? {})
    .map(([name, value]) => {
      const col = headerIndex.get(name) ?? -1;
      if (col === -1) return null;
      const wanted = String(value).split(',').map((v) => v.trim());
      return (row: string[]) => wanted.includes((row[col] ?? '').trim());
    })
    .filter((f): f is (row: string[]) => boolean => f !== null);

  // Date range applies to the first date-typed column that is present in the data.
  const dateName = schema.find((f) => f.type === 'date' && headerIndex.has(f.name))?.name;
  const dateIndex = dateName === undefined ? -1 : headerIndex.get(dateName) ?? -1;
  const from = req.dateFrom ? normalizeDate(req.dateFrom) : null;
  const to = req.dateTo ? normalizeDate(req.dateTo) : null;

  const limit = Math.min(req.limit ?? MAX_ROWS, MAX_ROWS);

  const rows: unknown[][] = [];
  let latestDate: string | null = null;
  for (const row of table) {
    if (filters.some((matches) => !matches(row))) continue;
    if (dateIndex !== -1 && (from !== null || to !== null)) {
      const date = normalizeDate(row[dateIndex] ?? '');
      if (date === null) continue;
      if (from !== null && date < from) continue;
      if (to !== null && date > to) continue;
    }
    if (dateIndex !== -1) {
      const date = normalizeDate(row[dateIndex] ?? '');
      if (date !== null && (latestDate === null || date > latestDate)) latestDate = date;
    }
    if (rows.length < limit) {
      rows.push(columnIndex.map((i) => (i === -1 ? null : row[i] ?? null)));
    }
  }

  return storeSlice(key, {
    schema,
    rows,
    asOfDate: latestDate ? formatAsOfDate(latestDate) : undefined,
    datasetVersion: SLICE_VERSION,
  });
}

function resolveUploadSlice(dataset: Dataset, req: SliceRequest, key: string): Slice {
  return buildSlice(
    dataset,
    req,
    key,
    getUploadRows(dataset.id),
    dataset.fields.map((f) => f.name),
  );
}

async function resolveApiSlice(dataset: Dataset, req: SliceRequest, key: string): Promise<Slice> {
  const source = getApiSource(dataset.id);
  if (!source) {
    throw new Error(`dataset "${dataset.id}" has no external API source`);
  }

  const limit = Math.min(req.limit ?? MAX_ROWS, MAX_ROWS);
  const rows = await readApiRows(source.url, source.auth, { ...source.options, maxRows: limit });
  const table = normalizeJsonToTable(rows);
  return buildSlice(dataset, req, key, table.rows, table.headers);
}

export async function resolveSlice(req: SliceRequest): Promise<Slice> {
  return resolveSliceWith(req, fetchTable);
}

export async function resolveSliceWith(req: SliceRequest, fetch: Fetcher): Promise<Slice> {
  const key = cacheKey(req);
  const cached = cache.get(key);
  if (cached) return cached;

  if (!req.datasetId) {
    throw new Error('slice request has no datasetId');
  }

  const dataset = findDataset(req.datasetId);
  if (!dataset) {
    throw new Error(`dataset "${req.datasetId}" not found`);
  }
  if (dataset.source === 'upload') {
    return resolveUploadSlice(dataset, req, key);
  }
  if (dataset.source === 'api') {
    return resolveApiSlice(dataset, req, key);
  }

  const apiName = dataset.id.slice('tushare:'.length);

  const params: Record<string, unknown> = {};
  if (req.dateFrom) params.start_date = toTushareDate(req.dateFrom);
  if (req.dateTo) params.end_date = toTushareDate(req.dateTo);
  for (const [name, value] of Object.entries(req.filter ?? {})) {
    params[name] = value;
  }

  const fieldNames = req.fields && req.fields.length > 0
    ? req.fields
    : dataset.fields.map((f) => f.name);

  const schema: FieldSpec[] = fieldNames.map((name) => {
    const spec = dataset.fields.find((f) => f.name === name);
    if (!spec) {
      throw new Error(`field "${name}" is not in dataset "${req.datasetId}"`);
    }
    return spec;
  });

  const limit = Math.min(req.limit ?? MAX_ROWS, MAX_ROWS);

  const table = await fetch(apiName, params, fieldNames, limit);

  // Read columns by name, never by position: Tushare is not obliged to keep the
  // order we asked for, and trusting it would silently swap columns.
  const columnIndex = fieldNames.map((name) => table.fields.indexOf(name));
  const missing = fieldNames.filter((_, i) => columnIndex[i] === -1);
  if (missing.length > 0) {
    throw new Error(`Tushare ${apiName} did not return requested fields: ${missing.join(', ')}`);
  }

  const rows = table.rows.slice(0, limit).map((row) => columnIndex.map((i) => row[i]));

  return storeSlice(key, {
    schema,
    rows,
    asOfDate: latestAsOfDate(schema, rows),
    datasetVersion: SLICE_VERSION,
  });
}

export function clearSliceCache(): void {
  cache.clear();
}
