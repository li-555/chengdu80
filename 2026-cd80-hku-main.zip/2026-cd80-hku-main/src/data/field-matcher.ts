import { findDataset } from './catalogue.ts';
import type { DataRequirement, RequirementReport, FieldSpec, FieldType } from './types.ts';

function fieldMatches(a: string, b: string): boolean {
  return a.toLowerCase() === b.toLowerCase();
}

function findCandidates(
  datasetFields: FieldSpec[],
  requiredName: string,
  requiredType: FieldType,
): string[] {
  return datasetFields
    .filter((f) => f.type === requiredType && !fieldMatches(f.name, requiredName))
    .map((f) => f.name);
}

export function checkRequirements(
  reqs: DataRequirement[],
  bindings?: Record<string, string>,
  mappings?: Record<string, Record<string, string>>,
): RequirementReport[] {
  return reqs.map((req) => {
    const problems: RequirementReport['problems'] = [];
    let datasetId = bindings?.[req.key];

    if (!datasetId && req.datasetHint) {
      const hinted = findDataset(req.datasetHint);
      if (hinted) datasetId = hinted.id;
    }

    if (!datasetId) {
      return {
        key: req.key,
        status: 'unsatisfiable' as const,
        problems: [
          {
            field: '(all)',
            code: 'NO_DATASET',
            message: `No dataset bound for "${req.key}". Provide a binding or datasetHint.`,
          },
        ],
      };
    }

    const dataset = findDataset(datasetId);
    if (!dataset) {
      return {
        key: req.key,
        status: 'unsatisfiable' as const,
        boundDatasetId: datasetId,
        problems: [
          {
            field: '(all)',
            code: 'DATASET_NOT_FOUND',
            message: `Dataset "${datasetId}" not found.`,
          },
        ],
      };
    }

    const fieldMap = mappings?.[req.key] ?? {};
    const mapping: Record<string, string> = {};
    let hasUnmatched = false;
    let hasUnsatisfiable = false;

    for (const f of req.fields) {
      const mappedName = fieldMap[f.name] ?? f.name;

      const found = dataset.fields.find((df) => fieldMatches(df.name, mappedName));

      if (found) {
        if (found.type !== f.type) {
          problems.push({
            field: f.name,
            code: 'TYPE_MISMATCH',
            message: `Field "${f.name}" mapped to "${mappedName}" but types differ: expected ${f.type}, got ${found.type}.`,
          });
        }
        mapping[f.name] = mappedName;
      } else {
        if (f.required) {
          const candidates = findCandidates(dataset.fields, f.name, f.type);
          if (candidates.length > 0) {
            problems.push({
              field: f.name,
              code: 'FIELD_NOT_FOUND',
              message: `Required field "${f.name}" not found. Candidates: ${candidates.join(', ')}`,
            });
            hasUnmatched = true;
          } else {
            problems.push({
              field: f.name,
              code: 'FIELD_NOT_FOUND',
              message: `Required field "${f.name}" (${f.type}) not found. No candidates of type ${f.type}.`,
            });
            hasUnsatisfiable = true;
          }
        }
      }
    }

    let status: RequirementReport['status'];
    if (hasUnsatisfiable) {
      status = 'unsatisfiable';
    } else if (hasUnmatched) {
      status = 'needs_mapping';
    } else {
      status = 'satisfied';
    }

    return {
      key: req.key,
      status,
      boundDatasetId: datasetId,
      mapping: Object.keys(mapping).length > 0 ? mapping : undefined,
      problems,
    };
  });
}