// src/data/trading-cal.ts
// The exchange trading calendar, from Tushare `trade_cal`.
//
// A trading day is a day the exchange is open. Market-relative scheduling depends on
// this file, so its failure modes matter more than its speed: a wrong answer here makes
// a scheduled application fire on a public holiday, or never fire at all.

import { fetchTable } from './tushare-client.ts';

type YearCalendar = {
  tradingDays: Set<string>;
  nonTradingDays: Set<string>;
};

/**
 * One entry per calendar year.
 *
 * It used to hold a single year, which made `nextTradingDay` fail whenever its search
 * crossed into the next year: the dates it stepped onto were looked up in a cache that
 * could not contain them, so the last days of December reported no trading day within
 * thirty days. Keyed by year, a search loads each year it reaches.
 */
const cache = new Map<string, YearCalendar>();
let lastFetchDurationMs = 0;

const MARKET_OPEN = '09:30';
const MARKET_CLOSE = '15:00';

/** How far `nextTradingDay` will look. Longer than any exchange closure. */
const MAX_LOOKAHEAD_DAYS = 30;

function yearOf(date: string): string {
  return date.slice(0, 4);
}

async function ensureYear(year: string): Promise<YearCalendar> {
  const cached = cache.get(year);
  if (cached) return cached;

  const t0 = Date.now();
  const table = await fetchTable(
    'trade_cal',
    { exchange: 'SSE', start_date: `${year}0101`, end_date: `${year}1231` },
    ['cal_date', 'is_open'],
  );
  lastFetchDurationMs = Date.now() - t0;

  /**
   * Read the columns by name.
   *
   * Tushare reports the column order it actually used in `fields`, and it is not obliged
   * to match the order we asked for. Reading `row[0]` and `row[1]` positionally would
   * silently swap the date and the open flag if that order ever changed, and every day
   * would then be classified wrongly with no error raised anywhere.
   */
  const dateAt = table.fields.indexOf('cal_date');
  const openAt = table.fields.indexOf('is_open');
  if (dateAt === -1 || openAt === -1) {
    throw new Error(
      `trade_cal did not return cal_date and is_open (got: ${table.fields.join(', ') || 'no fields'})`,
    );
  }

  const tradingDays = new Set<string>();
  const nonTradingDays = new Set<string>();

  for (const row of table.rows) {
    const raw = String(row[dateAt] ?? '');
    if (raw.length !== 8) continue;
    const formatted = `${raw.slice(0, 4)}-${raw.slice(4, 6)}-${raw.slice(6, 8)}`;
    const flag = row[openAt];
    if (flag === 1 || flag === '1') {
      tradingDays.add(formatted);
    } else {
      nonTradingDays.add(formatted);
    }
  }

  const entry: YearCalendar = { tradingDays, nonTradingDays };
  cache.set(year, entry);
  return entry;
}

/**
 * Is the exchange open on this date?
 *
 * A date the calendar has no record of raises an error rather than returning `false`.
 * Returning `false` would be indistinguishable from a holiday, so a market trigger whose
 * calendar failed to load would never fire and would report nothing wrong.
 */
export async function isTradingDay(date: string): Promise<boolean> {
  const cal = await ensureYear(yearOf(date));

  if (cal.tradingDays.has(date)) return true;
  if (cal.nonTradingDays.has(date)) return false;

  throw new Error(
    `the trading calendar has no record of ${date}; it covers ${describeCoverage(cal)}`,
  );
}

/** The first trading day strictly after `after`. */
export async function nextTradingDay(after: string): Promise<string> {
  let cursor = after;

  for (let i = 0; i < MAX_LOOKAHEAD_DAYS; i++) {
    cursor = addOneDay(cursor);
    const cal = await ensureYear(yearOf(cursor));
    if (cal.tradingDays.has(cursor)) return cursor;
  }

  throw new Error(
    `no trading day found within ${MAX_LOOKAHEAD_DAYS} days after ${after}`,
  );
}

/** When the exchange opens and closes on this date, or null when it is shut. */
export async function marketTimes(
  date: string,
): Promise<{ open: string; close: string } | null> {
  const open = await isTradingDay(date);
  if (!open) return null;
  return { open: MARKET_OPEN, close: MARKET_CLOSE };
}

/**
 * Add one calendar day to a `YYYY-MM-DD` date.
 *
 * Done in UTC so the result never depends on the machine's timezone. The previous version
 * used a local-time `Date`, which on a judge's machine in another timezone is a different
 * calculation from the one we tested.
 */
function addOneDay(date: string): string {
  const [y, m, d] = date.split('-').map(Number);
  if (!y || !m || !d) {
    throw new Error(`not a YYYY-MM-DD date: ${date}`);
  }
  const t = Date.UTC(y, m - 1, d) + 86_400_000;
  return new Date(t).toISOString().slice(0, 10);
}

function describeCoverage(cal: YearCalendar): string {
  const all = [...cal.tradingDays, ...cal.nonTradingDays].sort();
  const first = all[0];
  const last = all[all.length - 1];
  return first && last ? `${first} to ${last}` : 'nothing';
}

export function getCacheStats() {
  let tradingDays = 0;
  for (const entry of cache.values()) tradingDays += entry.tradingDays.size;
  return {
    hasCache: cache.size > 0,
    years: [...cache.keys()].sort(),
    tradingDays,
    lastFetchMs: lastFetchDurationMs,
  };
}

export function clearCalendarCache(): void {
  cache.clear();
  lastFetchDurationMs = 0;
}

/**
 * Load a year's calendar from already-fetched rows, without calling Tushare.
 *
 * This is what lets the calendar be tested offline against invented rows, and what lets
 * a caller prime it from a cached copy at startup.
 */
export function primeCalendar(
  year: string,
  rows: { date: string; open: boolean }[],
): void {
  const tradingDays = new Set<string>();
  const nonTradingDays = new Set<string>();
  for (const r of rows) {
    (r.open ? tradingDays : nonTradingDays).add(r.date);
  }
  cache.set(year, { tradingDays, nonTradingDays });
}
