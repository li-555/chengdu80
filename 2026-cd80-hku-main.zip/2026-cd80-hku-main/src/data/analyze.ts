// src/data/analyze.ts
// Basic table analysis: an overview, per-column numeric statistics and null/outlier
// detection. Pure and independent of any data source.

import type { FieldSpec } from './types.ts';

export type NumericStats = {
  count: number;
  min: number;
  max: number;
  mean: number;
  sum: number;
};

export type ColumnAnalysis = {
  name: string;
  type: FieldSpec['type'];
  total: number;
  nulls: number;
  outliers?: number;
  stats?: NumericStats;
};

export type TableAnalysis = {
  rowCount: number;
  columnCount: number;
  columns: ColumnAnalysis[];
};

function toNumber(value: unknown): number | null {
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  if (typeof value !== 'string' || value.trim() === '') return null;
  const number = Number(value);
  return Number.isFinite(number) ? number : null;
}

function numericStats(values: unknown[]): NumericStats | undefined {
  const numbers: number[] = [];
  for (const value of values) {
    const number = toNumber(value);
    if (number !== null) numbers.push(number);
  }
  if (numbers.length === 0) return undefined;
  const sum = numbers.reduce((a, b) => a + b, 0);
  const mean = sum / numbers.length;
  return {
    count: numbers.length,
    min: Math.min(...numbers),
    max: Math.max(...numbers),
    mean,
    sum,
  };
}

function outlierCount(values: unknown[], stats: NumericStats): number {
  let squaredSum = 0;
  for (const value of values) {
    const number = toNumber(value);
    if (number !== null) squaredSum += (number - stats.mean) ** 2;
  }
  const deviation = Math.sqrt(squaredSum / stats.count);
  if (deviation === 0) return 0;
  let outliers = 0;
  for (const value of values) {
    const number = toNumber(value);
    if (number !== null && Math.abs(number - stats.mean) > 3 * deviation) outliers += 1;
  }
  return outliers;
}

export function analyzeTable(fields: FieldSpec[], rows: string[][]): TableAnalysis {
  const columns: ColumnAnalysis[] = fields.map((field, i) => {
    const values = rows.map((row) => row[i] ?? '');
    const nulls = values.filter((v) => v === '' || v === null || v === undefined).length;

    if (field.type === 'number') {
      const stats = numericStats(values);
      if (!stats) {
        return { name: field.name, type: field.type, total: values.length, nulls };
      }
      return {
        name: field.name,
        type: field.type,
        total: values.length,
        nulls,
        outliers: outlierCount(values, stats),
        stats,
      };
    }

    return { name: field.name, type: field.type, total: values.length, nulls };
  });

  return { rowCount: rows.length, columnCount: fields.length, columns };
}
