import { registerUpload as parseAndRegister } from './file-upload.ts';
import { addUpload } from './catalogue.ts';
import type { Dataset } from './types.ts';

export async function registerUpload(filePath: string, name: string): Promise<Dataset> {
  const { dataset, rows } = await parseAndRegister(filePath, name);
  addUpload(dataset, rows);
  return dataset;
}