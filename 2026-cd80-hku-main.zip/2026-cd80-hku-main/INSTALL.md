# Installing and running Blocks

This guide takes a new computer from a fresh clone to a running platform in about five minutes.
It is written for someone who has never seen the project.

## 1. What you need

| Requirement | Notes |
|---|---|
| **macOS** with a terminal | Supported and tested on macOS (the venue Mac mini setup) with Node.js 24 and 25. Linux should work the same way but has not been tested. |
| **Node.js 24.11 or newer**, with npm | Check with `node -v`. The venue Mac mini already has Node.js 24 LTS. |
| A modern browser | Chrome, Edge, Safari or Firefox. |
| Network access to the npm registry | Only the first time, to install dependencies. |
| *Optional:* a Gitee AI key | Needed only to **build apps from chat**. Everything else works without it. |
| *Optional:* a Tushare token | Needed only to run apps on live market data. Uploaded files need no token. Flagships do not install invented inputs. |

Nothing else is required: no database server, no Python, no Docker. The database is a single
SQLite file that Blocks creates by itself.

## 2. Get the code

```sh
git clone http://10.8.23.23:8929/2026-cd80/2026-cd80-hku.git
cd 2026-cd80-hku
```

## 3. Add your keys (optional)

Create a file named `.env` in the project folder. `.env.example` shows every setting by name;
copy it and fill in only what you have:

```sh
cp .env.example .env
```

| Setting | What it is for | Default |
|---|---|---|
| `GITEE_AI_API_KEY` | The AI model that builds apps from chat | none: chat reports that AI is not set up |
| `CD80_LLM_BASE_URL` | The model service address | `https://ai.gitee.com/v1` |
| `CD80_LLM_MODEL` | The model name | `GLM-5.3` |
| `TUSHARE_TOKEN` | Live Chinese market data from Tushare | none: live datasets are unavailable |
| `CD80_PORT` | The web port | `3000` |
| `BLOCKS_DB_PATH` | Where the database file is kept | `data/blocks.sqlite` |

`.env` is ignored by Git and is never uploaded. Never put a key in chat, in an app or in a
committed file. Restart the server after you edit `.env`.

## 4. Start

```sh
npm run go
```

The first run installs the dependencies from `package-lock.json` and then starts the server.
Later runs start immediately. When you see

```
Blocks is running at http://127.0.0.1:3000
```

open **http://127.0.0.1:3000** in your browser. Keep the terminal open while you use Blocks;
press **Ctrl+C** to stop it.

After the first install you can also start with `npm start`. It never installs anything.

## 5. Check that it works

1. Open `http://127.0.0.1:3000/health`. It shows `{"status":"ok", ...}`.
2. Open the home page and choose **Start building**. The workspace opens.
3. Open **Flagship applications**, pick one, and choose **Connect my data**. The app is added to
   **My Apps** with Tushare catalogue hints. Configure `TUSHARE_TOKEN` on the server and ensure the
   account has access to the requested APIs. Connect your own required business records before
   choosing **Run application**. Without them the app reports missing data; it does not create
   sample holdings, clients, approvals or documents.
4. *(With a Gitee AI key)* open **Create app** and type, for example,
   "Show me the 10 biggest daily price moves in my uploaded file". A build takes one to four minutes;
   progress lines appear while it works.

To check the keys without starting the server:

```sh
npm run check
```

It checks dependencies and configuration, then makes one small request to each configured
service (one Tushare trading-calendar request and one short model request). It prints no key and
no data.

## 6. Where things are kept

| What | Where |
|---|---|
| Apps, run history, settings, schedules | `data/blocks.sqlite` |
| Uploaded files (parsed) | `data/uploads/` |
| Keys | `.env` (yours only) |

Delete the `data/` folder to start again with an empty platform.

## 7. Common problems

| Problem | Fix |
|---|---|
| `requires Node.js 24.11.0 or later` | Install Node.js 24 LTS or newer. If several versions are installed, run `BLOCKS_NODE_PATH=/path/to/node npm run go`. |
| Port 3000 is already in use | `CD80_PORT=3001 npm run go`, then open `http://127.0.0.1:3001`. |
| Chat says the AI is not set up | Add `GITEE_AI_API_KEY` to `.env` and restart. |
| A build takes several minutes | Normal when the model service is busy. Progress lines keep updating; the platform stops a build after 10 minutes and keeps the draft. |
| An app asks you to **Connect your data** | The app needs a dataset or column it cannot find. Choose a dataset and match the columns on that screen, then **Save and run**. |
| Dependency installation fails | Check that npm can reach its registry, then run `npm run go` again. |
| My Apps is empty in another browser | Each browser has its own local library. Use the same browser, or export the app and import it there. |

## 8. For developers

```sh
npm install          # all dependencies, including development tools
npm run verify       # dependency guard, type checks and the full test suite
npm run spec:build   # regenerate spec/ and skill/ after changing the app format or catalogue
npm run build:web    # rebuild the browser assets after changing web/src
```

How to build apps, the app format and every interface are described in [USER_GUIDE.md](USER_GUIDE.md).
Detailed engineering notes and manual acceptance records are in
[docs/DEVELOPMENT-NOTES.md](docs/DEVELOPMENT-NOTES.md).
