// Probe: does GLM-5.3 support tool calling through the Gitee OpenAI-compatible endpoint?
// Reads credentials from the environment only. Prints no secret value.
// Run:  set -a; . ~/.config/cd80/env; set +a; node probe/glm-toolcall.mjs

import { loadEnv } from './env.mjs';
const envInfo = loadEnv();
console.log(envInfo.loaded ? `env    read ${envInfo.file} (${envInfo.count} values)` : `env    no .env file at ${envInfo.file}`);

const KEY   = process.env.GITEE_AI_API_KEY;
const BASE  = process.env.CD80_LLM_BASE_URL || 'https://ai.gitee.com/v1';
const MODEL = process.env.CD80_LLM_MODEL    || 'GLM-5.3';

if (!KEY) {
  console.error('\nFAIL: GITEE_AI_API_KEY is not set.');
  console.error('Open .env in this folder and put your key after GITEE_AI_API_KEY=');
  process.exit(2);
}
console.log(`base   ${BASE}`);
console.log(`model  ${MODEL}`);
console.log(`key    set (${KEY.length} chars)`);
console.log('');

const TOOLS = [{
  type: 'function',
  function: {
    name: 'emit_application',
    description: 'Return a Blocks application document.',
    parameters: {
      type: 'object',
      properties: {
        name:  { type: 'string', description: 'short app name' },
        steps: { type: 'array', items: { type: 'object', properties: {
                   id: { type: 'string' }, op: { type: 'string', enum: ['filter','aggregate','sort_limit'] }
                 }, required: ['id','op'], additionalProperties: false } },
        row_limit: { type: 'integer' }
      },
      required: ['name','steps','row_limit'],
      additionalProperties: false
    }
  }
}];

async function post(body, label) {
  const t0 = Date.now();
  let res, text;
  try {
    res = await fetch(`${BASE}/chat/completions`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${KEY}` },
      body: JSON.stringify(body)
    });
    text = await res.text();
  } catch (e) {
    return { label, ok: false, err: `network: ${e.message}`, ms: Date.now() - t0 };
  }
  const ms = Date.now() - t0;
  if (!res.ok) return { label, ok: false, err: `HTTP ${res.status}: ${text.slice(0, 400)}`, ms };
  let json; try { json = JSON.parse(text); } catch { return { label, ok: false, err: `non-JSON body: ${text.slice(0,200)}`, ms }; }
  return { label, ok: true, json, ms };
}

const line = (s) => console.log(s);
const results = {};

// ---- TEST 1: does it emit a tool call at all? ----
line('TEST 1  tool call, tool_choice auto');
let r = await post({
  model: MODEL,
  messages: [
    { role: 'system', content: 'You build data applications. Use the emit_application tool to answer. Do not reply in prose.' },
    { role: 'user', content: 'Build an app that lists the 10 biggest daily price movers.' }
  ],
  tools: TOOLS, tool_choice: 'auto', temperature: 0
}, 'auto');

if (!r.ok) { line(`  FAIL (${r.ms} ms) ${r.err}`); results.t1 = false; }
else {
  const msg = r.json.choices?.[0]?.message ?? {};
  const tc  = msg.tool_calls;
  if (!tc || !tc.length) {
    line(`  NO TOOL CALL (${r.ms} ms). finish_reason=${r.json.choices?.[0]?.finish_reason}`);
    line(`  content: ${String(msg.content ?? '').slice(0, 300)}`);
    results.t1 = false;
  } else {
    line(`  TOOL CALL OK (${r.ms} ms)  name=${tc[0].function?.name}  id=${tc[0].id}`);
    let args = null;
    try { args = JSON.parse(tc[0].function.arguments); line('  arguments parse as JSON: YES'); }
    catch (e) { line(`  arguments parse as JSON: NO -> ${e.message}`); line(`  raw: ${String(tc[0].function.arguments).slice(0,300)}`); }
    if (args) {
      const keys = Object.keys(args);
      line(`  keys: ${keys.join(', ')}`);
      line(`  schema respected: name=${typeof args.name} steps=${Array.isArray(args.steps)?`array(${args.steps.length})`:typeof args.steps} row_limit=${typeof args.row_limit}`);
      const badOp = (args.steps||[]).find(s => !['filter','aggregate','sort_limit'].includes(s.op));
      line(`  enum respected: ${badOp ? 'NO -> ' + JSON.stringify(badOp) : 'YES'}`);
      results.args = args;
    }
    results.t1 = true;
    results.firstMsg = msg;
  }
  const u = r.json.usage; if (u) line(`  usage: prompt=${u.prompt_tokens} completion=${u.completion_tokens}`);
}
line('');

// ---- TEST 2: multi-turn, feed the tool result back ----
if (results.t1) {
  line('TEST 2  multi-turn, tool result fed back');
  const tc = results.firstMsg.tool_calls[0];
  r = await post({
    model: MODEL,
    messages: [
      { role: 'system', content: 'You build data applications. Use the emit_application tool to answer.' },
      { role: 'user', content: 'Build an app that lists the 10 biggest daily price movers.' },
      results.firstMsg,
      { role: 'tool', tool_call_id: tc.id, content: JSON.stringify({ status: 'invalid', errors: [{ code: 'E_LIMIT_ROWS', message: 'row_limit must be 5 or less' }] }) },
      { role: 'user', content: 'Fix it and emit it again.' }
    ],
    tools: TOOLS, tool_choice: 'auto', temperature: 0
  }, 'multiturn');
  if (!r.ok) { line(`  FAIL (${r.ms} ms) ${r.err}`); results.t2 = false; }
  else {
    const m = r.json.choices?.[0]?.message ?? {};
    if (m.tool_calls?.length) {
      let a = null; try { a = JSON.parse(m.tool_calls[0].function.arguments); } catch {}
      line(`  SECOND TOOL CALL OK (${r.ms} ms)  row_limit now = ${a?.row_limit}`);
      line(`  acted on the error: ${a && a.row_limit <= 5 ? 'YES' : 'NO'}`);
      results.t2 = true;
    } else {
      line(`  NO SECOND TOOL CALL (${r.ms} ms). finish_reason=${r.json.choices?.[0]?.finish_reason}`);
      line(`  content: ${String(m.content ?? '').slice(0,300)}`);
      results.t2 = false;
    }
  }
  line('');
}

// ---- TEST 3: forced tool choice ----
line('TEST 3  tool_choice forced to the function  [KNOWN BROKEN on this endpoint]');
line('        Verified 2026-10-13: 6 of 6 attempts returned finish_reason "abort" and leaked');
line('        a raw "<tool_call>[" fragment. Do NOT depend on forced tool_choice.');
line('        Use tool_choice "auto" with a system prompt that names the tool.');
r = await post({
  model: MODEL,
  messages: [{ role: 'user', content: 'Something about share prices.' }],
  tools: TOOLS,
  tool_choice: { type: 'function', function: { name: 'emit_application' } },
  temperature: 0
}, 'forced');
if (!r.ok) line(`  FAIL (${r.ms} ms) ${r.err}`);
else {
  const m = r.json.choices?.[0]?.message ?? {};
  line(`  ${m.tool_calls?.length ? `FORCED CALL OK (${r.ms} ms)` : `NO CALL (${r.ms} ms) finish_reason=${r.json.choices?.[0]?.finish_reason}`}`);
  results.t3 = !!m.tool_calls?.length;
}
line('');

// ---- TEST 4: fallback path, JSON object response format ----
line('TEST 4  fallback: response_format json_object');
r = await post({
  model: MODEL,
  messages: [
    { role: 'system', content: 'Reply with one JSON object only, no prose, no code fence. Keys: name (string), row_limit (integer).' },
    { role: 'user', content: 'An app listing the biggest daily movers.' }
  ],
  response_format: { type: 'json_object' }, temperature: 0
}, 'json_object');
if (!r.ok) line(`  FAIL (${r.ms} ms) ${r.err}`);
else {
  const c = r.json.choices?.[0]?.message?.content ?? '';
  let okJson = true; try { JSON.parse(c); } catch { okJson = false; }
  line(`  ${okJson ? 'OK' : 'NOT PARSEABLE'} (${r.ms} ms)  body: ${String(c).slice(0,200)}`);
  results.t4 = okJson;
}
line('');

// ---- TEST 5: fallback: plain prose asked for JSON, measures how dirty the output is ----
line('TEST 5  fallback: plain prompt, no response_format');
r = await post({
  model: MODEL,
  messages: [{ role: 'user', content: 'Reply with ONLY a JSON object, no code fence: {"name": "...", "row_limit": 10}' }],
  temperature: 0
}, 'plain');
if (!r.ok) line(`  FAIL (${r.ms} ms) ${r.err}`);
else {
  const c = String(r.json.choices?.[0]?.message?.content ?? '');
  line(`  fenced: ${c.includes('```') ? 'YES (must strip)' : 'no'}`);
  let okJson = true; try { JSON.parse(c); } catch { okJson = false; }
  line(`  parses raw: ${okJson ? 'YES' : 'NO'}  (${r.ms} ms)`);
  line(`  body: ${c.slice(0,200)}`);
}
line('');

line('==== VERDICT ====');
line(`tool calling works:        ${results.t1 ? 'YES' : 'NO'}`);
line(`multi-turn tool loop:      ${results.t2 ? 'YES' : results.t1 ? 'NO' : 'not reached'}`);
line(`forced tool_choice:        ${results.t3 ? 'YES' : 'NO (expected: known broken, do not use)'}`);
line(`json_object fallback:      ${results.t4 ? 'YES' : 'NO'}`);
line('');
line(results.t1 && results.t2
  ? 'DECISION: keep the agent design. Tool calling + repair loop are supported.'
  : 'DECISION: fall back. Use a single-shot prompt with JSON parsing and our own repair loop.');
