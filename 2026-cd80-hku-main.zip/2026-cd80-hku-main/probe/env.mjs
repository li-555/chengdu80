// Self-contained .env reader for the probes only.
// The real platform reads configuration in exactly one file (spec section 21); this is not it.
import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

export function loadEnv(file = resolve(process.cwd(), '.env')) {
  if (!existsSync(file)) return { loaded: false, file, count: 0 };
  let count = 0;
  for (const raw of readFileSync(file, 'utf8').split('\n')) {
    const line = raw.trim();
    if (!line || line.startsWith('#')) continue;
    const eq = line.indexOf('=');
    if (eq < 1) continue;
    const key = line.slice(0, eq).trim().replace(/^export\s+/, '');
    let val = line.slice(eq + 1).trim();
    if ((val.startsWith('"') && val.endsWith('"')) || (val.startsWith("'") && val.endsWith("'"))) {
      val = val.slice(1, -1);
    }
    if (val === '') continue;                 // empty means not set
    if (process.env[key] === undefined) { process.env[key] = val; count++; }
  }
  return { loaded: true, file, count };
}
