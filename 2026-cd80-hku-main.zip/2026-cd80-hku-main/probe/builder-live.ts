// Probe: run the application builder once against the configured model.
// Reads the key from .env; prints no secret. Saves nothing to the database: the built
// application is written to the file given as the second argument, for inspection.
//
// Run:  node probe/builder-live.ts "show me today's biggest movers" /tmp/app.json
//
// If the builder asks a question, the probe answers "Use sensible defaults and build it."
// once, which is what a person in a hurry would say.

import { writeFileSync } from 'node:fs';
import { loadEnv } from './env.mjs';
import { newConversation, runTurn } from '../src/generate/agent.ts';
import { configuredModel, configuredModelName } from '../src/platform/model.ts';
import { listAllDatasets } from '../src/data/catalogue.ts';
import { readSkillFamily } from '../src/skill/build.ts';
import type { AppDocument } from '../src/app-schema/index.ts';

loadEnv();
const request = process.argv[2] ?? "Show me which stocks on my list moved the most today.";
const outFile = process.argv[3];

let built: AppDocument | undefined;
const conv = newConversation('probe');
const t0 = Date.now();
// Time every model call, so slow steps are visible.
const inner = configuredModel() as unknown as { doGenerate: (o: unknown) => Promise<{ usage?: { inputTokens?: { total?: number }; outputTokens?: { total?: number } }; content: { type: string; toolName?: string }[] }> };
const timed = Object.create(inner);
let n = 0;
timed.doGenerate = async (o: unknown) => {
  const s = Date.now();
  const r = await inner.doGenerate.call(inner, o);
  const tools = r.content.filter((c) => c.type === 'tool-call').map((c) => c.toolName).join(',') || 'text';
  console.log(`  call ${++n}: ${((Date.now() - s) / 1000).toFixed(1)} s, in ${r.usage?.inputTokens?.total} tok, out ${r.usage?.outputTokens?.total} tok -> ${tools}`);
  return r;
};
const opts = {
  model: timed,
  deps: {
    listDatasets: listAllDatasets,
    readFamily: readSkillFamily,
    install: async (doc: AppDocument) => { built = doc; return { id: 'probe-app' }; },
    modelName: configuredModelName(),
  },
  today: new Date().toISOString().slice(0, 10),
  ...(process.env.THINK === 'off' ? { providerOptions: { configured: { enable_thinking: false } } } : {}),
  onEvent: (e: { line: string }) => console.log(`  ${((Date.now() - t0) / 1000).toFixed(1).padStart(5)}s  ${e.line}`),
};

console.log(`thinking ${process.env.THINK === 'off' ? 'off' : 'default'}`);
console.log(`model  ${configuredModelName()}\nask    ${request}\n`);
let result = await runTurn(conv, request, opts);
if (result.kind === 'question') {
  console.log(`\nQUESTION  ${result.questions.join(' / ')}\nANSWER    Use sensible defaults and build it.\n`);
  result = await runTurn(conv, 'Use sensible defaults and build it.', opts);
}

const calls_unused = conv.messages.flatMap((m) => Array.isArray(m.content) ? m.content : [])
  .filter((p): p is { type: 'tool-call'; toolName: string } => (p as { type: string }).type === 'tool-call')
  .map((p) => p.toolName);
console.log(`\nresult ${result.kind}${result.kind === 'failed' ? ` (${result.reason}): ${result.summary}` : ''}`);
console.log(`time   ${((Date.now() - t0) / 1000).toFixed(1)} s, submissions ${conv.session.submissions}, questions ${conv.session.questionsAsked}`);
if (result.kind === 'built') console.log(`app    ${result.name}: ${result.description}`);
if (result.kind === 'failed' && result.errors) console.log(JSON.stringify(result.errors, null, 2).slice(0, 3000));
if (outFile) writeFileSync(outFile, JSON.stringify(built ?? conv.session.lastDraft ?? null, null, 2) + '\n');
