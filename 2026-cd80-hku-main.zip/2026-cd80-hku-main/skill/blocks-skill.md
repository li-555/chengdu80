# Blocks application skill

Read only the sections you need for the current application.

## Contents

- SKILL.md
- application.schema.json
- examples/ex-01-daily-movers.json
- references/blocks.md
- references/data.md
- references/errors.md
- references/ops-finance.md
- references/ops-shaping.md
- references/ops-statistics.md
- references/ops-time-series.md
- references/screen-charts.md
- references/screen-controls.md
- references/screen-display.md
- references/screen-layout.md
- skill.json

## SKILL.md

---
name: building-blocks-applications
description: Builds financial applications for the Blocks platform. Use when someone asks for a financial tool, screen, report, alert, monitor or dashboard that should run on Blocks, for example "find today's biggest movers", "watch my bonds for redemption risk" or "summarise overnight announcements for my watchlist". Produces one JSON document that Blocks validates and runs.
---

# Building Blocks applications

## 1. What you produce

A Blocks application is **one JSON document**, not a program. It has six sections:

| Section | Holds |
|---|---|
| `meta` | name, a plain-language description, `spec_version`, an icon |
| `params` | the settings a person can change without rebuilding (a watchlist, a threshold) |
| `data` | what data the application needs: fields and filters only, **never data itself** |
| `compute` | calculation steps, each producing a named result |
| `triggers` | when it runs: by hand, on a schedule, around the market open or close, or as an alert |
| `ui` | what the screen shows, built from a fixed set of screen elements |

The platform reads the document and carries it out. Nothing is compiled or deployed. Set `meta.spec_version` to exactly `"1.0"`.

## 2. How to work

1. Decide what data the request needs. Read `references/data.md` for the available datasets and their exact field names.
2. Pick the calculation steps. Read the operation family files listed in section 9, **only the families you need**.
3. Pick the screen elements. Read the screen family files you need.
4. Write the whole document.
5. Check it with the validator (section 7). Fix exactly what each error names, and check again. Repeat until it passes.

Read a reference file instead of guessing. A guessed parameter name costs a whole check-and-fix round.

## 3. Rules

These rules are checked by the validator. Breaking one makes the document invalid.

- **Use only names that exist.** Every operation, screen element and property is listed in the reference files. There is nothing else. Do not invent one.
- **Data requirements describe data; they never contain it.** A requirement lists the fields it needs with their types. It does not name a dataset: `datasetHint` is only a suggestion, and the person connects the real data when the application is imported.
- **Name fields as the dataset names them** (copy them from `references/data.md`) and give each a `semantic` tag (for example `security_code`, `trade_date`). Matching names connect automatically. A field with a name of your own (as in the example in section 6) still works, but the person must match it by hand when connecting data, so prefer the dataset's names.
- **Filters name settings, never values.** A list of companies is a `params` entry with `"list": true`, and the filter points at it with `"param"`. A literal value in a filter cannot be written: the schema has no place for it.
- **Every step reads results that exist.** A step's `input` is a data requirement `key` or an earlier step `id`. There are no cycles.
- **Every screen element reads a step that exists**, through `from`. Every control names a declared setting through `param`.
- **Prefer, in this order:** a named operation → a formula (`derive`, `filter`) → a SQL step → a custom-code step. A named operation is checked, explained to the person and shown step by step. A SQL or code step that repeats a named operation produces a warning.
- **Keep it small.** Three to eight steps and four to ten screen elements make a good application. A bigger one is not a better one.
- **Include a manual trigger**, so the person can always run it by hand.
- **When the data does not exist, say so.** Do not invent a dataset or a field to make the request fit.

## 4. Writing for the person

The person using the application is not a programmer. `meta.description`, setting labels, element titles and empty-table hints are read by them.

- Short sentences. One idea per sentence. Ordinary words.
- Do not use these words in anything the person reads: `schema`, `JSON`, `document`, `field`, `parameter`, `dataset`, `query`, `SQL`, `validate`, `deploy`, `endpoint`, `API`, `operation`, `compute`, `trigger`, `component`, `expose`, `reference`, `cron`, `index`, `dataframe`, `pipeline`.
  Say "spreadsheet" not "dataset", "column" not "field", "setting" not "parameter", "check" not "validate".
- Explain a finance term the first time it appears, in the same sentence.
- `meta.description` is two or three sentences: what the application does, where its numbers come from, and when it runs.

## 5. The document skeleton

The comments are explanations, not part of the document.

```jsonc
{
  "meta": {"name":"Harbor Prices","description":"Review invented daily price changes.","spec_version":"1.0"}, // object: Name and describe the application and declare its specification version.
  "params": [{"key":"harbor_limit","label":"Rows to show","type":"number","default":10,"min":1,"max":50}], // array of object: Declare settings that controls and calculations can read when the application runs.
  "data": [{"key":"harbor_prices","grain":"daily","fields":[{"name":"harbor_price","type":"number","required":true}]}], // array of object: Declare required fields and optional windows or parameter filters without embedding data rows.
  "compute": [{"id":"harbor_positive","kind":"operation","op":"filter","input":"harbor_prices","params":{"where":"harbor_price > 0"}}], // array of object or object or object or object or object or object or object or object or object or object or object or object or object or object or object or object or object or object or object or object or object: Declare calculation steps whose ids name results available to later steps and the screen.
  "triggers": [{"kind":"manual"}], // array of object or object or object or object: Declare when the application runs, by hand, by schedule or around trading hours.
  "ui": {"root":"harbor_page","elements":{"harbor_page":{"type":"Section","children":["harbor_intro"]},"harbor_intro":{"type":"Text","text":"Invented price overview."}}} // object: Declare a flat map of screen elements and the root section whose children form the screen.
}
```

## 6. A complete example

The meta section names “Daily Movers”: Every trading day, show the companies on your list whose price moved the most.

The params section offers companies to watch, count a move as unusual above, how many to show.

The data section asks for daily closing prices for the companies on the list.

The compute section runs the calculations titled Work out each day's move, Keep only the unusual moves, Biggest movers first and counts the unusual moves.

The triggers section allows running by hand and thirty minutes after market close.

The ui section shows settings, the count of unusual moves and the Biggest movers table.

```json
{
  "$schema": "/api/spec/schema",
  "meta": {
    "name": "Daily Movers",
    "description": "Every trading day, show the companies on your list whose price moved the most.",
    "spec_version": "1.0",
    "icon": "chart-line",
    "provenance": { "created_by": "platform" }
  },
  "params": [
    { "key": "watchlist", "label": "Companies to watch", "type": "text", "list": true, "default": ["600000.SH", "000001.SZ"] },
    { "key": "move_threshold", "label": "Count a move as unusual above", "type": "number", "default": 3, "min": 0, "max": 50, "step": 0.5, "unit": "%" },
    { "key": "top_n", "label": "How many to show", "type": "number", "default": 10, "min": 1, "max": 50, "step": 1 }
  ],
  "data": [
    {
      "key": "prices",
      "purpose": "daily closing prices for the companies on the list",
      "grain": "daily",
      "datasetHint": "tushare:daily",
      "fields": [
        { "name": "code", "type": "text", "required": true, "semantic": "security_code" },
        { "name": "d", "type": "date", "required": true, "semantic": "trade_date" },
        { "name": "px", "type": "number", "required": true },
        { "name": "prev_px", "type": "number", "required": false }
      ],
      "window": { "field": "d", "lookbackDays": 30 },
      "filters": [{ "field": "code", "op": "in", "param": "watchlist" }]
    }
  ],
  "compute": [
    {
      "id": "with_change",
      "kind": "operation",
      "op": "derive",
      "input": "prices",
      "title": "Work out each day's move",
      "params": { "columns": { "pct_move": "(px - prev_px) / prev_px * 100" } }
    },
    {
      "id": "unusual",
      "kind": "operation",
      "op": "filter",
      "input": "with_change",
      "title": "Keep only the unusual moves",
      "key": true,
      "params": { "where": "abs(pct_move) >= $params.move_threshold" }
    },
    {
      "id": "movers",
      "kind": "operation",
      "op": "sort_limit",
      "input": "unusual",
      "title": "Biggest movers first",
      "key": true,
      "params": { "by": [{ "col": "pct_move", "dir": "desc" }], "limit": { "param": "top_n" } }
    },
    {
      "id": "mover_count",
      "kind": "operation",
      "op": "aggregate",
      "input": "unusual",
      "params": { "by": [], "metrics": [{ "fn": "count", "as": "n" }] }
    }
  ],
  "triggers": [
    { "kind": "manual" },
    { "kind": "market", "at": "close", "offsetMinutes": 30 }
  ],
  "ui": {
    "root": "page",
    "elements": {
      "page": { "type": "Section", "columns": 1, "children": ["controls", "headline", "table"] },
      "controls": { "type": "Section", "title": "Settings", "columns": 3, "children": ["w", "t", "n", "run"] },
      "w": { "type": "TextInput", "param": "watchlist", "label": "Companies", "list": true },
      "t": { "type": "NumberInput", "param": "move_threshold", "label": "Unusual above (%)" },
      "n": { "type": "NumberInput", "param": "top_n", "label": "How many to show" },
      "run": { "type": "RunButton", "label": "Run" },
      "headline": { "type": "Metric", "label": "Companies with an unusual move", "from": "mover_count", "value": "n", "format": "integer" },
      "table": {
        "type": "Table",
        "title": "Biggest movers",
        "from": "movers",
        "columns": [
          { "col": "code", "label": "Company", "format": "text" },
          { "col": "d", "label": "Date", "format": "date" },
          { "col": "px", "label": "Close", "format": "money" },
          { "col": "pct_move", "label": "Move", "format": "percent" }
        ],
        "emptyHint": "No company on your list moved more than the threshold."
      }
    }
  }
}
```

## 7. Checking your work

The validator is the authority. Run it on your document:

```
npm run validate -- app.json
```

or send the document to `POST /api/validate` on a running Blocks server. It answers with a report: `valid`, and a list of `errors` and `warnings`. Each error has a `pointer` (where in the document), a `code`, a `message`, and a `hint` saying how to fix it. **Follow the hint.**

The validator checks in stages: first the shape of the document, then the names it refers to, then formulas and limits. It stops at the first stage that fails. So fixing every reported error can reveal new ones from the next stage. Expect more than one round; that is normal.

`application.schema.json` (JSON Schema, draft 2020-12) checks structure and types only. The validator also checks references, formulas, SQL and limits. A document that passes the schema can still fail the validator.

### A repair, start to finish

Three broken fragments:

```json
{
  "Table": {
    "columns": [
      {
        "col": "code",
        "format": "text",
        "label": "Company"
      },
      {
        "col": "d",
        "format": "date",
        "label": "Date"
      },
      {
        "col": "px",
        "format": "money",
        "label": "Close"
      },
      {
        "col": "pct_move",
        "format": "percent",
        "label": "Move"
      }
    ],
    "emptyHint": "No company on your list moved more than the threshold.",
    "from": "moverz",
    "title": "Biggest movers",
    "type": "Table"
  },
  "filter": {
    "id": "unusual",
    "input": "with_change",
    "key": true,
    "kind": "operation",
    "op": "filter",
    "params": {
      "where": "abs(pct_move) >= $params.move_treshold"
    },
    "title": "Keep only the unusual moves"
  },
  "step": {
    "id": "movers",
    "input": "unusual",
    "key": true,
    "kind": "operation",
    "op": "top_n",
    "params": {
      "by": [
        {
          "col": "pct_move",
          "dir": "desc"
        }
      ],
      "limit": {
        "param": "top_n"
      }
    },
    "title": "Biggest movers first"
  }
}
```


Actual errors from the first check:

```json
[
  {
    "code": "E_SCHEMA_ENUM",
    "hint": "Use one of: filter, derive, join, aggregate, sort_limit, window, lag_change, rank, zscore, resample, and 7 more.",
    "message": "A step of kind \"operation\" needs a supported operation name.",
    "pointer": "/compute/2/op"
  }
]
```


Fix 1: change `top_n` back to `sort_limit`.

Actual errors after fixing the step name:

```json
[
  {
    "code": "E_REF_UNKNOWN_PARAM",
    "hint": "Did you mean \"move_threshold\"?",
    "message": "The formula uses a setting called \"move_treshold\", which is not declared.",
    "pointer": "/compute/1/params/where"
  },
  {
    "code": "E_REF_UNKNOWN_RELATION",
    "hint": "Did you mean \"movers\"?",
    "message": "Element \"table\" shows a table called \"moverz\", which nothing produces.",
    "pointer": "/ui/elements/table/from"
  }
]
```


Fix 2: change `$params.move_treshold` back to `$params.move_threshold`.

Fix 3: change the Table's `from` from `moverz` back to `movers`.

Checked again: valid

## 8. Importing and running

Save the document as `app.json`. In Blocks, open **My Apps → Import an application** and choose the file. Blocks checks it, then asks the person to connect any data it needs (a dataset from the catalogue, or a spreadsheet they upload). A requirement waiting to be connected is normal, not an error. Then press **Run**.

## 9. Where to read more

Read only the file that answers your question. Each file starts with its own contents list.

| File | Read it when | Contains |
| --- | --- | --- |
| [references/ops-shaping.md](references/ops-shaping.md) | You need shaping calculations | aggregate, derive, filter, join, pivot, sort_limit |
| [references/ops-time-series.md](references/ops-time-series.md) | You need time series calculations | adjust_price, lag_change, resample, window |
| [references/ops-statistics.md](references/ops-statistics.md) | You need statistics calculations | correlate, describe, rank, regress, zscore |
| [references/ops-finance.md](references/ops-finance.md) | You need finance calculations | ai, factor, irr |
| [references/screen-display.md](references/screen-display.md) | You need display on screen | Callout, List, Metric, Table, Text |
| [references/screen-charts.md](references/screen-charts.md) | You need charts on screen | Chart |
| [references/screen-controls.md](references/screen-controls.md) | You need controls on screen | DateRangeInput, NumberInput, RunButton, SelectInput, TextInput |
| [references/screen-layout.md](references/screen-layout.md) | You need layout on screen | Section |
| [references/blocks.md](references/blocks.md) | You need application sections or special step kinds | meta, params, data, triggers, sql, expression, ai, code, alert, manual, market, schedule |
| [references/data.md](references/data.md) | You need available tables or spreadsheet uploads | tushare:adj_factor, tushare:balancesheet, tushare:cashflow, tushare:cb_basic, tushare:cb_daily, tushare:cb_price_chg, tushare:cb_redeem, tushare:cn_cpi, tushare:cn_lpr, tushare:daily, tushare:daily_basic, tushare:disclosure, tushare:dividend, tushare:etf_basic, tushare:etf_fund_daily, tushare:etf_index, tushare:etf_share, tushare:factor_list, tushare:fina_indicator, tushare:fund_basic, tushare:fund_nav, tushare:fund_portfolio, tushare:income, tushare:index_daily, tushare:index_member, tushare:limit_list_d, tushare:limit_list_d_down, tushare:margin, tushare:moneyflow_hsgt, tushare:new_share, tushare:pledge_stat, tushare:sge_daily, tushare:stk_managers, tushare:stock_basic, tushare:top10_holders, tushare:trade_cal, tushare:yc_cb |
| [references/errors.md](references/errors.md) | A check reports an error or warning | E_BAD_CRON, E_BAD_EXPRESSION, E_BAD_SQL, E_CYCLE, E_ELEMENT_CYCLE, E_INTERNAL, E_LIMIT_AI_STEPS, E_LIMIT_CODE_STEPS, E_LIMIT_ELEMENTS, E_LIMIT_NESTING, E_LIMIT_STEPS, E_NO_TRIGGER, E_PARSE_EMPTY, E_PARSE_JSON, E_PARSE_NOT_OBJECT, E_REF_DUPLICATE_NAME, E_REF_UNKNOWN_ELEMENT, E_REF_UNKNOWN_PARAM, E_REF_UNKNOWN_RELATION, E_REF_UNKNOWN_ROOT, E_SCHEMA_CUSTOM, E_SCHEMA_ENUM, E_SCHEMA_PATTERN, E_SCHEMA_RANGE, E_SCHEMA_REQUIRED, E_SCHEMA_SPEC_VERSION, E_SCHEMA_TYPE, E_SCHEMA_UNION, E_SCHEMA_UNKNOWN_KEY, E_SELF_REFERENCE, E_TOO_MANY_ERRORS, W_CODE_COULD_BE_OPERATION, W_DEAD_CONTROL, W_NO_MANUAL_TRIGGER, W_ORPHAN_ELEMENT, W_SHORT_HISTORY, W_SQL_COULD_BE_OPERATION, W_SURROUNDING_TEXT, W_UNKNOWN_ICON, W_UNUSED_DATA, W_UNUSED_PARAM, W_UNUSED_STEP |

## 10. The five things that most often go wrong

1. **A field name that is not in the dataset.** Copy names from `references/data.md`.
2. **A parameter name guessed instead of read.** Open the family file for that operation.
3. **A screen element reading a step that does not exist,** often after a step was renamed. Check every `from`.
4. **A control whose setting is never used.** The validator warns: the control would do nothing.
5. **A literal value where a setting is expected.** Put the value in `params` and point at it.

## application.schema.json

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "$schema": {
      "description": "Optional specification identifier in an exported document, ignored by document validation when omitted or present.",
      "maxLength": 200,
      "minLength": 1,
      "type": "string"
    },
    "compute": {
      "description": "Named calculation steps and their dependencies, allowing an empty array for no calculations.",
      "items": {
        "anyOf": [
          {
            "oneOf": [
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "filter",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "where": {
                        "description": "Boolean expression that keeps only input rows for which it is true.",
                        "maxLength": 2000,
                        "minLength": 1,
                        "type": "string"
                      }
                    },
                    "required": [
                      "where"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "derive",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "columns": {
                        "additionalProperties": {
                          "maxLength": 2000,
                          "minLength": 1,
                          "type": "string"
                        },
                        "description": "Map from each new output column name to the expression calculated for every input row.",
                        "propertyNames": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "type": "object"
                      }
                    },
                    "required": [
                      "columns"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "join",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "asof_on": {
                        "description": "Ordered matching columns as [column in the input table, column in the right table], required for asof and adding no ordered match when omitted for other join kinds.",
                        "items": false,
                        "maxItems": 2,
                        "minItems": 2,
                        "prefixItems": [
                          {
                            "maxLength": 128,
                            "minLength": 1,
                            "type": "string"
                          },
                          {
                            "maxLength": 128,
                            "minLength": 1,
                            "type": "string"
                          }
                        ],
                        "type": "array"
                      },
                      "direction": {
                        "description": "As-of matching direction, defaulting to backward for the latest right row at or before the input row, with forward choosing the earliest at or after it and nearest currently unsupported.",
                        "enum": [
                          "backward",
                          "forward",
                          "nearest"
                        ],
                        "type": "string"
                      },
                      "how": {
                        "description": "Join kind, retaining matching rows for inner or all input rows for left and asof.",
                        "enum": [
                          "inner",
                          "left",
                          "asof"
                        ],
                        "type": "string"
                      },
                      "on": {
                        "description": "Pairs of equality keys in the order [column in the input table, column in the right table].",
                        "items": {
                          "items": false,
                          "maxItems": 2,
                          "minItems": 2,
                          "prefixItems": [
                            {
                              "maxLength": 128,
                              "minLength": 1,
                              "type": "string"
                            },
                            {
                              "maxLength": 128,
                              "minLength": 1,
                              "type": "string"
                            }
                          ],
                          "type": "array"
                        },
                        "maxItems": 8,
                        "minItems": 1,
                        "type": "array"
                      },
                      "right": {
                        "description": "Data requirement key or step id of the second table, while the step input names the first table.",
                        "maxLength": 40,
                        "pattern": "^[a-z][a-z0-9_]{0,39}$",
                        "type": "string"
                      }
                    },
                    "required": [
                      "right",
                      "on",
                      "how"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "aggregate",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "by": {
                        "description": "Grouping columns, with an empty array producing one summary across the whole input.",
                        "items": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "maxItems": 8,
                        "type": "array"
                      },
                      "metrics": {
                        "description": "Summary definitions producing one output column each per group.",
                        "items": {
                          "additionalProperties": false,
                          "properties": {
                            "as": {
                              "description": "Name of the output column holding this summary.",
                              "maxLength": 128,
                              "minLength": 1,
                              "type": "string"
                            },
                            "fn": {
                              "description": "Summary function to apply, with stddev and var using sample statistics.",
                              "enum": [
                                "sum",
                                "mean",
                                "median",
                                "min",
                                "max",
                                "count",
                                "count_distinct",
                                "stddev",
                                "var",
                                "quantile"
                              ],
                              "type": "string"
                            },
                            "of": {
                              "description": "Input column to summarise, required except for count, which counts all rows when omitted.",
                              "maxLength": 128,
                              "minLength": 1,
                              "type": "string"
                            },
                            "p": {
                              "description": "Quantile fraction from 0 to 1, required for quantile and unused by other summary functions.",
                              "maximum": 1,
                              "minimum": 0,
                              "type": "number"
                            }
                          },
                          "required": [
                            "fn",
                            "as"
                          ],
                          "type": "object"
                        },
                        "maxItems": 32,
                        "minItems": 1,
                        "type": "array"
                      }
                    },
                    "required": [
                      "by",
                      "metrics"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "sort_limit",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "by": {
                        "description": "Sort columns and directions in priority order.",
                        "items": {
                          "additionalProperties": false,
                          "properties": {
                            "col": {
                              "description": "Input column used to order rows.",
                              "maxLength": 128,
                              "minLength": 1,
                              "type": "string"
                            },
                            "dir": {
                              "description": "Sort direction, ascending for asc or descending for desc.",
                              "enum": [
                                "asc",
                                "desc"
                              ],
                              "type": "string"
                            }
                          },
                          "required": [
                            "col",
                            "dir"
                          ],
                          "type": "object"
                        },
                        "maxItems": 8,
                        "minItems": 1,
                        "type": "array"
                      },
                      "limit": {
                        "anyOf": [
                          {
                            "maximum": 200000,
                            "minimum": 1,
                            "type": "integer"
                          },
                          {
                            "additionalProperties": false,
                            "properties": {
                              "param": {
                                "description": "Declared parameter key supplying the integer value at run time.",
                                "maxLength": 40,
                                "pattern": "^[a-z][a-z0-9_]{0,39}$",
                                "type": "string"
                              }
                            },
                            "required": [
                              "param"
                            ],
                            "type": "object"
                          }
                        ],
                        "description": "Maximum number of output rows, supplied as an integer or parameter reference, with no row limit when omitted."
                      },
                      "offset": {
                        "anyOf": [
                          {
                            "maximum": 200000,
                            "minimum": 0,
                            "type": "integer"
                          },
                          {
                            "additionalProperties": false,
                            "properties": {
                              "param": {
                                "description": "Declared parameter key supplying the integer value at run time.",
                                "maxLength": 40,
                                "pattern": "^[a-z][a-z0-9_]{0,39}$",
                                "type": "string"
                              }
                            },
                            "required": [
                              "param"
                            ],
                            "type": "object"
                          }
                        ],
                        "description": "Number of sorted rows to skip, supplied as an integer or parameter reference, defaulting to zero when omitted."
                      }
                    },
                    "required": [
                      "by"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "window",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "as": {
                        "description": "Name of the new output column containing the window calculation.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "fn": {
                        "description": "Calculation applied within each frame, with stddev using sample standard deviation and count counting non-null values.",
                        "enum": [
                          "sum",
                          "mean",
                          "min",
                          "max",
                          "count",
                          "stddev",
                          "first",
                          "last"
                        ],
                        "type": "string"
                      },
                      "frame": {
                        "additionalProperties": false,
                        "description": "Inclusive frame around the current row using row counts or ordered-value distances.",
                        "properties": {
                          "following": {
                            "anyOf": [
                              {
                                "maximum": 100000,
                                "minimum": 0,
                                "type": "integer"
                              },
                              {
                                "additionalProperties": false,
                                "properties": {
                                  "param": {
                                    "description": "Declared parameter key supplying the integer value at run time.",
                                    "maxLength": 40,
                                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                                    "type": "string"
                                  }
                                },
                                "required": [
                                  "param"
                                ],
                                "type": "object"
                              }
                            ],
                            "description": "Distance after the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps."
                          },
                          "kind": {
                            "description": "Frame measure, using row counts for rows or ordered-value distances for range, measured in days for date or timestamp order columns.",
                            "enum": [
                              "rows",
                              "range"
                            ],
                            "type": "string"
                          },
                          "preceding": {
                            "anyOf": [
                              {
                                "maximum": 100000,
                                "minimum": 0,
                                "type": "integer"
                              },
                              {
                                "additionalProperties": false,
                                "properties": {
                                  "param": {
                                    "description": "Declared parameter key supplying the integer value at run time.",
                                    "maxLength": 40,
                                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                                    "type": "string"
                                  }
                                },
                                "required": [
                                  "param"
                                ],
                                "type": "object"
                              }
                            ],
                            "description": "Distance before the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps."
                          }
                        },
                        "required": [
                          "kind",
                          "preceding",
                          "following"
                        ],
                        "type": "object"
                      },
                      "of": {
                        "description": "Input column whose values are calculated within each frame.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "order_by": {
                        "description": "Columns and directions defining row order within each partition.",
                        "items": {
                          "additionalProperties": false,
                          "properties": {
                            "col": {
                              "description": "Input column used to order rows.",
                              "maxLength": 128,
                              "minLength": 1,
                              "type": "string"
                            },
                            "dir": {
                              "description": "Sort direction, ascending for asc or descending for desc.",
                              "enum": [
                                "asc",
                                "desc"
                              ],
                              "type": "string"
                            }
                          },
                          "required": [
                            "col",
                            "dir"
                          ],
                          "type": "object"
                        },
                        "maxItems": 8,
                        "minItems": 1,
                        "type": "array"
                      },
                      "partition_by": {
                        "description": "Columns separating independent row groups, with all rows in one group when omitted.",
                        "items": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "maxItems": 4,
                        "type": "array"
                      }
                    },
                    "required": [
                      "fn",
                      "of",
                      "order_by",
                      "frame",
                      "as"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "lag_change",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "as": {
                        "description": "Name of the new output column containing the change.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "mode": {
                        "description": "Change calculation, using current minus earlier for diff, current divided by earlier minus one for pct as a fraction, or the natural logarithm of their positive ratio for log.",
                        "enum": [
                          "diff",
                          "pct",
                          "log"
                        ],
                        "type": "string"
                      },
                      "of": {
                        "description": "Input column compared with its earlier value.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "order_by": {
                        "description": "Columns and directions determining which rows are earlier.",
                        "items": {
                          "additionalProperties": false,
                          "properties": {
                            "col": {
                              "description": "Input column used to order rows.",
                              "maxLength": 128,
                              "minLength": 1,
                              "type": "string"
                            },
                            "dir": {
                              "description": "Sort direction, ascending for asc or descending for desc.",
                              "enum": [
                                "asc",
                                "desc"
                              ],
                              "type": "string"
                            }
                          },
                          "required": [
                            "col",
                            "dir"
                          ],
                          "type": "object"
                        },
                        "maxItems": 8,
                        "minItems": 1,
                        "type": "array"
                      },
                      "partition_by": {
                        "description": "Columns separating independent histories, with all rows in one history when omitted.",
                        "items": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "maxItems": 4,
                        "type": "array"
                      },
                      "periods": {
                        "anyOf": [
                          {
                            "maximum": 10000,
                            "minimum": 1,
                            "type": "integer"
                          },
                          {
                            "additionalProperties": false,
                            "properties": {
                              "param": {
                                "description": "Declared parameter key supplying the integer value at run time.",
                                "maxLength": 40,
                                "pattern": "^[a-z][a-z0-9_]{0,39}$",
                                "type": "string"
                              }
                            },
                            "required": [
                              "param"
                            ],
                            "type": "object"
                          }
                        ],
                        "description": "Number of ordered rows to look back within the partition, supplied as an integer or parameter reference."
                      }
                    },
                    "required": [
                      "of",
                      "periods",
                      "mode",
                      "order_by",
                      "as"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "rank",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "as": {
                        "description": "Name of the new output column containing the rank.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "by": {
                        "description": "Input column whose values determine the rank.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "direction": {
                        "description": "Ascending or descending order used to assign ranks.",
                        "enum": [
                          "asc",
                          "desc"
                        ],
                        "type": "string"
                      },
                      "method": {
                        "description": "Ranking rule, using gaps for rank, no gaps for dense, distinct row numbers for row_number, or a fraction from 0 to 1 for percentile.",
                        "enum": [
                          "rank",
                          "dense",
                          "row_number",
                          "percentile"
                        ],
                        "type": "string"
                      },
                      "within": {
                        "description": "Columns separating independent ranking groups, with all rows ranked together when omitted.",
                        "items": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "maxItems": 4,
                        "type": "array"
                      }
                    },
                    "required": [
                      "by",
                      "direction",
                      "method",
                      "as"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "zscore",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "as": {
                        "description": "Name of the new output column containing the dimensionless standard score.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "of": {
                        "description": "Input column standardised as its value minus the mean divided by sample standard deviation.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "order_by": {
                        "description": "Columns and directions defining rolling row order, required when window is set and ignored otherwise.",
                        "items": {
                          "additionalProperties": false,
                          "properties": {
                            "col": {
                              "description": "Input column used to order rows.",
                              "maxLength": 128,
                              "minLength": 1,
                              "type": "string"
                            },
                            "dir": {
                              "description": "Sort direction, ascending for asc or descending for desc.",
                              "enum": [
                                "asc",
                                "desc"
                              ],
                              "type": "string"
                            }
                          },
                          "required": [
                            "col",
                            "dir"
                          ],
                          "type": "object"
                        },
                        "maxItems": 8,
                        "minItems": 1,
                        "type": "array"
                      },
                      "window": {
                        "anyOf": [
                          {
                            "maximum": 100000,
                            "minimum": 2,
                            "type": "integer"
                          },
                          {
                            "additionalProperties": false,
                            "properties": {
                              "param": {
                                "description": "Declared parameter key supplying the integer value at run time.",
                                "maxLength": 40,
                                "pattern": "^[a-z][a-z0-9_]{0,39}$",
                                "type": "string"
                              }
                            },
                            "required": [
                              "param"
                            ],
                            "type": "object"
                          }
                        ],
                        "description": "Rolling frame size in rows including the current row, supplied as an integer or parameter reference, requiring that many non-null values and using the entire group when omitted."
                      },
                      "within": {
                        "description": "Columns separating independent standardisation groups, with all rows in one group when omitted.",
                        "items": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "maxItems": 4,
                        "type": "array"
                      }
                    },
                    "required": [
                      "of",
                      "as"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "resample",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "by": {
                        "description": "Additional grouping columns kept separate within each period, with no additional grouping when omitted.",
                        "items": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "maxItems": 4,
                        "type": "array"
                      },
                      "date_col": {
                        "description": "Input date column whose name is preserved in the output and whose value becomes the first day of each period.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "metrics": {
                        "description": "Summary definitions calculated for each period and additional group.",
                        "items": {
                          "additionalProperties": false,
                          "properties": {
                            "as": {
                              "description": "Name of the output column holding this summary.",
                              "maxLength": 128,
                              "minLength": 1,
                              "type": "string"
                            },
                            "fn": {
                              "description": "Summary function to apply, with stddev and var using sample statistics.",
                              "enum": [
                                "sum",
                                "mean",
                                "median",
                                "min",
                                "max",
                                "count",
                                "count_distinct",
                                "stddev",
                                "var",
                                "quantile"
                              ],
                              "type": "string"
                            },
                            "of": {
                              "description": "Input column to summarise, required except for count, which counts all rows when omitted.",
                              "maxLength": 128,
                              "minLength": 1,
                              "type": "string"
                            },
                            "p": {
                              "description": "Quantile fraction from 0 to 1, required for quantile and unused by other summary functions.",
                              "maximum": 1,
                              "minimum": 0,
                              "type": "number"
                            }
                          },
                          "required": [
                            "fn",
                            "as"
                          ],
                          "type": "object"
                        },
                        "maxItems": 32,
                        "minItems": 1,
                        "type": "array"
                      },
                      "to": {
                        "description": "Calendar period to aggregate into, with weeks starting on Monday.",
                        "enum": [
                          "week",
                          "month",
                          "quarter",
                          "year"
                        ],
                        "type": "string"
                      }
                    },
                    "required": [
                      "date_col",
                      "to",
                      "metrics"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "pivot",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "agg": {
                        "description": "Summary function for each pivot cell, with quantile currently unsupported.",
                        "enum": [
                          "sum",
                          "mean",
                          "median",
                          "min",
                          "max",
                          "count",
                          "count_distinct",
                          "stddev",
                          "var",
                          "quantile"
                        ],
                        "type": "string"
                      },
                      "index": {
                        "description": "Columns identifying each output row and grouping the pivoted values.",
                        "items": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "maxItems": 4,
                        "minItems": 1,
                        "type": "array"
                      },
                      "on": {
                        "description": "Input category column whose distinct values become output columns.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "values": {
                        "description": "Input column whose values are summarised in each pivot cell.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      }
                    },
                    "required": [
                      "index",
                      "on",
                      "values",
                      "agg"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "describe",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "columns": {
                        "description": "Numeric input columns to summarise, defaulting to all numeric input columns when omitted.",
                        "items": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "maxItems": 64,
                        "type": "array"
                      }
                    },
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "correlate",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "columns": {
                        "description": "Input columns for which each distinct pair receives a correlation result.",
                        "items": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "maxItems": 32,
                        "minItems": 2,
                        "type": "array"
                      },
                      "method": {
                        "description": "Correlation method, using raw values for pearson or average ranks for spearman.",
                        "enum": [
                          "pearson",
                          "spearman"
                        ],
                        "type": "string"
                      },
                      "min_periods": {
                        "description": "Minimum count of rows with both values present before returning a correlation, with no additional count threshold when omitted.",
                        "maximum": 100000,
                        "minimum": 2,
                        "type": "integer"
                      }
                    },
                    "required": [
                      "columns",
                      "method"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "regress",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "by": {
                        "description": "Columns separating independent regression groups, with one fit across the input when omitted.",
                        "items": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "maxItems": 4,
                        "type": "array"
                      },
                      "x": {
                        "description": "Predictor input columns for the regression, allowing 1 to 16 names in the schema.",
                        "items": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "maxItems": 16,
                        "minItems": 1,
                        "type": "array"
                      },
                      "y": {
                        "description": "Dependent input column to fit.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      }
                    },
                    "required": [
                      "y",
                      "x"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "adjust_price",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "base_date": {
                        "description": "Forward adjustment cutoff in YYYY-MM-DD form, using the latest factor on or before this date or the latest available factor date per security when omitted and disallowed for backward adjustment.",
                        "maxLength": 10,
                        "pattern": "^\\d{4}-\\d{2}-\\d{2}$",
                        "type": "string"
                      },
                      "date": {
                        "description": "Trading date columns in the order [column in the input table, column in the factor table], matching the latest factor on or before each input date.",
                        "items": false,
                        "maxItems": 2,
                        "minItems": 2,
                        "prefixItems": [
                          {
                            "maxLength": 128,
                            "minLength": 1,
                            "type": "string"
                          },
                          {
                            "maxLength": 128,
                            "minLength": 1,
                            "type": "string"
                          }
                        ],
                        "type": "array"
                      },
                      "factor_col": {
                        "description": "Column in the factor table containing the cumulative multiplicative adjustment factor.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "factor_table": {
                        "description": "Data requirement key or step id of the cumulative adjustment factor table, distinct from the input price table.",
                        "maxLength": 40,
                        "pattern": "^[a-z][a-z0-9_]{0,39}$",
                        "type": "string"
                      },
                      "key": {
                        "description": "Security key columns in the order [column in the input table, column in the factor table].",
                        "items": false,
                        "maxItems": 2,
                        "minItems": 2,
                        "prefixItems": [
                          {
                            "maxLength": 128,
                            "minLength": 1,
                            "type": "string"
                          },
                          {
                            "maxLength": 128,
                            "minLength": 1,
                            "type": "string"
                          }
                        ],
                        "type": "array"
                      },
                      "mode": {
                        "description": "Adjustment direction, with backward multiplying prices by their dated factor and forward dividing that product by the base factor, using the latest factor date for each security when base_date is omitted.",
                        "enum": [
                          "forward",
                          "backward"
                        ],
                        "type": "string"
                      },
                      "price_cols": {
                        "description": "Input price columns replaced by adjusted values under the same names and in the same price units.",
                        "items": {
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "maxItems": 8,
                        "minItems": 1,
                        "type": "array"
                      }
                    },
                    "required": [
                      "price_cols",
                      "factor_table",
                      "key",
                      "date",
                      "factor_col",
                      "mode"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "irr",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "amount_col": {
                        "description": "Cash flow amount column in a consistent monetary unit, with payments out negative and receipts positive.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "date_col": {
                        "description": "Cash flow date column used to count elapsed days over a 365-day year.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "guess": {
                        "description": "Initial annual rate as a fraction for the iterative solver, defaulting to 0.1 when omitted.",
                        "type": "number"
                      },
                      "max_iter": {
                        "default": 100,
                        "description": "Maximum number of Newton iterations before the fallback solver, defaulting to 100 when omitted.",
                        "maximum": 100,
                        "minimum": 1,
                        "type": "integer"
                      }
                    },
                    "required": [
                      "amount_col",
                      "date_col"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "id": {
                    "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "input": {
                    "description": "Data requirement key or step id of the primary input table, which is the first table for join.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "key": {
                    "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                    "type": "boolean"
                  },
                  "kind": {
                    "const": "operation",
                    "description": "Step discriminator identifying a named operation.",
                    "type": "string"
                  },
                  "op": {
                    "const": "factor",
                    "description": "Named operation selected by this schema branch.",
                    "type": "string"
                  },
                  "params": {
                    "additionalProperties": false,
                    "description": "Parameters for the selected operation.",
                    "properties": {
                      "as_of": {
                        "description": "Latest eligible trading date in YYYY-MM-DD form, returning each security latest row on or before it or its latest available row when omitted.",
                        "maxLength": 10,
                        "pattern": "^\\d{4}-\\d{2}-\\d{2}$",
                        "type": "string"
                      },
                      "factor": {
                        "description": "Name of a supported market measure to calculate from the input daily rows.",
                        "maxLength": 60,
                        "minLength": 1,
                        "type": "string"
                      },
                      "universe": {
                        "description": "Data requirement key or step id whose ts_code column restricts the securities, with no universe restriction when omitted.",
                        "maxLength": 40,
                        "pattern": "^[a-z][a-z0-9_]{0,39}$",
                        "type": "string"
                      }
                    },
                    "required": [
                      "factor"
                    ],
                    "type": "object"
                  },
                  "title": {
                    "description": "Optional display title for the calculation, with no title specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "id",
                  "kind",
                  "op",
                  "input",
                  "params"
                ],
                "type": "object"
              }
            ]
          },
          {
            "additionalProperties": false,
            "properties": {
              "id": {
                "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                "maxLength": 40,
                "pattern": "^[a-z][a-z0-9_]{0,39}$",
                "type": "string"
              },
              "input": {
                "description": "Declared relation names available to the SQL query, with no relations declared when omitted.",
                "items": {
                  "maxLength": 40,
                  "pattern": "^[a-z][a-z0-9_]{0,39}$",
                  "type": "string"
                },
                "maxItems": 8,
                "type": "array"
              },
              "key": {
                "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                "type": "boolean"
              },
              "kind": {
                "const": "sql",
                "description": "Step discriminator identifying a SQL calculation.",
                "type": "string"
              },
              "sql": {
                "description": "Read-only SQL query checked by the SQL validator against declared inputs.",
                "maxLength": 20000,
                "minLength": 1,
                "type": "string"
              },
              "title": {
                "description": "Optional display title for the calculation, with no title specified when omitted.",
                "maxLength": 120,
                "minLength": 1,
                "type": "string"
              }
            },
            "required": [
              "id",
              "kind",
              "sql"
            ],
            "type": "object"
          },
          {
            "additionalProperties": false,
            "properties": {
              "expr": {
                "description": "Formula intended to produce a single value addressable by this step id.",
                "maxLength": 2000,
                "minLength": 1,
                "type": "string"
              },
              "id": {
                "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                "maxLength": 40,
                "pattern": "^[a-z][a-z0-9_]{0,39}$",
                "type": "string"
              },
              "input": {
                "description": "Optional data requirement key or step id declared as input, with no input declared when omitted.",
                "maxLength": 40,
                "pattern": "^[a-z][a-z0-9_]{0,39}$",
                "type": "string"
              },
              "key": {
                "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                "type": "boolean"
              },
              "kind": {
                "const": "expression",
                "description": "Step discriminator identifying a scalar expression.",
                "type": "string"
              },
              "title": {
                "description": "Optional display title for the calculation, with no title specified when omitted.",
                "maxLength": 120,
                "minLength": 1,
                "type": "string"
              }
            },
            "required": [
              "id",
              "kind",
              "expr"
            ],
            "type": "object"
          },
          {
            "additionalProperties": false,
            "properties": {
              "id": {
                "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                "maxLength": 40,
                "pattern": "^[a-z][a-z0-9_]{0,39}$",
                "type": "string"
              },
              "input": {
                "description": "Data requirement key or step id providing the input rows.",
                "maxLength": 40,
                "pattern": "^[a-z][a-z0-9_]{0,39}$",
                "type": "string"
              },
              "key": {
                "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                "type": "boolean"
              },
              "kind": {
                "const": "ai",
                "description": "Step discriminator identifying a row interpretation step.",
                "type": "string"
              },
              "params": {
                "additionalProperties": false,
                "description": "Processing limits, instructions, output shape, and error policy for this step.",
                "properties": {
                  "instructions": {
                    "description": "Instructions for interpreting the input rows, containing 1 to 4000 characters.",
                    "maxLength": 4000,
                    "minLength": 1,
                    "type": "string"
                  },
                  "max_input_chars": {
                    "default": 20000,
                    "description": "Maximum input text length in characters, defaulting to 20000 when omitted.",
                    "maximum": 60000,
                    "minimum": 100,
                    "type": "integer"
                  },
                  "max_rows": {
                    "anyOf": [
                      {
                        "maximum": 200,
                        "minimum": 1,
                        "type": "integer"
                      },
                      {
                        "additionalProperties": false,
                        "properties": {
                          "param": {
                            "description": "Declared parameter key supplying the integer value at run time.",
                            "maxLength": 40,
                            "pattern": "^[a-z][a-z0-9_]{0,39}$",
                            "type": "string"
                          }
                        },
                        "required": [
                          "param"
                        ],
                        "type": "object"
                      }
                    ],
                    "default": 50,
                    "description": "Maximum input row count as an integer or parameter reference, defaulting to 50 when omitted."
                  },
                  "mode": {
                    "description": "Requested processing scope, either the whole input or each row separately.",
                    "enum": [
                      "whole",
                      "per_row"
                    ],
                    "type": "string"
                  },
                  "on_error": {
                    "default": "null",
                    "description": "Declared error policy, either null or fail, defaulting to null when omitted.",
                    "enum": [
                      "null",
                      "fail"
                    ],
                    "type": "string"
                  },
                  "output": {
                    "description": "Declared result shape, either text, an enumerated string, or an object of typed fields.",
                    "oneOf": [
                      {
                        "additionalProperties": false,
                        "properties": {
                          "kind": {
                            "const": "text",
                            "description": "Result shape discriminator selecting text, enum, or object.",
                            "type": "string"
                          }
                        },
                        "required": [
                          "kind"
                        ],
                        "type": "object"
                      },
                      {
                        "additionalProperties": false,
                        "properties": {
                          "kind": {
                            "const": "enum",
                            "description": "Result shape discriminator selecting text, enum, or object.",
                            "type": "string"
                          },
                          "values": {
                            "description": "Allowed non-empty string result values for an enum output, containing 2 to 32 entries.",
                            "items": {
                              "minLength": 1,
                              "type": "string"
                            },
                            "maxItems": 32,
                            "minItems": 2,
                            "type": "array"
                          }
                        },
                        "required": [
                          "kind",
                          "values"
                        ],
                        "type": "object"
                      },
                      {
                        "additionalProperties": false,
                        "properties": {
                          "fields": {
                            "additionalProperties": {
                              "enum": [
                                "string",
                                "number",
                                "boolean"
                              ],
                              "type": "string"
                            },
                            "description": "Map of output column names to string, number, or boolean types, containing 1 to 32 fields.",
                            "propertyNames": {
                              "maxLength": 128,
                              "minLength": 1,
                              "type": "string"
                            },
                            "type": "object"
                          },
                          "kind": {
                            "const": "object",
                            "description": "Result shape discriminator selecting text, enum, or object.",
                            "type": "string"
                          }
                        },
                        "required": [
                          "kind",
                          "fields"
                        ],
                        "type": "object"
                      }
                    ]
                  }
                },
                "required": [
                  "mode",
                  "instructions",
                  "output"
                ],
                "type": "object"
              },
              "title": {
                "description": "Optional display title for the calculation, with no title specified when omitted.",
                "maxLength": 120,
                "minLength": 1,
                "type": "string"
              }
            },
            "required": [
              "id",
              "kind",
              "input",
              "params"
            ],
            "type": "object"
          },
          {
            "additionalProperties": false,
            "properties": {
              "body": {
                "description": "Sandboxed JavaScript body containing 1 to 40000 characters.",
                "maxLength": 40000,
                "minLength": 1,
                "type": "string"
              },
              "carry_state": {
                "default": false,
                "description": "Whether state from the previous successful run is available, capped at 64 KB and defaulting to false when omitted.",
                "type": "boolean"
              },
              "id": {
                "description": "Unique step name that also names its output in the namespace shared with data requirement keys.",
                "maxLength": 40,
                "pattern": "^[a-z][a-z0-9_]{0,39}$",
                "type": "string"
              },
              "input": {
                "description": "One to three declared input relation names.",
                "items": {
                  "maxLength": 40,
                  "pattern": "^[a-z][a-z0-9_]{0,39}$",
                  "type": "string"
                },
                "maxItems": 3,
                "minItems": 1,
                "type": "array"
              },
              "key": {
                "description": "Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently.",
                "type": "boolean"
              },
              "kind": {
                "const": "code",
                "description": "Step discriminator identifying a sandboxed code calculation.",
                "type": "string"
              },
              "output": {
                "additionalProperties": false,
                "description": "Declared columns and types for the result table.",
                "properties": {
                  "columns": {
                    "description": "One to 64 column declarations for the result table.",
                    "items": {
                      "additionalProperties": false,
                      "properties": {
                        "name": {
                          "description": "Output table column name.",
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "type": {
                          "description": "Output table column data type.",
                          "enum": [
                            "text",
                            "number",
                            "date",
                            "boolean"
                          ],
                          "type": "string"
                        }
                      },
                      "required": [
                        "name",
                        "type"
                      ],
                      "type": "object"
                    },
                    "maxItems": 64,
                    "minItems": 1,
                    "type": "array"
                  }
                },
                "required": [
                  "columns"
                ],
                "type": "object"
              },
              "title": {
                "description": "Optional display title for the calculation, with no title specified when omitted.",
                "maxLength": 120,
                "minLength": 1,
                "type": "string"
              }
            },
            "required": [
              "id",
              "kind",
              "input",
              "output",
              "body"
            ],
            "type": "object"
          }
        ]
      },
      "maxItems": 60,
      "type": "array"
    },
    "data": {
      "description": "Named data requirements to bind before running, allowing an empty array for no requirements.",
      "items": {
        "additionalProperties": false,
        "properties": {
          "datasetHint": {
            "description": "Optional dataset suggestion for the person or resolver, with no suggestion when omitted and no binding established by this field.",
            "maxLength": 100,
            "minLength": 1,
            "type": "string"
          },
          "fields": {
            "description": "Columns requested from the bound dataset with their types and mapping requirements.",
            "items": {
              "additionalProperties": false,
              "properties": {
                "name": {
                  "description": "Column name exposed to calculations after mapping the bound dataset.",
                  "maxLength": 128,
                  "minLength": 1,
                  "type": "string"
                },
                "required": {
                  "description": "Whether this column is required for the data requirement.",
                  "type": "boolean"
                },
                "semantic": {
                  "description": "Optional shared meaning such as security_code or trade_date used to help column mapping, with no semantic hint when omitted.",
                  "maxLength": 40,
                  "minLength": 1,
                  "type": "string"
                },
                "type": {
                  "description": "Required data type for the mapped column.",
                  "enum": [
                    "text",
                    "number",
                    "date",
                    "boolean"
                  ],
                  "type": "string"
                }
              },
              "required": [
                "name",
                "type",
                "required"
              ],
              "type": "object"
            },
            "maxItems": 100,
            "minItems": 1,
            "type": "array"
          },
          "filters": {
            "description": "Parameter-based filter requests, with no filters requested when omitted.",
            "items": {
              "additionalProperties": false,
              "properties": {
                "field": {
                  "description": "Requirement column on which the filter operates.",
                  "maxLength": 128,
                  "minLength": 1,
                  "type": "string"
                },
                "op": {
                  "description": "Comparison applied between the field and the named parameter value.",
                  "enum": [
                    "eq",
                    "neq",
                    "gt",
                    "gte",
                    "lt",
                    "lte",
                    "in",
                    "not_in",
                    "contains"
                  ],
                  "type": "string"
                },
                "param": {
                  "description": "Declared parameter key supplying the filter value rather than a literal in the document.",
                  "maxLength": 40,
                  "pattern": "^[a-z][a-z0-9_]{0,39}$",
                  "type": "string"
                }
              },
              "required": [
                "field",
                "op",
                "param"
              ],
              "type": "object"
            },
            "maxItems": 20,
            "type": "array"
          },
          "grain": {
            "description": "Optional declared time granularity of the requested rows, with none specified when omitted.",
            "enum": [
              "daily",
              "weekly",
              "monthly",
              "quarterly",
              "yearly",
              "snapshot"
            ],
            "type": "string"
          },
          "key": {
            "description": "Unique relation name used to reference this data requirement from calculations.",
            "maxLength": 40,
            "pattern": "^[a-z][a-z0-9_]{0,39}$",
            "type": "string"
          },
          "purpose": {
            "description": "Optional explanation of why this data is needed, with no explanation when omitted.",
            "maxLength": 200,
            "minLength": 1,
            "type": "string"
          },
          "window": {
            "additionalProperties": false,
            "description": "Optional trading-calendar lookback request, with no lookback request when omitted.",
            "properties": {
              "field": {
                "description": "Requirement date column to which the requested lookback applies.",
                "maxLength": 128,
                "minLength": 1,
                "type": "string"
              },
              "lookbackDays": {
                "description": "Requested number of trading-calendar days rather than wall-clock days, from 1 to 3650, with 1 requesting a single trading day and no date-boundary resolution enforced by the schema.",
                "exclusiveMinimum": 0,
                "maximum": 3650,
                "type": "integer"
              }
            },
            "required": [
              "field",
              "lookbackDays"
            ],
            "type": "object"
          }
        },
        "required": [
          "key",
          "fields"
        ],
        "type": "object"
      },
      "maxItems": 12,
      "type": "array"
    },
    "meta": {
      "additionalProperties": false,
      "description": "Application name, description, version, and optional presentation and audit metadata.",
      "properties": {
        "description": {
          "description": "Plain-language application description shown on the card and in the header.",
          "maxLength": 400,
          "minLength": 1,
          "type": "string"
        },
        "icon": {
          "description": "Optional icon name checked against the supported icon list, with no icon specified when omitted.",
          "maxLength": 40,
          "minLength": 1,
          "type": "string"
        },
        "name": {
          "description": "Application name shown to the person.",
          "maxLength": 80,
          "minLength": 1,
          "type": "string"
        },
        "provenance": {
          "additionalProperties": false,
          "description": "Optional audit metadata, with no provenance recorded when omitted.",
          "properties": {
            "created_by": {
              "description": "Audit origin category, either platform or external, which does not change document installation behaviour.",
              "enum": [
                "platform",
                "external"
              ],
              "type": "string"
            },
            "imported_at": {
              "description": "Optional audit timestamp text of 1 to 40 characters, with no timestamp recorded when omitted.",
              "maxLength": 40,
              "minLength": 1,
              "type": "string"
            },
            "model": {
              "description": "Optional audit label of 1 to 120 characters, absent when omitted.",
              "maxLength": 120,
              "minLength": 1,
              "type": "string"
            },
            "tool": {
              "description": "Optional audit label of 1 to 120 characters, absent when omitted.",
              "maxLength": 120,
              "minLength": 1,
              "type": "string"
            }
          },
          "required": [
            "created_by"
          ],
          "type": "object"
        },
        "spec_version": {
          "description": "Specification version string, required to match the supported version by the validator.",
          "maxLength": 16,
          "minLength": 1,
          "type": "string"
        },
        "theme": {
          "description": "Optional theme choice, with no application theme specified when omitted.",
          "enum": [
            "daylight",
            "night",
            "paper",
            "desk"
          ],
          "type": "string"
        },
        "updated_at": {
          "description": "Optional update timestamp text of 1 to 40 characters, with no timestamp recorded when omitted.",
          "maxLength": 40,
          "minLength": 1,
          "type": "string"
        }
      },
      "required": [
        "name",
        "description",
        "spec_version"
      ],
      "type": "object"
    },
    "params": {
      "description": "Declared settings referenced by controls and calculations, allowing an empty array for no settings.",
      "items": {
        "additionalProperties": false,
        "properties": {
          "default": {
            "anyOf": [
              {
                "anyOf": [
                  {
                    "maxLength": 500,
                    "type": "string"
                  },
                  {
                    "type": "number"
                  },
                  {
                    "type": "boolean"
                  }
                ]
              },
              {
                "items": {
                  "maxLength": 500,
                  "type": "string"
                },
                "maxItems": 500,
                "type": "array"
              }
            ],
            "description": "Initial value used when no run value is supplied, leaving the value undefined when omitted."
          },
          "key": {
            "description": "Unique parameter name used by controls, filters, and parameter references.",
            "maxLength": 40,
            "pattern": "^[a-z][a-z0-9_]{0,39}$",
            "type": "string"
          },
          "label": {
            "description": "Display label for this setting.",
            "maxLength": 80,
            "minLength": 1,
            "type": "string"
          },
          "list": {
            "description": "Whether a text setting holds a list of strings, treating it as a scalar when omitted.",
            "type": "boolean"
          },
          "max": {
            "description": "Optional maximum numeric value in the parameter units, with no declared upper bound when omitted.",
            "type": "number"
          },
          "min": {
            "description": "Optional minimum numeric value in the parameter units, with no declared lower bound when omitted.",
            "type": "number"
          },
          "options": {
            "description": "Allowed text choices shown as a dropdown, with no fixed choices when omitted and disallowed for list settings.",
            "items": {
              "additionalProperties": false,
              "properties": {
                "label": {
                  "description": "Display label for this choice.",
                  "maxLength": 200,
                  "minLength": 1,
                  "type": "string"
                },
                "value": {
                  "description": "Stored non-empty text value for this choice, unique within the setting.",
                  "maxLength": 200,
                  "minLength": 1,
                  "type": "string"
                }
              },
              "required": [
                "value",
                "label"
              ],
              "type": "object"
            },
            "maxItems": 100,
            "minItems": 1,
            "type": "array"
          },
          "step": {
            "description": "Optional positive numeric increment in the parameter units, with no increment declared when omitted.",
            "exclusiveMinimum": 0,
            "type": "number"
          },
          "type": {
            "description": "Value type of the setting, either text, number, date, or boolean.",
            "enum": [
              "text",
              "number",
              "date",
              "boolean"
            ],
            "type": "string"
          },
          "unit": {
            "description": "Optional unit label of 1 to 16 characters, with no unit label when omitted.",
            "maxLength": 16,
            "minLength": 1,
            "type": "string"
          }
        },
        "required": [
          "key",
          "label",
          "type"
        ],
        "type": "object"
      },
      "maxItems": 40,
      "type": "array"
    },
    "triggers": {
      "description": "One to eight declared ways to run the application, with manual running always available.",
      "items": {
        "oneOf": [
          {
            "additionalProperties": false,
            "properties": {
              "kind": {
                "const": "manual",
                "description": "Trigger discriminator selecting manual, schedule, market, or alert.",
                "type": "string"
              }
            },
            "required": [
              "kind"
            ],
            "type": "object"
          },
          {
            "additionalProperties": false,
            "properties": {
              "cron": {
                "description": "Five-field schedule in minute, hour, day-of-month, month, and weekday order.",
                "maxLength": 256,
                "pattern": "^\\s*\\S+(\\s+\\S+){4}\\s*$",
                "type": "string"
              },
              "kind": {
                "const": "schedule",
                "description": "Trigger discriminator selecting manual, schedule, market, or alert.",
                "type": "string"
              },
              "tz": {
                "default": "Asia/Shanghai",
                "description": "Schedule time zone, defaulting to Asia/Shanghai when omitted.",
                "maxLength": 64,
                "minLength": 1,
                "type": "string"
              }
            },
            "required": [
              "kind",
              "cron"
            ],
            "type": "object"
          },
          {
            "additionalProperties": false,
            "properties": {
              "at": {
                "description": "Market event to run near, either opening or closing.",
                "enum": [
                  "open",
                  "close"
                ],
                "type": "string"
              },
              "calendar": {
                "const": "SSE",
                "default": "SSE",
                "description": "Trading calendar used for market events, restricted to SSE and defaulting to SSE when omitted.",
                "type": "string"
              },
              "kind": {
                "const": "market",
                "description": "Trigger discriminator selecting manual, schedule, market, or alert.",
                "type": "string"
              },
              "offsetMinutes": {
                "default": 0,
                "description": "Signed offset in minutes from the market event, with negative values before it and zero when omitted.",
                "maximum": 240,
                "minimum": -240,
                "type": "integer"
              }
            },
            "required": [
              "kind",
              "at"
            ],
            "type": "object"
          },
          {
            "additionalProperties": false,
            "properties": {
              "condition": {
                "description": "Expression that must hold for a scheduled alert to raise a notification.",
                "maxLength": 2000,
                "minLength": 1,
                "type": "string"
              },
              "cron": {
                "description": "Five-field schedule in minute, hour, day-of-month, month, and weekday order.",
                "maxLength": 256,
                "pattern": "^\\s*\\S+(\\s+\\S+){4}\\s*$",
                "type": "string"
              },
              "kind": {
                "const": "alert",
                "description": "Trigger discriminator selecting manual, schedule, market, or alert.",
                "type": "string"
              },
              "tz": {
                "default": "Asia/Shanghai",
                "description": "Schedule time zone, defaulting to Asia/Shanghai when omitted.",
                "maxLength": 64,
                "minLength": 1,
                "type": "string"
              }
            },
            "required": [
              "kind",
              "cron",
              "condition"
            ],
            "type": "object"
          }
        ]
      },
      "maxItems": 8,
      "minItems": 1,
      "type": "array"
    },
    "ui": {
      "additionalProperties": false,
      "description": "Screen element definitions and the root of their section tree.",
      "properties": {
        "elements": {
          "additionalProperties": {
            "oneOf": [
              {
                "additionalProperties": false,
                "properties": {
                  "children": {
                    "description": "Ordered element ids contained by this section.",
                    "items": {
                      "maxLength": 40,
                      "pattern": "^[a-z][a-z0-9_]{0,39}$",
                      "type": "string"
                    },
                    "maxItems": 32,
                    "type": "array"
                  },
                  "columns": {
                    "anyOf": [
                      {
                        "const": 1,
                        "type": "number"
                      },
                      {
                        "const": 2,
                        "type": "number"
                      },
                      {
                        "const": 3,
                        "type": "number"
                      }
                    ],
                    "default": 1,
                    "description": "Number of section layout columns, defaulting to 1 when omitted."
                  },
                  "title": {
                    "description": "Optional heading text for this element, with no heading specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  },
                  "tone": {
                    "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
                    "enum": [
                      "default",
                      "positive",
                      "negative",
                      "warning",
                      "muted"
                    ],
                    "type": "string"
                  },
                  "type": {
                    "const": "Section",
                    "description": "Element type discriminator selecting the declared screen component.",
                    "type": "string"
                  }
                },
                "required": [
                  "type",
                  "children"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "emphasis": {
                    "default": "body",
                    "description": "Text presentation role, defaulting to body when omitted.",
                    "enum": [
                      "heading",
                      "body",
                      "caption"
                    ],
                    "type": "string"
                  },
                  "text": {
                    "description": "Text content displayed by the element.",
                    "maxLength": 4000,
                    "minLength": 1,
                    "type": "string"
                  },
                  "tone": {
                    "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
                    "enum": [
                      "default",
                      "positive",
                      "negative",
                      "warning",
                      "muted"
                    ],
                    "type": "string"
                  },
                  "type": {
                    "const": "Text",
                    "description": "Element type discriminator selecting the declared screen component.",
                    "type": "string"
                  }
                },
                "required": [
                  "type",
                  "text"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "change": {
                    "description": "Optional result column providing the metric change, with no change column when omitted.",
                    "maxLength": 128,
                    "minLength": 1,
                    "type": "string"
                  },
                  "format": {
                    "default": "number",
                    "description": "Metric display format, defaulting to number when omitted.",
                    "enum": [
                      "number",
                      "money",
                      "percent",
                      "integer"
                    ],
                    "type": "string"
                  },
                  "from": {
                    "description": "Data requirement key or step id providing the displayed result.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "label": {
                    "description": "Display label for this element.",
                    "maxLength": 60,
                    "minLength": 1,
                    "type": "string"
                  },
                  "tone": {
                    "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
                    "enum": [
                      "default",
                      "positive",
                      "negative",
                      "warning",
                      "muted"
                    ],
                    "type": "string"
                  },
                  "type": {
                    "const": "Metric",
                    "description": "Element type discriminator selecting the declared screen component.",
                    "type": "string"
                  },
                  "unit": {
                    "description": "Optional displayed unit label, with no unit label when omitted.",
                    "maxLength": 16,
                    "minLength": 1,
                    "type": "string"
                  },
                  "value": {
                    "description": "Result column providing the metric value.",
                    "maxLength": 128,
                    "minLength": 1,
                    "type": "string"
                  }
                },
                "required": [
                  "type",
                  "label",
                  "from",
                  "value"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "columns": {
                    "description": "Ordered declarations of the result columns displayed in the table.",
                    "items": {
                      "additionalProperties": false,
                      "properties": {
                        "col": {
                          "description": "Result column to display in this table column.",
                          "maxLength": 128,
                          "minLength": 1,
                          "type": "string"
                        },
                        "format": {
                          "description": "Optional display format for this column, with no format specified when omitted.",
                          "enum": [
                            "text",
                            "number",
                            "money",
                            "percent",
                            "date",
                            "integer"
                          ],
                          "type": "string"
                        },
                        "label": {
                          "description": "Optional display label for the column, with no label specified when omitted.",
                          "maxLength": 60,
                          "minLength": 1,
                          "type": "string"
                        }
                      },
                      "required": [
                        "col"
                      ],
                      "type": "object"
                    },
                    "maxItems": 40,
                    "minItems": 1,
                    "type": "array"
                  },
                  "emptyHint": {
                    "description": "Optional message for an empty result, with no custom message when omitted.",
                    "maxLength": 200,
                    "minLength": 1,
                    "type": "string"
                  },
                  "from": {
                    "description": "Data requirement key or step id providing the displayed result.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "pageSize": {
                    "default": 25,
                    "description": "Number of table rows per page, defaulting to 25 when omitted.",
                    "maximum": 200,
                    "minimum": 5,
                    "type": "integer"
                  },
                  "title": {
                    "description": "Optional heading text for this element, with no heading specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  },
                  "tone": {
                    "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
                    "enum": [
                      "default",
                      "positive",
                      "negative",
                      "warning",
                      "muted"
                    ],
                    "type": "string"
                  },
                  "type": {
                    "const": "Table",
                    "description": "Element type discriminator selecting the declared screen component.",
                    "type": "string"
                  }
                },
                "required": [
                  "type",
                  "from",
                  "columns"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "chart": {
                    "description": "Chart kind, either line, bar, candlestick, or heatmap.",
                    "enum": [
                      "line",
                      "bar",
                      "candlestick",
                      "heatmap"
                    ],
                    "type": "string"
                  },
                  "from": {
                    "description": "Data requirement key or step id providing the displayed result.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "heat": {
                    "additionalProperties": false,
                    "description": "Second-axis and value result columns, required for heatmaps and otherwise optional.",
                    "properties": {
                      "value": {
                        "description": "Result column supplying the heatmap cell value.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "y": {
                        "description": "Result column supplying the heatmap second axis.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      }
                    },
                    "required": [
                      "y",
                      "value"
                    ],
                    "type": "object"
                  },
                  "ohlc": {
                    "additionalProperties": false,
                    "description": "Open, high, low, and close result columns, required for candlestick charts and otherwise optional.",
                    "properties": {
                      "close": {
                        "description": "Result column containing each candle closing price.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "high": {
                        "description": "Result column containing each candle highest price.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "low": {
                        "description": "Result column containing each candle lowest price.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      },
                      "open": {
                        "description": "Result column containing each candle opening price.",
                        "maxLength": 128,
                        "minLength": 1,
                        "type": "string"
                      }
                    },
                    "required": [
                      "open",
                      "high",
                      "low",
                      "close"
                    ],
                    "type": "object"
                  },
                  "series": {
                    "description": "Text result column whose distinct values each become their own line or bar group, for example one line per company; only for line and bar charts with exactly one y column; at most 20 groups are drawn, the rest are listed as hidden.",
                    "maxLength": 128,
                    "minLength": 1,
                    "type": "string"
                  },
                  "stacked": {
                    "description": "Optional request to stack chart series, with no stacking request when omitted.",
                    "type": "boolean"
                  },
                  "title": {
                    "description": "Optional heading text for this element, with no heading specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  },
                  "tone": {
                    "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
                    "enum": [
                      "default",
                      "positive",
                      "negative",
                      "warning",
                      "muted"
                    ],
                    "type": "string"
                  },
                  "type": {
                    "const": "Chart",
                    "description": "Element type discriminator selecting the declared screen component.",
                    "type": "string"
                  },
                  "x": {
                    "description": "Result column supplying the horizontal axis.",
                    "maxLength": 128,
                    "minLength": 1,
                    "type": "string"
                  },
                  "y": {
                    "description": "Result columns supplying line or bar series, required and non-empty for those chart kinds and otherwise optional.",
                    "items": {
                      "maxLength": 128,
                      "minLength": 1,
                      "type": "string"
                    },
                    "maxItems": 8,
                    "type": "array"
                  }
                },
                "required": [
                  "type",
                  "chart",
                  "from",
                  "x"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "text": {
                    "description": "Text content displayed by the element.",
                    "maxLength": 2000,
                    "minLength": 1,
                    "type": "string"
                  },
                  "title": {
                    "description": "Optional heading text for this element, with no heading specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  },
                  "tone": {
                    "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
                    "enum": [
                      "default",
                      "positive",
                      "negative",
                      "warning",
                      "muted"
                    ],
                    "type": "string"
                  },
                  "type": {
                    "const": "Callout",
                    "description": "Element type discriminator selecting the declared screen component.",
                    "type": "string"
                  }
                },
                "required": [
                  "type",
                  "text"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "emptyHint": {
                    "description": "Optional message for an empty result, with no custom message when omitted.",
                    "maxLength": 200,
                    "minLength": 1,
                    "type": "string"
                  },
                  "from": {
                    "description": "Data requirement key or step id providing the displayed result.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "groupBy": {
                    "description": "Optional result column used to group list items, with no grouping column when omitted.",
                    "maxLength": 128,
                    "minLength": 1,
                    "type": "string"
                  },
                  "itemBody": {
                    "description": "Optional result column supplying each list item body, with no body column when omitted.",
                    "maxLength": 128,
                    "minLength": 1,
                    "type": "string"
                  },
                  "itemLink": {
                    "description": "Optional result column supplying each list item link, with no link column when omitted.",
                    "maxLength": 128,
                    "minLength": 1,
                    "type": "string"
                  },
                  "itemTitle": {
                    "description": "Result column supplying each list item title.",
                    "maxLength": 128,
                    "minLength": 1,
                    "type": "string"
                  },
                  "itemTone": {
                    "description": "Optional result column supplying each list item tone, with no per-item tone column when omitted.",
                    "maxLength": 128,
                    "minLength": 1,
                    "type": "string"
                  },
                  "title": {
                    "description": "Optional heading text for this element, with no heading specified when omitted.",
                    "maxLength": 120,
                    "minLength": 1,
                    "type": "string"
                  },
                  "tone": {
                    "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
                    "enum": [
                      "default",
                      "positive",
                      "negative",
                      "warning",
                      "muted"
                    ],
                    "type": "string"
                  },
                  "type": {
                    "const": "List",
                    "description": "Element type discriminator selecting the declared screen component.",
                    "type": "string"
                  }
                },
                "required": [
                  "type",
                  "from",
                  "itemTitle"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "label": {
                    "description": "Display label for this element.",
                    "maxLength": 60,
                    "minLength": 1,
                    "type": "string"
                  },
                  "param": {
                    "description": "Declared parameter key edited by this control.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "tone": {
                    "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
                    "enum": [
                      "default",
                      "positive",
                      "negative",
                      "warning",
                      "muted"
                    ],
                    "type": "string"
                  },
                  "type": {
                    "const": "NumberInput",
                    "description": "Element type discriminator selecting the declared screen component.",
                    "type": "string"
                  }
                },
                "required": [
                  "type",
                  "param",
                  "label"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "label": {
                    "description": "Display label for this element.",
                    "maxLength": 60,
                    "minLength": 1,
                    "type": "string"
                  },
                  "param": {
                    "description": "Declared parameter key edited by this control.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "tone": {
                    "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
                    "enum": [
                      "default",
                      "positive",
                      "negative",
                      "warning",
                      "muted"
                    ],
                    "type": "string"
                  },
                  "type": {
                    "const": "SelectInput",
                    "description": "Element type discriminator selecting the declared screen component.",
                    "type": "string"
                  }
                },
                "required": [
                  "type",
                  "param",
                  "label"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "label": {
                    "description": "Display label for this element.",
                    "maxLength": 60,
                    "minLength": 1,
                    "type": "string"
                  },
                  "list": {
                    "default": false,
                    "description": "Whether text input displays a string list as chips, defaulting to false when omitted.",
                    "type": "boolean"
                  },
                  "param": {
                    "description": "Declared parameter key edited by this control.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "placeholder": {
                    "description": "Optional text input hint, with no placeholder specified when omitted.",
                    "maxLength": 80,
                    "minLength": 1,
                    "type": "string"
                  },
                  "tone": {
                    "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
                    "enum": [
                      "default",
                      "positive",
                      "negative",
                      "warning",
                      "muted"
                    ],
                    "type": "string"
                  },
                  "type": {
                    "const": "TextInput",
                    "description": "Element type discriminator selecting the declared screen component.",
                    "type": "string"
                  }
                },
                "required": [
                  "type",
                  "param",
                  "label"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "fromParam": {
                    "description": "Declared parameter key edited as the start date of the range.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "label": {
                    "description": "Display label for this element.",
                    "maxLength": 60,
                    "minLength": 1,
                    "type": "string"
                  },
                  "toParam": {
                    "description": "Declared parameter key edited as the end date of the range.",
                    "maxLength": 40,
                    "pattern": "^[a-z][a-z0-9_]{0,39}$",
                    "type": "string"
                  },
                  "tone": {
                    "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
                    "enum": [
                      "default",
                      "positive",
                      "negative",
                      "warning",
                      "muted"
                    ],
                    "type": "string"
                  },
                  "type": {
                    "const": "DateRangeInput",
                    "description": "Element type discriminator selecting the declared screen component.",
                    "type": "string"
                  }
                },
                "required": [
                  "type",
                  "fromParam",
                  "toParam",
                  "label"
                ],
                "type": "object"
              },
              {
                "additionalProperties": false,
                "properties": {
                  "label": {
                    "default": "Run",
                    "description": "Button label, defaulting to Run when omitted.",
                    "maxLength": 40,
                    "minLength": 1,
                    "type": "string"
                  },
                  "tone": {
                    "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
                    "enum": [
                      "default",
                      "positive",
                      "negative",
                      "warning",
                      "muted"
                    ],
                    "type": "string"
                  },
                  "type": {
                    "const": "RunButton",
                    "description": "Element type discriminator selecting the declared screen component.",
                    "type": "string"
                  }
                },
                "required": [
                  "type"
                ],
                "type": "object"
              }
            ]
          },
          "description": "Map from element ids to their screen definitions, with section children linking the tree.",
          "propertyNames": {
            "maxLength": 40,
            "pattern": "^[a-z][a-z0-9_]{0,39}$",
            "type": "string"
          },
          "type": "object"
        },
        "root": {
          "description": "Element id of the outermost section in the screen tree.",
          "maxLength": 40,
          "pattern": "^[a-z][a-z0-9_]{0,39}$",
          "type": "string"
        }
      },
      "required": [
        "root",
        "elements"
      ],
      "type": "object"
    }
  },
  "required": [
    "meta",
    "params",
    "data",
    "compute",
    "triggers",
    "ui"
  ],
  "type": "object"
}
```

## examples/ex-01-daily-movers.json

```json
{
  "$schema": "/api/spec/schema",
  "meta": {
    "name": "Daily Movers",
    "description": "Every trading day, show the companies on your list whose price moved the most.",
    "spec_version": "1.0",
    "icon": "chart-line",
    "provenance": { "created_by": "platform" }
  },
  "params": [
    { "key": "watchlist", "label": "Companies to watch", "type": "text", "list": true, "default": ["600000.SH", "000001.SZ"] },
    { "key": "move_threshold", "label": "Count a move as unusual above", "type": "number", "default": 3, "min": 0, "max": 50, "step": 0.5, "unit": "%" },
    { "key": "top_n", "label": "How many to show", "type": "number", "default": 10, "min": 1, "max": 50, "step": 1 }
  ],
  "data": [
    {
      "key": "prices",
      "purpose": "daily closing prices for the companies on the list",
      "grain": "daily",
      "datasetHint": "tushare:daily",
      "fields": [
        { "name": "code", "type": "text", "required": true, "semantic": "security_code" },
        { "name": "d", "type": "date", "required": true, "semantic": "trade_date" },
        { "name": "px", "type": "number", "required": true },
        { "name": "prev_px", "type": "number", "required": false }
      ],
      "window": { "field": "d", "lookbackDays": 30 },
      "filters": [{ "field": "code", "op": "in", "param": "watchlist" }]
    }
  ],
  "compute": [
    {
      "id": "with_change",
      "kind": "operation",
      "op": "derive",
      "input": "prices",
      "title": "Work out each day's move",
      "params": { "columns": { "pct_move": "(px - prev_px) / prev_px * 100" } }
    },
    {
      "id": "unusual",
      "kind": "operation",
      "op": "filter",
      "input": "with_change",
      "title": "Keep only the unusual moves",
      "key": true,
      "params": { "where": "abs(pct_move) >= $params.move_threshold" }
    },
    {
      "id": "movers",
      "kind": "operation",
      "op": "sort_limit",
      "input": "unusual",
      "title": "Biggest movers first",
      "key": true,
      "params": { "by": [{ "col": "pct_move", "dir": "desc" }], "limit": { "param": "top_n" } }
    },
    {
      "id": "mover_count",
      "kind": "operation",
      "op": "aggregate",
      "input": "unusual",
      "params": { "by": [], "metrics": [{ "fn": "count", "as": "n" }] }
    }
  ],
  "triggers": [
    { "kind": "manual" },
    { "kind": "market", "at": "close", "offsetMinutes": 30 }
  ],
  "ui": {
    "root": "page",
    "elements": {
      "page": { "type": "Section", "columns": 1, "children": ["controls", "headline", "table"] },
      "controls": { "type": "Section", "title": "Settings", "columns": 3, "children": ["w", "t", "n", "run"] },
      "w": { "type": "TextInput", "param": "watchlist", "label": "Companies", "list": true },
      "t": { "type": "NumberInput", "param": "move_threshold", "label": "Unusual above (%)" },
      "n": { "type": "NumberInput", "param": "top_n", "label": "How many to show" },
      "run": { "type": "RunButton", "label": "Run" },
      "headline": { "type": "Metric", "label": "Companies with an unusual move", "from": "mover_count", "value": "n", "format": "integer" },
      "table": {
        "type": "Table",
        "title": "Biggest movers",
        "from": "movers",
        "columns": [
          { "col": "code", "label": "Company", "format": "text" },
          { "col": "d", "label": "Date", "format": "date" },
          { "col": "px", "label": "Close", "format": "money" },
          { "col": "pct_move", "label": "Move", "format": "percent" }
        ],
        "emptyHint": "No company on your list moved more than the threshold."
      }
    }
  }
}
```

## references/blocks.md

# blocks

## Contents

- meta
- params
- data
- triggers
- Step kind: sql
- Step kind: expression
- Step kind: ai
- Step kind: code
- manual
- schedule
- market
- alert

## meta

Name and describe the application and declare its specification version.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| description | string; minLength: 1; maxLength: 400 | yes | Plain-language application description shown on the card and in the header. |
| icon | string; minLength: 1; maxLength: 40 | no | Optional icon name checked against the supported icon list, with no icon specified when omitted. |
| name | string; minLength: 1; maxLength: 80 | yes | Application name shown to the person. |
| provenance | object | no | Optional audit metadata, with no provenance recorded when omitted. |
| provenance.created_by | "platform" / "external" | yes | Audit origin category, either platform or external, which does not change document installation behaviour. |
| provenance.imported_at | string; minLength: 1; maxLength: 40 | no | Optional audit timestamp text of 1 to 40 characters, with no timestamp recorded when omitted. |
| provenance.model | string; minLength: 1; maxLength: 120 | no | Optional audit label of 1 to 120 characters, absent when omitted. |
| provenance.tool | string; minLength: 1; maxLength: 120 | no | Optional audit label of 1 to 120 characters, absent when omitted. |
| spec_version | string; minLength: 1; maxLength: 16 | yes | Specification version string, required to match the supported version by the validator. |
| theme | "daylight" / "night" / "paper" / "desk" | no | Optional theme choice, with no application theme specified when omitted. |
| updated_at | string; minLength: 1; maxLength: 40 | no | Optional update timestamp text of 1 to 40 characters, with no timestamp recorded when omitted. |

Example:

```json
{
  "description": "Review invented daily price changes.",
  "name": "Harbor Prices",
  "spec_version": "1.0"
}
```

## params

Declare settings that controls and calculations can read when the application runs.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| default | string or number or boolean or array of string | no | Initial value used when no run value is supplied, leaving the value undefined when omitted. |
| key | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique parameter name used by controls, filters, and parameter references. |
| label | string; minLength: 1; maxLength: 80 | yes | Display label for this setting. |
| list | boolean | no | Whether a text setting holds a list of strings, treating it as a scalar when omitted. |
| max | number | no | Optional maximum numeric value in the parameter units, with no declared upper bound when omitted. |
| min | number | no | Optional minimum numeric value in the parameter units, with no declared lower bound when omitted. |
| options | array of object; minItems: 1; maxItems: 100 | no | Allowed text choices shown as a dropdown, with no fixed choices when omitted and disallowed for list settings. |
| options[].label | string; minLength: 1; maxLength: 200 | yes | Display label for this choice. |
| options[].value | string; minLength: 1; maxLength: 200 | yes | Stored non-empty text value for this choice, unique within the setting. |
| step | number; exclusiveMinimum: 0 | no | Optional positive numeric increment in the parameter units, with no increment declared when omitted. |
| type | "text" / "number" / "date" / "boolean" | yes | Value type of the setting, either text, number, date, or boolean. |
| unit | string; minLength: 1; maxLength: 16 | no | Optional unit label of 1 to 16 characters, with no unit label when omitted. |

Example:

```json
[
  {
    "default": 10,
    "key": "harbor_limit",
    "label": "Rows to show",
    "max": 50,
    "min": 1,
    "type": "number"
  }
]
```

## data

Declare required fields and optional windows or parameter filters without embedding data rows.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| datasetHint | string; minLength: 1; maxLength: 100 | no | Optional dataset suggestion for the person or resolver, with no suggestion when omitted and no binding established by this field. |
| fields | array of object; minItems: 1; maxItems: 100 | yes | Columns requested from the bound dataset with their types and mapping requirements. |
| fields[].name | string; minLength: 1; maxLength: 128 | yes | Column name exposed to calculations after mapping the bound dataset. |
| fields[].required | boolean | yes | Whether this column is required for the data requirement. |
| fields[].semantic | string; minLength: 1; maxLength: 40 | no | Optional shared meaning such as security_code or trade_date used to help column mapping, with no semantic hint when omitted. |
| fields[].type | "text" / "number" / "date" / "boolean" | yes | Required data type for the mapped column. |
| filters | array of object; maxItems: 20 | no | Parameter-based filter requests, with no filters requested when omitted. |
| filters[].field | string; minLength: 1; maxLength: 128 | yes | Requirement column on which the filter operates. |
| filters[].op | "eq" / "neq" / "gt" / "gte" / "lt" / "lte" / "in" / "not_in" / "contains" | yes | Comparison applied between the field and the named parameter value. |
| filters[].param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the filter value rather than a literal in the document. |
| grain | "daily" / "weekly" / "monthly" / "quarterly" / "yearly" / "snapshot" | no | Optional declared time granularity of the requested rows, with none specified when omitted. |
| key | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique relation name used to reference this data requirement from calculations. |
| purpose | string; minLength: 1; maxLength: 200 | no | Optional explanation of why this data is needed, with no explanation when omitted. |
| window | object | no | Optional trading-calendar lookback request, with no lookback request when omitted. |
| window.field | string; minLength: 1; maxLength: 128 | yes | Requirement date column to which the requested lookback applies. |
| window.lookbackDays | integer; maximum: 3650; exclusiveMinimum: 0 | yes | Requested number of trading-calendar days rather than wall-clock days, from 1 to 3650, with 1 requesting a single trading day and no date-boundary resolution enforced by the schema. |

Example:

```json
[
  {
    "fields": [
      {
        "name": "harbor_price",
        "required": true,
        "type": "number"
      }
    ],
    "grain": "daily",
    "key": "harbor_prices"
  }
]
```

## triggers

Declare when the application runs, by hand, by schedule or around trading hours.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| choice 1.kind | "manual" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| choice 2.cron | string; maxLength: 256; pattern: "^\\s*\\S+(\\s+\\S+){4}\\s*$" | yes | Five-field schedule in minute, hour, day-of-month, month, and weekday order. |
| choice 2.kind | "schedule" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| choice 2.tz | string; minLength: 1; maxLength: 64; default: "Asia/Shanghai" | no | Schedule time zone, defaulting to Asia/Shanghai when omitted. |
| choice 3.at | "open" / "close" | yes | Market event to run near, either opening or closing. |
| choice 3.calendar | "SSE"; default: "SSE" | no | Trading calendar used for market events, restricted to SSE and defaulting to SSE when omitted. |
| choice 3.kind | "market" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| choice 3.offsetMinutes | integer; minimum: -240; maximum: 240; default: 0 | no | Signed offset in minutes from the market event, with negative values before it and zero when omitted. |
| choice 4.condition | string; minLength: 1; maxLength: 2000 | yes | Expression that must hold for a scheduled alert to raise a notification. |
| choice 4.cron | string; maxLength: 256; pattern: "^\\s*\\S+(\\s+\\S+){4}\\s*$" | yes | Five-field schedule in minute, hour, day-of-month, month, and weekday order. |
| choice 4.kind | "alert" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| choice 4.tz | string; minLength: 1; maxLength: 64; default: "Asia/Shanghai" | no | Schedule time zone, defaulting to Asia/Shanghai when omitted. |

Example:

```json
[
  {
    "kind": "manual"
  }
]
```

## Step kind: sql

Run a single allowed SELECT or WITH query over declared input relations.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| input | array of string; maxItems: 8 | no | Declared relation names available to the SQL query, with no relations declared when omitted. |
| key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| kind | "sql" | yes | Step discriminator identifying a SQL calculation. |
| sql | string; minLength: 1; maxLength: 20000 | yes | Read-only SQL query checked by the SQL validator against declared inputs. |
| title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "id": "harbor_total",
  "input": [
    "harbor_prices"
  ],
  "kind": "sql",
  "sql": "SELECT sum(harbor_price) AS harbor_total FROM harbor_prices"
}
```

## Step kind: expression

Evaluate a one-line formula to produce a single value for later calculations.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| expr | string; minLength: 1; maxLength: 2000 | yes | Formula intended to produce a single value addressable by this step id. |
| id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | no | Optional data requirement key or step id declared as input, with no input declared when omitted. |
| key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| kind | "expression" | yes | Step discriminator identifying a scalar expression. |
| title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "expr": "2 * 3",
  "id": "harbor_assumption",
  "kind": "expression"
}
```

## Step kind: ai

Ask the configured model about input rows and declare the shape of its response.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the input rows. |
| key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| kind | "ai" | yes | Step discriminator identifying a row interpretation step. |
| params | object | yes | Processing limits, instructions, output shape, and error policy for this step. |
| params.instructions | string; minLength: 1; maxLength: 4000 | yes | Instructions for interpreting the input rows, containing 1 to 4000 characters. |
| params.max_input_chars | integer; minimum: 100; maximum: 60000; default: 20000 | no | Maximum input text length in characters, defaulting to 20000 when omitted. |
| params.max_rows | integer or object; default: 50 | no | Maximum input row count as an integer or parameter reference, defaulting to 50 when omitted. |
| params.max_rows.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| params.mode | "whole" / "per_row" | yes | Requested processing scope, either the whole input or each row separately. |
| params.on_error | "null" / "fail"; default: "null" | no | Declared error policy, either null or fail, defaulting to null when omitted. |
| params.output | object or object or object | yes | Declared result shape, either text, an enumerated string, or an object of typed fields. |
| params.output.choice 1.kind | "text" | yes | Result shape discriminator selecting text, enum, or object. |
| params.output.choice 2.kind | "enum" | yes | Result shape discriminator selecting text, enum, or object. |
| params.output.choice 2.values | array of string; minItems: 2; maxItems: 32 | yes | Allowed non-empty string result values for an enum output, containing 2 to 32 entries. |
| params.output.choice 3.fields | object | yes | Map of output column names to string, number, or boolean types, containing 1 to 32 fields. |
| params.output.choice 3.kind | "object" | yes | Result shape discriminator selecting text, enum, or object. |
| title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "id": "harbor_summary",
  "input": "harbor_prices",
  "kind": "ai",
  "params": {
    "instructions": "Summarize harbor_price.",
    "max_input_chars": 2000,
    "max_rows": 10,
    "mode": "whole",
    "on_error": "null",
    "output": {
      "kind": "text"
    }
  }
}
```

## Step kind: code

Run sandboxed JavaScript with declared inputs and output columns, optionally carrying state across successful runs.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| body | string; minLength: 1; maxLength: 40000 | yes | Sandboxed JavaScript body containing 1 to 40000 characters. |
| carry_state | boolean; default: false | no | Whether state from the previous successful run is available, capped at 64 KB and defaulting to false when omitted. |
| id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| input | array of string; minItems: 1; maxItems: 3 | yes | One to three declared input relation names. |
| key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| kind | "code" | yes | Step discriminator identifying a sandboxed code calculation. |
| output | object | yes | Declared columns and types for the result table. |
| output.columns | array of object; minItems: 1; maxItems: 64 | yes | One to 64 column declarations for the result table. |
| output.columns[].name | string; minLength: 1; maxLength: 128 | yes | Output table column name. |
| output.columns[].type | "text" / "number" / "date" / "boolean" | yes | Output table column data type. |
| title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "body": "return [{ harbor_value: 1 }];",
  "carry_state": false,
  "id": "harbor_constant",
  "input": [
    "harbor_prices"
  ],
  "kind": "code",
  "output": {
    "columns": [
      {
        "name": "harbor_value",
        "type": "number"
      }
    ]
  }
}
```

## manual

Allow a person to run the application with its current settings.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| kind | "manual" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |

Example:

```json
{
  "kind": "manual"
}
```

## schedule

Run on a five-field cron schedule in the named time zone.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| cron | string; maxLength: 256; pattern: "^\\s*\\S+(\\s+\\S+){4}\\s*$" | yes | Five-field schedule in minute, hour, day-of-month, month, and weekday order. |
| kind | "schedule" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| tz | string; minLength: 1; maxLength: 64; default: "Asia/Shanghai" | no | Schedule time zone, defaulting to Asia/Shanghai when omitted. |

Example:

```json
{
  "cron": "0 8 * * 1-5",
  "kind": "schedule",
  "tz": "Asia/Shanghai"
}
```

## market

Run before or after market opening or closing on actual trading days in the SSE calendar.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| at | "open" / "close" | yes | Market event to run near, either opening or closing. |
| calendar | "SSE"; default: "SSE" | no | Trading calendar used for market events, restricted to SSE and defaulting to SSE when omitted. |
| kind | "market" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| offsetMinutes | integer; minimum: -240; maximum: 240; default: 0 | no | Signed offset in minutes from the market event, with negative values before it and zero when omitted. |

Example:

```json
{
  "at": "close",
  "calendar": "SSE",
  "kind": "market",
  "offsetMinutes": 15
}
```

## alert

Run on a schedule and raise a notification only when the result condition holds.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| condition | string; minLength: 1; maxLength: 2000 | yes | Expression that must hold for a scheduled alert to raise a notification. |
| cron | string; maxLength: 256; pattern: "^\\s*\\S+(\\s+\\S+){4}\\s*$" | yes | Five-field schedule in minute, hour, day-of-month, month, and weekday order. |
| kind | "alert" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| tz | string; minLength: 1; maxLength: 64; default: "Asia/Shanghai" | no | Schedule time zone, defaulting to Asia/Shanghai when omitted. |

Example:

```json
{
  "condition": "harbor_assumption > 5",
  "cron": "0 16 * * 1-5",
  "kind": "alert",
  "tz": "Asia/Shanghai"
}
```

## references/data.md

# data

## Contents

- tushare:adj_factor
- tushare:balancesheet
- tushare:cashflow
- tushare:cb_basic
- tushare:cb_daily
- tushare:cb_price_chg
- tushare:cb_redeem
- tushare:cn_cpi
- tushare:cn_lpr
- tushare:daily
- tushare:daily_basic
- tushare:disclosure
- tushare:dividend
- tushare:etf_basic
- tushare:etf_fund_daily
- tushare:etf_index
- tushare:etf_share
- tushare:factor_list
- tushare:fina_indicator
- tushare:fund_basic
- tushare:fund_nav
- tushare:fund_portfolio
- tushare:income
- tushare:index_daily
- tushare:index_member
- tushare:limit_list_d
- tushare:limit_list_d_down
- tushare:margin
- tushare:moneyflow_hsgt
- tushare:new_share
- tushare:pledge_stat
- tushare:sge_daily
- tushare:stk_managers
- tushare:stock_basic
- tushare:top10_holders
- tushare:trade_cal
- tushare:yc_cb

Choose a CSV or XLSX spreadsheet in the data connection screen and upload it. Review the detected column names and types, then connect the matching columns to the application.
## tushare:adj_factor

Name: Adjustment Factor.

Coverage: 1990-12-19 to 2026-10-10.

| Name | Type |
| --- | --- |
| adj_factor | number |
| trade_date | date |
| ts_code | text |
## tushare:balancesheet

Name: Balance Sheet.

Coverage: 2020-01-01 to 2026-06-30.

| Name | Type |
| --- | --- |
| accounts_receiv | number |
| ann_date | date |
| comp_type | number |
| end_date | date |
| f_ann_date | date |
| fix_assets | number |
| goodwill | number |
| intan_assets | number |
| inventories | number |
| money_cap | number |
| report_type | number |
| total_assets | number |
| total_cur_assets | number |
| total_cur_liab | number |
| total_hldr_eqy_exc_min_int | number |
| total_liab | number |
| total_nca | number |
| total_ncl | number |
| ts_code | text |
## tushare:cashflow

Name: Cash Flow Statement.

Coverage: 2020-01-01 to 2026-06-30.

| Name | Type |
| --- | --- |
| ann_date | date |
| c_cash_equ_end_period | number |
| comp_type | number |
| end_date | date |
| f_ann_date | date |
| free_cashflow | number |
| n_cash_flows_fnc_act | number |
| n_cashflow_act | number |
| n_cashflow_inv_act | number |
| report_type | number |
| ts_code | text |
## tushare:cb_basic

Name: Convertible Bond Basic Info.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| bond_full_name | text |
| bond_short_name | text |
| conv_end_date | date |
| conv_price | number |
| conv_start_date | date |
| coupon_rate | number |
| issue_rating | text |
| issue_size | number |
| list_date | date |
| maturity | number |
| maturity_date | date |
| newest_rating | text |
| par | number |
| rate_type | text |
| stk_code | text |
| stk_short_name | text |
| ts_code | text |
## tushare:cb_daily

Name: Convertible Bond Daily Data.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| amount | number |
| bond_over_rate | number |
| bond_value | number |
| cb_over_rate | number |
| cb_value | number |
| change | number |
| close | number |
| high | number |
| low | number |
| open | number |
| pct_chg | number |
| pre_close | number |
| trade_date | date |
| ts_code | text |
| vol | number |
## tushare:cb_price_chg

Name: CB Conversion Price Changes.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| bond_short_name | text |
| change_date | date |
| conversion_price_after | number |
| conversion_price_before | number |
| initial_conversion_price | number |
| publication_date | date |
| ticker | text |
## tushare:cb_redeem

Name: Convertible Bond Redemption.

Coverage: 2015-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| ann_date | date |
| call_amount | number |
| call_date | date |
| call_price | number |
| call_price_tax | number |
| call_reg_date | date |
| call_type | text |
| call_vol | number |
| is_call | text |
| payment_date | date |
| ts_code | text |
## tushare:cn_cpi

Name: China CPI.

Coverage: 2015-01-01 to 2026-09-30.

| Name | Type |
| --- | --- |
| cnt_mom | number |
| cnt_val | number |
| cnt_yoy | number |
| month | date |
| nt_accu | number |
| nt_mom | number |
| nt_val | number |
| nt_yoy | number |
| town_mom | number |
| town_val | number |
| town_yoy | number |
## tushare:cn_lpr

Name: China Loan Prime Rate.

Coverage: 2015-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| 1y | number |
| 5y | number |
| date | date |
## tushare:daily

Name: Daily Stock Prices.

Coverage: 1990-12-19 to 2026-10-13.

| Name | Type |
| --- | --- |
| amount | number |
| change | number |
| close | number |
| high | number |
| low | number |
| open | number |
| pct_chg | number |
| pre_close | number |
| trade_date | date |
| ts_code | text |
| vol | number |
## tushare:daily_basic

Name: Daily Basic Indicators.

Coverage: 2004-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| circ_mv | number |
| close | number |
| dv_ratio | number |
| dv_ttm | number |
| float_share | number |
| free_share | number |
| pb | number |
| pe | number |
| pe_ttm | number |
| ps | number |
| ps_ttm | number |
| total_mv | number |
| total_share | number |
| trade_date | date |
| ts_code | text |
| turnover_rate | number |
| turnover_rate_f | number |
| volume_ratio | number |
## tushare:disclosure

Name: Announcements.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| announcement_date | date |
| announcement_title | text |
| security_name | text |
| ticker | text |
| url | text |
## tushare:dividend

Name: Dividend Data.

Coverage: 2015-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| ann_date | date |
| cash_div | number |
| cash_div_tax | number |
| div_proc | text |
| end_date | date |
| ex_date | date |
| pay_date | date |
| record_date | date |
| stk_div | number |
| ts_code | text |
## tushare:etf_basic

Name: ETF Basic Information.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| cname | text |
| etf_type | text |
| exchange | text |
| index_code | text |
| index_name | text |
| list_date | date |
| list_status | text |
| mgr_name | text |
| mgt_fee | number |
| name | text |
| setup_date | date |
| ts_code | text |
## tushare:etf_fund_daily

Name: ETF Fund Daily Indicators.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| close | number |
| discount | number |
| trade_date | date |
| ts_code | text |
| unit_nav | number |
| vol | number |
## tushare:etf_index

Name: ETF Tracking Index Info.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| index_code | text |
| index_name | text |
| index_type | text |
| ts_code | text |
## tushare:etf_share

Name: ETF Share Size.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| float_share | number |
| total_share | number |
| trade_date | date |
| ts_code | text |
## tushare:factor_list

Name: Available Factor List.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| asset_class | text |
| factor_category | text |
| factor_description | text |
| factor_name | text |
## tushare:fina_indicator

Name: Financial Indicators.

Coverage: 2020-01-01 to 2026-06-30.

| Name | Type |
| --- | --- |
| assets_turn | number |
| bps | number |
| current_ratio | number |
| debt_to_assets | number |
| end_date | date |
| eps | number |
| gross_margin | number |
| netprofit_margin | number |
| ocfps | number |
| quick_ratio | number |
| roa | number |
| roe | number |
| ts_code | text |
## tushare:fund_basic

Name: Fund Basic Information.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| benchmark | text |
| c_fee | number |
| custodian | text |
| found_date | date |
| fund_type | text |
| invest_type | text |
| issue_amount | number |
| list_date | date |
| m_fee | number |
| management | text |
| name | text |
| status | text |
| ts_code | text |
| type | text |
## tushare:fund_nav

Name: Fund NAV.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| accum_nav | number |
| adj_nav | number |
| ann_date | date |
| nav_date | date |
| total_netasset | number |
| ts_code | text |
| unit_nav | number |
| update_flag | number |
## tushare:fund_portfolio

Name: Fund Portfolio Holdings.

Coverage: 2024-01-01 to 2026-06-30.

| Name | Type |
| --- | --- |
| amount | number |
| ann_date | date |
| end_date | date |
| mkv | number |
| stk_float_ratio | number |
| stk_mkv_ratio | number |
| symbol | text |
| ts_code | text |
## tushare:income

Name: Income Statement.

Coverage: 2020-01-01 to 2026-06-30.

| Name | Type |
| --- | --- |
| admin_exp | number |
| ann_date | date |
| basic_eps | number |
| comp_type | number |
| diluted_eps | number |
| ebit | number |
| ebitda | number |
| end_date | date |
| f_ann_date | date |
| fin_exp | number |
| invest_income | number |
| n_income | number |
| n_income_attr_p | number |
| operate_profit | number |
| report_type | number |
| revenue | number |
| sell_exp | number |
| total_cogs | number |
| total_profit | number |
| total_revenue | number |
| ts_code | text |
## tushare:index_daily

Name: Index Daily Data.

Coverage: 1990-12-19 to 2026-10-10.

| Name | Type |
| --- | --- |
| amount | number |
| change | number |
| close | number |
| high | number |
| low | number |
| open | number |
| pct_chg | number |
| pre_close | number |
| trade_date | date |
| ts_code | text |
| vol | number |
## tushare:index_member

Name: Index Constituent Members.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| in_date | date |
| is_new | text |
| l1_code | text |
| l1_name | text |
| name | text |
| out_date | date |
| ts_code | text |
## tushare:limit_list_d

Name: Limit-Up Events.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| amount | number |
| code | text |
| high | number |
| is_limit_up | number |
| last_close | number |
| limit_down | number |
| limit_time | text |
| limit_up | number |
| low | number |
| name | text |
| open | number |
| price | number |
| trade_date | date |
## tushare:limit_list_d_down

Name: Limit-Down Events.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| amount | number |
| change | number |
| change_rate | number |
| code | text |
| limit_price | number |
| name | text |
| pre_close_price | number |
| price | number |
| trade_date | date |
| volume | number |
## tushare:margin

Name: Margin Trading Data.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| FINBALANCE | number |
| FINBUYAMT | number |
| FINREPAYAMT | number |
| MRGGBAL | number |
| MRGNREPAYAMT | number |
| MRGNSELLAMT | number |
| SECODE | text |
| SYMBOL | text |
| TRADEDATE | date |
## tushare:moneyflow_hsgt

Name: Institutional Trading Summary.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| AMOUNT | number |
| BIZSUNITNAME | text |
| BUYAMT | number |
| CHGTYPE | text |
| SALEAMT | number |
| SYMBOL | text |
| TRADEDATE | date |
| TRANSDIR | text |
## tushare:new_share

Name: IPO Data.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| ISSPUBDATE | date |
| LISTDATE | date |
| PS_ISS_PRC | number |
| SESNAME | text |
## tushare:pledge_stat

Name: Share Pledge Statistics.

Coverage: 2015-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| end_date | date |
| pledge_count | number |
| pledge_ratio | number |
| rest_pledge | number |
| total_share | number |
| ts_code | text |
| unrest_pledge | number |
## tushare:sge_daily

Name: Shanghai Gold Spot Daily.

Coverage: 2015-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| amount | number |
| change | number |
| close | number |
| high | number |
| low | number |
| open | number |
| pct_change | number |
| price_avg | number |
| trade_date | date |
| ts_code | text |
| vol | number |
## tushare:stk_managers

Name: Company Executives.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| ann_date | date |
| begin_date | date |
| birthday | text |
| edu | text |
| end_date | date |
| gender | text |
| lev | text |
| name | text |
| national | text |
| title | text |
| ts_code | text |
## tushare:stock_basic

Name: Stock Basic Information.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| area | text |
| industry | text |
| list_date | date |
| name | text |
| symbol | text |
| ts_code | text |
## tushare:top10_holders

Name: Top 10 Shareholders.

Coverage: 2024-01-01 to 2026-06-30.

| Name | Type |
| --- | --- |
| ann_date | date |
| end_date | date |
| hold_amount | number |
| hold_change | number |
| hold_float_ratio | number |
| hold_ratio | number |
| holder_name | text |
| holder_type | text |
| ts_code | text |
## tushare:trade_cal

Name: Trading Calendar.

Coverage: 2026-01-01 to 2026-12-31.

| Name | Type |
| --- | --- |
| cal_date | date |
| exchange | text |
| is_open | number |
| pretrade_date | date |
## tushare:yc_cb

Name: Convertible Bond Yield Curve.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| close | number |
| conv_value | number |
| duration | number |
| premium_rate | number |
| trade_date | date |
| ts_code | text |
| ytm | number |

## references/errors.md

# errors

## Contents

- E_BAD_CRON
- E_BAD_EXPRESSION
- E_BAD_SQL
- E_CYCLE
- E_ELEMENT_CYCLE
- E_INTERNAL
- E_LIMIT_AI_STEPS
- E_LIMIT_CODE_STEPS
- E_LIMIT_ELEMENTS
- E_LIMIT_NESTING
- E_LIMIT_STEPS
- E_NO_TRIGGER
- E_PARSE_EMPTY
- E_PARSE_JSON
- E_PARSE_NOT_OBJECT
- E_REF_DUPLICATE_NAME
- E_REF_UNKNOWN_ELEMENT
- E_REF_UNKNOWN_PARAM
- E_REF_UNKNOWN_RELATION
- E_REF_UNKNOWN_ROOT
- E_SCHEMA_CUSTOM
- E_SCHEMA_ENUM
- E_SCHEMA_PATTERN
- E_SCHEMA_RANGE
- E_SCHEMA_REQUIRED
- E_SCHEMA_SPEC_VERSION
- E_SCHEMA_TYPE
- E_SCHEMA_UNION
- E_SCHEMA_UNKNOWN_KEY
- E_SELF_REFERENCE
- E_TOO_MANY_ERRORS
- W_CODE_COULD_BE_OPERATION
- W_DEAD_CONTROL
- W_NO_MANUAL_TRIGGER
- W_ORPHAN_ELEMENT
- W_SHORT_HISTORY
- W_SQL_COULD_BE_OPERATION
- W_SURROUNDING_TEXT
- W_UNKNOWN_ICON
- W_UNUSED_DATA
- W_UNUSED_PARAM
- W_UNUSED_STEP

## E_BAD_CRON

A schedule is not a valid five-field cron expression.

Hint: Use five schedule parts with valid ranges and increments.
## E_BAD_EXPRESSION

A formula could not be understood.

Hint: Correct the formula using supported syntax and functions.
## E_BAD_SQL

A SQL step is not a single SELECT or WITH, or uses something not allowed.

Hint: Use one allowed SELECT or WITH statement over declared inputs.
## E_CYCLE

Two or more steps depend on each other, so no order can run them.

Hint: Remove the circular dependencies between steps.
## E_ELEMENT_CYCLE

Sections contain each other in a loop.

Hint: Remove the loop in Section children.
## E_INTERNAL

The checker could not finish checking this application.

Hint: This is a fault in the checker, not in your application. Simplify the value at this location and check again.
## E_LIMIT_AI_STEPS

More than four AI steps in one application.

Hint: Reduce the application to at most four ai steps.
## E_LIMIT_CODE_STEPS

More than one custom-code step in one application.

Hint: Combine custom logic into at most one code step.
## E_LIMIT_ELEMENTS

Too many screen elements.

Hint: Reduce the screen to at most 60 elements.
## E_LIMIT_NESTING

Sections are nested too deeply.

Hint: Flatten nested Sections to the allowed depth in the report.
## E_LIMIT_STEPS

Too many calculation steps.

Hint: Reduce the application to at most 60 calculation steps.
## E_NO_TRIGGER

An application needs at least one trigger.

Hint: Add a manual trigger or another supported trigger.
## E_PARSE_EMPTY

The file is empty.

Hint: Supply the complete application instead of an empty file.
## E_PARSE_JSON

The file is not valid JSON.

Hint: Fix the syntax and supply one complete JSON object.
## E_PARSE_NOT_OBJECT

The top level of an application must be a JSON object.

Hint: Supply an application object rather than a list or scalar.
## E_REF_DUPLICATE_NAME

Two things claim the same name. Data keys and step ids share one namespace.

Hint: Give each data key and step id a distinct name.
## E_REF_UNKNOWN_ELEMENT

A section lists a child element that does not exist.

Hint: Use an existing element id in children.
## E_REF_UNKNOWN_PARAM

Something names a parameter that was never declared.

Hint: Use a declared params key, or declare the missing setting.
## E_REF_UNKNOWN_RELATION

A step reads a table that no data requirement or earlier step produces.

Hint: Point at an existing data key or step id.
## E_REF_UNKNOWN_ROOT

The screen names a root element that does not exist.

Hint: Set ui.root to an existing element id.
## E_SCHEMA_CUSTOM

A value broke a rule specific to this field.

Hint: Follow the specific rule in the report hint.
## E_SCHEMA_ENUM

A value is not one of the allowed choices.

Hint: Choose one of the allowed values in the property table.
## E_SCHEMA_PATTERN

A value does not match the required form.

Hint: Use the required spelling and identifier format.
## E_SCHEMA_RANGE

A number or a length is outside the allowed range.

Hint: Keep the value or length within the stated bounds.
## E_SCHEMA_REQUIRED

A required field is missing.

Hint: Add the missing required property.
## E_SCHEMA_SPEC_VERSION

The specification version is missing or unsupported.

Hint: Set meta.spec_version to "1.0".
## E_SCHEMA_TYPE

A value is the wrong type.

Hint: Use the type required by the named property.
## E_SCHEMA_UNION

A value does not match any allowed shape.

Hint: Use one complete allowed shape, without mixing alternatives.
## E_SCHEMA_UNKNOWN_KEY

A key is not part of the specification. Usually a typo.

Hint: Remove or correct the unrecognised key.
## E_SELF_REFERENCE

A step reads its own output.

Hint: Read a different input instead of the step’s own output.
## E_TOO_MANY_ERRORS

More problems were found than one report can show.

Hint: Fix the reported problems and check again to see the remaining problems.
## W_CODE_COULD_BE_OPERATION

A custom-code step does something a named operation already does.

Hint: Replace the code step with the suggested named operation.
## W_DEAD_CONTROL

A parameter has a control on screen but nothing in the calculation reads it, so the control does nothing.

Hint: Connect the controlled setting to a calculation or remove the control.
## W_NO_MANUAL_TRIGGER

The application cannot be run by hand.

Hint: Add a manual trigger so the person can run by hand.
## W_ORPHAN_ELEMENT

An element is declared but nothing on the screen shows it.

Hint: Include the element in a reachable Section or remove it.
## W_SHORT_HISTORY

The data does not go back as far as this application asks for.

Hint: Connect a source with more history or shorten the requested window.
## W_SQL_COULD_BE_OPERATION

A SQL step does something a named operation already does.

Hint: Replace the SQL step with the suggested named operation.
## W_SURROUNDING_TEXT

The application was wrapped in a code fence or surrounded by prose. It was read anyway.

Hint: Supply the application alone without fences or surrounding prose.
## W_UNKNOWN_ICON

The icon name is not one we ship. A default will be used.

Hint: Choose an icon from the supported icon names or omit it.
## W_UNUSED_DATA

A data requirement is declared but no step reads it.

Hint: Read the data requirement in a step or remove it.
## W_UNUSED_PARAM

A parameter is declared but nothing uses it.

Hint: Read the setting in calculations or remove it.
## W_UNUSED_STEP

A step produces a table that nothing reads.

Hint: Use the result in another step or on screen, or remove the step.

## references/ops-finance.md

# ops-finance

## Contents

- ai
- factor
- irr

## ai

Return model responses as a typed table for the whole input or individual rows using the declared text, enum or object output shape.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| instructions | string; minLength: 1; maxLength: 4000 | yes | Instructions for interpreting the input rows, containing 1 to 4000 characters. |
| max_input_chars | integer; minimum: 100; maximum: 60000; default: 20000 | no | Maximum input text length in characters, defaulting to 20000 when omitted. |
| max_rows | integer or object; default: 50 | no | Maximum input row count as an integer or parameter reference, defaulting to 50 when omitted. |
| max_rows.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| mode | "whole" / "per_row" | yes | Requested processing scope, either the whole input or each row separately. |
| on_error | "null" / "fail"; default: "null" | no | Declared error policy, either null or fail, defaulting to null when omitted. |
| output | object or object or object | yes | Declared result shape, either text, an enumerated string, or an object of typed fields. |
| output.choice 1.kind | "text" | yes | Result shape discriminator selecting text, enum, or object. |
| output.choice 2.kind | "enum" | yes | Result shape discriminator selecting text, enum, or object. |
| output.choice 2.values | array of string; minItems: 2; maxItems: 32 | yes | Allowed non-empty string result values for an enum output, containing 2 to 32 entries. |
| output.choice 3.fields | object | yes | Map of output column names to string, number, or boolean types, containing 1 to 32 fields. |
| output.choice 3.kind | "object" | yes | Result shape discriminator selecting text, enum, or object. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "ai",
  "params": {
    "instructions": "Summarize the pattern in harbor_price and harbor_volume.",
    "max_input_chars": 20000,
    "max_rows": 50,
    "mode": "whole",
    "on_error": "null",
    "output": {
      "fields": {
        "harbor_summary": "string"
      },
      "kind": "object"
    }
  }
}
```


## factor

Return one row per security on its latest eligible day with ts_code, trade_date and a column named after the chosen market factor.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as_of | string; maxLength: 10; pattern: "^\\d{4}-\\d{2}-\\d{2}$" | no | Latest eligible trading date in YYYY-MM-DD form, returning each security latest row on or before it or its latest available row when omitted. |
| factor | string; minLength: 1; maxLength: 60 | yes | Name of a supported market measure to calculate from the input daily rows. |
| universe | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | no | Data requirement key or step id whose ts_code column restricts the securities, with no universe restriction when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "factor",
  "params": {
    "as_of": "2026-01-30",
    "factor": "momentum_20d",
    "universe": "harbor_universe"
  }
}
```

Supported factors (every factor also needs ts_code and trade_date):

| Factor | Meaning | Needed columns |
| --- | --- | --- |
| avg_amount_20d | average daily traded value over the last 20 trading days | amount |
| avg_volume_20d | average daily volume over the last 20 trading days | vol |
| book_to_price | book value per unit of price (1 / P/B), blank when book value is negative | pb |
| dividend_yield | dividends of the last 12 months per unit of price, as a fraction | dv_ttm |
| earnings_yield | earnings per unit of price (1 / P/E), blank when earnings are negative | pe |
| high_gap_250d | how far the price sits below its highest close of the last 250 trading days | close |
| log_size | natural logarithm of total market value | total_mv |
| ma_gap_20d | how far the price sits above its 20-day average | close |
| ma_gap_60d | how far the price sits above its 60-day average | close |
| momentum_120d | price change over the last 120 trading days | close |
| momentum_20d | price change over the last 20 trading days | close |
| momentum_250d | price change over the last 250 trading days | close |
| momentum_5d | price change over the last 5 trading days | close |
| momentum_60d | price change over the last 60 trading days | close |
| turnover_20d | average daily turnover rate over the last 20 trading days | turnover_rate |
| volatility_20d | yearly-scaled spread of daily returns over the last 20 trading days | close |
| volatility_60d | yearly-scaled spread of daily returns over the last 60 trading days | close |
| volume_ratio_5_20d | average volume of the last 5 days divided by that of the last 20 | vol |
## irr

Return one annual break-even rate as a scalar value, read from the single irr column.

Inputs: 1. Output shape: scalar.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| amount_col | string; minLength: 1; maxLength: 128 | yes | Cash flow amount column in a consistent monetary unit, with payments out negative and receipts positive. |
| date_col | string; minLength: 1; maxLength: 128 | yes | Cash flow date column used to count elapsed days over a 365-day year. |
| guess | number | no | Initial annual rate as a fraction for the iterative solver, defaulting to 0.1 when omitted. |
| max_iter | integer; minimum: 1; maximum: 100; default: 100 | no | Maximum number of Newton iterations before the fallback solver, defaulting to 100 when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "irr",
  "params": {
    "amount_col": "harbor_payment",
    "date_col": "harbor_day",
    "guess": 0.1,
    "max_iter": 100
  }
}
```

## references/ops-shaping.md

# ops-shaping

## Contents

- aggregate
- derive
- filter
- join
- pivot
- sort_limit

## aggregate

Return one row per group with the grouping columns and named summary columns.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| by | array of string; maxItems: 8 | yes | Grouping columns, with an empty array producing one summary across the whole input. |
| metrics | array of object; minItems: 1; maxItems: 32 | yes | Summary definitions producing one output column each per group. |
| metrics[].as | string; minLength: 1; maxLength: 128 | yes | Name of the output column holding this summary. |
| metrics[].fn | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function to apply, with stddev and var using sample statistics. |
| metrics[].of | string; minLength: 1; maxLength: 128 | no | Input column to summarise, required except for count, which counts all rows when omitted. |
| metrics[].p | number; minimum: 0; maximum: 1 | no | Quantile fraction from 0 to 1, required for quantile and unused by other summary functions. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "aggregate",
  "params": {
    "by": [
      "harbor_sector"
    ],
    "metrics": [
      {
        "as": "harbor_average",
        "fn": "mean",
        "of": "harbor_price"
      }
    ]
  }
}
```


## derive

Keep input columns and append the named calculated columns.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| columns | object | yes | Map from each new output column name to the expression calculated for every input row. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "derive",
  "params": {
    "columns": {
      "harbor_gain": "harbor_price - harbor_cost"
    }
  }
}
```


## filter

Keep matching rows with all input columns unchanged.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| where | string; minLength: 1; maxLength: 2000 | yes | Boolean expression that keeps only input rows for which it is true. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "filter",
  "params": {
    "where": "harbor_price > 20"
  }
}
```


## join

Combine matching rows, retaining left columns and non-key right columns, with right relation suffixes and numbered suffixes for name collisions.

Inputs: 2. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| asof_on | [string, string]; minItems: 2; maxItems: 2 | no | Ordered matching columns as [column in the input table, column in the right table], required for asof and adding no ordered match when omitted for other join kinds. |
| direction | "backward" / "forward" / "nearest" | no | As-of matching direction, defaulting to backward for the latest right row at or before the input row, with forward choosing the earliest at or after it and nearest currently unsupported. |
| how | "inner" / "left" / "asof" | yes | Join kind, retaining matching rows for inner or all input rows for left and asof. |
| on | array of [string, string]; minItems: 1; maxItems: 8 | yes | Pairs of equality keys in the order [column in the input table, column in the right table]. |
| right | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the second table, while the step input names the first table. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "join",
  "params": {
    "how": "left",
    "on": [
      [
        "harbor_code",
        "harbor_code"
      ]
    ],
    "right": "harbor_sectors"
  }
}
```


## pivot

Return index columns and one summary column per category in the pivot column.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| agg | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function for each pivot cell, with quantile currently unsupported. |
| index | array of string; minItems: 1; maxItems: 4 | yes | Columns identifying each output row and grouping the pivoted values. |
| on | string; minLength: 1; maxLength: 128 | yes | Input category column whose distinct values become output columns. |
| values | string; minLength: 1; maxLength: 128 | yes | Input column whose values are summarised in each pivot cell. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "pivot",
  "params": {
    "agg": "mean",
    "index": [
      "harbor_day"
    ],
    "on": "harbor_sector",
    "values": "harbor_price"
  }
}
```


## sort_limit

Sort rows and optionally skip or limit them while retaining all input columns.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| by | array of object; minItems: 1; maxItems: 8 | yes | Sort columns and directions in priority order. |
| by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| limit | integer or object | no | Maximum number of output rows, supplied as an integer or parameter reference, with no row limit when omitted. |
| limit.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| offset | integer or object | no | Number of sorted rows to skip, supplied as an integer or parameter reference, defaulting to zero when omitted. |
| offset.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "sort_limit",
  "params": {
    "by": [
      {
        "col": "harbor_price",
        "dir": "desc"
      }
    ],
    "limit": 10,
    "offset": 0
  }
}
```

## references/ops-statistics.md

# ops-statistics

## Contents

- correlate
- describe
- rank
- regress
- zscore

## correlate

Return a long table with one row per distinct column pair and columns col_a, col_b, corr and n.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| columns | array of string; minItems: 2; maxItems: 32 | yes | Input columns for which each distinct pair receives a correlation result. |
| method | "pearson" / "spearman" | yes | Correlation method, using raw values for pearson or average ranks for spearman. |
| min_periods | integer; minimum: 2; maximum: 100000 | no | Minimum count of rows with both values present before returning a correlation, with no additional count threshold when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "correlate",
  "params": {
    "columns": [
      "harbor_price",
      "harbor_volume"
    ],
    "method": "pearson",
    "min_periods": 5
  }
}
```


## describe

Return a long table with one row per numeric column and columns column, count, mean, std, min, q25, median, q75 and max.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| columns | array of string; maxItems: 64 | no | Numeric input columns to summarise, defaulting to all numeric input columns when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "describe",
  "params": {
    "columns": [
      "harbor_price",
      "harbor_volume"
    ]
  }
}
```


## rank

Keep input columns and append a named rank, dense rank, row number or percentile within each group.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the rank. |
| by | string; minLength: 1; maxLength: 128 | yes | Input column whose values determine the rank. |
| direction | "asc" / "desc" | yes | Ascending or descending order used to assign ranks. |
| method | "rank" / "dense" / "row_number" / "percentile" | yes | Ranking rule, using gaps for rank, no gaps for dense, distinct row numbers for row_number, or a fraction from 0 to 1 for percentile. |
| within | array of string; maxItems: 4 | no | Columns separating independent ranking groups, with all rows ranked together when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "rank",
  "params": {
    "as": "harbor_rank",
    "by": "harbor_price",
    "direction": "desc",
    "method": "dense",
    "within": [
      "harbor_sector"
    ]
  }
}
```


## regress

Return a long table of fitted intercept and predictor terms with grouping columns plus term, coefficient, r2 and n.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| by | array of string; maxItems: 4 | no | Columns separating independent regression groups, with one fit across the input when omitted. |
| x | array of string; minItems: 1; maxItems: 16 | yes | Predictor input columns for the regression, allowing 1 to 16 names in the schema. |
| y | string; minLength: 1; maxLength: 128 | yes | Dependent input column to fit. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "regress",
  "params": {
    "by": [
      "harbor_sector"
    ],
    "x": [
      "harbor_market",
      "harbor_size"
    ],
    "y": "harbor_return"
  }
}
```


## zscore

Keep input columns and append a named distance from the mean in sample standard deviations, optionally over a full rolling window.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the dimensionless standard score. |
| of | string; minLength: 1; maxLength: 128 | yes | Input column standardised as its value minus the mean divided by sample standard deviation. |
| order_by | array of object; minItems: 1; maxItems: 8 | no | Columns and directions defining rolling row order, required when window is set and ignored otherwise. |
| order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| window | integer or object | no | Rolling frame size in rows including the current row, supplied as an integer or parameter reference, requiring that many non-null values and using the entire group when omitted. |
| window.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| within | array of string; maxItems: 4 | no | Columns separating independent standardisation groups, with all rows in one group when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "zscore",
  "params": {
    "as": "harbor_score",
    "of": "harbor_price",
    "order_by": [
      {
        "col": "harbor_day",
        "dir": "asc"
      }
    ],
    "window": 20,
    "within": [
      "harbor_code"
    ]
  }
}
```

## references/ops-time-series.md

# ops-time-series

## Contents

- adjust_price
- lag_change
- resample
- window

## adjust_price

Keep input columns and replace selected prices under their original names using cumulative split and dividend adjustment factors.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| base_date | string; maxLength: 10; pattern: "^\\d{4}-\\d{2}-\\d{2}$" | no | Forward adjustment cutoff in YYYY-MM-DD form, using the latest factor on or before this date or the latest available factor date per security when omitted and disallowed for backward adjustment. |
| date | [string, string]; minItems: 2; maxItems: 2 | yes | Trading date columns in the order [column in the input table, column in the factor table], matching the latest factor on or before each input date. |
| factor_col | string; minLength: 1; maxLength: 128 | yes | Column in the factor table containing the cumulative multiplicative adjustment factor. |
| factor_table | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the cumulative adjustment factor table, distinct from the input price table. |
| key | [string, string]; minItems: 2; maxItems: 2 | yes | Security key columns in the order [column in the input table, column in the factor table]. |
| mode | "forward" / "backward" | yes | Adjustment direction, with backward multiplying prices by their dated factor and forward dividing that product by the base factor, using the latest factor date for each security when base_date is omitted. |
| price_cols | array of string; minItems: 1; maxItems: 8 | yes | Input price columns replaced by adjusted values under the same names and in the same price units. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "adjust_price",
  "params": {
    "base_date": "2026-01-30",
    "date": [
      "harbor_day",
      "harbor_date"
    ],
    "factor_col": "harbor_multiplier",
    "factor_table": "harbor_adjustments",
    "key": [
      "harbor_code",
      "harbor_security"
    ],
    "mode": "forward",
    "price_cols": [
      "harbor_price"
    ]
  }
}
```


## lag_change

Keep input columns and append a named difference, fractional change or logarithmic change from an earlier row.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the change. |
| mode | "diff" / "pct" / "log" | yes | Change calculation, using current minus earlier for diff, current divided by earlier minus one for pct as a fraction, or the natural logarithm of their positive ratio for log. |
| of | string; minLength: 1; maxLength: 128 | yes | Input column compared with its earlier value. |
| order_by | array of object; minItems: 1; maxItems: 8 | yes | Columns and directions determining which rows are earlier. |
| order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| partition_by | array of string; maxItems: 4 | no | Columns separating independent histories, with all rows in one history when omitted. |
| periods | integer or object | yes | Number of ordered rows to look back within the partition, supplied as an integer or parameter reference. |
| periods.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "lag_change",
  "params": {
    "as": "harbor_change",
    "mode": "pct",
    "of": "harbor_price",
    "order_by": [
      {
        "col": "harbor_day",
        "dir": "asc"
      }
    ],
    "partition_by": [
      "harbor_code"
    ],
    "periods": 1
  }
}
```


## resample

Return grouping columns, the original date column set to each period start, and named summary columns.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| by | array of string; maxItems: 4 | no | Additional grouping columns kept separate within each period, with no additional grouping when omitted. |
| date_col | string; minLength: 1; maxLength: 128 | yes | Input date column whose name is preserved in the output and whose value becomes the first day of each period. |
| metrics | array of object; minItems: 1; maxItems: 32 | yes | Summary definitions calculated for each period and additional group. |
| metrics[].as | string; minLength: 1; maxLength: 128 | yes | Name of the output column holding this summary. |
| metrics[].fn | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function to apply, with stddev and var using sample statistics. |
| metrics[].of | string; minLength: 1; maxLength: 128 | no | Input column to summarise, required except for count, which counts all rows when omitted. |
| metrics[].p | number; minimum: 0; maximum: 1 | no | Quantile fraction from 0 to 1, required for quantile and unused by other summary functions. |
| to | "week" / "month" / "quarter" / "year" | yes | Calendar period to aggregate into, with weeks starting on Monday. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "resample",
  "params": {
    "by": [
      "harbor_code"
    ],
    "date_col": "harbor_day",
    "metrics": [
      {
        "as": "harbor_average",
        "fn": "mean",
        "of": "harbor_price"
      }
    ],
    "to": "month"
  }
}
```


## window

Keep input columns and append a named running or rolling summary over the ordered frame.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the window calculation. |
| fn | "sum" / "mean" / "min" / "max" / "count" / "stddev" / "first" / "last" | yes | Calculation applied within each frame, with stddev using sample standard deviation and count counting non-null values. |
| frame | object | yes | Inclusive frame around the current row using row counts or ordered-value distances. |
| frame.following | integer or object | yes | Distance after the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps. |
| frame.following.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| frame.kind | "rows" / "range" | yes | Frame measure, using row counts for rows or ordered-value distances for range, measured in days for date or timestamp order columns. |
| frame.preceding | integer or object | yes | Distance before the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps. |
| frame.preceding.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| of | string; minLength: 1; maxLength: 128 | yes | Input column whose values are calculated within each frame. |
| order_by | array of object; minItems: 1; maxItems: 8 | yes | Columns and directions defining row order within each partition. |
| order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| partition_by | array of string; maxItems: 4 | no | Columns separating independent row groups, with all rows in one group when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "window",
  "params": {
    "as": "harbor_rolling",
    "fn": "mean",
    "frame": {
      "following": 0,
      "kind": "rows",
      "preceding": 4
    },
    "of": "harbor_price",
    "order_by": [
      {
        "col": "harbor_day",
        "dir": "asc"
      }
    ],
    "partition_by": [
      "harbor_code"
    ]
  }
}
```

## references/screen-charts.md

# screen-charts

## Contents

- Chart

## Chart

Plot daily results as a line, bar, candlestick or heatmap chart.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| chart | "line" / "bar" / "candlestick" / "heatmap" | yes | Chart kind, either line, bar, candlestick, or heatmap. |
| from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| heat | object | no | Second-axis and value result columns, required for heatmaps and otherwise optional. |
| heat.value | string; minLength: 1; maxLength: 128 | yes | Result column supplying the heatmap cell value. |
| heat.y | string; minLength: 1; maxLength: 128 | yes | Result column supplying the heatmap second axis. |
| ohlc | object | no | Open, high, low, and close result columns, required for candlestick charts and otherwise optional. |
| ohlc.close | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle closing price. |
| ohlc.high | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle highest price. |
| ohlc.low | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle lowest price. |
| ohlc.open | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle opening price. |
| series | string; minLength: 1; maxLength: 128 | no | Text result column whose distinct values each become their own line or bar group, for example one line per company; only for line and bar charts with exactly one y column; at most 20 groups are drawn, the rest are listed as hidden. |
| stacked | boolean | no | Optional request to stack chart series, with no stacking request when omitted. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Chart" | yes | Element type discriminator selecting the declared screen component. |
| x | string; minLength: 1; maxLength: 128 | yes | Result column supplying the horizontal axis. |
| y | array of string; maxItems: 8 | no | Result columns supplying line or bar series, required and non-empty for those chart kinds and otherwise optional. |

Example:

```json
{
  "chart": "line",
  "from": "prices",
  "type": "Chart",
  "x": "trade_date",
  "y": [
    "close"
  ]
}
```

## references/screen-controls.md

# screen-controls

## Contents

- DateRangeInput
- NumberInput
- RunButton
- SelectInput
- TextInput

## DateRangeInput

Edit the two named parameters that define a date range.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| fromParam | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited as the start date of the range. |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| toParam | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited as the end date of the range. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "DateRangeInput" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "fromParam": "start",
  "label": "Dates",
  "toParam": "end",
  "type": "DateRangeInput"
}
```

## NumberInput

Edit a named numeric parameter.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited by this control. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "NumberInput" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "label": "Rows",
  "param": "limit",
  "type": "NumberInput"
}
```

## RunButton

Run the application with its current settings.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| label | string; minLength: 1; maxLength: 40; default: "Run" | no | Button label, defaulting to Run when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "RunButton" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "label": "Run",
  "type": "RunButton"
}
```

## SelectInput

Choose among the declared options of a named text parameter.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited by this control. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "SelectInput" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "label": "Market",
  "param": "market",
  "type": "SelectInput"
}
```

## TextInput

Edit a named text parameter or list of text values.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| list | boolean; default: false | no | Whether text input displays a string list as chips, defaulting to false when omitted. |
| param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited by this control. |
| placeholder | string; minLength: 1; maxLength: 80 | no | Optional text input hint, with no placeholder specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "TextInput" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "label": "Companies",
  "param": "watchlist",
  "type": "TextInput"
}
```

## references/screen-display.md

# screen-display

## Contents

- Callout
- List
- Metric
- Table
- Text

## Callout

Show a note with an optional title and semantic tone.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| text | string; minLength: 1; maxLength: 2000 | yes | Text content displayed by the element. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Callout" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "text": "Prices are delayed.",
  "type": "Callout"
}
```

## List

Show result rows as items with titles and optional bodies, links, tones and groups.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| emptyHint | string; minLength: 1; maxLength: 200 | no | Optional message for an empty result, with no custom message when omitted. |
| from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| groupBy | string; minLength: 1; maxLength: 128 | no | Optional result column used to group list items, with no grouping column when omitted. |
| itemBody | string; minLength: 1; maxLength: 128 | no | Optional result column supplying each list item body, with no body column when omitted. |
| itemLink | string; minLength: 1; maxLength: 128 | no | Optional result column supplying each list item link, with no link column when omitted. |
| itemTitle | string; minLength: 1; maxLength: 128 | yes | Result column supplying each list item title. |
| itemTone | string; minLength: 1; maxLength: 128 | no | Optional result column supplying each list item tone, with no per-item tone column when omitted. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "List" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "from": "prices",
  "itemTitle": "name",
  "type": "List"
}
```

## Metric

Show one formatted result value with an optional change and unit.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| change | string; minLength: 1; maxLength: 128 | no | Optional result column providing the metric change, with no change column when omitted. |
| format | "number" / "money" / "percent" / "integer"; default: "number" | no | Metric display format, defaulting to number when omitted. |
| from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Metric" | yes | Element type discriminator selecting the declared screen component. |
| unit | string; minLength: 1; maxLength: 16 | no | Optional displayed unit label, with no unit label when omitted. |
| value | string; minLength: 1; maxLength: 128 | yes | Result column providing the metric value. |

Example:

```json
{
  "from": "totals",
  "label": "Total",
  "type": "Metric",
  "value": "n"
}
```

## Table

Show result rows in named, formatted columns with pagination.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| columns | array of object; minItems: 1; maxItems: 40 | yes | Ordered declarations of the result columns displayed in the table. |
| columns[].col | string; minLength: 1; maxLength: 128 | yes | Result column to display in this table column. |
| columns[].format | "text" / "number" / "money" / "percent" / "date" / "integer" | no | Optional display format for this column, with no format specified when omitted. |
| columns[].label | string; minLength: 1; maxLength: 60 | no | Optional display label for the column, with no label specified when omitted. |
| emptyHint | string; minLength: 1; maxLength: 200 | no | Optional message for an empty result, with no custom message when omitted. |
| from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| pageSize | integer; minimum: 5; maximum: 200; default: 25 | no | Number of table rows per page, defaulting to 25 when omitted. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Table" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "columns": [
    {
      "col": "close"
    }
  ],
  "from": "prices",
  "type": "Table"
}
```

## Text

Show prose as a heading, body or caption.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| emphasis | "heading" / "body" / "caption"; default: "body" | no | Text presentation role, defaulting to body when omitted. |
| text | string; minLength: 1; maxLength: 4000 | yes | Text content displayed by the element. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Text" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "text": "Daily prices.",
  "type": "Text"
}
```

## references/screen-layout.md

# screen-layout

## Contents

- Section

## Section

Arrange child elements in one, two or three columns with an optional title.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| children | array of string; maxItems: 32 | yes | Ordered element ids contained by this section. |
| columns | 1 or 2 or 3; default: 1 | no | Number of section layout columns, defaulting to 1 when omitted. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Section" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "children": [
    "intro"
  ],
  "type": "Section"
}
```

## skill.json

```json
{
  "files": {
    "SKILL.md": "7fac17af19e17f0ce561c62b1eea2e463d9d9f63056995ee8270d4ff8ca415d6",
    "application.schema.json": "171df3ed225c7fdf8a10efc0b934533cfc136d68c8cee2fc69c67acf4725a4e3",
    "examples/ex-01-daily-movers.json": "555ab54c1c19b5ad9344c589eb3ebe5b9eb152e6b378f9019394cd0d7e960233",
    "references/blocks.md": "2883a16b2b8c071fee2b45b553e401e03999fe65ccab4411184315b5108dbb39",
    "references/data.md": "c575b0b8375acc6fbc2d9ece7d896e56044595e7259431f358f9256c231703a0",
    "references/errors.md": "eefa0f01f39616520bf3a5b83c9d26da2c148b62a62547f20e4fd4a4b4767f81",
    "references/ops-finance.md": "219d05ea5101a50216d1de276df30716e30f4e74c364ecd5e3e55e08f95ecd8c",
    "references/ops-shaping.md": "19b7e0696f4ce62b84e1107a2e3586cebcb48ec4129ae46384e223ed4409e769",
    "references/ops-statistics.md": "ebbc8ed9a4b7225121bc49215714498d67b2a044c4db7a67a1fc71e791ac9473",
    "references/ops-time-series.md": "2f9bda02841b2a4829d87e341f30a26ee0f34a48f0257df208767397704b29e9",
    "references/screen-charts.md": "f817aed664884fc738f7fe4a625dc54aea1dc47e48a0af0431277f6546d5cc6b",
    "references/screen-controls.md": "6bd28fa53c1e9a13ea2f0fabfa4b9500a11d9e5a55bb07f3b829b2f3f95ec368",
    "references/screen-display.md": "838f0e950ca11896c9f12d3ed26d7814aa1239459046deab8927e7855253145f",
    "references/screen-layout.md": "30135a5f243ebfaff4823b68011cd418a16c46cb2378ba9e97f6dfe05a1664b5"
  },
  "spec_version": "1.0"
}
```
