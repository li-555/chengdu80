---
name: building-blocks-applications
description: Builds financial applications for the Blocks platform. Use when someone asks for a financial tool, screen, report, alert, monitor or dashboard that should run on Blocks, for example "find today's biggest movers", "watch my bonds for redemption risk" or "summarise overnight announcements for my watchlist". Produces one JSON document that Blocks validates and runs.
---

# Building Blocks applications

## 1. What you produce

A Blocks application is **one JSON document**, not a program. It has six sections:

| Section | Holds |
|---|---|
| `meta` | name, a plain-language description, `spec_version`, an icon |
| `params` | the settings a person can change without rebuilding (a watchlist, a threshold) |
| `data` | what data the application needs: fields and filters only, **never data itself** |
| `compute` | calculation steps, each producing a named result |
| `triggers` | when it runs: by hand, on a schedule, around the market open or close, or as an alert |
| `ui` | what the screen shows, built from a fixed set of screen elements |

The platform reads the document and carries it out. Nothing is compiled or deployed. Set `meta.spec_version` to exactly `"1.0"`.

## 2. How to work

1. Decide what data the request needs. Read `references/data.md` for the available datasets and their exact field names.
2. Pick the calculation steps. Read the operation family files listed in section 9, **only the families you need**.
3. Pick the screen elements. Read the screen family files you need.
4. Write the whole document.
5. Check it with the validator (section 7). Fix exactly what each error names, and check again. Repeat until it passes.

Read a reference file instead of guessing. A guessed parameter name costs a whole check-and-fix round.

## 3. Rules

These rules are checked by the validator. Breaking one makes the document invalid.

- **Use only names that exist.** Every operation, screen element and property is listed in the reference files. There is nothing else. Do not invent one.
- **Data requirements describe data; they never contain it.** A requirement lists the fields it needs with their types. It does not name a dataset: `datasetHint` is only a suggestion, and the person connects the real data when the application is imported.
- **Name fields as the dataset names them** (copy them from `references/data.md`) and give each a `semantic` tag (for example `security_code`, `trade_date`). Matching names connect automatically. A field with a name of your own (as in the example in section 6) still works, but the person must match it by hand when connecting data, so prefer the dataset's names.
- **Filters name settings, never values.** A list of companies is a `params` entry with `"list": true`, and the filter points at it with `"param"`. A literal value in a filter cannot be written: the schema has no place for it.
- **Every step reads results that exist.** A step's `input` is a data requirement `key` or an earlier step `id`. There are no cycles.
- **Every screen element reads a step that exists**, through `from`. Every control names a declared setting through `param`.
- **Prefer, in this order:** a named operation → a formula (`derive`, `filter`) → a SQL step → a custom-code step. A named operation is checked, explained to the person and shown step by step. A SQL or code step that repeats a named operation produces a warning.
- **Keep it small.** Three to eight steps and four to ten screen elements make a good application. A bigger one is not a better one.
- **Include a manual trigger**, so the person can always run it by hand.
- **When the data does not exist, say so.** Do not invent a dataset or a field to make the request fit.

## 4. Writing for the person

The person using the application is not a programmer. `meta.description`, setting labels, element titles and empty-table hints are read by them.

- Short sentences. One idea per sentence. Ordinary words.
- Do not use these words in anything the person reads: `schema`, `JSON`, `document`, `field`, `parameter`, `dataset`, `query`, `SQL`, `validate`, `deploy`, `endpoint`, `API`, `operation`, `compute`, `trigger`, `component`, `expose`, `reference`, `cron`, `index`, `dataframe`, `pipeline`.
  Say "spreadsheet" not "dataset", "column" not "field", "setting" not "parameter", "check" not "validate".
- Explain a finance term the first time it appears, in the same sentence.
- `meta.description` is two or three sentences: what the application does, where its numbers come from, and when it runs.

## 5. The document skeleton

The comments are explanations, not part of the document.

```jsonc
{
  "meta": {"name":"Harbor Prices","description":"Review invented daily price changes.","spec_version":"1.0"}, // object: Name and describe the application and declare its specification version.
  "params": [{"key":"harbor_limit","label":"Rows to show","type":"number","default":10,"min":1,"max":50}], // array of object: Declare settings that controls and calculations can read when the application runs.
  "data": [{"key":"harbor_prices","grain":"daily","fields":[{"name":"harbor_price","type":"number","required":true}]}], // array of object: Declare required fields and optional windows or parameter filters without embedding data rows.
  "compute": [{"id":"harbor_positive","kind":"operation","op":"filter","input":"harbor_prices","params":{"where":"harbor_price > 0"}}], // array of object or object or object or object or object or object or object or object or object or object or object or object or object or object or object or object or object or object or object or object or object: Declare calculation steps whose ids name results available to later steps and the screen.
  "triggers": [{"kind":"manual"}], // array of object or object or object or object: Declare when the application runs, by hand, by schedule or around trading hours.
  "ui": {"root":"harbor_page","elements":{"harbor_page":{"type":"Section","children":["harbor_intro"]},"harbor_intro":{"type":"Text","text":"Invented price overview."}}} // object: Declare a flat map of screen elements and the root section whose children form the screen.
}
```

## 6. A complete example

The meta section names “Daily Movers”: Every trading day, show the companies on your list whose price moved the most.

The params section offers companies to watch, count a move as unusual above, how many to show.

The data section asks for daily closing prices for the companies on the list.

The compute section runs the calculations titled Work out each day's move, Keep only the unusual moves, Biggest movers first and counts the unusual moves.

The triggers section allows running by hand and thirty minutes after market close.

The ui section shows settings, the count of unusual moves and the Biggest movers table.

```json
{
  "$schema": "/api/spec/schema",
  "meta": {
    "name": "Daily Movers",
    "description": "Every trading day, show the companies on your list whose price moved the most.",
    "spec_version": "1.0",
    "icon": "chart-line",
    "provenance": { "created_by": "platform" }
  },
  "params": [
    { "key": "watchlist", "label": "Companies to watch", "type": "text", "list": true, "default": ["600000.SH", "000001.SZ"] },
    { "key": "move_threshold", "label": "Count a move as unusual above", "type": "number", "default": 3, "min": 0, "max": 50, "step": 0.5, "unit": "%" },
    { "key": "top_n", "label": "How many to show", "type": "number", "default": 10, "min": 1, "max": 50, "step": 1 }
  ],
  "data": [
    {
      "key": "prices",
      "purpose": "daily closing prices for the companies on the list",
      "grain": "daily",
      "datasetHint": "tushare:daily",
      "fields": [
        { "name": "code", "type": "text", "required": true, "semantic": "security_code" },
        { "name": "d", "type": "date", "required": true, "semantic": "trade_date" },
        { "name": "px", "type": "number", "required": true },
        { "name": "prev_px", "type": "number", "required": false }
      ],
      "window": { "field": "d", "lookbackDays": 30 },
      "filters": [{ "field": "code", "op": "in", "param": "watchlist" }]
    }
  ],
  "compute": [
    {
      "id": "with_change",
      "kind": "operation",
      "op": "derive",
      "input": "prices",
      "title": "Work out each day's move",
      "params": { "columns": { "pct_move": "(px - prev_px) / prev_px * 100" } }
    },
    {
      "id": "unusual",
      "kind": "operation",
      "op": "filter",
      "input": "with_change",
      "title": "Keep only the unusual moves",
      "key": true,
      "params": { "where": "abs(pct_move) >= $params.move_threshold" }
    },
    {
      "id": "movers",
      "kind": "operation",
      "op": "sort_limit",
      "input": "unusual",
      "title": "Biggest movers first",
      "key": true,
      "params": { "by": [{ "col": "pct_move", "dir": "desc" }], "limit": { "param": "top_n" } }
    },
    {
      "id": "mover_count",
      "kind": "operation",
      "op": "aggregate",
      "input": "unusual",
      "params": { "by": [], "metrics": [{ "fn": "count", "as": "n" }] }
    }
  ],
  "triggers": [
    { "kind": "manual" },
    { "kind": "market", "at": "close", "offsetMinutes": 30 }
  ],
  "ui": {
    "root": "page",
    "elements": {
      "page": { "type": "Section", "columns": 1, "children": ["controls", "headline", "table"] },
      "controls": { "type": "Section", "title": "Settings", "columns": 3, "children": ["w", "t", "n", "run"] },
      "w": { "type": "TextInput", "param": "watchlist", "label": "Companies", "list": true },
      "t": { "type": "NumberInput", "param": "move_threshold", "label": "Unusual above (%)" },
      "n": { "type": "NumberInput", "param": "top_n", "label": "How many to show" },
      "run": { "type": "RunButton", "label": "Run" },
      "headline": { "type": "Metric", "label": "Companies with an unusual move", "from": "mover_count", "value": "n", "format": "integer" },
      "table": {
        "type": "Table",
        "title": "Biggest movers",
        "from": "movers",
        "columns": [
          { "col": "code", "label": "Company", "format": "text" },
          { "col": "d", "label": "Date", "format": "date" },
          { "col": "px", "label": "Close", "format": "money" },
          { "col": "pct_move", "label": "Move", "format": "percent" }
        ],
        "emptyHint": "No company on your list moved more than the threshold."
      }
    }
  }
}
```

## 7. Checking your work

The validator is the authority. Run it on your document:

```
npm run validate -- app.json
```

or send the document to `POST /api/validate` on a running Blocks server. It answers with a report: `valid`, and a list of `errors` and `warnings`. Each error has a `pointer` (where in the document), a `code`, a `message`, and a `hint` saying how to fix it. **Follow the hint.**

The validator checks in stages: first the shape of the document, then the names it refers to, then formulas and limits. It stops at the first stage that fails. So fixing every reported error can reveal new ones from the next stage. Expect more than one round; that is normal.

`application.schema.json` (JSON Schema, draft 2020-12) checks structure and types only. The validator also checks references, formulas, SQL and limits. A document that passes the schema can still fail the validator.

### A repair, start to finish

Three broken fragments:

```json
{
  "Table": {
    "columns": [
      {
        "col": "code",
        "format": "text",
        "label": "Company"
      },
      {
        "col": "d",
        "format": "date",
        "label": "Date"
      },
      {
        "col": "px",
        "format": "money",
        "label": "Close"
      },
      {
        "col": "pct_move",
        "format": "percent",
        "label": "Move"
      }
    ],
    "emptyHint": "No company on your list moved more than the threshold.",
    "from": "moverz",
    "title": "Biggest movers",
    "type": "Table"
  },
  "filter": {
    "id": "unusual",
    "input": "with_change",
    "key": true,
    "kind": "operation",
    "op": "filter",
    "params": {
      "where": "abs(pct_move) >= $params.move_treshold"
    },
    "title": "Keep only the unusual moves"
  },
  "step": {
    "id": "movers",
    "input": "unusual",
    "key": true,
    "kind": "operation",
    "op": "top_n",
    "params": {
      "by": [
        {
          "col": "pct_move",
          "dir": "desc"
        }
      ],
      "limit": {
        "param": "top_n"
      }
    },
    "title": "Biggest movers first"
  }
}
```


Actual errors from the first check:

```json
[
  {
    "code": "E_SCHEMA_ENUM",
    "hint": "Use one of: filter, derive, join, aggregate, sort_limit, window, lag_change, rank, zscore, resample, and 7 more.",
    "message": "A step of kind \"operation\" needs a supported operation name.",
    "pointer": "/compute/2/op"
  }
]
```


Fix 1: change `top_n` back to `sort_limit`.

Actual errors after fixing the step name:

```json
[
  {
    "code": "E_REF_UNKNOWN_PARAM",
    "hint": "Did you mean \"move_threshold\"?",
    "message": "The formula uses a setting called \"move_treshold\", which is not declared.",
    "pointer": "/compute/1/params/where"
  },
  {
    "code": "E_REF_UNKNOWN_RELATION",
    "hint": "Did you mean \"movers\"?",
    "message": "Element \"table\" shows a table called \"moverz\", which nothing produces.",
    "pointer": "/ui/elements/table/from"
  }
]
```


Fix 2: change `$params.move_treshold` back to `$params.move_threshold`.

Fix 3: change the Table's `from` from `moverz` back to `movers`.

Checked again: valid

## 8. Importing and running

Save the document as `app.json`. In Blocks, open **My Apps → Import an application** and choose the file. Blocks checks it, then asks the person to connect any data it needs (a dataset from the catalogue, or a spreadsheet they upload). A requirement waiting to be connected is normal, not an error. Then press **Run**.

## 9. Where to read more

Read only the file that answers your question. Each file starts with its own contents list.

| File | Read it when | Contains |
| --- | --- | --- |
| [references/ops-shaping.md](references/ops-shaping.md) | You need shaping calculations | aggregate, derive, filter, join, pivot, sort_limit |
| [references/ops-time-series.md](references/ops-time-series.md) | You need time series calculations | adjust_price, lag_change, resample, window |
| [references/ops-statistics.md](references/ops-statistics.md) | You need statistics calculations | correlate, describe, rank, regress, zscore |
| [references/ops-finance.md](references/ops-finance.md) | You need finance calculations | ai, factor, irr |
| [references/screen-display.md](references/screen-display.md) | You need display on screen | Callout, List, Metric, Table, Text |
| [references/screen-charts.md](references/screen-charts.md) | You need charts on screen | Chart |
| [references/screen-controls.md](references/screen-controls.md) | You need controls on screen | DateRangeInput, NumberInput, RunButton, SelectInput, TextInput |
| [references/screen-layout.md](references/screen-layout.md) | You need layout on screen | Section |
| [references/blocks.md](references/blocks.md) | You need application sections or special step kinds | meta, params, data, triggers, sql, expression, ai, code, alert, manual, market, schedule |
| [references/data.md](references/data.md) | You need available tables or spreadsheet uploads | tushare:adj_factor, tushare:balancesheet, tushare:cashflow, tushare:cb_basic, tushare:cb_daily, tushare:cb_price_chg, tushare:cb_redeem, tushare:cn_cpi, tushare:cn_lpr, tushare:daily, tushare:daily_basic, tushare:disclosure, tushare:dividend, tushare:etf_basic, tushare:etf_fund_daily, tushare:etf_index, tushare:etf_share, tushare:factor_list, tushare:fina_indicator, tushare:fund_basic, tushare:fund_nav, tushare:fund_portfolio, tushare:income, tushare:index_daily, tushare:index_member, tushare:limit_list_d, tushare:limit_list_d_down, tushare:margin, tushare:moneyflow_hsgt, tushare:new_share, tushare:pledge_stat, tushare:sge_daily, tushare:stk_managers, tushare:stock_basic, tushare:top10_holders, tushare:trade_cal, tushare:yc_cb |
| [references/errors.md](references/errors.md) | A check reports an error or warning | E_BAD_CRON, E_BAD_EXPRESSION, E_BAD_SQL, E_CYCLE, E_ELEMENT_CYCLE, E_INTERNAL, E_LIMIT_AI_STEPS, E_LIMIT_CODE_STEPS, E_LIMIT_ELEMENTS, E_LIMIT_NESTING, E_LIMIT_STEPS, E_NO_TRIGGER, E_PARSE_EMPTY, E_PARSE_JSON, E_PARSE_NOT_OBJECT, E_REF_DUPLICATE_NAME, E_REF_UNKNOWN_ELEMENT, E_REF_UNKNOWN_PARAM, E_REF_UNKNOWN_RELATION, E_REF_UNKNOWN_ROOT, E_SCHEMA_CUSTOM, E_SCHEMA_ENUM, E_SCHEMA_PATTERN, E_SCHEMA_RANGE, E_SCHEMA_REQUIRED, E_SCHEMA_SPEC_VERSION, E_SCHEMA_TYPE, E_SCHEMA_UNION, E_SCHEMA_UNKNOWN_KEY, E_SELF_REFERENCE, E_TOO_MANY_ERRORS, W_CODE_COULD_BE_OPERATION, W_DEAD_CONTROL, W_NO_MANUAL_TRIGGER, W_ORPHAN_ELEMENT, W_SHORT_HISTORY, W_SQL_COULD_BE_OPERATION, W_SURROUNDING_TEXT, W_UNKNOWN_ICON, W_UNUSED_DATA, W_UNUSED_PARAM, W_UNUSED_STEP |

## 10. The five things that most often go wrong

1. **A field name that is not in the dataset.** Copy names from `references/data.md`.
2. **A parameter name guessed instead of read.** Open the family file for that operation.
3. **A screen element reading a step that does not exist,** often after a step was renamed. Check every `from`.
4. **A control whose setting is never used.** The validator warns: the control would do nothing.
5. **A literal value where a setting is expected.** Put the value in `params` and point at it.
