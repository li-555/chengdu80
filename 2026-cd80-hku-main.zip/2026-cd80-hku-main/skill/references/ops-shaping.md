# ops-shaping

## Contents

- aggregate
- derive
- filter
- join
- pivot
- sort_limit

## aggregate

Return one row per group with the grouping columns and named summary columns.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| by | array of string; maxItems: 8 | yes | Grouping columns, with an empty array producing one summary across the whole input. |
| metrics | array of object; minItems: 1; maxItems: 32 | yes | Summary definitions producing one output column each per group. |
| metrics[].as | string; minLength: 1; maxLength: 128 | yes | Name of the output column holding this summary. |
| metrics[].fn | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function to apply, with stddev and var using sample statistics. |
| metrics[].of | string; minLength: 1; maxLength: 128 | no | Input column to summarise, required except for count, which counts all rows when omitted. |
| metrics[].p | number; minimum: 0; maximum: 1 | no | Quantile fraction from 0 to 1, required for quantile and unused by other summary functions. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "aggregate",
  "params": {
    "by": [
      "harbor_sector"
    ],
    "metrics": [
      {
        "as": "harbor_average",
        "fn": "mean",
        "of": "harbor_price"
      }
    ]
  }
}
```


## derive

Keep input columns and append the named calculated columns.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| columns | object | yes | Map from each new output column name to the expression calculated for every input row. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "derive",
  "params": {
    "columns": {
      "harbor_gain": "harbor_price - harbor_cost"
    }
  }
}
```


## filter

Keep matching rows with all input columns unchanged.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| where | string; minLength: 1; maxLength: 2000 | yes | Boolean expression that keeps only input rows for which it is true. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "filter",
  "params": {
    "where": "harbor_price > 20"
  }
}
```


## join

Combine matching rows, retaining left columns and non-key right columns, with right relation suffixes and numbered suffixes for name collisions.

Inputs: 2. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| asof_on | [string, string]; minItems: 2; maxItems: 2 | no | Ordered matching columns as [column in the input table, column in the right table], required for asof and adding no ordered match when omitted for other join kinds. |
| direction | "backward" / "forward" / "nearest" | no | As-of matching direction, defaulting to backward for the latest right row at or before the input row, with forward choosing the earliest at or after it and nearest currently unsupported. |
| how | "inner" / "left" / "asof" | yes | Join kind, retaining matching rows for inner or all input rows for left and asof. |
| on | array of [string, string]; minItems: 1; maxItems: 8 | yes | Pairs of equality keys in the order [column in the input table, column in the right table]. |
| right | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the second table, while the step input names the first table. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "join",
  "params": {
    "how": "left",
    "on": [
      [
        "harbor_code",
        "harbor_code"
      ]
    ],
    "right": "harbor_sectors"
  }
}
```


## pivot

Return index columns and one summary column per category in the pivot column.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| agg | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function for each pivot cell, with quantile currently unsupported. |
| index | array of string; minItems: 1; maxItems: 4 | yes | Columns identifying each output row and grouping the pivoted values. |
| on | string; minLength: 1; maxLength: 128 | yes | Input category column whose distinct values become output columns. |
| values | string; minLength: 1; maxLength: 128 | yes | Input column whose values are summarised in each pivot cell. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "pivot",
  "params": {
    "agg": "mean",
    "index": [
      "harbor_day"
    ],
    "on": "harbor_sector",
    "values": "harbor_price"
  }
}
```


## sort_limit

Sort rows and optionally skip or limit them while retaining all input columns.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| by | array of object; minItems: 1; maxItems: 8 | yes | Sort columns and directions in priority order. |
| by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| limit | integer or object | no | Maximum number of output rows, supplied as an integer or parameter reference, with no row limit when omitted. |
| limit.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| offset | integer or object | no | Number of sorted rows to skip, supplied as an integer or parameter reference, defaulting to zero when omitted. |
| offset.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "sort_limit",
  "params": {
    "by": [
      {
        "col": "harbor_price",
        "dir": "desc"
      }
    ],
    "limit": 10,
    "offset": 0
  }
}
```
