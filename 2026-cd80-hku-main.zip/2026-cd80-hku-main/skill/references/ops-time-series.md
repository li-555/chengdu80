# ops-time-series

## Contents

- adjust_price
- lag_change
- resample
- window

## adjust_price

Keep input columns and replace selected prices under their original names using cumulative split and dividend adjustment factors.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| base_date | string; maxLength: 10; pattern: "^\\d{4}-\\d{2}-\\d{2}$" | no | Forward adjustment cutoff in YYYY-MM-DD form, using the latest factor on or before this date or the latest available factor date per security when omitted and disallowed for backward adjustment. |
| date | [string, string]; minItems: 2; maxItems: 2 | yes | Trading date columns in the order [column in the input table, column in the factor table], matching the latest factor on or before each input date. |
| factor_col | string; minLength: 1; maxLength: 128 | yes | Column in the factor table containing the cumulative multiplicative adjustment factor. |
| factor_table | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the cumulative adjustment factor table, distinct from the input price table. |
| key | [string, string]; minItems: 2; maxItems: 2 | yes | Security key columns in the order [column in the input table, column in the factor table]. |
| mode | "forward" / "backward" | yes | Adjustment direction, with backward multiplying prices by their dated factor and forward dividing that product by the base factor, using the latest factor date for each security when base_date is omitted. |
| price_cols | array of string; minItems: 1; maxItems: 8 | yes | Input price columns replaced by adjusted values under the same names and in the same price units. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "adjust_price",
  "params": {
    "base_date": "2026-01-30",
    "date": [
      "harbor_day",
      "harbor_date"
    ],
    "factor_col": "harbor_multiplier",
    "factor_table": "harbor_adjustments",
    "key": [
      "harbor_code",
      "harbor_security"
    ],
    "mode": "forward",
    "price_cols": [
      "harbor_price"
    ]
  }
}
```


## lag_change

Keep input columns and append a named difference, fractional change or logarithmic change from an earlier row.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the change. |
| mode | "diff" / "pct" / "log" | yes | Change calculation, using current minus earlier for diff, current divided by earlier minus one for pct as a fraction, or the natural logarithm of their positive ratio for log. |
| of | string; minLength: 1; maxLength: 128 | yes | Input column compared with its earlier value. |
| order_by | array of object; minItems: 1; maxItems: 8 | yes | Columns and directions determining which rows are earlier. |
| order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| partition_by | array of string; maxItems: 4 | no | Columns separating independent histories, with all rows in one history when omitted. |
| periods | integer or object | yes | Number of ordered rows to look back within the partition, supplied as an integer or parameter reference. |
| periods.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "lag_change",
  "params": {
    "as": "harbor_change",
    "mode": "pct",
    "of": "harbor_price",
    "order_by": [
      {
        "col": "harbor_day",
        "dir": "asc"
      }
    ],
    "partition_by": [
      "harbor_code"
    ],
    "periods": 1
  }
}
```


## resample

Return grouping columns, the original date column set to each period start, and named summary columns.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| by | array of string; maxItems: 4 | no | Additional grouping columns kept separate within each period, with no additional grouping when omitted. |
| date_col | string; minLength: 1; maxLength: 128 | yes | Input date column whose name is preserved in the output and whose value becomes the first day of each period. |
| metrics | array of object; minItems: 1; maxItems: 32 | yes | Summary definitions calculated for each period and additional group. |
| metrics[].as | string; minLength: 1; maxLength: 128 | yes | Name of the output column holding this summary. |
| metrics[].fn | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function to apply, with stddev and var using sample statistics. |
| metrics[].of | string; minLength: 1; maxLength: 128 | no | Input column to summarise, required except for count, which counts all rows when omitted. |
| metrics[].p | number; minimum: 0; maximum: 1 | no | Quantile fraction from 0 to 1, required for quantile and unused by other summary functions. |
| to | "week" / "month" / "quarter" / "year" | yes | Calendar period to aggregate into, with weeks starting on Monday. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "resample",
  "params": {
    "by": [
      "harbor_code"
    ],
    "date_col": "harbor_day",
    "metrics": [
      {
        "as": "harbor_average",
        "fn": "mean",
        "of": "harbor_price"
      }
    ],
    "to": "month"
  }
}
```


## window

Keep input columns and append a named running or rolling summary over the ordered frame.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the window calculation. |
| fn | "sum" / "mean" / "min" / "max" / "count" / "stddev" / "first" / "last" | yes | Calculation applied within each frame, with stddev using sample standard deviation and count counting non-null values. |
| frame | object | yes | Inclusive frame around the current row using row counts or ordered-value distances. |
| frame.following | integer or object | yes | Distance after the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps. |
| frame.following.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| frame.kind | "rows" / "range" | yes | Frame measure, using row counts for rows or ordered-value distances for range, measured in days for date or timestamp order columns. |
| frame.preceding | integer or object | yes | Distance before the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps. |
| frame.preceding.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| of | string; minLength: 1; maxLength: 128 | yes | Input column whose values are calculated within each frame. |
| order_by | array of object; minItems: 1; maxItems: 8 | yes | Columns and directions defining row order within each partition. |
| order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| partition_by | array of string; maxItems: 4 | no | Columns separating independent row groups, with all rows in one group when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "window",
  "params": {
    "as": "harbor_rolling",
    "fn": "mean",
    "frame": {
      "following": 0,
      "kind": "rows",
      "preceding": 4
    },
    "of": "harbor_price",
    "order_by": [
      {
        "col": "harbor_day",
        "dir": "asc"
      }
    ],
    "partition_by": [
      "harbor_code"
    ]
  }
}
```
