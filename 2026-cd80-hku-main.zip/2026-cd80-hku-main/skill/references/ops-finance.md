# ops-finance

## Contents

- ai
- factor
- irr

## ai

Return model responses as a typed table for the whole input or individual rows using the declared text, enum or object output shape.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| instructions | string; minLength: 1; maxLength: 4000 | yes | Instructions for interpreting the input rows, containing 1 to 4000 characters. |
| max_input_chars | integer; minimum: 100; maximum: 60000; default: 20000 | no | Maximum input text length in characters, defaulting to 20000 when omitted. |
| max_rows | integer or object; default: 50 | no | Maximum input row count as an integer or parameter reference, defaulting to 50 when omitted. |
| max_rows.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| mode | "whole" / "per_row" | yes | Requested processing scope, either the whole input or each row separately. |
| on_error | "null" / "fail"; default: "null" | no | Declared error policy, either null or fail, defaulting to null when omitted. |
| output | object or object or object | yes | Declared result shape, either text, an enumerated string, or an object of typed fields. |
| output.choice 1.kind | "text" | yes | Result shape discriminator selecting text, enum, or object. |
| output.choice 2.kind | "enum" | yes | Result shape discriminator selecting text, enum, or object. |
| output.choice 2.values | array of string; minItems: 2; maxItems: 32 | yes | Allowed non-empty string result values for an enum output, containing 2 to 32 entries. |
| output.choice 3.fields | object | yes | Map of output column names to string, number, or boolean types, containing 1 to 32 fields. |
| output.choice 3.kind | "object" | yes | Result shape discriminator selecting text, enum, or object. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "ai",
  "params": {
    "instructions": "Summarize the pattern in harbor_price and harbor_volume.",
    "max_input_chars": 20000,
    "max_rows": 50,
    "mode": "whole",
    "on_error": "null",
    "output": {
      "fields": {
        "harbor_summary": "string"
      },
      "kind": "object"
    }
  }
}
```


## factor

Return one row per security on its latest eligible day with ts_code, trade_date and a column named after the chosen market factor.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as_of | string; maxLength: 10; pattern: "^\\d{4}-\\d{2}-\\d{2}$" | no | Latest eligible trading date in YYYY-MM-DD form, returning each security latest row on or before it or its latest available row when omitted. |
| factor | string; minLength: 1; maxLength: 60 | yes | Name of a supported market measure to calculate from the input daily rows. |
| universe | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | no | Data requirement key or step id whose ts_code column restricts the securities, with no universe restriction when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "factor",
  "params": {
    "as_of": "2026-01-30",
    "factor": "momentum_20d",
    "universe": "harbor_universe"
  }
}
```

Supported factors (every factor also needs ts_code and trade_date):

| Factor | Meaning | Needed columns |
| --- | --- | --- |
| avg_amount_20d | average daily traded value over the last 20 trading days | amount |
| avg_volume_20d | average daily volume over the last 20 trading days | vol |
| book_to_price | book value per unit of price (1 / P/B), blank when book value is negative | pb |
| dividend_yield | dividends of the last 12 months per unit of price, as a fraction | dv_ttm |
| earnings_yield | earnings per unit of price (1 / P/E), blank when earnings are negative | pe |
| high_gap_250d | how far the price sits below its highest close of the last 250 trading days | close |
| log_size | natural logarithm of total market value | total_mv |
| ma_gap_20d | how far the price sits above its 20-day average | close |
| ma_gap_60d | how far the price sits above its 60-day average | close |
| momentum_120d | price change over the last 120 trading days | close |
| momentum_20d | price change over the last 20 trading days | close |
| momentum_250d | price change over the last 250 trading days | close |
| momentum_5d | price change over the last 5 trading days | close |
| momentum_60d | price change over the last 60 trading days | close |
| turnover_20d | average daily turnover rate over the last 20 trading days | turnover_rate |
| volatility_20d | yearly-scaled spread of daily returns over the last 20 trading days | close |
| volatility_60d | yearly-scaled spread of daily returns over the last 60 trading days | close |
| volume_ratio_5_20d | average volume of the last 5 days divided by that of the last 20 | vol |
## irr

Return one annual break-even rate as a scalar value, read from the single irr column.

Inputs: 1. Output shape: scalar.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| amount_col | string; minLength: 1; maxLength: 128 | yes | Cash flow amount column in a consistent monetary unit, with payments out negative and receipts positive. |
| date_col | string; minLength: 1; maxLength: 128 | yes | Cash flow date column used to count elapsed days over a 365-day year. |
| guess | number | no | Initial annual rate as a fraction for the iterative solver, defaulting to 0.1 when omitted. |
| max_iter | integer; minimum: 1; maximum: 100; default: 100 | no | Maximum number of Newton iterations before the fallback solver, defaulting to 100 when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "irr",
  "params": {
    "amount_col": "harbor_payment",
    "date_col": "harbor_day",
    "guess": 0.1,
    "max_iter": 100
  }
}
```
