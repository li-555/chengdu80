# ops-statistics

## Contents

- correlate
- describe
- rank
- regress
- zscore

## correlate

Return a long table with one row per distinct column pair and columns col_a, col_b, corr and n.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| columns | array of string; minItems: 2; maxItems: 32 | yes | Input columns for which each distinct pair receives a correlation result. |
| method | "pearson" / "spearman" | yes | Correlation method, using raw values for pearson or average ranks for spearman. |
| min_periods | integer; minimum: 2; maximum: 100000 | no | Minimum count of rows with both values present before returning a correlation, with no additional count threshold when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "correlate",
  "params": {
    "columns": [
      "harbor_price",
      "harbor_volume"
    ],
    "method": "pearson",
    "min_periods": 5
  }
}
```


## describe

Return a long table with one row per numeric column and columns column, count, mean, std, min, q25, median, q75 and max.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| columns | array of string; maxItems: 64 | no | Numeric input columns to summarise, defaulting to all numeric input columns when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "describe",
  "params": {
    "columns": [
      "harbor_price",
      "harbor_volume"
    ]
  }
}
```


## rank

Keep input columns and append a named rank, dense rank, row number or percentile within each group.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the rank. |
| by | string; minLength: 1; maxLength: 128 | yes | Input column whose values determine the rank. |
| direction | "asc" / "desc" | yes | Ascending or descending order used to assign ranks. |
| method | "rank" / "dense" / "row_number" / "percentile" | yes | Ranking rule, using gaps for rank, no gaps for dense, distinct row numbers for row_number, or a fraction from 0 to 1 for percentile. |
| within | array of string; maxItems: 4 | no | Columns separating independent ranking groups, with all rows ranked together when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "rank",
  "params": {
    "as": "harbor_rank",
    "by": "harbor_price",
    "direction": "desc",
    "method": "dense",
    "within": [
      "harbor_sector"
    ]
  }
}
```


## regress

Return a long table of fitted intercept and predictor terms with grouping columns plus term, coefficient, r2 and n.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| by | array of string; maxItems: 4 | no | Columns separating independent regression groups, with one fit across the input when omitted. |
| x | array of string; minItems: 1; maxItems: 16 | yes | Predictor input columns for the regression, allowing 1 to 16 names in the schema. |
| y | string; minLength: 1; maxLength: 128 | yes | Dependent input column to fit. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "regress",
  "params": {
    "by": [
      "harbor_sector"
    ],
    "x": [
      "harbor_market",
      "harbor_size"
    ],
    "y": "harbor_return"
  }
}
```


## zscore

Keep input columns and append a named distance from the mean in sample standard deviations, optionally over a full rolling window.

Inputs: 1. Output shape: table.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the dimensionless standard score. |
| of | string; minLength: 1; maxLength: 128 | yes | Input column standardised as its value minus the mean divided by sample standard deviation. |
| order_by | array of object; minItems: 1; maxItems: 8 | no | Columns and directions defining rolling row order, required when window is set and ignored otherwise. |
| order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| window | integer or object | no | Rolling frame size in rows including the current row, supplied as an integer or parameter reference, requiring that many non-null values and using the entire group when omitted. |
| window.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| within | array of string; maxItems: 4 | no | Columns separating independent standardisation groups, with all rows in one group when omitted. |

Example step:

```json
{
  "id": "result",
  "input": "source",
  "kind": "operation",
  "op": "zscore",
  "params": {
    "as": "harbor_score",
    "of": "harbor_price",
    "order_by": [
      {
        "col": "harbor_day",
        "dir": "asc"
      }
    ],
    "window": 20,
    "within": [
      "harbor_code"
    ]
  }
}
```
