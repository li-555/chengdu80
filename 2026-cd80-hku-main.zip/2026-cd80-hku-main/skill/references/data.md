# data

## Contents

- tushare:adj_factor
- tushare:balancesheet
- tushare:cashflow
- tushare:cb_basic
- tushare:cb_daily
- tushare:cb_price_chg
- tushare:cb_redeem
- tushare:cn_cpi
- tushare:cn_lpr
- tushare:daily
- tushare:daily_basic
- tushare:disclosure
- tushare:dividend
- tushare:etf_basic
- tushare:etf_fund_daily
- tushare:etf_index
- tushare:etf_share
- tushare:factor_list
- tushare:fina_indicator
- tushare:fund_basic
- tushare:fund_nav
- tushare:fund_portfolio
- tushare:income
- tushare:index_daily
- tushare:index_member
- tushare:limit_list_d
- tushare:limit_list_d_down
- tushare:margin
- tushare:moneyflow_hsgt
- tushare:new_share
- tushare:pledge_stat
- tushare:sge_daily
- tushare:stk_managers
- tushare:stock_basic
- tushare:top10_holders
- tushare:trade_cal
- tushare:yc_cb

Choose a CSV or XLSX spreadsheet in the data connection screen and upload it. Review the detected column names and types, then connect the matching columns to the application.
## tushare:adj_factor

Name: Adjustment Factor.

Coverage: 1990-12-19 to 2026-10-10.

| Name | Type |
| --- | --- |
| adj_factor | number |
| trade_date | date |
| ts_code | text |
## tushare:balancesheet

Name: Balance Sheet.

Coverage: 2020-01-01 to 2026-06-30.

| Name | Type |
| --- | --- |
| accounts_receiv | number |
| ann_date | date |
| comp_type | number |
| end_date | date |
| f_ann_date | date |
| fix_assets | number |
| goodwill | number |
| intan_assets | number |
| inventories | number |
| money_cap | number |
| report_type | number |
| total_assets | number |
| total_cur_assets | number |
| total_cur_liab | number |
| total_hldr_eqy_exc_min_int | number |
| total_liab | number |
| total_nca | number |
| total_ncl | number |
| ts_code | text |
## tushare:cashflow

Name: Cash Flow Statement.

Coverage: 2020-01-01 to 2026-06-30.

| Name | Type |
| --- | --- |
| ann_date | date |
| c_cash_equ_end_period | number |
| comp_type | number |
| end_date | date |
| f_ann_date | date |
| free_cashflow | number |
| n_cash_flows_fnc_act | number |
| n_cashflow_act | number |
| n_cashflow_inv_act | number |
| report_type | number |
| ts_code | text |
## tushare:cb_basic

Name: Convertible Bond Basic Info.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| bond_full_name | text |
| bond_short_name | text |
| conv_end_date | date |
| conv_price | number |
| conv_start_date | date |
| coupon_rate | number |
| issue_rating | text |
| issue_size | number |
| list_date | date |
| maturity | number |
| maturity_date | date |
| newest_rating | text |
| par | number |
| rate_type | text |
| stk_code | text |
| stk_short_name | text |
| ts_code | text |
## tushare:cb_daily

Name: Convertible Bond Daily Data.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| amount | number |
| bond_over_rate | number |
| bond_value | number |
| cb_over_rate | number |
| cb_value | number |
| change | number |
| close | number |
| high | number |
| low | number |
| open | number |
| pct_chg | number |
| pre_close | number |
| trade_date | date |
| ts_code | text |
| vol | number |
## tushare:cb_price_chg

Name: CB Conversion Price Changes.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| bond_short_name | text |
| change_date | date |
| conversion_price_after | number |
| conversion_price_before | number |
| initial_conversion_price | number |
| publication_date | date |
| ticker | text |
## tushare:cb_redeem

Name: Convertible Bond Redemption.

Coverage: 2015-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| ann_date | date |
| call_amount | number |
| call_date | date |
| call_price | number |
| call_price_tax | number |
| call_reg_date | date |
| call_type | text |
| call_vol | number |
| is_call | text |
| payment_date | date |
| ts_code | text |
## tushare:cn_cpi

Name: China CPI.

Coverage: 2015-01-01 to 2026-09-30.

| Name | Type |
| --- | --- |
| cnt_mom | number |
| cnt_val | number |
| cnt_yoy | number |
| month | date |
| nt_accu | number |
| nt_mom | number |
| nt_val | number |
| nt_yoy | number |
| town_mom | number |
| town_val | number |
| town_yoy | number |
## tushare:cn_lpr

Name: China Loan Prime Rate.

Coverage: 2015-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| 1y | number |
| 5y | number |
| date | date |
## tushare:daily

Name: Daily Stock Prices.

Coverage: 1990-12-19 to 2026-10-13.

| Name | Type |
| --- | --- |
| amount | number |
| change | number |
| close | number |
| high | number |
| low | number |
| open | number |
| pct_chg | number |
| pre_close | number |
| trade_date | date |
| ts_code | text |
| vol | number |
## tushare:daily_basic

Name: Daily Basic Indicators.

Coverage: 2004-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| circ_mv | number |
| close | number |
| dv_ratio | number |
| dv_ttm | number |
| float_share | number |
| free_share | number |
| pb | number |
| pe | number |
| pe_ttm | number |
| ps | number |
| ps_ttm | number |
| total_mv | number |
| total_share | number |
| trade_date | date |
| ts_code | text |
| turnover_rate | number |
| turnover_rate_f | number |
| volume_ratio | number |
## tushare:disclosure

Name: Announcements.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| announcement_date | date |
| announcement_title | text |
| security_name | text |
| ticker | text |
| url | text |
## tushare:dividend

Name: Dividend Data.

Coverage: 2015-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| ann_date | date |
| cash_div | number |
| cash_div_tax | number |
| div_proc | text |
| end_date | date |
| ex_date | date |
| pay_date | date |
| record_date | date |
| stk_div | number |
| ts_code | text |
## tushare:etf_basic

Name: ETF Basic Information.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| cname | text |
| etf_type | text |
| exchange | text |
| index_code | text |
| index_name | text |
| list_date | date |
| list_status | text |
| mgr_name | text |
| mgt_fee | number |
| name | text |
| setup_date | date |
| ts_code | text |
## tushare:etf_fund_daily

Name: ETF Fund Daily Indicators.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| close | number |
| discount | number |
| trade_date | date |
| ts_code | text |
| unit_nav | number |
| vol | number |
## tushare:etf_index

Name: ETF Tracking Index Info.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| index_code | text |
| index_name | text |
| index_type | text |
| ts_code | text |
## tushare:etf_share

Name: ETF Share Size.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| float_share | number |
| total_share | number |
| trade_date | date |
| ts_code | text |
## tushare:factor_list

Name: Available Factor List.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| asset_class | text |
| factor_category | text |
| factor_description | text |
| factor_name | text |
## tushare:fina_indicator

Name: Financial Indicators.

Coverage: 2020-01-01 to 2026-06-30.

| Name | Type |
| --- | --- |
| assets_turn | number |
| bps | number |
| current_ratio | number |
| debt_to_assets | number |
| end_date | date |
| eps | number |
| gross_margin | number |
| netprofit_margin | number |
| ocfps | number |
| quick_ratio | number |
| roa | number |
| roe | number |
| ts_code | text |
## tushare:fund_basic

Name: Fund Basic Information.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| benchmark | text |
| c_fee | number |
| custodian | text |
| found_date | date |
| fund_type | text |
| invest_type | text |
| issue_amount | number |
| list_date | date |
| m_fee | number |
| management | text |
| name | text |
| status | text |
| ts_code | text |
| type | text |
## tushare:fund_nav

Name: Fund NAV.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| accum_nav | number |
| adj_nav | number |
| ann_date | date |
| nav_date | date |
| total_netasset | number |
| ts_code | text |
| unit_nav | number |
| update_flag | number |
## tushare:fund_portfolio

Name: Fund Portfolio Holdings.

Coverage: 2024-01-01 to 2026-06-30.

| Name | Type |
| --- | --- |
| amount | number |
| ann_date | date |
| end_date | date |
| mkv | number |
| stk_float_ratio | number |
| stk_mkv_ratio | number |
| symbol | text |
| ts_code | text |
## tushare:income

Name: Income Statement.

Coverage: 2020-01-01 to 2026-06-30.

| Name | Type |
| --- | --- |
| admin_exp | number |
| ann_date | date |
| basic_eps | number |
| comp_type | number |
| diluted_eps | number |
| ebit | number |
| ebitda | number |
| end_date | date |
| f_ann_date | date |
| fin_exp | number |
| invest_income | number |
| n_income | number |
| n_income_attr_p | number |
| operate_profit | number |
| report_type | number |
| revenue | number |
| sell_exp | number |
| total_cogs | number |
| total_profit | number |
| total_revenue | number |
| ts_code | text |
## tushare:index_daily

Name: Index Daily Data.

Coverage: 1990-12-19 to 2026-10-10.

| Name | Type |
| --- | --- |
| amount | number |
| change | number |
| close | number |
| high | number |
| low | number |
| open | number |
| pct_chg | number |
| pre_close | number |
| trade_date | date |
| ts_code | text |
| vol | number |
## tushare:index_member

Name: Index Constituent Members.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| in_date | date |
| is_new | text |
| l1_code | text |
| l1_name | text |
| name | text |
| out_date | date |
| ts_code | text |
## tushare:limit_list_d

Name: Limit-Up Events.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| amount | number |
| code | text |
| high | number |
| is_limit_up | number |
| last_close | number |
| limit_down | number |
| limit_time | text |
| limit_up | number |
| low | number |
| name | text |
| open | number |
| price | number |
| trade_date | date |
## tushare:limit_list_d_down

Name: Limit-Down Events.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| amount | number |
| change | number |
| change_rate | number |
| code | text |
| limit_price | number |
| name | text |
| pre_close_price | number |
| price | number |
| trade_date | date |
| volume | number |
## tushare:margin

Name: Margin Trading Data.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| FINBALANCE | number |
| FINBUYAMT | number |
| FINREPAYAMT | number |
| MRGGBAL | number |
| MRGNREPAYAMT | number |
| MRGNSELLAMT | number |
| SECODE | text |
| SYMBOL | text |
| TRADEDATE | date |
## tushare:moneyflow_hsgt

Name: Institutional Trading Summary.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| AMOUNT | number |
| BIZSUNITNAME | text |
| BUYAMT | number |
| CHGTYPE | text |
| SALEAMT | number |
| SYMBOL | text |
| TRADEDATE | date |
| TRANSDIR | text |
## tushare:new_share

Name: IPO Data.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| ISSPUBDATE | date |
| LISTDATE | date |
| PS_ISS_PRC | number |
| SESNAME | text |
## tushare:pledge_stat

Name: Share Pledge Statistics.

Coverage: 2015-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| end_date | date |
| pledge_count | number |
| pledge_ratio | number |
| rest_pledge | number |
| total_share | number |
| ts_code | text |
| unrest_pledge | number |
## tushare:sge_daily

Name: Shanghai Gold Spot Daily.

Coverage: 2015-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| amount | number |
| change | number |
| close | number |
| high | number |
| low | number |
| open | number |
| pct_change | number |
| price_avg | number |
| trade_date | date |
| ts_code | text |
| vol | number |
## tushare:stk_managers

Name: Company Executives.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| ann_date | date |
| begin_date | date |
| birthday | text |
| edu | text |
| end_date | date |
| gender | text |
| lev | text |
| name | text |
| national | text |
| title | text |
| ts_code | text |
## tushare:stock_basic

Name: Stock Basic Information.

Coverage: not specified to not specified.

| Name | Type |
| --- | --- |
| area | text |
| industry | text |
| list_date | date |
| name | text |
| symbol | text |
| ts_code | text |
## tushare:top10_holders

Name: Top 10 Shareholders.

Coverage: 2024-01-01 to 2026-06-30.

| Name | Type |
| --- | --- |
| ann_date | date |
| end_date | date |
| hold_amount | number |
| hold_change | number |
| hold_float_ratio | number |
| hold_ratio | number |
| holder_name | text |
| holder_type | text |
| ts_code | text |
## tushare:trade_cal

Name: Trading Calendar.

Coverage: 2026-01-01 to 2026-12-31.

| Name | Type |
| --- | --- |
| cal_date | date |
| exchange | text |
| is_open | number |
| pretrade_date | date |
## tushare:yc_cb

Name: Convertible Bond Yield Curve.

Coverage: 2024-01-01 to 2026-10-10.

| Name | Type |
| --- | --- |
| close | number |
| conv_value | number |
| duration | number |
| premium_rate | number |
| trade_date | date |
| ts_code | text |
| ytm | number |
