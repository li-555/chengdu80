# screen-controls

## Contents

- DateRangeInput
- NumberInput
- RunButton
- SelectInput
- TextInput

## DateRangeInput

Edit the two named parameters that define a date range.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| fromParam | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited as the start date of the range. |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| toParam | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited as the end date of the range. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "DateRangeInput" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "fromParam": "start",
  "label": "Dates",
  "toParam": "end",
  "type": "DateRangeInput"
}
```

## NumberInput

Edit a named numeric parameter.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited by this control. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "NumberInput" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "label": "Rows",
  "param": "limit",
  "type": "NumberInput"
}
```

## RunButton

Run the application with its current settings.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| label | string; minLength: 1; maxLength: 40; default: "Run" | no | Button label, defaulting to Run when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "RunButton" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "label": "Run",
  "type": "RunButton"
}
```

## SelectInput

Choose among the declared options of a named text parameter.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited by this control. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "SelectInput" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "label": "Market",
  "param": "market",
  "type": "SelectInput"
}
```

## TextInput

Edit a named text parameter or list of text values.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| list | boolean; default: false | no | Whether text input displays a string list as chips, defaulting to false when omitted. |
| param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited by this control. |
| placeholder | string; minLength: 1; maxLength: 80 | no | Optional text input hint, with no placeholder specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "TextInput" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "label": "Companies",
  "param": "watchlist",
  "type": "TextInput"
}
```
