# screen-charts

## Contents

- Chart

## Chart

Plot daily results as a line, bar, candlestick or heatmap chart.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| chart | "line" / "bar" / "candlestick" / "heatmap" | yes | Chart kind, either line, bar, candlestick, or heatmap. |
| from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| heat | object | no | Second-axis and value result columns, required for heatmaps and otherwise optional. |
| heat.value | string; minLength: 1; maxLength: 128 | yes | Result column supplying the heatmap cell value. |
| heat.y | string; minLength: 1; maxLength: 128 | yes | Result column supplying the heatmap second axis. |
| ohlc | object | no | Open, high, low, and close result columns, required for candlestick charts and otherwise optional. |
| ohlc.close | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle closing price. |
| ohlc.high | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle highest price. |
| ohlc.low | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle lowest price. |
| ohlc.open | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle opening price. |
| series | string; minLength: 1; maxLength: 128 | no | Text result column whose distinct values each become their own line or bar group, for example one line per company; only for line and bar charts with exactly one y column; at most 20 groups are drawn, the rest are listed as hidden. |
| stacked | boolean | no | Optional request to stack chart series, with no stacking request when omitted. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Chart" | yes | Element type discriminator selecting the declared screen component. |
| x | string; minLength: 1; maxLength: 128 | yes | Result column supplying the horizontal axis. |
| y | array of string; maxItems: 8 | no | Result columns supplying line or bar series, required and non-empty for those chart kinds and otherwise optional. |

Example:

```json
{
  "chart": "line",
  "from": "prices",
  "type": "Chart",
  "x": "trade_date",
  "y": [
    "close"
  ]
}
```
