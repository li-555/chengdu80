# blocks

## Contents

- meta
- params
- data
- triggers
- Step kind: sql
- Step kind: expression
- Step kind: ai
- Step kind: code
- manual
- schedule
- market
- alert

## meta

Name and describe the application and declare its specification version.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| description | string; minLength: 1; maxLength: 400 | yes | Plain-language application description shown on the card and in the header. |
| icon | string; minLength: 1; maxLength: 40 | no | Optional icon name checked against the supported icon list, with no icon specified when omitted. |
| name | string; minLength: 1; maxLength: 80 | yes | Application name shown to the person. |
| provenance | object | no | Optional audit metadata, with no provenance recorded when omitted. |
| provenance.created_by | "platform" / "external" | yes | Audit origin category, either platform or external, which does not change document installation behaviour. |
| provenance.imported_at | string; minLength: 1; maxLength: 40 | no | Optional audit timestamp text of 1 to 40 characters, with no timestamp recorded when omitted. |
| provenance.model | string; minLength: 1; maxLength: 120 | no | Optional audit label of 1 to 120 characters, absent when omitted. |
| provenance.tool | string; minLength: 1; maxLength: 120 | no | Optional audit label of 1 to 120 characters, absent when omitted. |
| spec_version | string; minLength: 1; maxLength: 16 | yes | Specification version string, required to match the supported version by the validator. |
| theme | "daylight" / "night" / "paper" / "desk" | no | Optional theme choice, with no application theme specified when omitted. |
| updated_at | string; minLength: 1; maxLength: 40 | no | Optional update timestamp text of 1 to 40 characters, with no timestamp recorded when omitted. |

Example:

```json
{
  "description": "Review invented daily price changes.",
  "name": "Harbor Prices",
  "spec_version": "1.0"
}
```

## params

Declare settings that controls and calculations can read when the application runs.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| default | string or number or boolean or array of string | no | Initial value used when no run value is supplied, leaving the value undefined when omitted. |
| key | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique parameter name used by controls, filters, and parameter references. |
| label | string; minLength: 1; maxLength: 80 | yes | Display label for this setting. |
| list | boolean | no | Whether a text setting holds a list of strings, treating it as a scalar when omitted. |
| max | number | no | Optional maximum numeric value in the parameter units, with no declared upper bound when omitted. |
| min | number | no | Optional minimum numeric value in the parameter units, with no declared lower bound when omitted. |
| options | array of object; minItems: 1; maxItems: 100 | no | Allowed text choices shown as a dropdown, with no fixed choices when omitted and disallowed for list settings. |
| options[].label | string; minLength: 1; maxLength: 200 | yes | Display label for this choice. |
| options[].value | string; minLength: 1; maxLength: 200 | yes | Stored non-empty text value for this choice, unique within the setting. |
| step | number; exclusiveMinimum: 0 | no | Optional positive numeric increment in the parameter units, with no increment declared when omitted. |
| type | "text" / "number" / "date" / "boolean" | yes | Value type of the setting, either text, number, date, or boolean. |
| unit | string; minLength: 1; maxLength: 16 | no | Optional unit label of 1 to 16 characters, with no unit label when omitted. |

Example:

```json
[
  {
    "default": 10,
    "key": "harbor_limit",
    "label": "Rows to show",
    "max": 50,
    "min": 1,
    "type": "number"
  }
]
```

## data

Declare required fields and optional windows or parameter filters without embedding data rows.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| datasetHint | string; minLength: 1; maxLength: 100 | no | Optional dataset suggestion for the person or resolver, with no suggestion when omitted and no binding established by this field. |
| fields | array of object; minItems: 1; maxItems: 100 | yes | Columns requested from the bound dataset with their types and mapping requirements. |
| fields[].name | string; minLength: 1; maxLength: 128 | yes | Column name exposed to calculations after mapping the bound dataset. |
| fields[].required | boolean | yes | Whether this column is required for the data requirement. |
| fields[].semantic | string; minLength: 1; maxLength: 40 | no | Optional shared meaning such as security_code or trade_date used to help column mapping, with no semantic hint when omitted. |
| fields[].type | "text" / "number" / "date" / "boolean" | yes | Required data type for the mapped column. |
| filters | array of object; maxItems: 20 | no | Parameter-based filter requests, with no filters requested when omitted. |
| filters[].field | string; minLength: 1; maxLength: 128 | yes | Requirement column on which the filter operates. |
| filters[].op | "eq" / "neq" / "gt" / "gte" / "lt" / "lte" / "in" / "not_in" / "contains" | yes | Comparison applied between the field and the named parameter value. |
| filters[].param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the filter value rather than a literal in the document. |
| grain | "daily" / "weekly" / "monthly" / "quarterly" / "yearly" / "snapshot" | no | Optional declared time granularity of the requested rows, with none specified when omitted. |
| key | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique relation name used to reference this data requirement from calculations. |
| purpose | string; minLength: 1; maxLength: 200 | no | Optional explanation of why this data is needed, with no explanation when omitted. |
| window | object | no | Optional trading-calendar lookback request, with no lookback request when omitted. |
| window.field | string; minLength: 1; maxLength: 128 | yes | Requirement date column to which the requested lookback applies. |
| window.lookbackDays | integer; maximum: 3650; exclusiveMinimum: 0 | yes | Requested number of trading-calendar days rather than wall-clock days, from 1 to 3650, with 1 requesting a single trading day and no date-boundary resolution enforced by the schema. |

Example:

```json
[
  {
    "fields": [
      {
        "name": "harbor_price",
        "required": true,
        "type": "number"
      }
    ],
    "grain": "daily",
    "key": "harbor_prices"
  }
]
```

## triggers

Declare when the application runs, by hand, by schedule or around trading hours.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| choice 1.kind | "manual" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| choice 2.cron | string; maxLength: 256; pattern: "^\\s*\\S+(\\s+\\S+){4}\\s*$" | yes | Five-field schedule in minute, hour, day-of-month, month, and weekday order. |
| choice 2.kind | "schedule" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| choice 2.tz | string; minLength: 1; maxLength: 64; default: "Asia/Shanghai" | no | Schedule time zone, defaulting to Asia/Shanghai when omitted. |
| choice 3.at | "open" / "close" | yes | Market event to run near, either opening or closing. |
| choice 3.calendar | "SSE"; default: "SSE" | no | Trading calendar used for market events, restricted to SSE and defaulting to SSE when omitted. |
| choice 3.kind | "market" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| choice 3.offsetMinutes | integer; minimum: -240; maximum: 240; default: 0 | no | Signed offset in minutes from the market event, with negative values before it and zero when omitted. |
| choice 4.condition | string; minLength: 1; maxLength: 2000 | yes | Expression that must hold for a scheduled alert to raise a notification. |
| choice 4.cron | string; maxLength: 256; pattern: "^\\s*\\S+(\\s+\\S+){4}\\s*$" | yes | Five-field schedule in minute, hour, day-of-month, month, and weekday order. |
| choice 4.kind | "alert" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| choice 4.tz | string; minLength: 1; maxLength: 64; default: "Asia/Shanghai" | no | Schedule time zone, defaulting to Asia/Shanghai when omitted. |

Example:

```json
[
  {
    "kind": "manual"
  }
]
```

## Step kind: sql

Run a single allowed SELECT or WITH query over declared input relations.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| input | array of string; maxItems: 8 | no | Declared relation names available to the SQL query, with no relations declared when omitted. |
| key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| kind | "sql" | yes | Step discriminator identifying a SQL calculation. |
| sql | string; minLength: 1; maxLength: 20000 | yes | Read-only SQL query checked by the SQL validator against declared inputs. |
| title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "id": "harbor_total",
  "input": [
    "harbor_prices"
  ],
  "kind": "sql",
  "sql": "SELECT sum(harbor_price) AS harbor_total FROM harbor_prices"
}
```

## Step kind: expression

Evaluate a one-line formula to produce a single value for later calculations.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| expr | string; minLength: 1; maxLength: 2000 | yes | Formula intended to produce a single value addressable by this step id. |
| id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | no | Optional data requirement key or step id declared as input, with no input declared when omitted. |
| key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| kind | "expression" | yes | Step discriminator identifying a scalar expression. |
| title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "expr": "2 * 3",
  "id": "harbor_assumption",
  "kind": "expression"
}
```

## Step kind: ai

Ask the configured model about input rows and declare the shape of its response.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the input rows. |
| key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| kind | "ai" | yes | Step discriminator identifying a row interpretation step. |
| params | object | yes | Processing limits, instructions, output shape, and error policy for this step. |
| params.instructions | string; minLength: 1; maxLength: 4000 | yes | Instructions for interpreting the input rows, containing 1 to 4000 characters. |
| params.max_input_chars | integer; minimum: 100; maximum: 60000; default: 20000 | no | Maximum input text length in characters, defaulting to 20000 when omitted. |
| params.max_rows | integer or object; default: 50 | no | Maximum input row count as an integer or parameter reference, defaulting to 50 when omitted. |
| params.max_rows.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| params.mode | "whole" / "per_row" | yes | Requested processing scope, either the whole input or each row separately. |
| params.on_error | "null" / "fail"; default: "null" | no | Declared error policy, either null or fail, defaulting to null when omitted. |
| params.output | object or object or object | yes | Declared result shape, either text, an enumerated string, or an object of typed fields. |
| params.output.choice 1.kind | "text" | yes | Result shape discriminator selecting text, enum, or object. |
| params.output.choice 2.kind | "enum" | yes | Result shape discriminator selecting text, enum, or object. |
| params.output.choice 2.values | array of string; minItems: 2; maxItems: 32 | yes | Allowed non-empty string result values for an enum output, containing 2 to 32 entries. |
| params.output.choice 3.fields | object | yes | Map of output column names to string, number, or boolean types, containing 1 to 32 fields. |
| params.output.choice 3.kind | "object" | yes | Result shape discriminator selecting text, enum, or object. |
| title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "id": "harbor_summary",
  "input": "harbor_prices",
  "kind": "ai",
  "params": {
    "instructions": "Summarize harbor_price.",
    "max_input_chars": 2000,
    "max_rows": 10,
    "mode": "whole",
    "on_error": "null",
    "output": {
      "kind": "text"
    }
  }
}
```

## Step kind: code

Run sandboxed JavaScript with declared inputs and output columns, optionally carrying state across successful runs.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| body | string; minLength: 1; maxLength: 40000 | yes | Sandboxed JavaScript body containing 1 to 40000 characters. |
| carry_state | boolean; default: false | no | Whether state from the previous successful run is available, capped at 64 KB and defaulting to false when omitted. |
| id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| input | array of string; minItems: 1; maxItems: 3 | yes | One to three declared input relation names. |
| key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| kind | "code" | yes | Step discriminator identifying a sandboxed code calculation. |
| output | object | yes | Declared columns and types for the result table. |
| output.columns | array of object; minItems: 1; maxItems: 64 | yes | One to 64 column declarations for the result table. |
| output.columns[].name | string; minLength: 1; maxLength: 128 | yes | Output table column name. |
| output.columns[].type | "text" / "number" / "date" / "boolean" | yes | Output table column data type. |
| title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "body": "return [{ harbor_value: 1 }];",
  "carry_state": false,
  "id": "harbor_constant",
  "input": [
    "harbor_prices"
  ],
  "kind": "code",
  "output": {
    "columns": [
      {
        "name": "harbor_value",
        "type": "number"
      }
    ]
  }
}
```

## manual

Allow a person to run the application with its current settings.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| kind | "manual" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |

Example:

```json
{
  "kind": "manual"
}
```

## schedule

Run on a five-field cron schedule in the named time zone.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| cron | string; maxLength: 256; pattern: "^\\s*\\S+(\\s+\\S+){4}\\s*$" | yes | Five-field schedule in minute, hour, day-of-month, month, and weekday order. |
| kind | "schedule" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| tz | string; minLength: 1; maxLength: 64; default: "Asia/Shanghai" | no | Schedule time zone, defaulting to Asia/Shanghai when omitted. |

Example:

```json
{
  "cron": "0 8 * * 1-5",
  "kind": "schedule",
  "tz": "Asia/Shanghai"
}
```

## market

Run before or after market opening or closing on actual trading days in the SSE calendar.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| at | "open" / "close" | yes | Market event to run near, either opening or closing. |
| calendar | "SSE"; default: "SSE" | no | Trading calendar used for market events, restricted to SSE and defaulting to SSE when omitted. |
| kind | "market" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| offsetMinutes | integer; minimum: -240; maximum: 240; default: 0 | no | Signed offset in minutes from the market event, with negative values before it and zero when omitted. |

Example:

```json
{
  "at": "close",
  "calendar": "SSE",
  "kind": "market",
  "offsetMinutes": 15
}
```

## alert

Run on a schedule and raise a notification only when the result condition holds.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| condition | string; minLength: 1; maxLength: 2000 | yes | Expression that must hold for a scheduled alert to raise a notification. |
| cron | string; maxLength: 256; pattern: "^\\s*\\S+(\\s+\\S+){4}\\s*$" | yes | Five-field schedule in minute, hour, day-of-month, month, and weekday order. |
| kind | "alert" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| tz | string; minLength: 1; maxLength: 64; default: "Asia/Shanghai" | no | Schedule time zone, defaulting to Asia/Shanghai when omitted. |

Example:

```json
{
  "condition": "harbor_assumption > 5",
  "cron": "0 16 * * 1-5",
  "kind": "alert",
  "tz": "Asia/Shanghai"
}
```
