# screen-layout

## Contents

- Section

## Section

Arrange child elements in one, two or three columns with an optional title.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| children | array of string; maxItems: 32 | yes | Ordered element ids contained by this section. |
| columns | 1 or 2 or 3; default: 1 | no | Number of section layout columns, defaulting to 1 when omitted. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Section" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "children": [
    "intro"
  ],
  "type": "Section"
}
```
