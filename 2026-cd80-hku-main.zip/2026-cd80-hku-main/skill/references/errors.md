# errors

## Contents

- E_BAD_CRON
- E_BAD_EXPRESSION
- E_BAD_SQL
- E_CYCLE
- E_ELEMENT_CYCLE
- E_INTERNAL
- E_LIMIT_AI_STEPS
- E_LIMIT_CODE_STEPS
- E_LIMIT_ELEMENTS
- E_LIMIT_NESTING
- E_LIMIT_STEPS
- E_NO_TRIGGER
- E_PARSE_EMPTY
- E_PARSE_JSON
- E_PARSE_NOT_OBJECT
- E_REF_DUPLICATE_NAME
- E_REF_UNKNOWN_ELEMENT
- E_REF_UNKNOWN_PARAM
- E_REF_UNKNOWN_RELATION
- E_REF_UNKNOWN_ROOT
- E_SCHEMA_CUSTOM
- E_SCHEMA_ENUM
- E_SCHEMA_PATTERN
- E_SCHEMA_RANGE
- E_SCHEMA_REQUIRED
- E_SCHEMA_SPEC_VERSION
- E_SCHEMA_TYPE
- E_SCHEMA_UNION
- E_SCHEMA_UNKNOWN_KEY
- E_SELF_REFERENCE
- E_TOO_MANY_ERRORS
- W_CODE_COULD_BE_OPERATION
- W_DEAD_CONTROL
- W_NO_MANUAL_TRIGGER
- W_ORPHAN_ELEMENT
- W_SHORT_HISTORY
- W_SQL_COULD_BE_OPERATION
- W_SURROUNDING_TEXT
- W_UNKNOWN_ICON
- W_UNUSED_DATA
- W_UNUSED_PARAM
- W_UNUSED_STEP

## E_BAD_CRON

A schedule is not a valid five-field cron expression.

Hint: Use five schedule parts with valid ranges and increments.
## E_BAD_EXPRESSION

A formula could not be understood.

Hint: Correct the formula using supported syntax and functions.
## E_BAD_SQL

A SQL step is not a single SELECT or WITH, or uses something not allowed.

Hint: Use one allowed SELECT or WITH statement over declared inputs.
## E_CYCLE

Two or more steps depend on each other, so no order can run them.

Hint: Remove the circular dependencies between steps.
## E_ELEMENT_CYCLE

Sections contain each other in a loop.

Hint: Remove the loop in Section children.
## E_INTERNAL

The checker could not finish checking this application.

Hint: This is a fault in the checker, not in your application. Simplify the value at this location and check again.
## E_LIMIT_AI_STEPS

More than four AI steps in one application.

Hint: Reduce the application to at most four ai steps.
## E_LIMIT_CODE_STEPS

More than one custom-code step in one application.

Hint: Combine custom logic into at most one code step.
## E_LIMIT_ELEMENTS

Too many screen elements.

Hint: Reduce the screen to at most 60 elements.
## E_LIMIT_NESTING

Sections are nested too deeply.

Hint: Flatten nested Sections to the allowed depth in the report.
## E_LIMIT_STEPS

Too many calculation steps.

Hint: Reduce the application to at most 60 calculation steps.
## E_NO_TRIGGER

An application needs at least one trigger.

Hint: Add a manual trigger or another supported trigger.
## E_PARSE_EMPTY

The file is empty.

Hint: Supply the complete application instead of an empty file.
## E_PARSE_JSON

The file is not valid JSON.

Hint: Fix the syntax and supply one complete JSON object.
## E_PARSE_NOT_OBJECT

The top level of an application must be a JSON object.

Hint: Supply an application object rather than a list or scalar.
## E_REF_DUPLICATE_NAME

Two things claim the same name. Data keys and step ids share one namespace.

Hint: Give each data key and step id a distinct name.
## E_REF_UNKNOWN_ELEMENT

A section lists a child element that does not exist.

Hint: Use an existing element id in children.
## E_REF_UNKNOWN_PARAM

Something names a parameter that was never declared.

Hint: Use a declared params key, or declare the missing setting.
## E_REF_UNKNOWN_RELATION

A step reads a table that no data requirement or earlier step produces.

Hint: Point at an existing data key or step id.
## E_REF_UNKNOWN_ROOT

The screen names a root element that does not exist.

Hint: Set ui.root to an existing element id.
## E_SCHEMA_CUSTOM

A value broke a rule specific to this field.

Hint: Follow the specific rule in the report hint.
## E_SCHEMA_ENUM

A value is not one of the allowed choices.

Hint: Choose one of the allowed values in the property table.
## E_SCHEMA_PATTERN

A value does not match the required form.

Hint: Use the required spelling and identifier format.
## E_SCHEMA_RANGE

A number or a length is outside the allowed range.

Hint: Keep the value or length within the stated bounds.
## E_SCHEMA_REQUIRED

A required field is missing.

Hint: Add the missing required property.
## E_SCHEMA_SPEC_VERSION

The specification version is missing or unsupported.

Hint: Set meta.spec_version to "1.0".
## E_SCHEMA_TYPE

A value is the wrong type.

Hint: Use the type required by the named property.
## E_SCHEMA_UNION

A value does not match any allowed shape.

Hint: Use one complete allowed shape, without mixing alternatives.
## E_SCHEMA_UNKNOWN_KEY

A key is not part of the specification. Usually a typo.

Hint: Remove or correct the unrecognised key.
## E_SELF_REFERENCE

A step reads its own output.

Hint: Read a different input instead of the step’s own output.
## E_TOO_MANY_ERRORS

More problems were found than one report can show.

Hint: Fix the reported problems and check again to see the remaining problems.
## W_CODE_COULD_BE_OPERATION

A custom-code step does something a named operation already does.

Hint: Replace the code step with the suggested named operation.
## W_DEAD_CONTROL

A parameter has a control on screen but nothing in the calculation reads it, so the control does nothing.

Hint: Connect the controlled setting to a calculation or remove the control.
## W_NO_MANUAL_TRIGGER

The application cannot be run by hand.

Hint: Add a manual trigger so the person can run by hand.
## W_ORPHAN_ELEMENT

An element is declared but nothing on the screen shows it.

Hint: Include the element in a reachable Section or remove it.
## W_SHORT_HISTORY

The data does not go back as far as this application asks for.

Hint: Connect a source with more history or shorten the requested window.
## W_SQL_COULD_BE_OPERATION

A SQL step does something a named operation already does.

Hint: Replace the SQL step with the suggested named operation.
## W_SURROUNDING_TEXT

The application was wrapped in a code fence or surrounded by prose. It was read anyway.

Hint: Supply the application alone without fences or surrounding prose.
## W_UNKNOWN_ICON

The icon name is not one we ship. A default will be used.

Hint: Choose an icon from the supported icon names or omit it.
## W_UNUSED_DATA

A data requirement is declared but no step reads it.

Hint: Read the data requirement in a step or remove it.
## W_UNUSED_PARAM

A parameter is declared but nothing uses it.

Hint: Read the setting in calculations or remove it.
## W_UNUSED_STEP

A step produces a table that nothing reads.

Hint: Use the result in another step or on screen, or remove the step.
