# screen-display

## Contents

- Callout
- List
- Metric
- Table
- Text

## Callout

Show a note with an optional title and semantic tone.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| text | string; minLength: 1; maxLength: 2000 | yes | Text content displayed by the element. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Callout" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "text": "Prices are delayed.",
  "type": "Callout"
}
```

## List

Show result rows as items with titles and optional bodies, links, tones and groups.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| emptyHint | string; minLength: 1; maxLength: 200 | no | Optional message for an empty result, with no custom message when omitted. |
| from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| groupBy | string; minLength: 1; maxLength: 128 | no | Optional result column used to group list items, with no grouping column when omitted. |
| itemBody | string; minLength: 1; maxLength: 128 | no | Optional result column supplying each list item body, with no body column when omitted. |
| itemLink | string; minLength: 1; maxLength: 128 | no | Optional result column supplying each list item link, with no link column when omitted. |
| itemTitle | string; minLength: 1; maxLength: 128 | yes | Result column supplying each list item title. |
| itemTone | string; minLength: 1; maxLength: 128 | no | Optional result column supplying each list item tone, with no per-item tone column when omitted. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "List" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "from": "prices",
  "itemTitle": "name",
  "type": "List"
}
```

## Metric

Show one formatted result value with an optional change and unit.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| change | string; minLength: 1; maxLength: 128 | no | Optional result column providing the metric change, with no change column when omitted. |
| format | "number" / "money" / "percent" / "integer"; default: "number" | no | Metric display format, defaulting to number when omitted. |
| from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Metric" | yes | Element type discriminator selecting the declared screen component. |
| unit | string; minLength: 1; maxLength: 16 | no | Optional displayed unit label, with no unit label when omitted. |
| value | string; minLength: 1; maxLength: 128 | yes | Result column providing the metric value. |

Example:

```json
{
  "from": "totals",
  "label": "Total",
  "type": "Metric",
  "value": "n"
}
```

## Table

Show result rows in named, formatted columns with pagination.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| columns | array of object; minItems: 1; maxItems: 40 | yes | Ordered declarations of the result columns displayed in the table. |
| columns[].col | string; minLength: 1; maxLength: 128 | yes | Result column to display in this table column. |
| columns[].format | "text" / "number" / "money" / "percent" / "date" / "integer" | no | Optional display format for this column, with no format specified when omitted. |
| columns[].label | string; minLength: 1; maxLength: 60 | no | Optional display label for the column, with no label specified when omitted. |
| emptyHint | string; minLength: 1; maxLength: 200 | no | Optional message for an empty result, with no custom message when omitted. |
| from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| pageSize | integer; minimum: 5; maximum: 200; default: 25 | no | Number of table rows per page, defaulting to 25 when omitted. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Table" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "columns": [
    {
      "col": "close"
    }
  ],
  "from": "prices",
  "type": "Table"
}
```

## Text

Show prose as a heading, body or caption.

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| emphasis | "heading" / "body" / "caption"; default: "body" | no | Text presentation role, defaulting to body when omitted. |
| text | string; minLength: 1; maxLength: 4000 | yes | Text content displayed by the element. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Text" | yes | Element type discriminator selecting the declared screen component. |

Example:

```json
{
  "text": "Daily prices.",
  "type": "Text"
}
```
