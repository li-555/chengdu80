# DATA-SHAPES.md

Documentation of every data shape used by Blocks.
For each endpoint: API name, every field, each field's type, the date range, and one **invented** example row.

> All example rows in this document are **invented** — they do not contain real market data.

---

## 1. Core Market Data

### 1.1 daily — Daily Stock Prices

| Tushare API | `daily` |
|---|---|
| Date range | 1990-12-19 to 2026-10-13 |
| Row shape | One row per stock per trading day |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `ts_code` | text | no | — | Stock code, e.g. `600000.SH` or `000001.SZ` |
| 2 | `trade_date` | date | no | — | Trading date, `YYYYMMDD` |
| 3 | `open` | number | no | CNY | Opening price |
| 4 | `high` | number | no | CNY | Highest price of the day |
| 5 | `low` | number | no | CNY | Lowest price of the day |
| 6 | `close` | number | no | CNY | Closing price |
| 7 | `pre_close` | number | no | CNY | Previous closing price |
| 8 | `change` | number | no | CNY | Price change from previous close |
| 9 | `pct_chg` | number | no | % | Percentage change |
| 10 | `vol` | number | no | lots | Volume in lots (1 lot = 100 shares) |
| 11 | `amount` | number | no | thousand CNY | Turnover (thousand CNY) |

**Invented example row:**

| ts_code | trade_date | open | high | low | close | pre_close | change | pct_chg | vol | amount |
|---|---|---|---|---|---|---|---|---|---|---|
| 600519.SH | 20261012 | 1680.00 | 1710.50 | 1675.00 | 1702.30 | 1695.00 | 7.30 | 0.43 | 2850000 | 4825600000 |

---

### 1.2 daily_basic — Daily Basic Indicators

| Tushare API | `daily_basic` |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |
| Row shape | One row per stock per trading day |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `ts_code` | text | no | — | Stock code |
| 2 | `trade_date` | date | no | — | Trading date |
| 3 | `close` | number | no | CNY | Closing price |
| 4 | `turnover_rate` | number | yes | % | Turnover rate |
| 5 | `turnover_rate_f` | number | yes | % | Free-float turnover rate |
| 6 | `volume_ratio` | number | yes | — | Volume ratio |
| 7 | `pe` | number | yes | — | Price-to-earnings ratio |
| 8 | `pe_ttm` | number | yes | — | PE (trailing twelve months) |
| 9 | `pb` | number | yes | — | Price-to-book ratio |
| 10 | `ps` | number | yes | — | Price-to-sales ratio |
| 11 | `ps_ttm` | number | yes | — | PS (trailing twelve months) |
| 12 | `dv_ratio` | number | yes | % | Dividend yield |
| 13 | `dv_ttm` | number | yes | % | Dividend yield (TTM) |
| 14 | `total_share` | number | yes | 10k shares | Total shares |
| 15 | `float_share` | number | yes | 10k shares | Floating shares |
| 16 | `free_share` | number | yes | 10k shares | Free-float shares |
| 17 | `total_mv` | number | yes | 10k CNY | Total market value |
| 18 | `circ_mv` | number | yes | 10k CNY | Circulating market value |

**Invented example row:**

| ts_code | trade_date | close | turnover_rate | volume_ratio | pe | pe_ttm | pb | total_mv | circ_mv |
|---|---|---|---|---|---|---|---|---|---|
| 600519.SH | 20261012 | 1702.30 | 0.23 | 0.85 | 32.50 | 31.80 | 8.92 | 2140000 | 2140000 |

---

### 1.3 adj_factor — Adjustment Factor

| Tushare API | `adj_factor` |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | Stock code |
| 2 | `trade_date` | date | no | Trading date |
| 3 | `adj_factor` | number | no | Cumulative adjustment factor for forward-adjusted prices |

**Invented example row:**

| ts_code | trade_date | adj_factor |
|---|---|---|
| 600519.SH | 20261012 | 156.320 |

---

## 2. Reference Data

### 2.1 stock_basic — Stock Basic Information

| Tushare API | `stock_basic` |
|---|---|
| Date range | Snapshot (current list of listed stocks) |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | Stock code, e.g. `000001.SZ` |
| 2 | `symbol` | text | no | Ticker symbol without exchange, e.g. `1` |
| 3 | `name` | text | no | Company name in English |
| 4 | `area` | text | yes | Region / province |
| 5 | `industry` | text | yes | Industry classification |
| 6 | `list_date` | date | no | Listing date, `YYYYMMDD` |

**Invented example row:**

| ts_code | symbol | name | area | industry | list_date |
|---|---|---|---|---|---|
| 600519.SH | 600519 | Kweichow Moutai | Guizhou | Liquor | 20010827 |

---

### 2.2 trade_cal — Trading Calendar

| Tushare API | `trade_cal` |
|---|---|
| Date range | 2026-01-01 to 2026-12-31 (full year available) |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `exchange` | text | no | Exchange code, e.g. `SSE` |
| 2 | `cal_date` | date | no | Calendar date, `YYYYMMDD` |
| 3 | `is_open` | number | no | 1 = trading day, 0 = non-trading day |
| 4 | `pretrade_date` | date | no | Previous trading date |

**Invented example row:**

| exchange | cal_date | is_open | pretrade_date |
|---|---|---|---|
| SSE | 20261014 | 1 | 20261013 |

---

### 2.3 stock_basic_managers — Company Executives

| Tushare API | `stk_managers` |
|---|---|
| Date range | Current appointments |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | Stock code |
| 2 | `ann_date` | date | yes | Announcement date |
| 3 | `name` | text | no | Name |
| 4 | `gender` | text | yes | Gender |
| 5 | `title` | text | yes | Job title |
| 6 | `edu` | text | yes | Education background |
| 7 | `national` | text | yes | Nationality |
| 8 | `birthday` | text | yes | Birth year |
| 9 | `begin_date` | date | yes | Start date of appointment |
| 10 | `end_date` | date | yes | End date of appointment |

**Invented example row:**

| ts_code | name | gender | title | edu | begin_date | end_date |
|---|---|---|---|---|---|---|
| 600519.SH | Zhang Wei | Male | General Manager | Master's Degree | 20230501 | |

---

## 3. Index Data

### 3.1 index_dd — Index Daily Data

| Tushare API | `index_daily` |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | Index code, e.g. `000001.SH` (SSE Composite) |
| 2 | `trade_date` | date | no | Trading date |
| 3 | `close` | number | no | Closing value |
| 4 | `open` | number | no | Opening value |
| 5 | `high` | number | no | Highest value |
| 6 | `low` | number | no | Lowest value |
| 7 | `pre_close` | number | no | Previous closing value |
| 8 | `change` | number | no | Change from previous close |
| 9 | `pct_chg` | number | no | Percentage change |
| 10 | `vol` | number | no | Volume |
| 11 | `amount` | number | no | Turnover |

**Invented example row:**

| ts_code | trade_date | close | open | high | low | pre_close | change | pct_chg | vol | amount |
|---|---|---|---|---|---|---|---|---|---|---|
| 000001.SH | 20261012 | 3280.50 | 3265.20 | 3295.00 | 3258.10 | 3268.70 | 11.80 | 0.36 | 158000000 | 185000000000 |

---

### 3.2 ci_index_member — Index Constituent Members

| Tushare API | `index_member` |
|---|---|
| Date range | Current constituents |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `l1_code` | text | yes | Level 1 index code |
| 2 | `l1_name` | text | yes | Level 1 index name |
| 3 | `ts_code` | text | no | Stock code |
| 4 | `name` | text | no | Stock name |
| 5 | `in_date` | date | yes | Date added to index |
| 6 | `out_date` | date | yes | Date removed from index |
| 7 | `is_new` | text | yes | Whether newly added |

**Invented example row:**

| l1_code | l1_name | ts_code | name | in_date | out_date | is_new |
|---|---|---|---|---|---|---|
| CI005021.CI | Banks | 600036.SH | China Merchants Bank | 20191202 | | Y |

---

## 4. Fund Data

### 4.1 fund_basic — Fund Basic Information

| Tushare API | `fund_basic` |
|---|---|
| Date range | Snapshot (listed funds) |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | Fund code |
| 2 | `name` | text | no | Fund full name |
| 3 | `management` | text | yes | Management company |
| 4 | `custodian` | text | yes | Custodian bank |
| 5 | `fund_type` | text | yes | Fund type (Equity, Bond, Mixed, etc.) |
| 6 | `found_date` | date | yes | Foundation date |
| 7 | `list_date` | date | yes | Listing date |
| 8 | `issue_amount` | number | yes | 100M CNY | Issue amount |
| 9 | `m_fee` | number | yes | % | Management fee rate |
| 10 | `c_fee` | number | yes | % | Custodian fee rate |
| 11 | `benchmark` | text | yes | Performance benchmark |
| 12 | `status` | text | yes | L = listed, D = delisted |
| 13 | `invest_type` | text | yes | Investment type |
| 14 | `type` | text | yes | Fund style |

**Invented example row:**

| ts_code | name | fund_type | found_date | list_date | m_fee | status | invest_type |
|---|---|---|---|---|---|---|---|
| 510050.SH | ChinaAMC SSE 50 ETF | Equity | 20041230 | 20050223 | 0.50 | L | Passive Index |

---

### 4.2 fund_nav — Fund NAV

| Tushare API | `fund_nav` |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `ts_code` | text | no | — | Fund code |
| 2 | `ann_date` | date | yes | — | Announcement date |
| 3 | `nav_date` | date | no | — | NAV date |
| 4 | `unit_nav` | number | no | CNY | Unit NAV |
| 5 | `accum_nav` | number | no | CNY | Accumulated NAV |
| 6 | `adj_nav` | number | yes | CNY | Adjusted NAV |
| 7 | `update_flag` | number | yes | — | Update flag |
| 8 | `total_netasset` | number | yes | CNY | Total net assets |

**Invented example row:**

| ts_code | nav_date | unit_nav | accum_nav | adj_nav |
|---|---|---|---|---|
| 510050.SH | 20261012 | 3.4520 | 4.1250 | 3.4520 |

---

### 4.3 fund_portfolio — Fund Portfolio Holdings

| Tushare API | `fund_portfolio` |
|---|---|
| Date range | 2024-01-01 to 2026-06-30 |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | Fund code |
| 2 | `ann_date` | date | yes | Announcement date |
| 3 | `end_date` | date | no | Period end date |
| 4 | `symbol` | text | no | Holding stock code |
| 5 | `mkv` | number | yes | Market value of holding |
| 6 | `amount` | number | yes | Number of shares held |
| 7 | `stk_mkv_ratio` | number | yes | % of fund NAV |
| 8 | `stk_float_ratio` | number | yes | % of stock float |

**Invented example row:**

| ts_code | end_date | symbol | mkv | amount | stk_mkv_ratio |
|---|---|---|---|---|---|
| 510050.SH | 20260630 | 600519.SH | 850000000 | 500000 | 16.50 |

---

## 5. ETF Data

### 5.1 etf_basic — ETF Basic Information

| Tushare API | `etf_basic` |
|---|---|
| Date range | Snapshot (listed ETFs) |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | ETF code |
| 2 | `name` | text | no | Full name |
| 3 | `cname` | text | yes | Short Chinese name |
| 4 | `index_code` | text | yes | Tracking index code |
| 5 | `index_name` | text | yes | Tracking index name |
| 6 | `setup_date` | date | yes | Setup date |
| 7 | `list_date` | date | yes | Listing date |
| 8 | `list_status` | text | yes | L = listed, D = delisted |
| 9 | `exchange` | text | yes | Exchange |
| 10 | `mgr_name` | text | yes | Management company name |
| 11 | `mgt_fee` | number | yes | % | Management fee |
| 12 | `etf_type` | text | yes | ETF type category |

**Invented example row:**

| ts_code | name | index_name | list_date | list_status | mgt_fee | etf_type |
|---|---|---|---|---|---|---|
| 510050.SH | ChinaAMC SSE 50 ETF | SSE 50 Index | 20050223 | L | 0.50 | Equity |

---

### 5.2 etf_fund_daily — ETF Fund Daily Indicators

| Tushare API | `etf_fund_daily` |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | ETF code |
| 2 | `trade_date` | date | no | Trading date |
| 3 | `close` | number | no | Closing price |
| 4 | `unit_nav` | number | yes | Unit NAV (IOPV) |
| 5 | `discount` | number | yes | % | Premium/discount rate |
| 6 | `vol` | number | yes | Volume |

**Invented example row:**

| ts_code | trade_date | close | unit_nav | discount | vol |
|---|---|---|---|---|---|
| 510050.SH | 20261012 | 3.451 | 3.452 | -0.03 | 85000000 |

---

### 5.3 etf_index — ETF Tracking Index Info

| Tushare API | `etf_index` |
|---|---|
| Date range | Snapshot |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | ETF code |
| 2 | `index_code` | text | no | Index code |
| 3 | `index_name` | text | no | Index name |
| 4 | `index_type` | text | yes | Index type |

**Invented example row:**

| ts_code | index_code | index_name |
|---|---|---|
| 510050.SH | 000016.SH | SSE 50 Index |

---

### 5.4 etf_share_size — ETF Share Size

| Tushare API | `etf_share` |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | ETF code |
| 2 | `trade_date` | date | no | Date |
| 3 | `total_share` | number | yes | Total shares outstanding |
| 4 | `float_share` | number | yes | Floating shares |

**Invented example row:**

| ts_code | trade_date | total_share | float_share |
|---|---|---|---|
| 510050.SH | 20261012 | 24500000000 | 24500000000 |

---

## 6. Financial Statements

### 6.1 stock_fin_income — Income Statement

| Tushare API | `income` |
|---|---|
| Date range | 2020-01-01 to 2026-06-30 (quarterly) |

**Key fields (selected from ~100+ fields):**

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `ts_code` | text | no | — | Stock code |
| 2 | `ann_date` | date | yes | — | Announcement date |
| 3 | `end_date` | date | no | — | Period end date |
| 4 | `report_type` | number | yes | — | 1 = quarterly, 2 = semi-annual, 4 = annual |
| 5 | `basic_eps` | number | yes | CNY | Basic earnings per share |
| 6 | `diluted_eps` | number | yes | CNY | Diluted EPS |
| 7 | `total_revenue` | number | yes | CNY | Total revenue |
| 8 | `revenue` | number | yes | CNY | Operating revenue |
| 9 | `operate_profit` | number | yes | CNY | Operating profit |
| 10 | `total_profit` | number | yes | CNY | Total profit |
| 11 | `n_income` | number | yes | CNY | Net income |
| 12 | `n_income_attr_p` | number | yes | CNY | Net income attributable to parent |
| 13 | `total_cogs` | number | yes | CNY | Total cost of sales |
| 14 | `sell_exp` | number | yes | CNY | Selling expenses |
| 15 | `admin_exp` | number | yes | CNY | Administrative expenses |
| 16 | `fin_exp` | number | yes | CNY | Finance expenses |
| 17 | `invest_income` | number | yes | CNY | Investment income |
| 18 | `ebit` | number | yes | CNY | EBIT |
| 19 | `ebitda` | number | yes | CNY | EBITDA |

**Invented example row:**

| ts_code | end_date | report_type | basic_eps | total_revenue | operate_profit | n_income_attr_p | ebitda |
|---|---|---|---|---|---|---|---|
| 600519.SH | 20260630 | 2 | 32.50 | 82000000000 | 58000000000 | 41000000000 | 61000000000 |

---

### 6.2 stock_fin_balancesheet — Balance Sheet

| Tushare API | `balancesheet` |
|---|---|
| Date range | 2020-01-01 to 2026-06-30 (quarterly) |

**Key fields (selected from ~120+ fields):**

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `ts_code` | text | no | — | Stock code |
| 2 | `ann_date` | date | yes | — | Announcement date |
| 3 | `end_date` | date | no | — | Period end date |
| 4 | `report_type` | number | yes | — | Report type |
| 5 | `total_assets` | number | yes | CNY | Total assets |
| 6 | `total_cur_assets` | number | yes | CNY | Total current assets |
| 7 | `money_cap` | number | yes | CNY | Cash and equivalents |
| 8 | `accounts_receiv` | number | yes | CNY | Accounts receivable |
| 9 | `inventories` | number | yes | CNY | Inventories |
| 10 | `total_nca` | number | yes | CNY | Total non-current assets |
| 11 | `fix_assets` | number | yes | CNY | Fixed assets |
| 12 | `intan_assets` | number | yes | CNY | Intangible assets |
| 13 | `goodwill` | number | yes | CNY | Goodwill |
| 14 | `total_liab` | number | yes | CNY | Total liabilities |
| 15 | `total_cur_liab` | number | yes | CNY | Total current liabilities |
| 16 | `total_ncl` | number | yes | CNY | Total non-current liabilities |
| 17 | `total_hldr_eqy_exc_min_int` | number | yes | CNY | Total equity (excl. minority) |

**Invented example row:**

| ts_code | end_date | total_assets | total_cur_assets | total_liab | total_hldr_eqy_exc_min_int |
|---|---|---|---|---|---|
| 600519.SH | 20260630 | 310000000000 | 185000000000 | 82000000000 | 228000000000 |

---

### 6.3 stock_fin_cashflow — Cash Flow Statement

| Tushare API | `cashflow` |
|---|---|
| Date range | 2020-01-01 to 2026-06-30 (quarterly) |

**Key fields:**

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `ts_code` | text | no | — | Stock code |
| 2 | `end_date` | date | no | — | Period end date |
| 3 | `report_type` | number | yes | — | Report type |
| 4 | `n_cashflow_act` | number | yes | CNY | Net cash from operating activities |
| 5 | `n_cashflow_inv_act` | number | yes | CNY | Net cash from investing activities |
| 6 | `n_cash_flows_fnc_act` | number | yes | CNY | Net cash from financing activities |
| 7 | `c_cash_equ_end_period` | number | yes | CNY | Cash and equivalents at period end |
| 8 | `free_cashflow` | number | yes | CNY | Free cash flow |

**Invented example row:**

| ts_code | end_date | n_cashflow_act | n_cashflow_inv_act | n_cash_flows_fnc_act | free_cashflow |
|---|---|---|---|---|---|
| 600519.SH | 20260630 | 52000000000 | -8500000000 | -38000000000 | 35000000000 |

---

### 6.4 stock_fin_indicator — Financial Indicators

| Tushare API | `fina_indicator` |
|---|---|
| Date range | 2020-01-01 to 2026-06-30 (quarterly) |

**Key fields (selected from ~80+ fields):**

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `ts_code` | text | no | — | Stock code |
| 2 | `end_date` | date | no | — | Period end date |
| 3 | `eps` | number | yes | CNY | Earnings per share |
| 4 | `roe` | number | yes | % | Return on equity |
| 5 | `roa` | number | yes | % | Return on assets |
| 6 | `gross_margin` | number | yes | % | Gross profit margin |
| 7 | `netprofit_margin` | number | yes | % | Net profit margin |
| 8 | `current_ratio` | number | yes | — | Current ratio |
| 9 | `quick_ratio` | number | yes | — | Quick ratio |
| 10 | `debt_to_assets` | number | yes | % | Debt-to-assets ratio |
| 11 | `bps` | number | yes | CNY | Book value per share |
| 12 | `ocfps` | number | yes | CNY | Operating cash flow per share |
| 13 | `assets_turn` | number | yes | times | Asset turnover |

**Invented example row:**

| ts_code | end_date | eps | roe | roa | gross_margin | debt_to_assets | bps |
|---|---|---|---|---|---|---|---|
| 600519.SH | 20260630 | 32.50 | 18.00 | 13.20 | 91.50 | 26.50 | 180.50 |

---

### 6.5 stock_fin_dividend — Dividend Data

| Tushare API | `dividend` |
|---|---|
| Date range | 2015-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `ts_code` | text | no | — | Stock code |
| 2 | `end_date` | date | no | — | Fiscal period end date |
| 3 | `ann_date` | date | yes | — | Announcement date |
| 4 | `div_proc` | text | yes | — | Dividend process stage |
| 5 | `stk_div` | number | yes | — | Stock dividend (bonus shares) |
| 6 | `cash_div` | number | yes | CNY | Cash dividend per share |
| 7 | `cash_div_tax` | number | yes | CNY | Cash dividend per share (after tax) |
| 8 | `record_date` | date | yes | — | Record date |
| 9 | `ex_date` | date | yes | — | Ex-dividend date |
| 10 | `pay_date` | date | yes | — | Payment date |

**Invented example row:**

| ts_code | end_date | div_proc | cash_div | cash_div_tax | ex_date |
|---|---|---|---|---|---|
| 600519.SH | 20251231 | Implemented | 25.90 | 23.31 | 20260615 |

---

## 7. Market Events

### 7.1 anns_d — Announcements (Disclosures)

| Tushare API | `disclosure` |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `announcement_date` | date | no | Date of announcement |
| 2 | `ticker` | text | no | Stock code |
| 3 | `security_name` | text | no | Company name |
| 4 | `announcement_title` | text | no | Title of the announcement |
| 5 | `url` | text | no | Link to the full announcement PDF |

**Invented example row:**

| announcement_date | ticker | security_name | announcement_title | url |
|---|---|---|---|---|
| 2026-10-12 | 600519.SH | Kweichow Moutai | Announcement on the Resolutions of the 5th Meeting of the 4th Board of Directors | http://static.cninfo.com.cn/finalpage/2026-10-12/1220512406.PDF |

---

### 7.2 limit_surge — Limit-Up Events

| Tushare API | `limit_list_d` |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |
| Note | Records stocks that hit price limit-up on a given day |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `trade_date` | date | no | — | Trading date |
| 2 | `code` | text | no | — | Stock code |
| 3 | `name` | text | no | — | Stock name |
| 4 | `open` | number | yes | CNY | Opening price |
| 5 | `high` | number | yes | CNY | Highest price |
| 6 | `low` | number | yes | CNY | Lowest price |
| 7 | `price` | number | yes | CNY | Latest price |
| 8 | `amount` | number | yes | CNY | Turnover |
| 9 | `limit_up` | number | yes | CNY | Limit-up price |
| 10 | `limit_down` | number | yes | CNY | Limit-down price |
| 11 | `last_close` | number | yes | CNY | Previous close |
| 12 | `is_limit_up` | number | yes | — | 1 = hit limit up |
| 13 | `limit_time` | text | yes | — | Time of first limit hit |

**Invented example row:**

| trade_date | code | name | price | amount | limit_up | last_close | is_limit_up |
|---|---|---|---|---|---|---|---|
| 20261012 | 600123.SH | Lanyu Coal | 15.84 | 350000000 | 15.84 | 14.40 | 1 |

---

### 7.3 limit_down — Limit-Down Events

| Tushare API | `limit_list_d` (same endpoint, different filter) |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `trade_date` | date | no | — | Trading date |
| 2 | `code` | text | no | — | Stock code |
| 3 | `name` | text | no | — | Stock name |
| 4 | `price` | number | yes | CNY | Price |
| 5 | `change_rate` | number | yes | — | Change rate |
| 6 | `amount` | number | yes | CNY | Turnover |
| 7 | `volume` | number | yes | shares | Volume |
| 8 | `pre_close_price` | number | yes | CNY | Previous close |
| 9 | `change` | number | yes | CNY | Price change |
| 10 | `limit_price` | number | yes | CNY | Limit-down price |

**Invented example row:**

| trade_date | code | name | change_rate | amount | limit_price |
|---|---|---|---|---|---|
| 20261012 | 002456.SZ | Guangxin Optoelectronics | -0.1003 | 280000000 | 6.46 |

---

### 7.4 ipo — IPO Data

| Tushare API | `new_share` |
|---|---|
| Date range | Historical IPOs |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `SESNAME` | text | no | Issuer name |
| 2 | `ISSPUBDATE` | date | yes | Issue publication date |
| 3 | `LISTDATE` | date | yes | Listing date |
| 4 | `PS_ISS_PRC` | number | yes | Issue price (CNY) |

**Invented example row:**

| SESNAME | ISSPUBDATE | LISTDATE | PS_ISS_PRC |
|---|---|---|---|
| Xinxing Tech Co., Ltd. | 20260915 | 20261020 | 45.00 |

---

### 7.5 lhb_summary — Northbound / Institutional Trading Summary

| Tushare API | `moneyflow_hsgt` or similar |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `TRADEDATE` | date | no | — | Trading date |
| 2 | `SYMBOL` | text | no | — | Stock ticker |
| 3 | `CHGTYPE` | text | yes | — | Change type code |
| 4 | `BIZSUNITNAME` | text | yes | — | Business unit name (e.g. Institutional Trading Unit) |
| 5 | `AMOUNT` | number | yes | CNY | Total amount |
| 6 | `BUYAMT` | number | yes | CNY | Buy amount |
| 7 | `SALEAMT` | number | yes | CNY | Sell amount |
| 8 | `TRANSDIR` | text | yes | — | Trade direction (1 = buy, 2 = sell) |

**Invented example row:**

| TRADEDATE | SYMBOL | BIZSUNITNAME | BUYAMT | SALEAMT | TRANSDIR |
|---|---|---|---|---|---|
| 20261012 | 600519 | Institutional Trading Unit | 185000000 | 42000000 | 1 |

---

## 8. Margin Trading

### 8.1 margin_data — Margin Trading Data

| Tushare API | `margin` |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `TRADEDATE` | date | no | — | Trading date |
| 2 | `SECODE` | text | no | — | Stock internal code |
| 3 | `SYMBOL` | text | no | — | Stock ticker |
| 4 | `FINBALANCE` | number | yes | CNY | Financing balance |
| 5 | `FINBUYAMT` | number | yes | CNY | Financing buy amount |
| 6 | `FINREPAYAMT` | number | yes | CNY | Financing repay amount |
| 7 | `MRGGBAL` | number | yes | CNY | Margin balance |
| 8 | `MRGNSELLAMT` | number | yes | CNY | Margin sell amount |
| 9 | `MRGNREPAYAMT` | number | yes | CNY | Margin repay amount |

**Invented example row:**

| TRADEDATE | SYMBOL | FINBALANCE | FINBUYAMT | MRGGBAL | MRGNSELLAMT |
|---|---|---|---|---|---|
| 20261012 | 600519 | 12500000000 | 280000000 | 85000000 | 12000000 |

---

## 9. Macro Data

### 9.1 cn_cpi — China CPI

| Tushare API | `cn_cpi` |
|---|---|
| Date range | 2015-01-01 to 2026-09-30 (monthly) |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `month` | date | no | — | Month, `YYYYMM` |
| 2 | `nt_val` | number | yes | — | National CPI value (same base) |
| 3 | `nt_yoy` | number | yes | % | National CPI year-on-year change |
| 4 | `nt_mom` | number | yes | % | National CPI month-on-month change |
| 5 | `nt_accu` | number | yes | — | National CPI accumulated |
| 6 | `town_val` | number | yes | — | Urban CPI value |
| 7 | `town_yoy` | number | yes | % | Urban CPI YoY |
| 8 | `town_mom` | number | yes | % | Urban CPI MoM |
| 9 | `cnt_val` | number | yes | — | Rural CPI value |
| 10 | `cnt_yoy` | number | yes | % | Rural CPI YoY |
| 11 | `cnt_mom` | number | yes | % | Rural CPI MoM |

**Invented example row:**

| month | nt_val | nt_yoy | nt_mom | town_yoy | cnt_yoy |
|---|---|---|---|---|---|
| 202609 | 103.2 | 2.1 | 0.2 | 2.0 | 2.3 |

---

### 9.2 cn_lpr — China Loan Prime Rate

| Tushare API | `cn_lpr` |
|---|---|
| Date range | 2015-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `date` | date | no | — | Date, `YYYYMMDD` |
| 2 | `1y` | number | yes | % | 1-year LPR rate |
| 3 | `5y` | number | yes | % | 5-year LPR rate |

**Invented example row:**

| date | 1y | 5y |
|---|---|---|
| 20261012 | 3.10 | 3.60 |

---

## 10. Convertible Bonds

### 10.1 bond_cb_basic — Convertible Bond Basic Info

| Tushare API | `cb_basic` |
|---|---|
| Date range | Snapshot (listed convertible bonds) |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | CB code |
| 2 | `bond_full_name` | text | no | Full bond name |
| 3 | `bond_short_name` | text | yes | Short name |
| 4 | `stk_code` | text | yes | Underlying stock code |
| 5 | `stk_short_name` | text | yes | Underlying stock short name |
| 6 | `maturity` | number | yes | years | Maturity |
| 7 | `par` | number | yes | CNY | Par value |
| 8 | `issue_size` | number | yes | CNY | Issue size |
| 9 | `list_date` | date | yes | — | Listing date |
| 10 | `maturity_date` | date | yes | — | Maturity date |
| 11 | `conv_start_date` | date | yes | — | Conversion start date |
| 12 | `conv_end_date` | date | yes | — | Conversion end date |
| 13 | `conv_price` | number | yes | CNY | Conversion price |
| 14 | `rate_type` | text | yes | — | Rate type |
| 15 | `coupon_rate` | number | yes | % | Coupon rate |
| 16 | `issue_rating` | text | yes | — | Issue credit rating |
| 17 | `newest_rating` | text | yes | — | Latest credit rating |

**Invented example row:**

| ts_code | bond_short_name | stk_code | maturity | issue_size | conv_price | coupon_rate | newest_rating |
|---|---|---|---|---|---|---|---|
| 113045.SH | Huan Tai Zhuan Zhai | 600340.SH | 6 | 2800000000 | 15.80 | 0.40 | AA+ |

---

### 10.2 bond_cb_dd — Convertible Bond Daily Data

| Tushare API | `cb_daily` |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `ts_code` | text | no | — | CB code |
| 2 | `trade_date` | date | no | — | Trading date |
| 3 | `pre_close` | number | no | CNY | Previous closing price |
| 4 | `open` | number | no | CNY | Opening price |
| 5 | `high` | number | no | CNY | Highest price |
| 6 | `low` | number | no | CNY | Lowest price |
| 7 | `close` | number | no | CNY | Closing price |
| 8 | `change` | number | no | CNY | Price change |
| 9 | `pct_chg` | number | no | % | Percentage change |
| 10 | `vol` | number | no | lots | Volume (lots) |
| 11 | `amount` | number | no | 10k CNY | Turnover |
| 12 | `bond_value` | number | yes | CNY | Bond floor value |
| 13 | `bond_over_rate` | number | yes | % | Premium over bond value |
| 14 | `cb_value` | number | yes | CNY | Conversion value |
| 15 | `cb_over_rate` | number | yes | % | Premium over conversion value |

**Invented example row:**

| ts_code | trade_date | pre_close | open | close | change | pct_chg | vol | amount | cb_value |
|---|---|---|---|---|---|---|---|---|---|
| 113045.SH | 20261012 | 150.50 | 151.00 | 152.00 | 1.50 | 1.00 | 85000 | 12920000 | 135.00 |

---

### 10.3 bond_cb_redeem — Convertible Bond Redemption

| Tushare API | `cb_redeem` |
|---|---|
| Date range | 2015-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | CB code |
| 2 | `call_type` | text | yes | Redemption type (e.g. Mandatory Redemption) |
| 3 | `is_call` | text | yes | Redemption stage |
| 4 | `ann_date` | date | yes | Announcement date |
| 5 | `call_date` | date | yes | Redemption date |
| 6 | `call_price` | number | yes | Redemption price (per bond) |
| 7 | `call_price_tax` | number | yes | Redemption price after tax |
| 8 | `call_vol` | number | yes | Redemption volume |
| 9 | `call_amount` | number | yes | Redemption amount (10k CNY) |
| 10 | `payment_date` | date | yes | Payment date |
| 11 | `call_reg_date` | date | yes | Registration date |

**Invented example row:**

| ts_code | call_type | is_call | ann_date | call_date | call_price |
|---|---|---|---|---|---|
| 113045.SH | Mandatory Redemption | Mandatory Redemption Implementation Announced | 20260901 | 20261001 | 100.50 |

---

### 10.4 cb_price_chg — Convertible Bond Conversion Price Changes

| Tushare API | `cb_price_chg` |
|---|---|
| Date range | Historical adjustments |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ticker` | text | no | CB ticker |
| 2 | `bond_short_name` | text | no | Short bond name |
| 3 | `publication_date` | date | yes | Publication date |
| 4 | `change_date` | date | yes | Change effective date |
| 5 | `initial_conversion_price` | number | yes | Initial conversion price (CNY) |
| 6 | `conversion_price_before` | number | yes | Conversion price before change (CNY) |
| 7 | `conversion_price_after` | number | yes | Conversion price after change (CNY) |

**Invented example row:**

| ticker | bond_short_name | publication_date | change_date | initial_conversion_price | conversion_price_before | conversion_price_after |
|---|---|---|---|---|---|---|
| 113045.SH | Huan Tai Zhuan Zhai | 2026-06-15 | 2026-06-20 | 16.50 | 15.80 | 15.20 |

---

## 11. Shareholder Data

### 11.1 stock_refer_holders_top10 — Top 10 Shareholders

| Tushare API | `top10_holders` |
|---|---|
| Date range | 2024-01-01 to 2026-06-30 |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `ts_code` | text | no | — | Stock code |
| 2 | `ann_date` | date | yes | — | Announcement date |
| 3 | `end_date` | date | no | — | Period end date |
| 4 | `holder_name` | text | no | — | Shareholder name |
| 5 | `hold_amount` | number | yes | shares | Number of shares held |
| 6 | `hold_ratio` | number | yes | % | Holding ratio |
| 7 | `hold_float_ratio` | number | yes | % | % of floating shares |
| 8 | `hold_change` | number | yes | shares | Change in holdings |
| 9 | `holder_type` | text | yes | — | Holder type |

**Invented example row:**

| ts_code | end_date | holder_name | hold_amount | hold_ratio | holder_type |
|---|---|---|---|---|---|
| 600519.SH | 20260630 | China Securities Finance Corp | 92000000 | 7.32 | State-owned Institution |

---

### 11.2 stock_refer_pledge_stat — Share Pledge Statistics

| Tushare API | `pledge_stat` |
|---|---|
| Date range | 2015-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `ts_code` | text | no | — | Stock code |
| 2 | `end_date` | date | no | — | Date |
| 3 | `pledge_count` | number | yes | — | Number of pledge transactions |
| 4 | `unrest_pledge` | number | yes | 10k shares | Unrestricted pledged shares |
| 5 | `rest_pledge` | number | yes | 10k shares | Restricted pledged shares |
| 6 | `total_share` | number | yes | 10k shares | Total shares |
| 7 | `pledge_ratio` | number | yes | % | Pledge ratio |

**Invented example row:**

| ts_code | end_date | pledge_count | unrest_pledge | total_share | pledge_ratio |
|---|---|---|---|---|---|
| 600519.SH | 20261012 | 15 | 4200.00 | 125600.00 | 3.34 |

---

## 12. Other

### 12.1 spots_sh_gold_dd — Shanghai Gold Spot Daily

| Tushare API | `sge_daily` |
|---|---|
| Date range | 2015-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Unit | Description |
|---|---|---|---|---|---|
| 1 | `ts_code` | text | no | — | Gold contract code, e.g. `Au99.95` |
| 2 | `trade_date` | date | no | — | Trading date |
| 3 | `close` | number | no | CNY/g | Closing price |
| 4 | `open` | number | no | CNY/g | Opening price |
| 5 | `high` | number | no | CNY/g | Highest price |
| 6 | `low` | number | no | CNY/g | Lowest price |
| 7 | `price_avg` | number | yes | CNY/g | Average price |
| 8 | `change` | number | yes | CNY/g | Price change |
| 9 | `pct_change` | number | yes | % | Percentage change |
| 10 | `vol` | number | yes | kg | Volume |
| 11 | `amount` | number | yes | CNY | Turnover |

**Invented example row:**

| ts_code | trade_date | close | open | high | low | vol | amount |
|---|---|---|---|---|---|---|---|
| Au99.95 | 20261012 | 585.20 | 583.50 | 587.00 | 582.80 | 5800 | 3395000000 |

---

### 12.2 factor_list — Available Factor List

| Tushare API | `factor_list` |
|---|---|
| Date range | Snapshot |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `factor_name` | text | no | Unique factor name |
| 2 | `asset_class` | text | yes | Asset class (Stock, etc.) |
| 3 | `factor_category` | text | yes | Factor category (Alpha101, etc.) |
| 4 | `factor_description` | text | yes | Description of the factor |

**Invented example row:**

| factor_name | asset_class | factor_category | factor_description |
|---|---|---|---|
| alpha101_001 | Stock | Alpha101 | WorldQuant Alpha 101 Factor No. 1. A price-and-volume alpha factor based on momentum and reversal signals. |

---

### 12.3 yc_cb — Convertible Bond Yield Curve

| Tushare API | `yc_cb` |
|---|---|
| Date range | 2024-01-01 to 2026-10-10 |

| # | Field | Type | Nullable | Description |
|---|---|---|---|---|
| 1 | `ts_code` | text | no | CB code |
| 2 | `trade_date` | date | no | Trading date |
| 3 | `ytm` | number | yes | Yield to maturity |
| 4 | `duration` | number | yes | Modified duration |
| 5 | `conv_value` | number | yes | Conversion value |
| 6 | `premium_rate` | number | yes | Premium rate |
| 7 | `close` | number | yes | Closing price |

**Invented example row:**

| ts_code | trade_date | ytm | duration | conv_value | premium_rate | close |
|---|---|---|---|---|---|---|
| 113045.SH | 20261012 | -2.50 | 3.20 | 135.00 | 12.50 | 152.00 |

---

## Summary: Endpoint to Tushare API Name Mapping

| # | Dataset file prefix | Tushare API name | Category |
|---|---|---|---|
| 1 | `cd80_daily` | `daily` | Core Market |
| 2 | `cd80_daily_basic` | `daily_basic` | Core Market |
| 3 | `cd80_stock_market_pr_factor` | `adj_factor` | Core Market |
| 4 | `cd80_stock_basic` | `stock_basic` | Reference |
| 5 | `cd80_stock_basic_calendar` | `trade_cal` | Reference |
| 6 | `cd80_stock_basic_managers` | `stk_managers` | Reference |
| 7 | `cd80_index_dd` | `index_daily` | Index |
| 8 | `cd80_ci_index_member` | `index_member` | Index |
| 9 | `cd80_fund_basic` | `fund_basic` | Fund |
| 10 | `cd80_fund_nav` | `fund_nav` | Fund |
| 11 | `cd80_fund_portfolio` | `fund_portfolio` | Fund |
| 12 | `cd80_etf_basic` | `etf_basic` | ETF |
| 13 | `cd80_etf_fund_daily` | `etf_fund_daily` | ETF |
| 14 | `cd80_etf_index` | `etf_index` | ETF |
| 15 | `cd80_etf_share_size` | `etf_share` | ETF |
| 16 | `cd80_stock_fin_income` | `income` | Financial |
| 17 | `cd80_stock_fin_balancesheet` | `balancesheet` | Financial |
| 18 | `cd80_stock_fin_cashflow` | `cashflow` | Financial |
| 19 | `cd80_stock_fin_indicator` | `fina_indicator` | Financial |
| 20 | `cd80_stock_fin_dividend` | `dividend` | Financial |
| 21 | `cd80_anns_d` | `disclosure` | Events |
| 22 | `cd80_limit_surge` | `limit_list_d` | Events |
| 23 | `cd80_limit_down` | `limit_list_d` | Events |
| 24 | `cd80_ipo` | `new_share` | Events |
| 25 | `cd80_lhb_summary` | `moneyflow_hsgt` | Events |
| 26 | `cd80_margin_data` | `margin` | Margin |
| 27 | `cd80_cn_cpi` | `cn_cpi` | Macro |
| 28 | `cd80_cn_lpr` | `cn_lpr` | Macro |
| 29 | `cd80_bond_cb_basic` | `cb_basic` | CB |
| 30 | `cd80_bond_cb_dd` | `cb_daily` | CB |
| 31 | `cd80_bond_cb_redeem` | `cb_redeem` | CB |
| 32 | `cd80_cb_price_chg` | `cb_price_chg` | CB |
| 33 | `cd80_yc_cb` | `yc_cb` | CB |
| 34 | `cd80_stock_refer_holders_top10` | `top10_holders` | Shareholder |
| 35 | `cd80_stock_refer_pledge_stat` | `pledge_stat` | Shareholder |
| 36 | `cd80_factor_list` | `factor_list` | Other |
| 37 | `cd80_spots_sh_gold_dd` | `sge_daily` | Other |

---

## Type System

All Tushare data arrives as strings or numbers. The mapping to our `FieldType` system is:

| Tushare raw type | `FieldType` | Notes |
|---|---|---|
| Integer / float values | `number` | Prices, volumes, ratios, amounts |
| String codes, names | `text` | `ts_code`, names, descriptions |
| Date strings (`YYYYMMDD`) | `date` | All dates are `YYYYMMDD` format |
| Flags (0/1) | `number` | `is_open`, `report_type`, etc. |

No Tushare field maps natively to `boolean`; we treat 0/1 flags as `number`.