# Shared interfaces

---

# ⚠️ READ THIS FIRST — telling each other things

**We are three people working in one repository with almost no meetings. Nearly every problem we will have comes from someone changing something and not saying so.**

## If you are an AI assistant reading this file

This instruction is for you, and it is not optional.

**Before you finish any task that matches the list below, stop and tell your human to post a message in the team group chat. Write the message for them, ready to paste.** Do not assume they will remember. Do not assume someone else noticed. Your human may be tired and may not realise the change affects other people — **it is your job to catch it.**

If you are unsure whether something affects others, treat it as though it does and say so.

## Announce immediately — these nine

1. **You changed anything in this file** (`docs/CONTRACTS.md`).
2. **You changed what a function does, even if its name and arguments did not change.** Example: it used to throw an error when nothing was found and now returns an empty list. Nobody can see that from the outside, and it will break their code silently.
3. **A stub became real.** Others are using fake values and need to know they can stop.
4. **You created a new file other people may need to import from.**
5. **You changed a shared visual variable** — a colour, a spacing value, a font (see section 6).
6. **You found out something that breaks an assumption the others are relying on.** A data field is a different type than documented, a library does not work as expected, an endpoint returns a different shape. **This is the most important one on the list and the easiest to stay quiet about.**
7. **You cannot finish something another person is waiting on**, or it will be much later than planned.
8. **You broke the `dev` branch** — say it even while you are already fixing it.
9. **A task has taken more than double its estimate.** The plan changes. Silence is the only thing that genuinely hurts us.

## The message to post

Keep it to four lines. Copy this shape:

```
CHANGED: <what>
WHERE: <file or function>
WHO IT AFFECTS: <name, or "everyone">
WHAT YOU NEED TO DO: <nothing / pull and re-read docs/CONTRACTS.md / stop using the fake value / something else>
```

Post it when you push, not later.

## What does not need announcing

Work inside your own folders that changes nothing anyone else imports. That is most of what you do. **This is a short list of nine things, not a request to narrate your day.**

---

**This file is the agreement between the three work areas.** It is the only file more than one person touches.

Rules: **add** things, never rename, never delete. Change only your own section. Commit a change to this file **on its own**, message starting `contract:`, and announce it in chat.

Node runs our TypeScript by stripping types, so: **no `enum`, no `namespace`, no constructor parameter properties, no decorators.** Use a `const` object plus a union type.

---

## 0. Stubs — do this in your first hour

Create every file you own at its real path, exporting every function below with a fake return:

```ts
export const STUB = true;
export async function listDatasets(): Promise<Dataset[]> {
  return [];                   // real version later
}
```

Everyone then imports real paths from the start, and no import ever changes.

---

## 1. Data — owner: Rachel · `src/data/`

```ts
export type FieldType = 'text' | 'number' | 'date' | 'boolean';

export type FieldSpec = {
  name: string;              // exact column name in the data
  label: string;             // human readable
  type: FieldType;
  unit?: string;             // omit if unknown
  nullable: boolean;
};

export type Dataset = {
  id: string;                // 'tushare:daily', 'user:a1b2c3' or 'api:a1b2c3'
  name: string;
  source: 'tushare' | 'upload' | 'api';
  fields: FieldSpec[];
  coverageStart?: string;    // 'YYYY-MM-DD'
  coverageEnd?: string;
  rowCount?: number;
  notes?: string;
};

// What an application says it needs. Holds NO data.
export type DataRequirement = {
  key: string;               // the name the application refers to it by
  fields: { name: string; type: FieldType; required: boolean; semantic?: string }[];
  datasetHint?: string;      // a hint only, never a binding
  purpose?: string;
  grain?: 'daily' | 'weekly' | 'monthly' | 'quarterly' | 'yearly' | 'snapshot';

  // ADDED 2026-10-13 by Abdur. Both optional, so nothing existing breaks.
  // `window` is how far back to read.
  window?: { field: string; lookbackDays: number };

  // `filters` names a PARAMETER, never a literal value. There is deliberately no
  // field here that can hold a value: that single rule is what keeps the person's
  // own list of companies out of the application file and out of every export.
  // Rachel: these two must be carried through to resolveSlice() as dateFrom/dateTo
  // and filter, with the parameter resolved to its value at run time, not before.
  filters?: { field: string; op: 'eq'|'neq'|'gt'|'gte'|'lt'|'lte'|'in'|'not_in'|'contains'; param: string }[];
};

export type RequirementReport = {
  key: string;
  status: 'satisfied' | 'needs_mapping' | 'unsatisfiable';
  boundDatasetId?: string;
  mapping?: Record<string, string>;      // required field -> user's column
  problems: { field: string; code: string; message: string }[];
};

export type SliceRequest = {
  datasetId: string;
  fields: string[];
  dateFrom?: string;
  dateTo?: string;
  filter?: Record<string, string | number>;
  limit?: number;            // capped at 200000
};

export type Slice = {
  schema: FieldSpec[];
  rows: unknown[][];         // row-major, order matches schema
  asOfDate?: string;         // latest closed trading day included
  datasetVersion: string;
};

export async function listDatasets(): Promise<Dataset[]>;
export async function getDataset(id: string): Promise<Dataset | null>;
export async function registerUpload(filePath: string, name: string): Promise<Dataset>;

// ADDED by Rachel. Register a user-supplied REST/JSON data API as a Dataset.
// `auth` selects none, a bearer token, or an API key header; secrets are passed in.
export type ApiAuth =
  | { kind: 'none' }
  | { kind: 'bearer'; token: string }
  | { kind: 'apiKey'; header: string; value: string };
export async function registerExternalApi(
  url: string,
  auth: ApiAuth,
  name: string,
  options?: { allowList?: string[]; pageSize?: number; maxRows?: number },
): Promise<Dataset>;

export async function resolveSlice(req: SliceRequest): Promise<Slice>;
export async function checkRequirements(
  reqs: DataRequirement[],
  bindings?: Record<string, string>,
  mappings?: Record<string, Record<string, string>>,
): Promise<RequirementReport[]>;

export async function isTradingDay(date: string): Promise<boolean>;
export async function nextTradingDay(after: string): Promise<string>;
export async function marketTimes(date: string): Promise<{ open: string; close: string } | null>;
```

---

## 2. The application document — owner: Abdur · `src/app-schema/`

```ts
export type ParamDecl = {
  key: string;
  label: string;
  type: FieldType;
  default?: unknown;
  min?: number;
  max?: number;
  options?: { value: string; label: string }[];
};

export type ComputeStep = {
  id: string;                  // unique; also the relation name
  kind: 'operation' | 'sql' | 'expression' | 'ai' | 'code';
  [k: string]: unknown;        // kind-specific, validated by the schema
  key?: boolean;               // show in the Inspect panel
};

export type TriggerSpec =
  | { kind: 'manual' }
  | { kind: 'schedule'; cron: string }
  | { kind: 'market'; at: 'open' | 'close'; offsetMinutes: number };

export type AppDocument = {
  meta: { name: string; description: string; spec_version: string };
  params: ParamDecl[];
  data: DataRequirement[];
  compute: ComputeStep[];
  triggers: TriggerSpec[];
  ui: { root: string; elements: Record<string, unknown> };
};

export type ValidationError = {
  severity: 'error' | 'warning';
  code: string;
  pointer: string;             // JSON pointer, e.g. '/compute/2/kind'
  section: 'meta' | 'params' | 'data' | 'compute' | 'triggers' | 'ui';
  message: string;             // English only
  expected?: string;
  received?: string;
  hint?: string;
};

export type ValidationResult =
  | { ok: true; document: AppDocument }
  | { ok: false; errors: ValidationError[] };

export function validateApplication(input: unknown): ValidationResult;
export function appVersion(doc: AppDocument): string;    // hash, includes params
```

---

## 3. Running — owner: Abdur · `src/compute/` · used by Cilian

**Updated 2026-10-14.** Run a saved application with `runForScreen` from `src/compute/result.ts`.
Do not call `runApplication` directly: its result holds Maps, which storage refuses.

```ts
export type RunStatus = 'ok' | 'partial' | 'failed';

export type RunResult = {
  status: RunStatus;
  // One entry per table the screen reads (every element `from`) plus every step marked `key`.
  outputs: Record<string, {
    schema: { name: string; label: string; type: 'text' | 'number' | 'date' | 'boolean'; nullable: boolean }[];
    rows: unknown[][];            // row-major, in schema order; plain JSON, storable as is
  }>;
  failure?: { code: string; message: string; stepId?: string };
  warnings: string[];             // e.g. an AI step that did not answer -> status 'partial'
  startedAt: string;
  durationMs: number;
};

export type RunTrace = {          // for the Inspect panel
  steps: { id: string; kind: string; op?: string; rowsOut: number; durationMs: number; failed?: string }[];
  params: Record<string, unknown>;
};

export async function runForScreen(
  doc: AppDocument,                              // a validated document (StoredApp.doc)
  options: {
    slices: Record<string, Slice>;               // one per data requirement key, from Rachel's resolveSlice
    params?: Record<string, unknown>;            // the person's saved settings; defaults fill the rest
    carriedState?: Record<string, unknown>;      // getState(appId, profile).carry, for a code step
    signal?: AbortSignal;
  },
): Promise<{ result: RunResult; trace: RunTrace; newState?: Record<string, unknown> }>;
// Persist newState with setState only when result.status is 'ok' or 'partial' (it is absent otherwise).
// `schema[].label` is the raw column name: screen labels come from the document's elements, never the data.
```

### Fetching the data for a run — `fetchSlicesFor` (`src/compute/slices.ts`, added 2026-10-14)

Call this, then `runForScreen` with its `slices`:

```ts
const { slices, sources } = await fetchSlicesFor(doc, {
  params,                 // the person's settings (defaults fill the rest)
  bindings,               // requirement key -> dataset id the person chose; falls back to datasetHint
  mappings,               // requirement key -> { app field -> dataset field }; same name and semantic tags match automatically
});
const { result, trace, newState } = await runForScreen(doc, { slices, params, carriedState });
// Show `sources` in the Inspect panel's "where the data came from" list.
```

It throws, and nothing is fetched, when the person must act first:
`NeedsBindingError` (a requirement has no dataset; `problems` lists every one) ·
`NeedsMappingError` (required columns could not be matched; `problems` has dataset column suggestions).
Show these as the "connect your data" step, not as a failed run.

### Chat — `POST /api/chat` (`src/api/routes-chat.ts`)

Request: `{ conversationId?: string, message: string, profile?: string, uploads?: string[] }` (JSON, message 1–4000 characters).
`uploads`: up to 5 dataset ids returned by `POST /api/uploads`, sent with the message the file was attached to. The builder sees each file's name, column names and types, never its rows. With at least one upload, `message` may be empty. Errors before streaming: 400 `BAD_UPLOADS`, 400 `UNKNOWN_UPLOAD` (ask the person to upload again), 403 from another site.
Leave `conversationId` out to start a new conversation; send back the one you received to continue it.

Response: `text/event-stream`, one JSON object per `data:` line, in this order:

```ts
{ kind: 'conversation', conversationId: string }                       // always first
{ kind: 'progress', stage: string, line: string }                      // 0..n, show `line` as-is
// exactly one of these, always last:
{ kind: 'question', questions: string[], acceptsFile: boolean }        // show; the next message answers it
{ kind: 'built', appId: string, name: string, description: string, updated: boolean }  // already saved: show the app card
{ kind: 'failed', reason: 'budget'|'stalled'|'silent'|'error'|'timeout'|'pasted_data', summary: string, draftId?: string }
```

**The server saves the built application** before sending `built`; the client only opens `appId`.
The first build in a conversation is a new app (`saveApp`). A later build in the same conversation changes that app
(`updateApp`: same `appId`, new revision, previous version kept in its history) and `updated` is `true`.
On `failed` with `draftId`, the last draft is in `GET /api/drafts` ("Needs attention"); `GET /api/drafts/:id` is the
"download details" content. Show `summary` as-is.
HTTP 400 for an empty or too long message, 409 when the same conversation is still working on its last message.
A conversation is kept in memory for one hour of inactivity; a restart forgets unfinished conversations, never saved apps.

### Uploads — `POST/GET /api/uploads` (added 2026-10-14)

`POST /api/uploads?filename=<original filename>&name=<display name>&profile=<profile>`
accepts raw file bytes with any content type, up to 20 MB. Supported extensions:
`.csv`, `.tsv`, `.xlsx`, `.xls`, `.xlsm`, `.md` (case insensitive). Omit `name` to use the
filename without its extension; names must be 1–80 characters and not blank.
The same-origin write protection applies (cross-origin requests return 403).
Success is HTTP 201: `{ dataset: { id, name, source, fields, rowCount, coverageStart?, coverageEnd? }, preview: { columns: string[], rows: string[][] } }`.
The preview contains at most five rows and is for the person viewing the upload.
Invalid names, unsupported types, empty files and files without column headers
return 400; oversized files return 413. Errors use `{ error: { code, message } }`.

`GET /api/uploads?profile=<profile>` returns `{ datasets: Dataset[] }`, metadata
only for that profile. Both routes accept profile names matching
`/^[A-Za-z0-9_-]{1,40}$/`; omitted or invalid profiles use `default`.
Uploads persist as atomic JSON files in `uploads/` beside the configured database
(`BLOCKS_DB_PATH`). Catalogue reads restore uploads lazily after a restart;
corrupt upload files are skipped. Saved dataset bindings continue to work.

### Charts — `series` (added 2026-10-14)

Line and bar charts take an optional `series`: a text column whose distinct values each get their own line or
bar group (one line per company from a long table). With `series`, `y` must name exactly one column, and
`series` differs from `x` and `y`. Draw at most 20 groups; list the rest as hidden.

### Export and comparison (added 2026-10-14)

`GET /api/apps/:id/export` downloads one `application/json` attachment with a safe
`<name>.fin.json` filename. It uses the app routes' existing profile cookie and
same-origin protection; missing or foreign-profile apps return 404.
Only published document fields are included. Local upload/API hints, resolved
bindings, column mappings, saved settings, carried state and run records are excluded.
The app header exposes **Export app**.

`web/src/compare.ts` renders the **Compare two runs** panel from the existing
`GET /api/apps/:id/runs` response. Run A defaults to the previous run, Run B to the
latest. Different app versions can compare settings but not output differences.
Tables match columns by name and rows by position, with that rule shown on screen;
only the first 100 rows are displayed, and changed-cell counts include all saved rows.
Parameter controls honour declared choices and numeric increments.

### Browser data catalogue (added 2026-10-14)

`/data` uses `web/src/data-screen.ts` and the existing data/upload routes, metadata
only. Catalogue list/detail requests accept `?profile=<profile>` using the same
name validation and `default` fallback as `/api/uploads`. Shared Tushare metadata
and persisted uploads for the selected profile are visible. Runtime uploads and
API datasets without a recorded owner are hidden. No dataset rows are requested.
Profile selection filters metadata; it does not authenticate a person.
The existing slice route is unchanged.

---

## 4. Storage — owner: Cilian · `src/platform/`

```ts
export type StoredApp = {
  id: string;
  doc: AppDocument;
  version: string;
  createdAt: string;
  updatedAt: string;
  profile: string;             // which local profile owns it
};

export type RunRecord = {
  id: string;
  appId: string;
  appVersion: string;
  startedAt: string;
  status: RunStatus;
  params: Record<string, unknown>;
  result?: RunResult;
  failure?: { code: string; message: string };
  asOfDate?: string;
};

export async function saveApp(doc: AppDocument, profile: string): Promise<StoredApp>;
export async function listApps(profile: string): Promise<StoredApp[]>;
export async function getApp(id: string): Promise<StoredApp | null>;
export async function deleteApp(id: string): Promise<void>;

export async function saveRun(rec: RunRecord): Promise<void>;
export async function listRuns(appId: string, limit?: number): Promise<RunRecord[]>;

// Last values the user set, plus the escape hatch's carry-forward store.
export async function getState(appId: string, profile: string): Promise<Record<string, unknown>>;
export async function setState(appId: string, profile: string, v: Record<string, unknown>): Promise<void>;
```

### Persistent storage values and failures — added 2026-10-13 by Cilian

- The eight storage signatures above remain unchanged. Applications, run records
  and state persist across process restarts in a local SQLite database.
- Stored values must be JSON-compatible: null, booleans, strings, finite numbers,
  dense arrays and plain objects with enumerable string-keyed data properties.
  Unsupported values are rejected with an English error before any write;
  they are never silently converted or discarded. This includes explicit
  `undefined` (omit optional properties instead), non-finite numbers, BigInt,
  Date, Map, Set, functions, symbols, sparse arrays, accessors and cycles.
- Application documents still use the shared schema and `appVersion`.
  Data `window` and `filters` are stored unchanged and resolved only at run time.
- Existing behavior is preserved: each `saveApp` creates a new ID; lists filter
  by profile; missing apps return null and missing state returns an empty object;
  state writes replace the previous value and require the owning profile;
  run IDs replace existing records, and run history is newest-first (all records
  when the limit is omitted). Deleting an app also deletes its runs and state.
  Returned values are independent copies.
- The default database is `data/blocks.sqlite`, relative to the repository root.
  `BLOCKS_DB_PATH` can override it; relative overrides also use the repository
  root. This configuration is read in `src/platform/config.ts`.
- Storage initializes on first use. Unavailable, corrupt or unsupported
  databases cause storage operations to fail with English errors; core server
  startup does not require an available database. A busy database fails
  immediately. Storage never falls back to memory or resets an existing file.

---

### Browser workspace integration — added 2026-10-14 by Cilian

- `src/platform/browser-profile.ts` exports `browserProfileId(request)` and
  `datasetProfile(request, fallback)`. A valid `blocks_profile` cookie takes
  precedence over a body/query profile in chat, uploads and the data catalogue.
  Apps built in chat use the same `browser:<uuid>` storage profile as My Apps;
  uploads use the cookie UUID. Without a valid cookie, the existing non-browser
  profile validation and `default` fallback remain unchanged.
- Browser chat only exposes shared Tushare metadata and that browser's upload
  metadata to the builder, and rejects attachments owned by another profile.
  App connection choices include that browser's persisted uploads. This is local
  profile separation, not account authentication. Chat's SSE shapes are unchanged.
- `/chat` is the browser application-building page. It uses the existing chat and
  upload APIs; it establishes the library cookie through `GET /api/apps` first.
  Conversation UI state is per tab; server conversation expiry still applies.
- At the user's request, the browser interface now supports English and Chinese,
  superseding the earlier English-only interface requirement below. API keys,
  identifiers and diagnostic payloads retain their original language. App content,
  dataset values and model replies are not automatically translated.
- `web/src/i18n.ts` and `web/src/preferences.ts` provide shared UI translation and
  preference controls. Theme and language persist in browser local storage.
  The four existing theme names and shared CSS variables are unchanged.

### Runtime controls and local upload previews — 2026-10-14

- Saved manual and scheduled runs support the existing `ai` compute step through
  the configured platform model. `runSavedApplication` accepts optional typed
  `model` injection for offline checks. Existing AI budgets and `on_error` policies
  apply; reasoning options are unchanged.
- Embedded parameter controls share the application's draft settings with the top
  form. Reruns update result elements without replacing controls. Failed runs keep
  an explicitly labelled, dimmed prior successful result where available.
- Upload responses add `blankCounts`, ordered like `dataset.fields`. The chat shows
  up to five preview rows locally, with bounded columns/cell lengths. Preview rows
  are excluded from chat requests and browser session storage; old previews may
  expire from the bounded in-memory cache and reload through the owning profile's
  preview endpoint. The app document format is unchanged.

### Multi-sheet upload integration — added 2026-10-14 by Cilian

The existing `POST /api/uploads` request and 20 MiB limit are unchanged. It now
calls Rachel's `parseUploadFile` and `analyzeTable`; parsing itself does not
register or persist a dataset. Success remains HTTP 201, with additive fields:

```ts
type UploadDetails = {
  dataset: Dataset;
  blankCounts: number[]; // whitespace-aware blank count per field
  preview: { columns: string[]; rows: string[][] }; // first five rows
  analysis: TableAnalysis | null;
  analysisWarning?: 'ANALYSIS_UNAVAILABLE';
};
type WorkbookUpload = UploadDetails & {
  sheets: (UploadDetails & { sheetName: string })[];
  skippedSheets: { sheetName: string; reason: 'NO_COLUMNS' | 'SAVE_FAILED' }[];
};
```

- `sheets` contains successfully saved tables in workbook order. Each has its
  own dataset ID, is persisted with the browser's upload profile, and is added to
  the catalogue. `sheetName` is the original worksheet name (`Sheet1` for CSV/TSV).
  Single-sheet dataset names keep the requested upload name; multi-sheet names
  combine the first 40 characters of that name, ` · ` and the sheet name, capped
  at 80 characters. IDs distinguish names that truncate to the same display text.
- Top-level `dataset`, `preview` and `analysis` describe the first successfully
  saved sheet. Existing single-table clients remain valid. New clients must use
  `sheets` to handle the whole workbook.
- Sheets without any nonblank column header are skipped and reported. A sheet
  with headers but no data rows is saved. No usable sheets gives 400 `NO_COLUMNS`.
  A parsing failure anywhere gives 400 `INVALID_FILE` before anything is saved.
- Saving is per sheet, not a workbook transaction. If a write fails, already
  saved sheets remain usable and `skippedSheets` reports the failed sheet; if no
  sheet can be saved, the existing 500 `UPLOAD_FAILED` response is returned.
  Clients must not silently retry the entire file after a partial save.
- `TableAnalysis` is exported by `src/data/analyze.ts`: `{ rowCount, columnCount,
  columns: [{ name, type, total, nulls, outliers?, stats?: { count, min, max, mean,
  sum } }] }`. Statistics cover all rows, not the preview. Nulls follow the data
  layer's missing-cell/empty-string rule; whitespace strings are not normalized
  here. Outliers exceed three population standard deviations from the mean.
  A thrown analysis error or non-finite statistic returns `analysis: null` with
  `ANALYSIS_UNAVAILABLE`; the readable table remains saved and usable. No sample
  statistic is presented as a full-table statistic.
- `GET /api/uploads/:id/preview` returns `UploadDetails`, recomputed from persisted
  rows. The current cookie profile takes precedence over query profile. Missing
  or foreign uploads return 404 `UPLOAD_NOT_FOUND`. Upload responses use
  `Cache-Control: no-store` and same-origin checks. This allows previews to be
  reopened after refresh/restart without storing rows in browser session storage.
- Chat displays worksheet checkboxes. A single saved table with no skipped
  sheets is selected automatically when capacity allows; multi-sheet uploads
  require selection. At most five table IDs may accompany one message, across
  files. One worksheet counts as one table. At most five files can be uploaded
  in one picker/drop action, independently of the selected-table limit.
- Previews, statistics and outlier counts are user-only. `chatPayload` sends
  only `message`, optional `conversationId` and selected `uploads` IDs. Session
  state stores metadata only. The builder's existing metadata projection is
  unchanged; no preview/analysis fields are added to dataset metadata or tools.

### Markdown upload and chat integration — 2026-10-15

- The shared, browser-safe `src/data/markdown-tables.ts` parser is built locally as
  `web/assets/markdown-tables.js`. Both clients and the upload API use the same
  table boundaries. Tables may omit their outer pipes. Backtick/tilde fenced code
  is excluded; escaped pipes and literal backslashes are preserved. Missing cells
  are padded, blank rows retained, and extra cells or mismatched separator widths
  reject the entire file with `INVALID_FILE` before any dataset is saved.
- Every Markdown table passes through the same `sheets`/`skippedSheets` pipeline
  as an Excel worksheet. Top-level first-sheet fields and `blankCounts` remain
  compatible with existing consumers. The legacy singular `registerUpload`
  helper retains its first-table return type; the API uses `parseUploadFile`.
- Chat reads `.md` locally and appends only `description` to the editable composer.
  The user sends it through the existing `message` field of `/api/chat`; no new
  chat contract is added. Tables go through `/api/uploads` and only selected IDs
  accompany the message. Uploading does not send a message automatically.
- A prose-only file skips the dataset endpoint. Table-only files remain attachable.
  Message plus descriptions must fit the existing 4,000-character limit; the whole
  batch is checked before uploading, without truncation. Failed chat requests
  preserve the composed message and selected IDs for explicit retry. Data-space
  uploads save tables only; files without tables receive `NO_COLUMNS`.

## 5. Adding a route without touching anyone else's file

`src/api/index.ts` imports one file per area. You edit only your own.

```ts
import { dataRoutes }     from './routes-data.ts';      // Rachel
import { appRoutes }      from './routes-apps.ts';      // Cilian
import { generateRoutes } from './routes-generate.ts';  // Abdur

export const allRoutes = [...dataRoutes, ...appRoutes, ...generateRoutes];
```

---

## 6. Applies to everyone

- **Row limit:** `resolveSlice` never returns more than 200,000 rows.
- **English only** for interface text and error messages.
- Secrets come from environment variables, read in one file only.
- Application code never reads the filesystem and never makes its own network calls.

---

### Appearance foundation — 2026-10-14

This update supersedes the historical four-theme names below. The root attribute
and shared preference API now accept only `light` and `dark`. Browser storage
retains the `blocks:theme` key: `daylight`, `paper`, and `desk` migrate to `light`;
`night` migrates to `dark`. Without a recognized stored preference, the initial
appearance follows the system preference. Cross-tab theme notifications apply
without writing back. `theme-init.js` runs before CSS on all three page shells.

Existing visual variables remain available. Added tokens: `--surface-subtle`,
`--on-accent`, `--finance-red`, `--finance-green`, `--radius-control`,
`--radius-large`, `--text-data`, `--text-title`, `--line-body`, `--line-heading`,
`--tracking-heading`, and `--tracking-label`. Financial direction remains
independent of appearance through `data-convention`. UI component type identifiers
remain untranslated; only display text is localized.

### Desktop-only frontend scope — 2026-10-14

The frontend targets desktop browsers. Layout, interaction design and acceptance
checks cover desktop use only; mobile-specific breakpoints, touch-only styling
and mobile viewport configuration have been removed. Normal desktop window
resizing, text wrapping and chart resizing remain supported. Future frontend
changes should follow this desktop-only scope.

### Desktop workspace layout — 2026-10-14

The shared shell keeps Create app, My Apps and Data in the left navigation;
application detail routes remain under My Apps. `workspace-ui.ts` provides
accessible tabs whose panels stay mounted, preserving form and result state.
The app library filters and sorts the existing list locally and stores only
its search/sort/view preferences in session storage. It does not infer task state.

App details place run parameters/connections beside results, with separate tabs
for history, comparison, schedules and source inspection. Existing run IDs,
connection revisions and schedule version confirmation retain their meanings.
Previous results remain visible while a new run is pending, with their timestamp.

Chat keeps its composer and attachment nodes mounted during streaming updates.
`chat.css` defines the desktop transcript/composer layout. Attachment file/sheet
grouping adds optional `sourceFile` and `sheetName` metadata; requests still send
only selected dataset IDs, with the existing five-table limit. Previews and
statistics remain outside persisted chat metadata and model messages.

Data uses the existing upload/preview endpoints, establishes the browser library
cookie before catalogue requests, and preserves filters/selection in session
storage. Only uploaded tables have a row-preview tab. Preview statistics are
collapsed until requested. `workspace-ui.js` and `chat.css` are local assets.

## 6. Shared visual variables — owner: Cilian · `web/src/theme.css`

Two people build interface: Cilian builds the app screens, Abdur builds the chat page. Without one shared set of values **the chat page and the app screens will look like two different products.**

Cilian owns `web/src/theme.css` and defines these CSS custom properties. **Everyone uses only these. Never a raw colour, never a hard-coded pixel size.**

```css
:root {
  /* surfaces and text */
  --bg: ...;            /* page background */
  --surface: ...;       /* cards, panels */
  --fg: ...;            /* main text */
  --muted: ...;         /* secondary text */
  --border: ...;
  --accent: ...;        /* buttons, links, focus */

  /* finance direction — see note below */
  --up: ...;
  --down: ...;

  /* shape and spacing */
  --radius: ...;
  --space-1: ...; --space-2: ...; --space-3: ...; --space-4: ...;

  /* type */
  --font-sans: ...;
  --font-mono: ...;
  --text-sm: ...; --text-base: ...; --text-lg: ...; --text-xl: ...;
}
```

**The four themes** are selected with an attribute on the root element, and each one redefines the values above:

```css
:root[data-theme="daylight"] { ... }
:root[data-theme="night"]    { ... }
:root[data-theme="paper"]    { ... }
:root[data-theme="desk"]     { ... }
```

**Price direction colours.** In the Chinese market **red means a price went up** and green means down, which is the opposite of Western convention. This is a separate attribute so it can be switched without touching the theme:

```css
:root[data-convention="cn"]   { --up: <red>;   --down: <green>; }
:root[data-convention="intl"] { --up: <green>; --down: <red>;   }
```

`cn` is the default. **Never write "green means up" anywhere in the code.** Use `--up` and `--down`.

**Rules**
- Only Cilian changes `theme.css`. Adding a new variable is fine; renaming or removing one is not.
- If Abdur needs a value that does not exist, he asks Cilian to add it. He does not add his own.
- Any change here is announced, because it affects both interfaces (see the list at the top of this file).
- Charts use these variables too, so a chart matches the page it sits on.

## Bundled application templates and local list actions

`GET /api/examples` returns three template summaries. `POST /api/examples/:id/import` accepts only `{ "mode": "connect" }`, requires the established browser-profile cookie, same-origin request and `X-Blocks-Request: 1`, and returns `{kind:"imported",appId,mode}`. Legacy demo requests return400. Connect mode installs only the portable definition with Tushare hints, without creating uploads or bindings. Old flagged demo applications cannot execute; create a new connected copy. Exports omit uploads, bindings, action history and saved parameters. Imports are not idempotent; if confirmation is lost, check My Apps before repeating.

`GET /api/apps/:id/list-actions` returns `{appVersion,revision,params,history}` for the owned application's declared text-list parameters. `POST` accepts `{param,recordId,action:"add"|"remove",note,requestId,revision}`. It atomically updates that saved parameter while preserving other settings, bindings and carry state. Revision is a compare-and-swap token. Within retained history, repeating the same request ID and payload does not reapply the action and returns the current snapshot; different payload or stale revision returns409. Invalid action returns422; foreign applications are404. History holds the latest100 local events; it is not a tamper-proof institutional approval log. Rerun to update derived results.

Templates require explicit dated, comparable supplied inputs. AlphaVista joins Tushare daily prices, same-date adjustment factors, company metadata, valuations and annual statements with user holdings; RiskRift joins Tushare income, cashflow and balancesheet data by code and period, and requires user-provided excerpts or approved document snapshots; WealthWeave requires authorised client/product/activity records and separately displays published Tushare fund NAV. Ranking thresholds are configurable research assumptions. Observation/digest tables do not deliver notifications. Local review/task actions do not modify imported source files or create institutional approvals. These definitions use the existing AppDocument format and standard renderer/theme.

### Optional result-driven workspace controls

The workspace can enhance ordinary saved result tables without changing AppDocument or replacing its portable manual controls. Mark these steps `key: true` to retain them in results/Inspect. The convention applies to any application; it does not branch on application names or IDs.

- `pick_<param>` targets an existing scalar text parameter. Rows require string `value` and `label` columns. An explicit empty value is supported for a labelled default/all choice; whitespace-only values are rejected. Choices are deduplicated and bounded to500. Unknown current values remain visible and are never silently replaced. **Show selection** updates the existing parameter draft and runs it.
- `act_<param>` targets an existing text-list parameter. Rows require string `record_id`, `label`, `add_label` and `remove_label`, with optional string `detail`. At most50 unique valid rows are shown. Action groups above3rows start collapsed. Button state comes from current saved list membership, not the displayed row's previous status.
- Actions use the same profile/origin/CAS/idempotency service and pending-request lock as the manual list-action form. Other parameter drafts remain in place. A successful action updates only its affected list input and reruns. Before accepting a refreshed connection revision, the host checks that saved settings equal the previous snapshot plus that list mutation. Unrelated concurrent changes or refresh failure require reviewing saved settings; the action itself remains saved.
- Failed results and outputs from another app version do not expose active record tools. Picks/actions are disabled during active or unconfirmed requests and unsaved connection changes. Exact request retry remains available in Saved list actions. These controls record local workflow settings; they do not create institutional approval, authenticated roles or source-data edits.

Bundled AlphaVista choices follow its watchlist and eligible date window. RiskRift includes reviewed findings in selection. WealthWeave keeps all connected client/product choices available after filtering and includes completed tasks for reopening. Existing installed copies keep their original definition until updated or imported again.

### Optional monitoring results and local acknowledgements

A `key: true` step named `monitor_events` may return exactly six TEXT columns: `event_id`, `title`, `status`, `value`, `detail`, `source_url`. IDs identify stable conditions, not content revisions. Status is `active`, `clear` or `unknown`. Use only supplied safe HTTPS source links; the interface omits other links. This convention uses the existing AppDocument format.

The shared saved-run completion transaction updates profile-owned monitor state for manual and scheduled executions. The first successful complete result establishes a baseline and queues current conditions; it does not claim newly discovered news. Comparable subsequent runs produce new/changed/cleared/unknown summaries. Missing rows become unknown, never automatically clear. Failed, partial, malformed or oversized results preserve the last good baseline with a notice. Limits are 200 conditions and 4,000 characters per cell; a comparison whose combined condition set exceeds 200 is skipped with a notice.

Context includes application version, captured bindings/mappings, effective run parameters and data-source identity. Substantive changes establish a new baseline. Declared text-list parameters with matching `act_<param>` outputs are local workflow actions and do not reset context. Saved connection changes invalidate current actions until another run. Completing a local task can clear its overdue condition; reviewing a research finding does not resolve it.

`GET /api/apps/:id/monitor` returns the current notice, counts, changes, alert revisions and bounded prior-revision `history`. `POST /api/apps/:id/monitor/ack` accepts only `{alertId,acknowledged:boolean}` under the existing profile, origin and browser-write guards. Acknowledgements set a desired state idempotently; changed or closed revisions return 409. Unchanged conditions retain acknowledgement; changed evidence reopens a new revision. Latest 200 prior revisions and latest 200 acknowledgement records (actor/time/state) are retained. These are local records, without authentication or institutional audit guarantees. Export includes only the portable document, never this state.

The Monitoring tab reflects the latest monitor record, independently of any selected historical result. Refresh reads authoritative state; overlapping refreshes queue a final read. Network uncertainty disables acknowledgement until refresh succeeds. No email, push, webhook, new alert-trigger type or background delivery service is provided. Existing scheduled tasks must be enabled and the server must remain running; use Refresh to see their updates. Existing installed copies need an updated definition or fresh import to emit monitoring results.

### Additional bundled financial checks and client lifecycle views

RiskRift adds descriptive revenue-decline and net-loss checks over eligible supplied annual nonfinancial reports. Revenue decline requires consecutive comparable periods and positive prior revenue; zero current revenue is evaluable. Net loss uses the latest unambiguous eligible net income and does not require cash-flow figures. Thresholds are illustrative research settings. Findings share existing evidence, review and monitoring behavior; they are not fraud determinations or regulatory rules.

WealthWeave client segments are descriptive groups over supplied attributes, not investment advice or inferred client classifications. Optional text fields `assessment_expires_on` and `last_reviewed_on` support strict calendar-date reminders against the selected As of date. `reminder_days` and `stale_after_days` are integer day settings (0–365); dates do not advance automatically. missing/invalid dates remain explicit. A supplied expired or invalid assessment expiry cannot leave an otherwise positive assessment flag silently eligible. Absent optional expiry preserves the existing recorded-flag check with date coverage stated separately. Local follow-up completion does not change supplied assessment dates or resolve an expired assessment. New fields and parameters use the existing published types; older installed definitions remain unchanged until updated or imported again.
