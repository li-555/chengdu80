# Development notes and manual acceptance records

This file holds engineering notes and acceptance records written during development.
**To install and run Blocks, use [INSTALL.md](../INSTALL.md).** To build and share applications, use [USER_GUIDE.md](../USER_GUIDE.md).

## Prerequisites

- Node.js 24.11.0 or later (stable releases), and npm.
- Access to the npm registry when dependencies need to be installed.

The project records Node 24 in `.node-version` as a development default, not an
upper version limit. The startup, check and storage-test launchers accept the
minimum version declared in `package.json`, including Node 25 and newer stable
releases. They prefer the current Node runtime when it meets the minimum, then
look on PATH and in standard installation locations. A version file does not
change the active runtime by itself. The launchers do not change the computer's
default runtime.

## Start the server

From the repository directory, run:

```sh
npm run go
```

When a runtime dependency is missing or differs from the lockfile, this command installs runtime dependencies from
`package-lock.json` before starting the server. Open `http://127.0.0.1:3000` in
your browser. Keep the terminal running while using the server. Press Ctrl+C
to stop it.

For an already installed project, start only the server with:

```sh
npm start
```

`npm start` selects a supported runtime and starts the server. It never installs
dependencies or runs configuration/service checks. Missing dependencies cause
startup to fail; install them manually or run `npm run go` to prepare them.
Neither startup command requires service credentials or successful online checks.

Both commands load the repository's `.env` automatically when it exists. Put
`GITEE_AI_API_KEY`, `CD80_LLM_BASE_URL` and `CD80_LLM_MODEL` in that local file
once, then restart after editing it. `.env` is ignored by Git; `.env.example`
contains the configuration shape without credentials. Existing terminal
environment variables take precedence over the file, including empty values.
For a direct Node invocation, use `node --env-file-if-exists=.env src/server.ts`
from the repository directory.

To select a specific runtime, set `BLOCKS_NODE_PATH` to its executable:

```sh
BLOCKS_NODE_PATH=/path/to/node npm start
```

An invalid or unsupported explicit path reports an error; it does not silently
fall back to another runtime. The same override applies to `go`, `check` and
`test:storage`.

To select a different port:

```sh
CD80_PORT=3001 npm run go
```

`CD80_PORT` is the primary port variable, matching `.env.example`. `BLOCKS_PORT`
remains supported for compatibility when `CD80_PORT` is unset. If both are set,
`CD80_PORT` wins. If neither is set, the server uses port 3000.

The selected value must be an integer from 0 to 65535; port 0 requests an
available port from the operating system. An empty or invalid `CD80_PORT`
reports an error instead of falling back to `BLOCKS_PORT`. Set variables in the
terminal environment or local `.env`; `.env.example` itself is a reference and
is not loaded by the startup launcher.

## Verify startup

The home page opens the landing screen. `GET /health` returns the server status and Node
version. Unavailable endpoints return a JSON error.

## My Apps

Open `http://127.0.0.1:3000/apps` (or the configured port).

1. Choose **Import app**, then select a JSON application file or paste its content.
   The file must be no larger than 1 MiB. This imports an application definition,
   not a CSV or Excel dataset.
2. Blocks checks the document with the shared application validator. Invalid
   documents show an explanation and are not saved. Validation warnings do not
   prevent import and are shown separately. No application executes during import.
3. After import, the app appears in My Apps. Open its card to see the saved app's
   name, description and details. Use **Back to My Apps** to return to the list.
   Direct links and page refreshes work for the same local library.

Applications persist in SQLite across server restarts. A persistent, HttpOnly,
SameSite=Strict cookie named `blocks_profile` selects this browser's local
library. Keep cookies enabled. A different browser profile has a separate
library; clearing the cookie disconnects the browser from its previous library
without deleting its saved records. These local profiles are not account login
or organisation authentication. Use the same hostname when returning to a library.

Opening an app shows its saved details, connection settings, run results and task
controls. Export remains separate. Import success confirms document validation
and saving; it does not enable tasks or establish that data is available.
If storage is unavailable, My Apps reports the failure instead of displaying
an empty library. The home page and `/health` remain available.

## Appearance and language

Use the **Theme** and **Language** selectors in the page header. The two themes
are Light and Dark. On a first visit without a saved theme, the system appearance
selects Light or Dark. A saved selection takes precedence. Legacy Daylight, Paper
and Desk preferences migrate to Light; Night migrates to Dark. Appearance is
applied before stylesheet loading on workspace and example pages. English and 中文 apply to the platform's
navigation, controls, statuses, chart controls and examples. Preferences persist
in this browser and synchronize across tabs on the same origin. If browser
storage is unavailable, they still work for the current page.

App names, document-defined labels, data values and AI replies keep their original
content. Write in Chinese or English to have the builder reply in that language.
Technical diagnostics retain their original details. During an active application
run, the body language updates after completion so that changing language does
not interrupt the run or discard its result.

## Build an app in chat

Choose **Create app**, or open `/chat`. Describe the application and answer any
follow-up questions. A successful build shows **Open app** and saves the app to
this browser's My Apps library. Further requests in the same conversation update
that app. A failed build can provide a link to a retained draft.

Use **Attach files** or drag CSV, TSV, Excel or Markdown files into the page: up to five
files per upload action, each at most 20 MiB. Every usable worksheet is saved
separately. Select up to five tables per message using the checkboxes: one
worksheet counts as one table, even when several come from one Excel file.
Single-table uploads are selected automatically if there is room; multi-sheet
uploads require an explicit choice. Uncheck a table to make room for another.
Only metadata (names, columns, types and counts) is attached to the builder
request; file rows stay in the workspace.
Use uploads instead of pasting data rows into messages. Uploaded datasets also
appear in Data and the app's connection choices for this browser profile.

For Markdown (`.md`), chat adds the prose description to the message box for you
to review and edit before sending. Each pipe table is saved as a separate table;
select the tables to attach as usual. Prose-only files do not create datasets.
The combined message must be at most 4,000 characters; oversized descriptions are
rejected before upload, never truncated. Data-space Markdown uploads save tables
only. Missing table cells become empty strings; extra cells produce a line-numbered
error instead of silently losing data. Escape literal pipes inside a cell as `\|`.

Expand a table's name to see the first five rows and full-table column statistics:
numeric count, minimum, maximum, mean, sum, empty cells and outlier count. Outliers
are values more than three population standard deviations from the mean. Empty
cells mean missing cells or empty strings; whitespace-only strings retain the
data layer's existing behavior. These summaries are hints to inspect, not proof
that a value is wrong. The view shows up to 50 preview columns and 200 statistics
columns, with a notice if additional columns exist. Rows and statistics are only
shown to the user, never attached to the builder or saved in browser session
storage. Refresh/restart reloads previews from the saved upload through its owning
profile.

Empty sheets without headers are reported as skipped; header-only sheets remain
available. A malformed workbook is rejected before saving. If some sheets fail
to save, the UI names them while retaining the successful tables. If analysis
fails (for example, a large table exceeds the current analyser's argument limit,
or a sum overflows), a clear message replaces the statistics; the table stays
usable. There is no automatic retry of a partially saved workbook.

Enter sends, Shift+Enter adds a line, and **Stop** cancels waiting for the current
request. If a connection ends unexpectedly, check My Apps before sending again:
the app may already have been saved. There is no automatic resend. **New
conversation** starts another app. The current transcript and draft input are
stored per browser tab; server conversations expire after an hour of inactivity
or a server restart. Saved applications persist independently.

Chat uses the existing configured AI service. Without its server-side credential,
the UI reports that AI is not configured; it does not generate a fake app. See
`.env.example` for configuration names. Do not enter service keys in chat.

## Development checks

### Desktop frontend phase two — manual acceptance

Restart the local server after updating the explicit asset routes, then reload
the browser. Use a desktop window (1280 pixels wide or wider is recommended).
Visual acceptance is performed by the user; automated checks below are separate.

1. Navigate between Create app, My Apps and Data using the left sidebar. Open
   an app and confirm My Apps remains selected. Check light/dark and English/中文.
2. Import `test/fixtures/desktop-workspace.fin.json`. This contains invented
   values and requires neither a data provider nor AI credentials. Search by
   `Desktop`, switch Grid/List, change the sort, and return from its detail page.
   Search/sort/view choices should remain. A nonmatching search offers Clear search.
3. Open the imported app: results are on the left, parameters/connections on the
   right. Run with Example multiplier 1, then 2: totals are 30 and 60; bars and
   table amounts are 10/20 and 20/40. The previous result remains during loading.
   Select a run in Run history, then open Compare; choosing the two runs shows
   multiplier 1 → 2 and total 30 → 60 (B − A = 30 when A is the first run).
   Inspect shows the selected run's settings and provenance. This fixture has no
   schedules, so Scheduled tasks shows the explicit no-trigger state.
4. For an existing app with data requirements, run it without a valid binding.
   The connection panel should open with missing requirements. Match columns and
   Save and run. Switching result tabs must preserve parameter drafts. Existing
   scheduled applications retain Pause/Resume and version-confirmation controls.
5. In Create app, type several lines (Shift+Enter inserts a line) and check the
   composer grows to a limit. Upload `test/fixtures/invented-upload-review.xlsx`:
   six usable sheets appear under their file, the empty sheet is reported, and
   at most five tables can be selected. Expanding a preview or changing a
   selection must not reset other expanded previews; statistics open separately.
   The tray scrolls without hiding Send. With AI configured, send a request and
   check streaming updates, Stop and Open app. Reading older messages must not
   force a scroll; a new-message shortcut appears when a reply arrives.
6. In Data, upload the same fictional workbook and check the saved-table feedback.
   Select Numbers, open Preview and statistics, and expand Column statistics:
   12 rows, 3 columns, amount minimum 0, maximum 1000, sum 1000, one outlier.
   Search/filter, refresh, navigate away/back, and confirm the selection remains
   when it matches the filter. Provider datasets show metadata fields only.

The isolated fictional chat server can also be used for user acceptance:
`node scripts/workspace-acceptance.ts --serve`. Open the loopback URL it prints.
It uses temporary storage and a mock model; `ask fixture` yields a question and
`slow fixture` allows testing Stop. This does not validate the real AI service.

With Node.js 24.11.0 or later active, install dependencies after pulling team
updates and run the required pre-commit checks:

```sh
npm install
npm run verify
npm run test:storage
```

`npm run verify` runs the dependency guard, source/frontend type checking and
the team's tests in order, stopping if a command fails. Run `npm run check:web`,
`npm run test:startup`, `npm run test:apps` and `npm run test:storage` separately.
These checks do not install dependencies
or contact external services. Stop and inspect any failure before continuing.

`npm run test:startup` can also run independently. It checks runtime selection,
version boundaries, startup/shutdown, the home page and `/health`, and that
`start` never invokes installation. Missing-dependency cases use temporary
copies and a fake installer; they never download packages or alter the working
installation. A failure retains the temporary evidence directory.

`npm run typecheck` checks the team's source configuration and the frontend
configuration in `scripts/tsconfig.web.json`. Keep the existing dependencies and
scripts when adding packages. After changing a browser entry or its renderer, run
`npm run build:web` with development dependencies already installed, and commit
all generated files in `web/assets/` alongside the source. `npm run check:web`
checks every browser module listed in `scripts/build-web.mjs`, including the
shared Markdown parser, embedded controls, upload previews, desktop appearance and
motion modules, plus local ECharts/GSAP distributions and their license notices.
The build uses native browser modules and the existing TypeScript compiler,
rewriting local `.ts` imports to `.js`. It copies the already-installed, declared
ECharts version; it installs and downloads nothing. It does not replace type
checking. Startup serves the committed assets without development dependencies,
building or fetching browser packages. ECharts loads lazily from the same server
when a chart is mounted; no CDN is used. React integration remains separate.

`npm run test:apps` checks the My Apps endpoints using invented documents and
temporary databases: import validation, profile separation, upload limits,
static pages, process restart persistence and storage failures. It installs
nothing, makes no external service requests, stops at the first failure and
retains failed evidence for inspection. The browser acceptance flow is import,
open, return to the list, refresh and open again.

`npm run test:workspace` checks chat-to-library integration,
follow-up revisions, browser profile separation, upload metadata boundaries,
stream decoding and translation helpers. It uses an invented model, files and
temporary database, rejects external fetches, and does not exercise the real AI
service. It requires permission to listen on a loopback port.

For manual multi-sheet acceptance, upload `test/fixtures/invented-upload-review.xlsx`.
It contains only invented values: six usable tables and one empty sheet. Confirm
that `Empty` is reported as skipped, all six usable tables appear, and selecting
five prevents selecting a sixth until one is unchecked. Expand `Numbers`: 12
rows, 3 columns, amount minimum 0, maximum 1000, mean 83.3333333333333, sum 1000,
one amount outlier, and one empty note cell. The first five preview amounts are
zero, demonstrating that statistics cover rows beyond the preview. `Headers only`
has zero data rows. Refresh and reopen the previews, then restart the server and
repeat. Also upload `invented-single-upload.xlsx` from the same fixture directory
and a small invented CSV; each should select its sole table when there is room.
Check English/中文, light/dark themes and keyboard checkbox/expand controls in a
desktop browser. These are expected results, not a claim that visual acceptance ran.

Manual acceptance for this change: switch light/dark themes with a chart open;
switch English/中文 on My Apps, Data, chat and an app's run/compare views; refresh
to check preference persistence; send a chat request, answer a question, attach a
file, open the built app and request an update; check keyboard controls and desktop
layouts. Automated checks do not substitute for this visual acceptance.

## Screen elements — user-reported manual acceptance

The source for Preparing task 4 is present: `Table`, `Metric`, `Text`, `Callout`
and `List`, with `Section` for layout. Browser assets are present, and the user
reported successful manual acceptance of task 4. No itemized browser record or
full automated verification result accompanies that report. My Apps acceptance
alone does not cover this page, and this report does not cover the later charts.

After building the browser assets and restarting the server, `/screen-elements`
is the dedicated example page. Its `/api/screen-example` endpoint validates one
fixed, explicitly invented application and runs it through the existing engine
using eight invented rows. It accepts no application or data input, contacts no
external services and saves nothing to SQLite. `/gate1` remains available.
This example is not an execution endpoint for applications in My Apps.

`web/src/screen-elements.ts` exports `renderScreen(ui, results)`, which returns a
DOM element. It receives the validated document's `ui` and a Map of named engine
results, each with `columns` and field-keyed `rows`. The fixed example serializes
the engine's Map as entries for transport; the browser restores that Map.
Always request the relations referenced by UI `from` fields through the run
engine's `want` option, including those not marked as key steps.

- Tables use only document-declared columns, in document order, with document
  labels and formats. An omitted optional label displays `Column 1`, `Column 2`,
  etc.; raw result field names are not used as headings. Pagination follows
  `pageSize`; the example uses five rows per page.
- A Metric expects at most one row. Missing values display an em dash, not zero;
  multiple rows or a missing result produce an explicit unavailable message.
- Percent values are already percentages: `25` displays as `25%`. Money uses
  two decimals without inventing a currency. Exact numeric strings from the
  engine remain strings to avoid loss of precision. Date strings retain their
  calendar date without conversion to the browser's time zone.
- Text and Callout content is plain text. Lists support document-defined title,
  body, grouping, link and tone fields. Only HTTP(S) links without embedded
  credentials become clickable; example links use a reserved domain.
- Layout and tones use the shared theme variables. Charts are provided by task 5
  below; input controls still show an unavailable message.

When acceptance is authorized, check all five element types, the table's
document labels and 5/3 row pagination, a count of 8, an average move of -1.86%,
missing values, grouped notes, keyboard navigation and desktop layouts. These
numbers are static expectations, not recorded test results. Missing-result,
empty-result and unsafe-text/link handling also require acceptance. Stop on any
failure. The previously deferred NodeList type error remains outside this change.

## Charts — implementation prepared for manual acceptance

Preparing task 5 adds ECharts line, bar, candlestick and heatmap rendering to the
same `renderScreen(ui, results)` entry point. Open `/charts` after preparing the
browser assets and restarting the server. `/api/chart-example` validates a fixed
invented document and runs its sort operations through the real engine. It uses
six fictional daily observations, nine fictional score rows, seven company rows
and 21 company-limit rows, explicitly asks
for the UI's relations, contacts no external service and writes no database.
It does not run imported My Apps applications.

The renderer follows the existing Chart schema: `from`, `x`, `y`, `stacked`,
`ohlc`, `heat` and optional `series`. Category order follows result order; dates remain strings and
are not shifted into a browser time zone. The schema has no separate series-label
fields: ungrouped legends use selected column names; grouped legends use the
text values in `series`. Source-table headers use selected column names.
Candles map named fields into open/close/low/high order. Invalid or incomplete
candles leave a gap. Missing values, non-numeric values and numeric strings are
not coerced to zero or rounded into chart coordinates. Exact source strings remain
available in the data table. Duplicate categories (or heatmap cells) produce an
explicit message instead of being silently combined. Results above 5,000 rows
require an upstream limit; the accessible source table displays up to 100 rows.

Charts use the shared theme and price-convention variables, with canvas tooltips
instead of interpreting result text as HTML. Heatmaps anchor mixed-sign values
around a neutral zero. Long line/bar/candlestick results have a horizontal zoom
slider. Missing results, missing columns and empty results show an explanation.
The local ECharts load can fail without removing the source data table.

After inserting a returned screen into the document, call
`mountScreenCharts(screen)`. Before replacing or removing it, call
`disposeScreenCharts(screen)`. Both are exported from `web/src/screen-elements.ts`.
The example client follows this lifecycle, including browser page restoration.
Container resizing and root theme/convention changes update mounted charts.
This supports the existing attributes; it does not implement task 6's theme picker.

Manual acceptance checklist (expected values, not recorded results):

1. On `/charts`, all eight charts appear, and their data tables open with a keyboard.
   Hover to inspect values and toggle Actual/Plan through the legends.
2. The line chart has six dates. Actual is missing on January 7 and is zero on
   January 8; Plan remains present. The missing Actual point leaves a gap.
3. The stacked bars total 20, 26, 12, 9, 29 and 27, in date order. January 7's
   missing Actual value is still shown as missing in the source table.
4. Under the default Chinese convention, January 5 is a rising red candle
   (open 10, close 13, low 9, high 14); January 6 falls and is green. January 7
   is flat; January 8 has no candle; January 9 rises and January 12 falls.
5. The heatmap has three days and three groups, eight numeric cells and one gap
   (Birch, January 6). Amber on January 6 is a real zero. Scores range from -4 to 4.
6. Resize the desktop browser window; charts fit their panels and retain the
   document-defined column layout.
   Refresh, follow Back to My Apps, then use browser Back to check restoration.
7. Recheck `/screen-elements` and `/gate1`. My Apps continues to open saved details.

Missing-result/column, duplicate-category, all-empty and resource-load failure
paths also need acceptance beyond this fixed example. No browser acceptance or
full `verify` pass is claimed for task 5. The deferred NodeList issue is unchanged.

### Company series — user-reported manual acceptance

For line/bar, `series: 'Company'` with `y: ['Value']` creates one line or bar
series per company. `series` must differ from `x` and `y`. Each (x, company)
pair must be unique; duplicates produce an error rather than being aggregated.
Missing pairs and null values remain gaps; zero remains zero. First-seen result
order determines categories and the first 20 visible companies. Remaining company
names are listed as hidden, while source rows remain available (first 100 rows).
Grouped bars remain side by side unless `stacked: true` is requested.

The user reported manual chart acceptance after the series update. The working
tree also contains an updated browser asset; this does not establish an automated
resource-consistency or test pass in this session. For repeat acceptance after
further renderer edits, from the repository root with development dependencies
already installed, run:

```sh
npm run build:web
npm run check:web
npm start
```

Stop any older server first, then open `/charts` at the address printed by startup
and hard-refresh the browser. These commands are instructions, not recorded passes.
If a command fails, keep its output and resolve that failure before acceptance.

8. Company lines and grouped bars show Amber and Birch separately across four
   dates. Amber is 12, missing, 18, 16; Birch is 8, 0, absent, 10. Legend toggling
   hides only the selected company. Lines must not bridge missing observations.
9. Company stacked bars total 20, 0, 18, 26. Source tables distinguish the explicit
   Amber null from the absent Birch January 7 row and retain the Company column.
10. The limit chart draws Company 01 through 20 and explicitly lists
    `Fictional Company 21` as hidden. Its source table still contains all 21 rows.
11. Repeat the existing four-chart checks, keyboard access, resizing and theme
    changes. No real market data is needed for any of these examples.

For duplicate-pair/error-path acceptance, use a disposable browser rendering of
`renderChart` with two rows sharing Day and Company; expect the explicit duplicate
message. Different companies sharing Day must render normally. An invalid series
configuration (multiple y columns or a missing/non-text company value) must show
an explanation. Do not alter real stored applications for these checks.

## Scheduled execution foundation

The platform has persistent tasks and a unified single-run entry point. Saved-app
runs and connection handling have separate verification records below. The clock
loop now starts with the server; see Automatic clock scheduling for explicit
enablement and its automated checks. Import does not enable tasks. Market triggers,
interrupted-run recovery and bounded catch-up are described below. Historical
data replay and alert delivery remain separate work.

On the first storage operation, a transaction upgrades a recognized version 1
Blocks database to version 2, adding `scheduled_tasks` and `executions`. Existing
applications, runs and state are retained. New databases use the same migration
path; unsupported or foreign databases are rejected. The migration has not been
executed as part of preparing this change. The previous version of the platform
does not understand a version 2 database.

The existing eight storage interfaces remain unchanged. New module interfaces
are exported from `src/platform/index.ts`:

- `createScheduledTask(appId, profile, triggerIndex)` stores one declared
  `schedule` or `market` trigger, disabled with no next execution time. A second
  task for the same application trigger is rejected. Manual and alert triggers
  are not accepted by this entry point.
- `getScheduledTask(id, profile)` and `listScheduledTasks(profile)` read tasks
  only for the selected profile.
- `configureScheduledTask(id, profile, { enabled, nextRunAt })` stores an explicit
  next occurrence; it does not compute it. Times use canonical UTC strings such
  as `2026-10-14T08:00:00.000Z`. The declared trigger retains its own time zone.
  An enabled task must be configured with a next occurrence.
- `runSavedApplication({ appId, profile, runId?, params?, scheduled?, adapter?,
  allowInventedData?, signal? })` invokes one saved application through
  `runForScreen`. For a scheduled invocation, `scheduled` contains `taskId` and
  `scheduledFor`; the task must be enabled, match the application's version and
  next occurrence, and be due. It never waits for a future occurrence.
- `listExecutionAttempts(profile)` shows persistent running and finished
  attempts. Attempts are distinct from completed `RunRecord` objects.

The state object convention is `{ params?, bindings?, mappings?, carry?, ... }`.
Run parameters resolve in this order: explicit overrides, saved `params`, then
document defaults. Unknown settings, missing values and values outside the
declared types/ranges/options are rejected with a failed run record. Per-run
overrides are recorded, not written over the saved settings. The binding and
mapping objects are passed to the shared data resolver by default; see the
shared data resolution section below for connection-required replies.

The execution entry point checks application ownership before claiming work.
It records the application version and actual start time, plus the planned
time for scheduled invocations. One database constraint permits only one running
execution per application, across manual and scheduled calls and across
processes. Another permits only one attempt per task and planned time. Supply
and retain a `runId` for manual request retries; a fresh id represents a new run.
Repeat calls return `in_progress` or the previous `completed` record with
`reused: true`. Different work against a running application returns `busy`.
Reusing an id with different inputs is rejected.

Data resolution, validation and engine failures become failed run records, except
for the two connection-required errors described below.
The engine trace's undefined optional step fields are omitted at the platform
boundary; all remaining stored values still pass the strict JSON encoder.
Results, trace, effective parameters, data-source labels and dataset versions
are retained in the run record. An adapter may supply an `asOfDate`; no date is
invented when it does not. No output values are converted for display here.

For `ok` or `partial`, an available `newState` replaces only `state.carry`, while
preserving the latest settings, mappings, bindings and other state fields.
Failed runs never update carry. If another writer changes carry during a run,
the run is recorded as failed with `E_STATE_CHANGED` instead of overwriting it.
The run record, carry update, execution completion and task's last-run markers
are saved in one transaction. Completing an explicitly configured single
occurrence clears nextRunAt. An enabled automatic clock task calculates and saves
its next occurrence in that same transaction.
A newer occurrence or pause configured while the run was active is preserved.

Storage failures propagate instead of reporting success. The unfinished claim
remains visible until recovery can safely record it as interrupted. The scanner
recovers abandoned/expired claims without replaying their carry updates. This
guarantees one saved outcome per occurrence, not exactly-once external computation.

### Explicit invented data adapter

`src/platform/invented-execution.ts` exports `inventedScheduledDocument()` and
`inventedExecutionAdapter()`. The document has one numeric scale setting and two
fictional values, 12 and 8, supplied separately by the adapter. The adapter only
accepts that normalized example document's version, never an arbitrary imported
application. It uses no external service. Execution with an invented adapter
requires `allowInventedData: true` and rejects model steps so that the example
does not make model calls. No adapter is selected automatically.

The following is a module integration example to run only when execution is
authorized, from the repository root in a suitable TypeScript entry file:

```ts
import { randomUUID } from 'node:crypto';
import { saveApp, runSavedApplication } from './src/platform/index.ts';
import { inventedScheduledDocument, inventedExecutionAdapter } from './src/platform/invented-execution.ts';

const profile = 'invented-scheduler-example';
const app = await saveApp(inventedScheduledDocument(), profile);
const runId = randomUUID(); // Keep this id for retries of this request.
const reply = await runSavedApplication({
  appId: app.id, profile, runId,
  adapter: inventedExecutionAdapter(), allowInventedData: true,
  params: { scale: 2 },
});
// Expected total: 40. This is an expectation, not a recorded acceptance result.
// reply.kind distinguishes completed, in_progress and busy.
```

These records use a separate explicit profile; they do not appear in a browser's
My Apps library unless the host integration deliberately uses its owning profile.
Every invented execution includes an invented-data source label and warning.
Without an adapter or explicit permission, the entry point records a failure;
it never supplies fixtures to a real application as a fallback.

Acceptance remains pending: version 1 migration with existing records, independent
process persistence and competing claims, ownership checks, duplicate occurrence
handling, failed resolution, result/trace serialization, successful and failed
carry updates, concurrent settings edits, transactional rollback and interrupted
attempts. Tests for the later timer/recovery features are not covered by this stage.

## Configuration and service verification

Set `TUSHARE_TOKEN` and `GITEE_AI_API_KEY` in the ignored local `.env` or terminal
environment without writing their values to tracked files or shell history.
`npm run check` also loads `.env`. Run:

```sh
npm run check
```

The command selects a supported Node runtime, checks every declared runtime dependency and dependency-lock consistency,
validates the local server configuration, and verifies external service access.
It does not install dependencies or start a server. It can run while the server
is already running.

- Tushare: one `trade_cal` request for a single calendar day. Success verifies
  this interface only, not every dataset permission.
- GLM-5.3: one short text-completion request with a small output limit. This is
  a real service call and uses the configured service resources.
- Each configured service is requested once, with a 30-second timeout and no
  automatic retries. Missing credentials are reported without sending a request.
- Credentials, returned calendar rows, and generated text are not printed.
- All required checks passing returns exit code 0. Any required failure returns
  exit code 1 after the report is complete. A check failure does not stop the server.

In a second terminal, the exit status can be inspected immediately afterwards:

```sh
npm run check
echo $?
```

Application integration is still pending; this command does not establish that
application features have been implemented.

## Current functionality

This version provides the Express startup entry point, persistent storage,
the My Apps shell and the configuration and external-service check. My Apps
loads `/assets/app.js`; its HTML loads `/assets/theme.css` and
`/assets/platform.css` through separate stylesheet links. `/gate1`,
`/screen-elements` and `/charts` run fixed invented examples through the engine.
Application creation, data binding and execution for saved My Apps applications
are not integrated.

## Shared interfaces during integration

`src/platform/index.ts` exports `StoredApp`, `RunRecord` and the eight storage
functions from `docs/CONTRACTS.md` section 4. It uses the real `AppDocument`
schema and `appVersion` from `src/app-schema/index.ts`. Unknown document keys
are rejected. Optional data `window` and `filters` are preserved; this module
does not resolve parameter names or fetch data.

The storage adapter uses Node's built-in SQLite and has `STUB = false`.
Applications, run records and state are saved on disk and survive a process
restart. No additional database package or server is required.

The default file is `data/blocks.sqlite`, relative to the repository root,
regardless of the caller's working directory. To use a different file:

```sh
BLOCKS_DB_PATH=/path/to/blocks.sqlite npm run go
```

Relative overrides also resolve from the repository root. Empty paths, paths
containing a null character, and `:memory:` are rejected. Configure the path
before the first storage operation; changing it requires restarting the process.
The database directory and first database are created on first storage use.
Existing files are opened without clearing their contents. Unsupported versions
and files belonging to another database are rejected. Runtime database files
and journal files are ignored by Git.

Stored values must be JSON-compatible: null, booleans, strings, finite numbers,
dense arrays and plain objects with enumerable string-keyed data properties.
Explicit `undefined`, Date, BigInt, Map, Set, non-finite numbers, functions,
symbols, accessors, sparse arrays and cycles are rejected with English errors
before writing. Omit optional properties instead of setting them to `undefined`.
Values are never silently converted or discarded.

Database opening, permissions, corruption or version errors fail storage
operations. A busy database fails immediately without waiting or retrying.
Storage never falls back to memory or recreates an existing database. The core
home page and `/health` remain available because storage opens only on first use.
The configuration/service check does not establish database availability.

- `saveApp` creates a new application ID on each call.
- Lists are separated by local profile. Run history is newest-first; an omitted
  limit returns all records. Equal run timestamps preserve first-insertion order.
- Saving an existing run ID replaces its record without changing insertion order.
- Deleting an application also removes its runs and state in the same database
  operation through foreign-key constraints.
- `getApp` returns `null` for a missing application. Missing state returns `{}`.
- `setState` replaces the previous state and requires the application's owning
  profile. Saving a run requires an existing application.
- Returned values are copies; modifying them does not change stored records.

### Storage acceptance check

From the repository directory, with the existing dependencies installed, run:

```sh
npm run test:storage
```

The launcher selects a supported Node runtime without installing dependencies. The check uses
explicitly invented data and temporary database files, never the configured
working database. It verifies independent-process persistence, restarts the
actual server, checks all eight interfaces and exercises rejected values and
database failures. It stops at the first failure and retains the temporary
directory for inspection; it cleans up after success. Type checking and the
team's existing schema tests are separate checks.

`src/api/routes-apps.ts` now has `STUB = false` and exports an array containing
the Express router, mounted directly by `src/server.ts`:

- `GET /api/apps` returns `{ apps }`, containing summaries for the browser's
  local profile, newest first. A first read issues the profile cookie.
- `GET /api/apps/:id` returns `{ app }` with the saved document and version.
  Missing apps and apps owned by another profile both return 404.
- `POST /api/apps/import` accepts raw UTF-8 document text with `text/plain` or
  `application/json`, up to 1 MiB. It requires the profile cookie and
  `X-Blocks-Request: 1`; an Origin header, if present, must match the server.
  The browser supplies these automatically. A valid import returns 201 with
  `{ app, warnings }`. Code fences and the optional `$schema` export envelope
  are handled by the shared validator; only its normalized document is stored.

The API does not accept profile selection in a query or request body and never
returns the stored profile identifier. Responses use `Cache-Control: no-store`.
Failures return `{ error: { code, message, issues? } }`: invalid documents use
422, oversized files 413 and unavailable storage 503. Import does not call the
data resolver, execute calculations or activate triggers.

`src/server.ts` mounts the application routes and the data routes directly,
alongside the chat, validation, specification and skill routers.

### Data HTTP routes

- `GET /api/data/datasets` returns `{ datasets }` from the data catalogue.
- `GET /api/data/datasets/:id` returns `{ dataset }`, or 404 with
  `DATASET_NOT_FOUND` when the dataset is missing.
- `POST /api/data/slice` accepts a JSON `SliceRequest`, subject to the existing
  same-origin guard and a 1 MiB request-body limit, and returns `{ slice }`.
  This operation may request real data from the selected provider.

Data-route failures use `{ error: { code, message } }`. Invalid slice requests
return 400, oversized bodies return 413, and foreign origins return 403.
Catalogue lookup failures return 503. Saved application runs continue to call
the shared data layer through `fetchSlicesFor`; they do not call these HTTP routes.

`web/src/app-types.ts` re-exports the real document and element types for the
frontend. The shared `web/src/theme.css` provides every agreed visual variable
for `daylight`, `night`, `paper` and `desk`. The initial theme is `daylight`;
price colors default to the required `cn` convention. Set `data-theme` and
`data-convention` independently on the document root. Interface and chart code
must use these variables instead of defining their own colors or pixel sizes.

## C8 shared data resolution — offline verified; live acceptance separate

Normal `runSavedApplication` calls now default to the team's `fetchSlicesFor`
from `src/compute/slices.ts`, then pass its `slices` to `runForScreen`.
`realExecutionAdapter({ today? })` is a thin platform wrapper for an optional
explicit reference date. It replaces the previous custom daily-only resolver;
its earlier `asOfDate` option is replaced by `today`, matching the shared API.
Invented execution still requires an explicit adapter and `allowInventedData: true`.
External model steps remain disabled in this execution entry point.

State uses `{ params, bindings: { requirementKey: datasetId }, mappings: {
requirementKey: { applicationColumn: datasetColumn } }, carry? }`.
The shared resolver falls back to datasetHint, matches same-name fields without
case sensitivity and supports semantic tags. It owns window calculation, filters,
row conversion and warnings. Upload row reading is delegated to the shared data layer. No custom
four-dataset allowlist, previous-day policy, cache clearing or extra truncation
policy is applied by the platform wrapper. Daily vol remains lots and amount
remains thousand CNY; the platform does not rescale them.

### Connecting data before a run

The entry returns a JSON-compatible reply instead of a failed run for these
two shared errors:

```ts
{ kind: 'needs_data', appId, runId, issue }
// issue.code: 'NeedsBindingError' | 'NeedsMappingError'
```

Binding issues retain `problems` (requirement keys and optional unknown dataset
IDs); mapping issues retain `problems` with fields and column suggestions.
The saved-app interface renders these as a Connect your data step, with dataset
and column choices. See the connection editor acceptance steps below.

The platform releases only the current unfinished execution claim in a
transaction. No RunRecord is written, carry is unchanged, and scheduled task
last-run markers and nextRunAt remain unchanged. After updating bindings or
mappings, the caller can retry with the same runId or scheduled occurrence.
A release/storage failure propagates; it must not be reported as successful
connection handling. Genuine fetch, validation or compute errors remain failed
runs. The scanner pauses a needs_data task with its structured reason until the
person corrects the settings and explicitly resumes it. Recovery is described below.

### Saved sources

RunRecord.sources preserves SourceRecord[] from fetchSlicesFor: requirement key,
dataset ID/source, app-to-dataset field mapping, provider/local filters, optional
date bounds, row count, optional asOfDate, datasetVersion, duration and warnings.
It is saved atomically with the result and eligible carry update, including when
computation fails after successful resolution. Invented adapters may omit it.
No source history is retroactively generated for old records.

Sources can contain the person's filter values; keep them within the profile's
run history. The Inspect panel shows each source and its conversion
warnings. Per-source asOfDate is preserved exactly, not collapsed into a new
run-wide date. It reflects the fetched slice, not necessarily rows retained by
local filtering. datasetVersion currently describes structure, not a market
snapshot. Source warnings remain in sources, separate from engine warnings.

### Manual acceptance helper — updated, not executed in this change

From the repository root, with the supported Node version, existing dependencies
and TUSHARE_TOKEN set securely in your shell:

```sh
cd 2026-cd80-hku
BLOCKS_DB_PATH=/tmp/blocks-c8-manual.sqlite node scripts/c8-manual.ts 600000.SH 2026-10-13
```

This explicitly makes live requests and writes an isolated acceptance app, runs,
state and a task. It does not start a server or timer. Each invocation creates a
new app; existing records are retained. Expected output, not recorded passes:

1. manual: completed status ok with nonempty rows for an available stock and
   sources containing the prices requirement, dataset/version/date and warnings.
   Missing/empty historical observations need investigation.
2. retry: reused true, savedRuns 1.
3. scheduled: status ok, lastRunId populated, nextRunAt null (an explicit due
   invocation only; not proof of an automatic scheduler).
4. missing_binding: kind needs_data, issue.code NeedsBindingError,
   carryPreserved true, savedRuns 2. It must not create a third failed run.
5. reconnected: kind completed, status ok, savedRuns 3, using the same runId
   after restoring bindings. It must not remain busy or reuse a failed record.

Also verify NeedsMappingError, scheduled connection
handling, source persistence after restarting, compute failure with retained
sources, and concurrent execution separately when checks are authorized.
This helper does not establish those outcomes or successful carry advancement.

Open integration decisions: the shared resolver defaults to today's Shanghai
date, including today if it is a trading day; it does not automatically use the
scheduled occurrence. Cache freshness, truncation visibility and publication
cutoff policy remain team follow-ups. fetchSlicesFor has no AbortSignal option;
the platform deadline prevents a late successful run, but cannot cancel the
underlying request. The custom resolver's prior acceptance criteria are obsolete.

### Offline connection and persistence acceptance

Run the focused check with existing dependencies (no live credentials needed):

```sh
node --experimental-test-module-mocks scripts/c8-offline-acceptance.ts
```

The helper replaces the data-layer module with invented fixtures before importing
platform code and rejects global fetch calls. It exercises the default real
adapter wrapper, the shared fetchSlicesFor logic, the real compute engine and
SQLite in a newly created temporary directory. The source label is `real` because
it exercises that production path; every dataset and row supplied by the test is
fictional. It never uses the configured application database.

Recorded on 2026-10-14 with Node v26.8.1: six scenarios passed (three connection
errors, each manual and scheduled), followed by a fresh-process persistence
check. No failed run or dangling claim was created for connection errors; state
and scheduled occurrence were unchanged. Fixing the connection and reusing the
same runId succeeded. Repeating a completed request reused its result without
fetching. Saved sources retained mappings, version, date and conversion warnings.
A second process verified full saved records, state and task markers. The latest
rerun also checked parameter precedence and carry advancement for ok/partial,
with failed computation preserving carry and sources. Network calls: zero;
invented slice resolutions: twelve. Exit code: zero.

The initial attempt uncovered an incorrect bare `scale` parameter reference in
the platform's invented example. It was corrected to `$params.scale` before the
passing rerun. Existing saved copies of the old example are not rewritten.
Node reported experimental/deprecation notices for module mocking; these were
not test failures. This result does not establish real-service permissions,
real-data availability, UI acceptance, automatic scheduling or crash recovery.

## Saved-app runs and Inspect

My Apps details now include Run application, per-run parameter inputs, up to ten
recent runs and Inspect / Where the data came from. Parameters initialize from
saved settings, then document defaults; edits override only the current run.
The interface restores saved results and sources after refresh and reconstructs
row objects from result.outputs' schema/row arrays for the existing renderer.

GET /api/apps/:id/runs returns the owning browser profile's ten latest runs and
saved params. POST /api/apps/:id/run accepts only { runId, params? }; adapter,
profile and carriedState cannot be selected by the browser. Both routes enforce
ownership; writes require the existing same-origin check, profile cookie and
X-Blocks-Request header. Normal runs use the default shared adapter. Unknown
completion retains the runId and payload in sessionStorage for Retry same run.
Run history can confirm completion. Reading an app or its history never runs it.

Inspect shows saved dataset identity, mappings, request date bounds, per-source
asOfDate, row counts, version, provider/local filters, duration and conversion
warnings. It also shows effective run parameters. Three connection errors show
Connect your data with details, without adding a failed run. The editor lets the
person save bindings and column mappings along with the parameter values above.
Applications with matching dataset hints and field names can still run directly.

Manual acceptance (real-service availability still requires your own check):

1. Restart the server with credentials available in its terminal environment.
   Import scripts/c8-daily-review.fin.json into My Apps; importing makes no market
   request. Open its details and confirm Company code is prefilled.
2. Choose Run application. This explicitly requests real daily data. Check the
   result, then expand Inspect: dataset tushare:daily; field mappings ts_code,
   trade_date and close; provider ts_code filter matching the chosen company;
   row count/date/version/warnings. The current shared resolver may include today.
3. Change Company code and run again. Inspect must describe the selected run's
   filter and parameters. Selecting an earlier recent run restores its own
   result and sources. Refresh the page: history and Inspect must remain present.
4. In a separate browser profile, the application/results must be inaccessible.
5. To check the connection prompt without market access, import a copy with
   datasetHint removed. Run it: expect Connect your data and no saved failed run.
   Keep this as a separate acceptance app, not a replacement of your saved app.
6. Check narrow layout, keyboard controls, chart legend, navigation/back and the
   browser console. If a request cannot be confirmed, use Retry same run rather
   than starting another request. AI-step apps remain outside this run entry.

Automated checks in this change used invented data only: parameter override >
saved > default, carry advancement for ok/partial and preservation for failure,
source persistence (including failed compute results), and fresh-process reads.
Loopback HTTP checks covered ownership, write headers, origin, strict request
shape, history/source access, same-id retry and needs_data. No real market
request was made by these checks. These do not substitute for browser acceptance.

### Connect your data editor

GET /api/apps/:id/connection returns the owner's editable settings, a revision,
and public Tushare dataset/column metadata. It does not enumerate other profiles'
uploads. Existing unavailable/upload bindings remain visible without exposing
the shared upload registry. Reading this endpoint does not request market rows.

POST /api/apps/:id/connection accepts { revision, settings: { params, bindings,
mappings } }. It checks ownership, same origin, the write header and declared
parameter/requirement/field keys. A transaction compares the settings revision
and merges only these three fields into the latest state, preserving carry and
unrelated state. A concurrent settings change returns 409 without overwriting.
Saving settings itself never executes an application.

The editor retains raw parameter entries, bindings and mappings in the current
tab's sessionStorage draft, including after a connection error or page refresh.
Unsaved binding/mapping changes require Save and run or Save connection and
settings before Run application. Parameter-only edits can remain per-run values.
After a settings conflict, Review latest saved settings shows the current saved
values while retaining the draft; a subsequent explicit save applies the draft.
If browser storage is unavailable, inputs remain in the current page only.

NeedsBindingError asks for a dataset; NeedsMappingError lists the required fields
and available columns. Save and run retries a released connection attempt using the same runId
while the page remains open. These attempts create neither failed history nor a
permanent running claim. Explicit single occurrences remain due for retry. An
automatic clock task instead pauses with a schedulingIssue until explicitly
enabled again. Upload reading is outside this change.

Manual browser acceptance (user reported passed; separate from automated results):

1. Restart the local server, then import scripts/c8-connect-review.fin.json as a
   separate application. Change Company code to another valid stock if desired.
   Run application: expect Connect your data / choose a dataset, retained input,
   and no failed history entry. This preflight makes no market-row request.
2. Select tushare:daily and leave all three columns at Automatic matching. Choose
   Save and run: expect a field-mapping prompt for company/day/price and no failed
   history. The saved company parameter and dataset choice must remain visible.
3. Map company to ts_code and day to trade_date; leave price automatic. Save and
   run again: expect only price to require mapping. Refresh: the partial mapping,
   dataset and company parameter must remain. No request should be stuck busy.
4. Map price to close. With TUSHARE_TOKEN available to the server, Save and run
   explicitly requests real data. Expect a completed result for an available
   stock and period, plus Inspect sources showing the three mappings. A genuine
   provider/token/data error is a separate failed run, not a connection error.
5. In two tabs, load the same saved settings. Save a changed company parameter in
   one tab, then save the other tab's draft: expect a settings-conflict message,
   with its inputs intact. Review latest saved settings before choosing whether
   to apply that draft. Check keyboard use, narrow layout and console errors.
6. If you already own an app with an upload binding, run it to check the upload
   explanation and preserved settings. Otherwise do not fabricate an upload in
   the live registry: this branch is covered by the fixture HTTP test below.

Recorded automated verification: node --experimental-test-module-mocks
scripts/c8-http-acceptance.ts passed all three connection/correction/retry flows,
no extra run records, carry-safe saves, settings conflicts, ownership, origin,
write headers, input validation and upload catalogue privacy. Global external
requests: zero; only loopback HTTP and invented data were used. Browser rendering
and live service availability still require the manual steps above.

## Automatic scheduling, recovery and task controls

The server starts one non-overlapping scan every second after listening. It runs
only tasks explicitly opted into automatic clock or market scheduling; existing
one-shot tasks and imports are not automatically activated. Alert triggers are
outside this scheduler.

Platform integration (existing ownership checks apply):

```ts
const task = await createScheduledTask(appId, profile, triggerIndex);
await setScheduleEnabled(task.id, profile, true);  // calculate and persist next occurrence
await setScheduleEnabled(task.id, profile, false); // pause future starts
```

These functions are exported from src/platform/index.ts. My Apps exposes enable,
pause, resume, refresh, and explicit version confirmation. configureScheduledTask retains its
explicit single-occurrence behavior and sets automatic to false. Re-enabling an
automatic task clears its schedulingIssue and schedules a fresh future occurrence.
It does not replay the previously blocked occurrence.

Supported cron syntax matches the existing five-field validator: numbers, lists,
ranges and steps, including 0 or 7 for Sunday. Time zones use the runtime's Intl
time-zone database. Two restricted day fields use day-of-month OR weekday; a
wildcard day field restricts the other. Nonexistent local minutes during a DST
advance are skipped; repeated local minutes have two distinct UTC occurrences.
An invalid time zone or no occurrence within eight years leaves the task paused
with a visible invalid_schedule reason.

The scanner calls runSavedApplication with the saved task profile and occurrence.
Database claims prevent concurrent duplicate execution. Successful and ordinary
failed runs both calculate the next regular occurrence strictly after completion
(and after the original occurrence if the clock moved backwards). That time is
saved atomically with the run and carry for clock tasks. A market task's completed
record leaves nextRunAt null; the following scan calculates its next occurrence
through the shared calendar, or pauses with calendar_unavailable. This also works
if the process exits between saving the result and calculating the next time.
There is no immediate failure retry or backlog replay: a late scan executes at
most one persisted pending occurrence within 24 hours, then skips elapsed slots.
Older pending occurrences are skipped with a persisted explanation. This is not
a historical-data replay policy; the shared
adapter still uses the current Shanghai date unless explicitly configured otherwise.

Pausing prevents a new claim; an already claimed run may finish and save its result
but cannot re-enable the task. A newer configured occurrence is preserved. On
needs_data, the task is paused with a persisted reason, without a failed RunRecord
or a running claim. Correct the connection and explicitly enable the task to resume.
An unconfirmed execution also pauses for review, without silently releasing a claim.
Busy/in-progress replies leave the occurrence pending.

Every claim has a 90-second lease renewed every five seconds while its execution
deadline remains active. The scanner detects a departed local process immediately,
or recovers after lease expiry when process ownership cannot be established.
Legacy claims without leases use startedAt plus 90 seconds. Recovery atomically
writes one E_RUN_INTERRUPTED result, finishes the claim, pauses its task and keeps
carry unchanged. A late worker cannot finish a recovered claim. The same run ID
and planned occurrence cannot produce a second result. Resuming an interrupted
task schedules a new future occurrence; the interrupted occurrence is not replayed.
Recovery and task reload run when the server starts and on subsequent scans.

Market triggers use the team's marketTimes interface (including its trading-day
check), SSE and Asia/Shanghai. Both open/close and signed minute offsets are
supported. The next occurrence search is bounded to 31 days and ten seconds;
calendar errors, missing coverage and invalid clock times pause with a visible
calendar_unavailable reason. Due market occurrences are checked against the
calendar again before execution. No calendar data is fabricated on failures.

GET /api/apps/:id/schedules returns only the owning profile's tasks, current
document triggers/version and running summaries. POST accepts exactly
{ triggerIndex, action, appVersion }, with action enable/pause/resume/confirm.
It uses the existing cookie, same-origin and write-header protections. A changed
app version requires explicit review and confirmation before enable/resume;
pausing remains possible. Removed/non-schedulable triggers cannot be enabled.
The panel shows next execution in UTC, latest result, waiting/interrupted reasons
and catch-up skips. Refresh tasks retrieves the latest server state. Save corrected
data bindings/mappings first, then Resume; saving data alone does not enable tasks.

Shutdown stops new scans and awaits the current scheduled run before closing storage.
No extra dependency or schema migration is required. Existing JSON records accept
the added optional fields; the updated app.js is generated from the task controls.

Targeted automated checks (combined browser acceptance deferred):

```sh
node scripts/c8-scheduler-acceptance.ts
node scripts/c8-lifecycle-acceptance.ts
node --experimental-test-module-mocks scripts/c8-http-acceptance.ts
node --experimental-test-module-mocks scripts/c8-offline-acceptance.ts
npm run typecheck
npm run build:web
npm run check:web
```

The clock-loop check uses an isolated temporary database, fictional rows, blocked
external fetch, fixed cron expectations and a short real timer. It covers future
versus due tasks, overlapping scans, next occurrence, pause before/during a run,
connection-required pauses and re-enable, ordinary failure, timer start/stop,
time zones, leap dates, DST gaps/folds and invalid schedules. The regression check
covers the existing manual/single-occurrence connection, sources and carry behavior.
The lifecycle check additionally uses real child-process exit/reload to verify
bounded catch-up and abandoned claims; it checks leases, stale-write rejection,
both persisted connection errors, calendar failures/offsets, and changed
application versions. HTTP checks cover task actions and profile isolation.
All fixtures are fictional, databases are temporary, and external fetch is blocked.

For the final combined manual review, import scripts/c8-schedule-review.fin.json.
It declares a two-minute clock trigger and SSE close +15 minutes, initially off.
Enabling them requests real data when due, requiring credentials in the server's
environment. Review the five areas together: automatic timing/pause; connection
waiting/resume; restart/interrupted/bounded catch-up; market calendar/offsets;
and task controls/version confirmation. Automated checks are not a claim that
this final browser/live-service review has already passed.
