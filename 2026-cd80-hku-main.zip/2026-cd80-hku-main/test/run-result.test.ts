import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import { runForScreen, screenRelations } from '../src/compute/result.ts';
import { encodeStoredValue } from '../src/platform/json.ts';
import { AppDocument } from '../src/app-schema/index.ts';
import { validateApplication } from '../src/validate/index.ts';
import type { Slice } from '../src/compute/run.ts';

/** The saved-application entry point, on the bundled example and invented rows. */

const checked = validateApplication(JSON.parse(readFileSync(new URL('../examples/ex-01-daily-movers.fin.json', import.meta.url), 'utf8')));
if (!checked.ok) throw new Error('the example must be valid');
const doc = checked.document;

const prices: Slice = {
  columns: [
    { name: 'code', type: 'string' }, { name: 'd', type: 'date' },
    { name: 'px', type: 'number' }, { name: 'prev_px', type: 'number' },
  ],
  rows: [
    { code: 'AAA', d: '2026-01-06', px: 12.5, prev_px: 10 },
    { code: 'BBB', d: '2026-01-06', px: 45, prev_px: 50 },
    { code: 'CCC', d: '2026-01-06', px: 10.2, prev_px: 10 },
  ],
};

test('runForScreen returns every table the screen reads, row by row, storable as is', async () => {
  const { result, trace } = await runForScreen(doc, { slices: { prices } });
  assert.equal(result.status, 'ok', result.failure?.message);
  assert.deepEqual(Object.keys(result.outputs).sort(), screenRelations(doc).sort());

  const movers = result.outputs.movers!;
  assert.deepEqual(movers.schema.map((c) => c.name), ['code', 'd', 'px', 'prev_px', 'pct_move']);
  assert.deepEqual(movers.schema.map((c) => c.type), ['text', 'date', 'number', 'number', 'number']);
  assert.deepEqual(movers.rows.map((r) => r[0]), ['AAA', 'BBB'], 'CCC moved 2%, under the 3% default');
  assert.equal(result.outputs.mover_count!.rows[0]![0], 2);

  assert.ok(trace.steps.length === 4 && trace.steps.every((s) => !s.failed));
  // Storage refuses anything that is not plain JSON, so this must not throw.
  encodeStoredValue({ result, trace });
});

test('a failed run names its failing step and is still storable', async () => {
  const { result } = await runForScreen(doc, { slices: {} });
  assert.equal(result.status, 'failed');
  assert.equal(result.failure?.code, 'E_RUN_FAILED');
  encodeStoredValue(result);
});

test('chart series: one line per company, with exactly one value column', () => {
  const base = { type: 'Chart', chart: 'line', from: 'prices', x: 'd' };
  const ok = structuredClone(doc) as unknown as { ui: { elements: Record<string, unknown> } };
  ok.ui.elements.table = { ...base, y: ['px'], series: 'code' };
  assert.ok(AppDocument.safeParse(ok).success);

  for (const bad of [
    { ...base, y: ['px', 'prev_px'], series: 'code' },
    { ...base, chart: 'heatmap', heat: { y: 'code', value: 'px' }, series: 'code' },
    { ...base, y: ['px'], series: 'd' },
  ]) {
    const d = structuredClone(ok);
    d.ui.elements.table = bad;
    assert.equal(AppDocument.safeParse(d).success, false, JSON.stringify(bad));
  }
});
