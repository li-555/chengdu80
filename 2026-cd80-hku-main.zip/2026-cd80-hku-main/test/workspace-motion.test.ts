import { test } from 'node:test';
import assert from 'node:assert/strict';
import { coveringRadius, magneticOffset, mountWorkspaceMotion } from '../web/src/workspace-motion.ts';

test('magnet reach includes the halo, stays bounded, and leaves the hit box untouched', () => {
  const box = { left: 100, top: 50, width: 120, height: 44 };
  const original = { ...box };
  assert.deepEqual(magneticOffset(box, 160, 72), { x: 0, y: 0 });
  assert.deepEqual(magneticOffset(box, 236, 110), { x: 5, y: 5 });
  assert.equal(magneticOffset(box, 237, 72), null);
  assert.equal(magneticOffset({ ...box, width: 0 }, 100, 50), null);
  assert.deepEqual(box, original);
});

test('card reveal covers every corner for a top-right origin and after a resize', () => {
  for (const [width, height, x, y] of [[280, 160, 248, 32], [420, 190, 388, 32], [80, 80, 40, 40]]) {
    const radius = coveringRadius(width!, height!, x!, y!);
    for (const [cx, cy] of [[0, 0], [width, 0], [0, height], [width, height]]) {
      assert.ok(radius > Math.hypot(cx! - x!, cy! - y!));
    }
  }
});

test('motion mounting is inert in a non-rendering runtime', () => {
  const dispose = mountWorkspaceMotion({} as HTMLElement);
  assert.doesNotThrow(() => { dispose(); dispose(); });
});

test('a workspace opened with reduced motion can activate later, and disposing prevents remounts', async () => {
  class Media extends EventTarget { matches = true; }
  const media = new Media();
  const frames = new Map<number, FrameRequestCallback>(); let sequence = 0; let scans = 0; let disconnected = 0;
  const raf = (callback: FrameRequestCallback) => { frames.set(++sequence, callback); return sequence; };
  const browser = Object.assign(new EventTarget(), { requestAnimationFrame: raf, getComputedStyle: () => ({}), matchMedia: () => media, gsap: {} });
  const page = Object.assign(new EventTarget(), { hidden: false, documentElement: { getBoundingClientRect() {} } });
  class Observer { observe() {} disconnect() { disconnected++; } }
  const environment: Record<string, unknown> = {
    window: browser, document: page, ResizeObserver: Observer, MutationObserver: Observer,
    requestAnimationFrame: raf, cancelAnimationFrame: (id: number) => frames.delete(id),
  };
  const originals = new Map(Object.keys(environment).map((key) => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  for (const [key, value] of Object.entries(environment)) Object.defineProperty(globalThis, key, { configurable: true, value });
  const flushFrames = () => { for (const [id, callback] of frames) { frames.delete(id); callback(0); } };
  const root = { querySelectorAll: () => { scans++; return []; } } as unknown as HTMLElement;
  let dispose = () => {};
  try {
    dispose = mountWorkspaceMotion(root);
    await Promise.resolve(); flushFrames(); assert.equal(scans, 0);
    media.matches = false; media.dispatchEvent(new Event('change'));
    await Promise.resolve(); flushFrames(); assert.equal(scans, 1, 'loading resumes when the user allows motion');
    media.matches = true; media.dispatchEvent(new Event('change'));
    media.matches = false; media.dispatchEvent(new Event('change'));
    flushFrames(); assert.equal(scans, 2);
    dispose(); browser.dispatchEvent(new Event('pageshow')); media.dispatchEvent(new Event('change'));
    flushFrames(); assert.equal(scans, 2); assert.equal(disconnected, 1);
  } finally {
    dispose();
    for (const [key, descriptor] of originals) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor); else Reflect.deleteProperty(globalThis, key);
    }
  }
});
