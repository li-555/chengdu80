import { test } from 'node:test';
import assert from 'node:assert/strict';
import { compareRuns } from '../web/src/compare.ts';
import type { RunRecord } from '../web/src/app-types.ts';

// Invented runs only: no provider data.
function run(id: string): RunRecord {
  return { id, appId: 'invented-app', appVersion: 'invented-v1', startedAt: '2026-10-14T00:00:00Z', status: 'ok', params: { threshold: 10, config: { a: 1, b: 2 } }, result: { status: 'ok', startedAt: '2026-10-14T00:00:00Z', durationMs: 1, outputs: { total: { schema: [{ name: 'value', label: 'Value', type: 'number', nullable: false }], rows: [[10]] } } } };
}
test('compares changed settings and a numeric single value without object order noise', () => {
  const left = run('a'), right = run('b'); right.params = { threshold: 12, config: { b: 2, a: 1 } }; right.result!.outputs.total!.rows = [[15]];
  const result = compareRuns(left, right);
  assert.equal(result.settings.filter((item) => item.changed).length, 1);
  assert.equal(result.settings[0]!.delta, 2); assert.equal(result.tables[0]!.scalar, true); assert.equal(result.tables[0]!.cells[0]!.delta, 5);
});
test('matches columns by name and distinguishes absent columns, changed types and null', () => {
  const left = run('a'), right = run('b');
  left.result!.outputs.total = { schema: [{ name: 'a', label: 'A', type: 'number', nullable: true }, { name: 'b', label: 'B', type: 'number', nullable: false }], rows: [[null, 4], [3, 5]] };
  right.result!.outputs.total = { schema: [{ name: 'b', label: 'B', type: 'text', nullable: false }, { name: 'c', label: 'C', type: 'number', nullable: true }], rows: [['4', null]] };
  const result = compareRuns(left, right).tables[0]!;
  assert.equal(result.columns.filter((column) => column.changed).length, 3);
  assert.equal(result.cells[0]!.left.present, true); assert.equal(result.cells[0]!.left.value, null); assert.equal(result.cells[0]!.right.present, false);
  assert.equal(result.leftRows, 2); assert.equal(result.rightRows, 1); assert.equal(result.changedCells, 5);
});
test('column reorder alone does not change cell values', () => {
  const left = run('a'), right = run('b'); const schema = [{ name: 'x', label: 'X', type: 'number' as const, nullable: false }, { name: 'y', label: 'Y', type: 'number' as const, nullable: false }];
  left.result!.outputs.total = { schema, rows: [[1, 2]] }; right.result!.outputs.total = { schema: [...schema].reverse(), rows: [[2, 1]] };
  assert.equal(compareRuns(left, right).tables[0]!.changedCells, 0);
});
test('incompatible versions and apps retain settings but do not claim output deltas', () => {
  const left = run('a'), right = run('b'); right.appVersion = 'invented-v2';
  assert.deepEqual(compareRuns(left, right).tables, []); assert.equal(compareRuns(left, right).compatible, false);
  right.appVersion = left.appVersion; right.appId = 'other-invented-app'; assert.equal(compareRuns(left, right).compatible, false);
});
test('handles absent results and counts differences beyond displayed row limit', () => {
  const left = run('a'), right = run('b'); left.result!.outputs.total!.rows = Array.from({ length: 110 }, () => [1]); right.result!.outputs.total!.rows = Array.from({ length: 110 }, () => [2]);
  assert.equal(compareRuns(left, right).tables[0]!.changedCells, 110); assert.equal(compareRuns(left, right).tables[0]!.cells.length, 100);
  delete right.result; assert.equal(compareRuns(left, right).tables[0]!.rightRows, 0);
});
