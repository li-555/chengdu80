import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { cpSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { IncomingMessage, ServerResponse } from 'node:http';
import { Socket } from 'node:net';
import express from 'express';
import { OPERATION_INFO, COMPONENT_INFO } from '../src/app-schema/describe.ts';
import { ELEMENT_SCHEMA } from '../src/app-schema/ui.ts';
import { ERROR_CODES, validateApplication } from '../src/validate/index.ts';
import { buildSkill, readSkillFamily, SKILL_FAMILIES, skillRepairExample } from '../src/skill/build.ts';
import { BANNED_WORDS } from '../src/skill/vocabulary.ts';
import { skillRouter } from '../src/api/routes-skill.ts';

const root = fileURLToPath(new URL('../', import.meta.url));
const files = buildSkill();
const markdown = files.get('SKILL.md')!;
const references = [...files].filter(([path]) => path.startsWith('references/'));

test('skill reference families cover every operation, element and error exactly once', () => {
  for (const name of [...Object.keys(OPERATION_INFO), ...Object.keys(COMPONENT_INFO), ...Object.keys(ERROR_CODES)]) {
    const matches = references.filter(([, content]) => content.split('\n').includes(`## ${name}`));
    assert.equal(matches.length, 1, name);
  }
  assert.deepEqual(references.map(([path]) => path.slice(11, -3)).sort(), [...SKILL_FAMILIES].sort());
});

test('skill routing links every family and reference files do not link each other', () => {
  const routing = markdown.split('## 9. Where to read more')[1]!.split('## 10.')[0]!;
  for (const [path, content] of references) {
    assert.ok(routing.includes(`[${path}](${path})`), path);
    assert.doesNotMatch(content, /\]\([^)]*\.md(?:#[^)]*)?\)/, path);
  }
});

test('skill is compact and long reference files start with contents', () => {
  assert.ok(markdown.trimEnd().split('\n').length < 500);
  for (const [path, content] of references) {
    if (content.trimEnd().split('\n').length > 100) assert.match(content, /^# [^\n]+\n\n## Contents\n/, path);
  }
});

test('example description uses ordinary words and copies remain byte identical', () => {
  const example = files.get('examples/ex-01-daily-movers.json')!;
  const description = (JSON.parse(example) as { meta: { description: string } }).meta.description;
  for (const word of BANNED_WORDS) assert.doesNotMatch(description, new RegExp(`\\b${word}\\b`, 'i'));
  assert.equal(example, readFileSync(join(root, 'examples/ex-01-daily-movers.fin.json'), 'utf8'));
  assert.equal(files.get('application.schema.json'), readFileSync(join(root, 'spec/application.schema.json'), 'utf8'));
});

test('repair makes exactly three changes and renders real phase reports', () => {
  const { broken, fixed, sortIndex } = skillRepairExample();
  const initial = validateApplication(broken);
  assert.equal(initial.ok, false);
  const working = structuredClone(broken);
  working.compute[sortIndex] = structuredClone(fixed.compute[sortIndex]!);
  const second = validateApplication(working);
  assert.equal(second.ok, false);
  assert.ok(second.report.errors.some((issue) => issue.code === 'E_REF_UNKNOWN_PARAM'));
  assert.ok(second.report.errors.some((issue) => issue.code === 'E_REF_UNKNOWN_RELATION'));
  const filter = working.compute.find((step) => step.id === 'unusual')!;
  if (filter.kind !== 'operation') throw new Error('Missing filter.');
  (filter.params as { where: string }).where = 'abs(pct_move) >= $params.move_threshold';
  const table = working.ui.elements.table!;
  if (table.type !== 'Table') throw new Error('Missing table.');
  table.from = 'movers';
  assert.deepEqual(working, fixed);
  assert.equal(validateApplication(working).ok, true);
  for (const result of [initial, second]) {
    for (const { pointer, code, message, hint } of result.report.errors) {
      for (const value of [pointer, code, message, hint ?? null]) assert.ok(markdown.includes(JSON.stringify(value)), String(value));
    }
  }
  assert.ok(markdown.includes('Checked again: valid'));
});

test('runtime family reader only accepts declared family names', () => {
  for (const name of ['../package.json', 'SKILL', '', 'ops-shaping.md', 'ops-shaping/..']) assert.equal(readSkillFamily(name), undefined);
  assert.equal(readSkillFamily('ops-shaping'), files.get('references/ops-shaping.md'));
});

test('skill check accepts a fresh build and rejects a one-byte change in a temporary copy', () => {
  const temporary = mkdtempSync(join(tmpdir(), 'blocks-skill-test-'));
  try {
    cpSync(join(root, 'skill'), temporary, { recursive: true });
    const check = () => spawnSync('npm', ['run', 'skill:check', '--', temporary], { cwd: root, encoding: 'utf8' });
    const fresh = check();
    assert.equal(fresh.status, 0, fresh.stderr);
    const path = join(temporary, 'references/ops-shaping.md');
    const content = readFileSync(path);
    content[content.length - 1] = 32;
    writeFileSync(path, content);
    const changed = check();
    assert.equal(changed.status, 1);
    assert.match(changed.stderr, /references\/ops-shaping\.md: differs/);
  } finally {
    rmSync(temporary, { recursive: true, force: true });
  }
});

test('template prose is unchanged outside placeholders', () => {
  const template = readFileSync(join(root, 'skill-src/SKILL.template.md'), 'utf8');
  let cursor = 0;
  for (const prose of template.split(/\{\{[A-Z_]+\}\}/)) {
    const index = markdown.indexOf(prose, cursor);
    assert.ok(index >= cursor, prose);
    cursor = index + prose.length;
  }
  assert.doesNotMatch(markdown, /\{\{[A-Z_]+\}\}/);
});

test('skill generation is deterministic and manifest hashes every generated payload', () => {
  assert.deepEqual(buildSkill(), files);
  const manifest = JSON.parse(files.get('skill.json')!) as { files: Record<string, string> };
  assert.deepEqual(Object.keys(manifest.files), [...files.keys()].filter((path) => path !== 'skill.json'));
  for (const [path, content] of files) {
    assert.ok(content.endsWith('\n'), path);
    if (path !== 'skill.json') assert.equal(manifest.files[path], createHash('sha256').update(content).digest('hex'));
  }
});

test('screen examples parse against their matching property schemas', () => {
  for (const [name, elementSchema] of Object.entries(ELEMENT_SCHEMA)) {
    const content = references.find(([, text]) => text.includes(`## ${name}\n`))![1];
    const section = content.split(`## ${name}\n`)[1]!.split('\n## ')[0]!;
    const example = JSON.parse(section.match(/```json\n([\s\S]*?)```/)![1]!);
    assert.equal(elementSchema.safeParse(example).success, true, name);
  }
});

test('skill routes serve published content and reject unknown paths and traversal', async () => {
  const app = express();
  app.use(skillRouter);
  const get = (url: string) => new Promise<{ response: ServerResponse; body: string }>((resolve, reject) => {
    const request = new IncomingMessage(new Socket());
    request.method = 'GET';
    request.url = url;
    const response = new ServerResponse(request);
    response.end = ((body: string | Buffer) => {
      resolve({ response, body: String(body) });
      return response;
    }) as typeof response.end;
    app(request as express.Request, response as express.Response, (error?: unknown) => reject(error ?? new Error(`No route for ${url}`)));
  });
  const bundle = await get('/api/skill');
  assert.match(String(bundle.response.getHeader('content-type')), /^text\/markdown/);
  assert.equal(bundle.body, readFileSync(join(root, 'skill/blocks-skill.md'), 'utf8'));
  for (const [path, content] of files) {
    const result = await get(`/api/skill/files/${path}`);
    assert.equal(result.response.statusCode, path === 'skill.json' ? 404 : 200);
    if (path !== 'skill.json') assert.equal(result.body, content);
  }
  for (const path of ['../package.json', '%2e%2e/package.json', 'references/%2e%2e/SKILL.md', 'unknown.md']) {
    assert.equal((await get(`/api/skill/files/${path}`)).response.statusCode, 404);
  }
});

test('the commented skeleton is labelled jsonc and its document parses without explanations', () => {
  const skeleton = markdown.match(/```jsonc\n([\s\S]*?)```/);
  assert.ok(skeleton);
  assert.ok(markdown.indexOf('The comments are explanations, not part of the document.') < skeleton.index!);
  const document = JSON.parse(skeleton[1]!.split('\n').map((line) => line.replace(/ \/\/ .*$/, '')).join('\n'));
  assert.equal(validateApplication(document).ok, true);
});
