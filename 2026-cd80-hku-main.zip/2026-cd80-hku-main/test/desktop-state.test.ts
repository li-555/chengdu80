import { test } from 'node:test';
import assert from 'node:assert/strict';
import { detachedDOM } from './dom-fixture.ts';
import { showDataScreen } from '../web/src/data-screen.ts';

const settle = () => new Promise<void>((resolve) => setImmediate(resolve));
test('catalogue establishes the library profile first and keeps filters and selection on refresh', async () => {
  const dom = detachedDOM('/data'); const original = globalThis.fetch;
  const paths: string[] = [];
  const dataset = { id: 'user:invented', name: 'Invented worksheet', source: 'upload', fields: [{ name: 'amount', label: 'Amount', type: 'number', nullable: false }], rowCount: 2 };
  globalThis.fetch = async (url) => {
    paths.push(String(url));
    return Response.json(String(url).startsWith('/api/uploads?') ? { datasets: [dataset] } : { datasets: [] });
  };
  try {
    await showDataScreen(dom.view as unknown as HTMLElement);
    assert.equal(paths[0], '/api/apps');
    dom.view.querySelector('.data-choice')!.click(); await settle();
    const search = dom.view.querySelectorAll('input').find((input) => input.type === 'search')!; search.value = 'Invented'; search.dispatchEvent(new Event('input'));
    assert.match(dom.view.querySelector('.data-detail')!.textContent, /Invented worksheet/);
    await showDataScreen(dom.view as unknown as HTMLElement);
    assert.equal(dom.view.querySelectorAll('input').find((input) => input.type === 'search')!.value, 'Invented');
    assert.equal(dom.view.querySelector('.data-choice')!.getAttribute('aria-pressed'), 'true');
    assert.match(dom.view.querySelector('.data-detail')!.textContent, /Invented worksheet/);
    const refreshedSearch = dom.view.querySelectorAll('input').find((input) => input.type === 'search')!; refreshedSearch.value = 'nothing matches'; refreshedSearch.dispatchEvent(new Event('input'));
    assert.equal(dom.view.querySelector('.data-choice'), null);
    assert.match(dom.view.querySelector('.data-detail')!.textContent, /Choose a dataset/);
  } finally { globalThis.fetch = original; dom.restore(); }
});

test('chat appends a streamed reply without replacing the composer or expanded attachment nodes', async () => {
  const upload = { id: 'user:invented-sheet', name: 'Invented sheet', fields: [], rowCount: 0 };
  const dom = detachedDOM('/chat', { 'blocks:chat:v1': JSON.stringify({ messages: [], input: '', attachments: [], available: [upload] }) });
  const original = globalThis.fetch;
  let stream: ReadableStreamDefaultController<Uint8Array> | undefined;
  globalThis.fetch = async (url) => String(url) === '/api/apps' ? Response.json({ apps: [] })
    : new Response(new ReadableStream<Uint8Array>({ start(controller) { stream = controller; } }), { headers: { 'Content-Type': 'text/event-stream' } });
  try {
    const { showChatScreen } = await import('../web/src/chat-screen.ts');
    showChatScreen(dom.view as unknown as HTMLElement, () => {});
    const input = dom.view.querySelector('#chat-message')!;
    const attachment = dom.view.querySelector('.chat-attachments')!.querySelector('.chat-file')!; attachment.open = true;
    const checkbox = dom.view.querySelector('input[data-upload-id]')!;
    checkbox.checked = true; checkbox.dispatchEvent(new Event('change'));
    assert.equal(dom.view.querySelector('.chat-attachments')!.querySelector('.chat-file'), attachment); assert.equal(attachment.open, true);
    input.value = 'Invented request'; input.dispatchEvent(new Event('input'));
    dom.view.querySelector('form')!.requestSubmit(); await settle();
    assert.ok(stream); assert.equal(dom.view.querySelector('#chat-message'), input);
    const transcript = dom.view.querySelector('.chat-transcript')!;
    transcript.scrollHeight = 1000; transcript.scrollTop = 0; transcript.clientHeight = 100;
    stream.enqueue(new TextEncoder().encode('data: {"kind":"conversation","conversationId":"invented"}\n\ndata: {"kind":"question","questions":["Invented follow-up?"],"acceptsFile":true}\n\n')); stream.close();
    await settle(); await settle();
    assert.equal(dom.view.querySelector('#chat-message'), input);
    assert.equal(dom.view.querySelector('.chat-attachments')!.querySelector('.chat-file'), attachment);
    assert.equal(attachment.open, true);
    assert.match(dom.view.querySelector('.chat-messages')!.textContent, /Invented follow-up/);
    assert.equal(dom.view.querySelector('.chat-latest')!.hidden, false);
    assert.equal(input.disabled, false);
    assert.equal(transcript.scrollTop, 0, 'reading older messages must not force a scroll');
  } finally { globalThis.fetch = original; dom.restore(); }
});
