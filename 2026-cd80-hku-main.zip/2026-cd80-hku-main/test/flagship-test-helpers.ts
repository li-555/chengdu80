import { readFileSync } from 'node:fs';
import type { AppDocument } from '../src/app-schema/index.ts';
import type { Slice } from '../src/compute/run.ts';
export type Fixture = { label: string; requirements: Record<string, { fields: { name: string; type: 'text' | 'number' | 'date' | 'boolean' }[]; rows: Record<string, string | number | boolean | null>[] }> };
export function flagshipFixture(id: string): Fixture {
  return JSON.parse(readFileSync(new URL(`./fixtures/flagship-inputs/${id}.json`, import.meta.url), 'utf8'));
}
/** Isolate the unchanged business rules from provider joins. Only tests use these invented rows. */
export function flagshipLogicDocument(id: string, document: AppDocument): AppDocument {
  const doc = structuredClone(document), fixture = flagshipFixture(id);
  delete (doc as unknown as Record<string, unknown>).$schema;
  doc.data = Object.entries(fixture.requirements).map(([key, value]) => ({ key, fields: value.fields.map(field => ({ name: field.name, type: field.type, required: true })) }));
  doc.compute = doc.compute.filter(step => !['market', 'fundamentals', 'financials'].includes(step.id));
  for (const param of doc.params) if (['watchlist', 'companies'].includes(param.key)) param.default = [];
  if (id === 'wealth-weave') {
    const root = doc.ui.elements[doc.ui.root]!;
    if (Array.isArray(root.children)) root.children = (root.children as string[]).filter(key => !['nav_reference', 'nav_settings'].includes(key));
    for (const key of ['nav_reference', 'nav_settings', 'fund_code', 'nav_start']) delete doc.ui.elements[key];
  }
  return doc;
}
export function fixtureSlices(id: string): Record<string, Slice> {
  return Object.fromEntries(Object.entries(flagshipFixture(id).requirements).map(([key, value]) => [key, {
    columns: value.fields.map(field => ({ name: field.name, type: field.type === 'text' ? 'string' : field.type })), rows: value.rows,
  }]));
}
