import { test } from 'node:test';
import assert from 'node:assert/strict';
import { canAnimate, loadGsap, revealNewContent } from '../web/src/motion-runtime.ts';

test('motion keeps server and detached-DOM consumers usable without browser APIs', async () => {
  assert.equal(canAnimate(), false);
  assert.equal(await loadGsap(), null);
  await revealNewContent([]);
});

test('reduced motion skips the vendor request; concurrent requests share one local script and tolerate failure', async () => {
  const previous = ['window', 'document'].map((key) => [key, Object.getOwnPropertyDescriptor(globalThis, key)] as const);
  let reduced = true;
  const scripts: { src: string; onerror: (() => void) | null }[] = [];
  const browser = {
    requestAnimationFrame() {}, getComputedStyle() {}, setTimeout, clearTimeout,
    matchMedia: () => ({ matches: reduced }),
  };
  Object.defineProperty(globalThis, 'window', { configurable: true, value: browser });
  Object.defineProperty(globalThis, 'document', { configurable: true, value: {
    documentElement: { getBoundingClientRect() {} },
    createElement: () => ({}), head: { append: (script: typeof scripts[number]) => scripts.push(script) },
  } });
  try {
    assert.equal(await loadGsap(), null);
    assert.equal(scripts.length, 0);
    reduced = false;
    const first = loadGsap(); const second = loadGsap();
    assert.equal(first, second);
    assert.equal(scripts.length, 1);
    assert.equal(scripts[0]!.src, '/assets/gsap.min.js');
    scripts[0]!.onerror!();
    assert.equal(await first, null);
    assert.equal(await second, null);
  } finally {
    for (const [key, descriptor] of previous) {
      if (descriptor) Object.defineProperty(globalThis, key, descriptor);
      else Reflect.deleteProperty(globalThis, key);
    }
  }
});
