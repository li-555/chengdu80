import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { MockLanguageModelV4 } from 'ai/test';
import { AppDocument } from '../src/app-schema/index.ts';
import { closeStorage } from '../src/platform/database.ts';
import { saveApp, getState, setState, listRuns } from '../src/platform/storage.ts';
import { createScheduledTask, configureScheduledTask, getScheduledTask } from '../src/platform/schedules.ts';
import { runSavedApplication } from '../src/platform/execute.ts';
import type { InventedDataAdapter } from '../src/platform/execution-data.ts';
const directory = mkdtempSync(join(tmpdir(), 'blocks-saved-model-'));
const previous = process.env.BLOCKS_DB_PATH;
before(() => { process.env.BLOCKS_DB_PATH = join(directory, 'storage.sqlite'); });
after(() => { closeStorage(); if (previous === undefined) delete process.env.BLOCKS_DB_PATH; else process.env.BLOCKS_DB_PATH = previous; rmSync(directory, { recursive: true, force: true }); });
const adapter: InventedDataAdapter = { kind: 'invented', id: 'fake-model-fixture', label: 'Invented runtime model rows', resolve: async () => ({ slices: { items: { columns: [{ name: 'label', type: 'string' }], rows: [{ label: 'FAKE-RUNTIME-CANARY' }] } }, datasetVersions: { items: 'fake-v1' }, asOfDate: '2026-10-14' }) };
function document(on_error: 'null' | 'fail' = 'null') {
  return AppDocument.parse({ meta: { name: 'Invented runtime model app', description: 'Invented rows and replies only', spec_version: '1.0' }, params: [],
    data: [{ key: 'items', fields: [{ name: 'label', type: 'text', required: true }] }],
    compute: [
      { id: 'carry', kind: 'code', input: ['items'], carry_state: true, body: 'const n = (state.n || 0) + 1; return { rows: [{ total: n }], state: { n } };', output: { columns: [{ name: 'total', type: 'number' }] } },
      { id: 'summary', kind: 'ai', input: 'carry', params: { mode: 'whole', instructions: 'Describe this invented count.', output: { kind: 'enum', values: ['small', 'large'] }, on_error } },
    ], triggers: [{ kind: 'manual' }], ui: { root: 'root', elements: { root: { type: 'Section', children: ['summary'] }, summary: { type: 'Table', from: 'summary', columns: [{ col: 'value', label: 'Invented summary' }] } } } });
}
function mock(text: string) { return new MockLanguageModelV4({ doGenerate: { content: [{ type: 'text', text }], finishReason: { unified: 'stop', raw: undefined }, usage: { inputTokens: { total: 1, noCache: 1, cacheRead: 0, cacheWrite: 0 }, outputTokens: { total: 1, text: 1, reasoning: 0 } }, warnings: [] } }); }
async function invoke(on_error: 'null' | 'fail', model?: MockLanguageModelV4, signal?: AbortSignal) {
  const app = await saveApp(document(on_error), 'fake-owner');
  await setState(app.id, app.profile, { carry: { n: 4 }, bindings: { items: 'fake-items' } });
  const reply = await runSavedApplication({ appId: app.id, profile: app.profile, runId: `fake-${app.id}`, adapter, allowInventedData: true, ...(model ? { model } : {}), ...(signal ? { signal } : {}) });
  assert.equal(reply.kind, 'completed');
  if (reply.kind !== 'completed') throw new Error('Expected completion');
  return { app, reply };
}
test('saved model execution succeeds, stores history/state and reuses completed claim without a model call', async () => {
  const model = mock('"small"');
  const { app, reply } = await invoke('fail', model);
  assert.equal(reply.record.status, 'ok');
  assert.deepEqual(reply.record.result!.outputs.summary!.rows, [['small']]);
  assert.equal(((await getState(app.id, app.profile)).carry as { n: number }).n, 5);
  assert.equal((await listRuns(app.id))[0]!.status, 'ok');
  assert.ok(reply.record.trace?.steps.some((step) => step.id === 'summary'));
  assert.equal(model.doGenerateCalls.length, 1);
  assert.equal(model.doGenerateCalls[0]!.providerOptions?.configured?.enable_thinking, undefined);
  const reused = await runSavedApplication({ appId: app.id, profile: app.profile, runId: reply.record.id, adapter, allowInventedData: true, model });
  assert.equal(reused.kind, 'completed'); if (reused.kind === 'completed') assert.equal(reused.reused, true);
  assert.equal(model.doGenerateCalls.length, 1);
});
test('runtime reply errors produce partial runs with state or failed runs without state according to declared policy', async () => {
  for (const policy of ['null', 'fail'] as const) {
    const model = mock('"not-an-option"');
    const { app, reply } = await invoke(policy, model);
    assert.equal(reply.record.status, policy === 'null' ? 'partial' : 'failed');
    assert.equal(((await getState(app.id, app.profile)).carry as { n: number }).n, policy === 'null' ? 5 : 4);
    assert.equal((await listRuns(app.id)).length, 1);
    assert.equal(model.doGenerateCalls.length, 2);
    if (policy === 'null') assert.ok((reply.record.result!.warnings ?? []).length > 0);
  }
});
test('missing configured key uses declared runtime error policy and never invokes a provider', async () => {
  const previousKey = process.env.GITEE_AI_API_KEY;
  delete process.env.GITEE_AI_API_KEY;
  try {
    for (const policy of ['null', 'fail'] as const) {
      const { reply } = await invoke(policy);
      assert.equal(reply.record.status, policy === 'null' ? 'partial' : 'failed');
    }
  } finally { if (previousKey !== undefined) process.env.GITEE_AI_API_KEY = previousKey; }
});
test('cancelling a hanging runtime model stores failed history and leaves carried state unchanged', async () => {
  const controller = new AbortController();
  const model = new MockLanguageModelV4({ doGenerate: async () => { controller.abort(); return new Promise(() => {}); } });
  const { app, reply } = await invoke('null', model, controller.signal);
  assert.equal(reply.record.status, 'failed');
  assert.equal(reply.record.failure?.code, 'E_RUN_CANCELLED');
  assert.equal(((await getState(app.id, app.profile)).carry as { n: number }).n, 4);
  assert.equal((await listRuns(app.id))[0]!.status, 'failed');
});

test('independent text/per-row and object/whole variants use the same saved runtime', async () => {
  for (const variant of ['text', 'object'] as const) {
    const doc = document('fail');
    const step = doc.compute[1]!;
    if (step.kind !== 'ai') throw new Error('Expected AI step');
    step.input = 'items';
    step.params.mode = variant === 'text' ? 'per_row' : 'whole';
    step.params.output = variant === 'text' ? { kind: 'text' } : { kind: 'object', fields: { count: 'number', note: 'string' } };
    doc.ui.elements.summary = { type: 'Table', from: 'summary', columns: [{ col: variant === 'text' ? 'value' : 'count' }] };
    const app = await saveApp(doc, 'fake-variants');
    const model = mock(variant === 'text' ? 'Invented note' : '{"count":1,"note":"Invented note"}');
    const reply = await runSavedApplication({ appId: app.id, profile: app.profile, adapter, allowInventedData: true, model });
    assert.equal(reply.kind, 'completed');
    if (reply.kind !== 'completed') throw new Error('Expected completion');
    assert.equal(reply.record.status, 'ok');
    const table = reply.record.result!.outputs.summary!;
    const index = table.schema.findIndex((column) => column.name === (variant === 'text' ? 'value' : 'count'));
    assert.equal(table.rows[0]![index], variant === 'text' ? 'Invented note' : 1);
    assert.equal(model.doGenerateCalls.length, 1);
    assert.ok(JSON.stringify(model.doGenerateCalls[0]!.prompt).includes('FAKE-RUNTIME-CANARY'));
  }
});
test('scheduled occurrence uses shared model runtime and finishes its task exactly once', async () => {
  const doc = document('fail'); doc.triggers.push({ kind: 'schedule', cron: '0 8 * * *', tz: 'Asia/Shanghai' });
  const app = await saveApp(doc, 'fake-scheduled');
  const task = await createScheduledTask(app.id, app.profile, 1);
  const scheduledFor = '2026-01-01T08:00:00.000Z';
  await configureScheduledTask(task.id, app.profile, { enabled: true, nextRunAt: scheduledFor });
  const model = mock('"large"');
  const reply = await runSavedApplication({ appId: app.id, profile: app.profile, runId: 'fake-scheduled-model', scheduled: { taskId: task.id, scheduledFor }, adapter, allowInventedData: true, model });
  assert.equal(reply.kind, 'completed');
  if (reply.kind !== 'completed') throw new Error('Expected completion');
  assert.equal(reply.record.status, 'ok');
  assert.equal(reply.record.taskId, task.id);
  assert.equal(reply.record.scheduledFor, scheduledFor);
  const finished = await getScheduledTask(task.id, app.profile);
  assert.equal(finished!.lastRunId, reply.record.id);
  assert.equal(finished!.lastScheduledFor, scheduledFor);
  assert.equal((await listRuns(app.id)).length, 1);
});
test('a timed execution signal bounds an unresponsive runtime model and records the failed attempt', async () => {
  const controller = new AbortController();
  const model = new MockLanguageModelV4({ doGenerate: async () => {
    // Begin the model timeout after setup/SQL has reached the hanging call.
    // Parallel-suite contention must not expire it before the call starts.
    setTimeout(() => controller.abort(new DOMException('Invented model timeout', 'TimeoutError')), 50);
    return new Promise(() => {});
  } });
  const start = Date.now();
  const { app, reply } = await invoke('fail', model, controller.signal);
  assert.equal(reply.record.status, 'failed');
  assert.equal(reply.record.failure?.code, 'E_RUN_CANCELLED');
  assert.ok(Date.now() - start < 2000);
  assert.equal(((await getState(app.id, app.profile)).carry as { n: number }).n, 4);
  assert.equal((await listRuns(app.id)).length, 1);
  assert.equal(model.doGenerateCalls.length, 1);
});
