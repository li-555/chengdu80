import { test } from 'node:test';
import assert from 'node:assert/strict';
import express from 'express';
import { IncomingMessage, ServerResponse } from 'node:http';
import { Socket } from 'node:net';
import { dataRoutes } from '../src/api/routes-data.ts';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { saveUpload } from '../src/data/upload-store.ts';
import { addApiSource, addUpload, resetUploadsForTests } from '../src/data/catalogue.ts';
import type { Dataset } from '../src/data/types.ts';

type GetResult = { status: number; body: string };

function get(app: express.Express, url: string): Promise<GetResult> {
  return new Promise((resolve, reject) => {
    const request = new IncomingMessage(new Socket());
    request.method = 'GET';
    request.url = url;
    const response = new ServerResponse(request);
    response.end = ((body: string | Buffer) => {
      resolve({ status: response.statusCode, body: String(body) });
      return response;
    }) as typeof response.end;
    app(request as express.Request, response as express.Response, (error?: unknown) =>
      reject(error ?? new Error(`No route for ${url}`)));
  });
}

test('GET /api/data/datasets lists the catalogue', async () => {
  const app = express();
  app.use(...dataRoutes);
  const { status, body } = await get(app, '/api/data/datasets');
  assert.equal(status, 200);
  const parsed = JSON.parse(body) as { datasets: unknown[] };
  assert.ok(parsed.datasets.length > 0, 'the catalogue must not be empty');
});

test('GET /api/data/datasets/:id returns 404 for an unknown dataset', async () => {
  const app = express();
  app.use(...dataRoutes);
  const { status, body } = await get(app, '/api/data/datasets/missing:table');
  assert.equal(status, 404);
  assert.match(body, /DATASET_NOT_FOUND/);
});

test('browser catalogue scopes invented uploads and hides sources without an owner', async (t) => {
  const directory = mkdtempSync(join(tmpdir(), 'blocks-catalogue-scope-'));
  const previous = process.env.BLOCKS_DB_PATH;
  process.env.BLOCKS_DB_PATH = join(directory, 'blocks.sqlite');
  resetUploadsForTests();
  t.after(() => {
    if (previous === undefined) delete process.env.BLOCKS_DB_PATH;
    else process.env.BLOCKS_DB_PATH = previous;
    resetUploadsForTests();
    rmSync(directory, { recursive: true, force: true });
  });
  const fake = (id: string): Dataset => ({ id, name: 'Invented dataset', source: 'upload', rowCount: 1,
    fields: [{ name: 'value', label: 'Value', type: 'text', nullable: false }] });
  saveUpload(fake('user:alice'), [['FAKE-PRIVATE-ALICE']], 'alice');
  saveUpload(fake('user:bob'), [['FAKE-PRIVATE-BOB']], 'bob');
  saveUpload(fake('user:default'), [['FAKE-DEFAULT']], 'default');
  addUpload(fake('user:unowned'), [['FAKE-UNOWNED']]);
  addApiSource({ ...fake('api:unowned'), source: 'api' }, {
    url: 'https://example.invalid/fake', auth: { kind: 'none' }, options: { allowList: [], maxRows: 1, pageSize: 1 },
  });
  const app = express(); app.use(...dataRoutes);
  const listing = await get(app, '/api/data/datasets?profile=alice');
  assert.equal(listing.status, 200);
  const datasets = JSON.parse(listing.body).datasets as Dataset[];
  assert.deepEqual(datasets.filter((dataset) => dataset.source !== 'tushare').map((dataset) => dataset.id), ['user:alice']);
  assert.doesNotMatch(listing.body, /FAKE-PRIVATE|FAKE-DEFAULT|FAKE-UNOWNED/);
  for (const id of ['user:bob', 'user:default', 'user:unowned', 'api:unowned']) {
    assert.equal((await get(app, `/api/data/datasets/${encodeURIComponent(id)}?profile=alice`)).status, 404);
  }
  const own = await get(app, '/api/data/datasets/user%3Aalice?profile=alice');
  assert.equal(own.status, 200);
  assert.doesNotMatch(own.body, /FAKE-PRIVATE/);
  const defaults = JSON.parse((await get(app, '/api/data/datasets?profile=invalid!')).body).datasets as Dataset[];
  assert.deepEqual(defaults.filter((dataset) => dataset.source !== 'tushare').map((dataset) => dataset.id), ['user:default']);
});
