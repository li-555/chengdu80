import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createServer, type Server, type IncomingMessage, type ServerResponse } from 'node:http';
import { once } from 'node:events';

import { inferApiSchema, normalizeJsonToTable } from '../src/data/infer-api-schema.ts';
import { readApiRows, assertSafeUrl } from '../src/data/api-client.ts';
import { registerExternalApi } from '../src/data/register-external-api.ts';
import { resolveSliceWith, clearSliceCache } from '../src/data/resolve-slice.ts';

/**
 * Every row in this file is invented. Nothing here is real market data.
 */

type Handler = (req: IncomingMessage, res: ServerResponse) => void;

async function startServer(handler: Handler): Promise<{ server: Server; url: string }> {
  const server = createServer(handler);
  server.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const address = server.address();
  const port = typeof address === 'object' && address !== null ? address.port : 0;
  return { server, url: `http://127.0.0.1:${port}` };
}

async function stopServer(server: Server): Promise<void> {
  await new Promise<void>((resolve) => server.close(() => resolve()));
}

function json(res: ServerResponse, value: unknown, status = 200): void {
  res.statusCode = status;
  res.setHeader('content-type', 'application/json');
  res.end(JSON.stringify(value));
}

// ---------------------------------------------------------------- schema inference

test('inferApiSchema flattens nested objects and infers types', () => {
  const rows = [
    { ts_code: '000001', close: 12.5, meta: { name: 'A' }, date: '20260114' },
    { ts_code: '000002', close: 13, meta: { name: 'B' }, date: '20260115' },
  ];
  const { schema } = inferApiSchema(rows);
  const byName = Object.fromEntries(schema.map((f) => [f.name, f.type]));
  assert.equal(byName.ts_code, 'text');
  assert.equal(byName.close, 'number');
  assert.equal(byName['meta.name'], 'text');
  assert.equal(byName.date, 'date');
});

test('normalizeJsonToTable keeps rows aligned to the union of headers', () => {
  const table = normalizeJsonToTable([{ a: 1 }, { b: 2 }, { a: 3, b: 4 }]);
  assert.deepEqual(table.headers, ['a', 'b']);
  assert.deepEqual(table.rows, [['1', ''], ['', '2'], ['3', '4']]);
});

// ---------------------------------------------------------------- URL safety

test('assertSafeUrl allows allow-listed https and rejects IP, http and non-allow-listed hosts', () => {
  assertSafeUrl('https://data.example.com/x', ['example.com']);
  assert.throws(() => assertSafeUrl('https://1.2.3.4/x', []), /direct IP addresses/);
  assert.throws(() => assertSafeUrl('http://example.com/x', []), /http is only allowed/);
  assert.throws(() => assertSafeUrl('https://evil.com/x', ['example.com']), /not on the allow-list/);
  assert.throws(() => assertSafeUrl('ftp://example.com/x', []), /unsupported protocol/);
});

// ---------------------------------------------------------------- reading

test('readApiRows follows offset pagination and stops on a short page', async () => {
  const pages = [[{ id: 1 }, { id: 2 }], [{ id: 3 }]];
  let calls = 0;
  const { server, url } = await startServer((req, res) => {
    const requestUrl = new URL(req.url ?? '/', url);
    const offset = Number(requestUrl.searchParams.get('offset') ?? '0');
    calls++;
    json(res, pages[Math.floor(offset / 2)] ?? []);
  });
  try {
    const rows = await readApiRows(url, { kind: 'none' }, { allowList: [], pageSize: 2 });
    assert.equal(rows.length, 3);
    assert.equal(calls, 2);
  } finally {
    await stopServer(server);
  }
});

test('readApiRows throws a clear error on a non-JSON response', async () => {
  const { server, url } = await startServer((req, res) => {
    res.statusCode = 200;
    res.setHeader('content-type', 'text/plain');
    res.end('not json');
  });
  try {
    await assert.rejects(readApiRows(url, { kind: 'none' }, { allowList: [] }), /non-JSON/);
  } finally {
    await stopServer(server);
  }
});

test('readApiRows retries transient 500s then fails', async () => {
  let calls = 0;
  const { server, url } = await startServer((req, res) => {
    calls++;
    json(res, { message: 'boom' }, 500);
  });
  try {
    await assert.rejects(
      readApiRows(url, { kind: 'none' }, { allowList: [], maxRetries: 1 }),
      /API request failed: boom/,
    );
    assert.equal(calls, 2);
  } finally {
    await stopServer(server);
  }
});

// ---------------------------------------------------------------- end to end

test('registerExternalApi then resolveSlice reads and maps API rows', async () => {
  clearSliceCache();
  const { server, url } = await startServer((req, res) => {
    json(res, [
      { ts_code: '000001', close: 12.5 },
      { ts_code: '000002', close: 13 },
    ]);
  });
  try {
    const ds = await registerExternalApi(url, { kind: 'none' }, 'Invented prices', {
      allowList: [],
      maxRows: 50,
    });
    assert.equal(ds.source, 'api');
    assert.ok(ds.id.startsWith('api:'));

    const slice = await resolveSliceWith(
      { datasetId: ds.id, fields: ['ts_code', 'close'] },
      async () => ({ fields: [], rows: [] }),
    );
    assert.deepEqual(slice.schema.map((f) => f.name), ['ts_code', 'close']);
    assert.deepEqual(slice.rows, [['000001', '12.5'], ['000002', '13']]);
    assert.equal(slice.datasetVersion, '1.0.0');
  } finally {
    await stopServer(server);
  }
});
