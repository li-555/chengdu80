import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, mkdirSync, writeFileSync, rmSync, symlinkSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const script = fileURLToPath(new URL('../scripts/check-deps.mjs', import.meta.url));

function fixture(packages: Record<string, object>, files: Record<string, string> = {}, args: string[] = [], useCwd = false, links: Record<string, string> = {}) {
  const project = mkdtempSync(join(tmpdir(), 'dependency-guard-'));
  try {
    writeFileSync(join(project, 'package-lock.json'), JSON.stringify({ lockfileVersion: 3, packages }));
    for (const [path, content] of Object.entries(files)) {
      const target = join(project, path);
      mkdirSync(join(target, '..'), { recursive: true });
      writeFileSync(target, content);
    }
    for (const [path, target] of Object.entries(links)) {
      mkdirSync(join(project, path, '..'), { recursive: true });
      symlinkSync(join(project, target), join(project, path));
    }
    const result = spawnSync(process.execPath, [script, ...(useCwd ? [] : [project]), ...args], {
      cwd: project, encoding: 'utf8', timeout: 10_000,
    });
    assert.ifError(result.error);
    return { status: result.status, output: result.stdout + result.stderr };
  } finally {
    rmSync(project, { recursive: true, force: true });
  }
}

test('dependency guard accepts a clean lock and defaults to the current directory', () => {
  const result = fixture({ 'node_modules/plain': {} }, {
    'node_modules/plain/package.json': '{"scripts":{"test":"node test.js"}}',
  }, [], true);
  assert.equal(result.status, 0, result.output);
  assert.equal(result.output, 'Dependency guard: 1 runtime packages, none compiles or runs an install script.\n');
});

test('dependency guard rejects a runtime install flag even when the package is absent', () => {
  const result = fixture({ 'node_modules/flagged': { hasInstallScript: true } });
  assert.equal(result.status, 1, result.output);
  assert.match(result.output, /node_modules\/flagged: hasInstallScript: true in lock/);
  assert.match(result.output, /not present in node_modules; checked from lock alone/);
});

test('dependency guard excludes dev-only packages with install scripts and build files', () => {
  const result = fixture({ 'node_modules/development': { dev: true, hasInstallScript: true } }, {
    'node_modules/development/package.json': '{"scripts":{"postinstall":"node setup.js"}}',
    'node_modules/development/binding.gyp': '{}',
  });
  assert.equal(result.status, 0, result.output);
  assert.match(result.output, /0 runtime packages/);
});

for (const hook of ['preinstall', 'install', 'postinstall']) {
  test(`dependency guard rejects a runtime package.json ${hook}`, () => {
    const result = fixture({ 'node_modules/lifecycle': {} }, {
      'node_modules/lifecycle/package.json': JSON.stringify({ scripts: { [hook]: 'node setup.js' } }),
    });
    assert.equal(result.status, 1, result.output);
    assert.ok(result.output.includes(`node_modules/lifecycle: package.json scripts.${hook}`), result.output);
  });
}

test('dependency guard rejects binding.gyp at a runtime package root', () => {
  const result = fixture({ 'node_modules/native-build': {} }, { 'node_modules/native-build/binding.gyp': '{}' });
  assert.equal(result.status, 1, result.output);
  assert.match(result.output, /node_modules\/native-build: binding.gyp at package root/);
});

test('dependency guard includes optional packages and reports absent packages in verbose output', () => {
  const result = fixture({ 'node_modules/optional': { optional: true } }, {}, ['--verbose']);
  assert.equal(result.status, 0, result.output);
  assert.match(result.output, /Checked node_modules\/optional: OK \(not present in node_modules; checked from lock alone\)/);
  const rejected = fixture({ 'node_modules/optional': { optional: true, hasInstallScript: true } });
  assert.equal(rejected.status, 1, rejected.output);
  assert.match(rejected.output, /node_modules\/optional: hasInstallScript/);
});

test('dependency guard allows shipped native binaries and nested build files', () => {
  const result = fixture({ 'node_modules/prebuilt': {} }, {
    'node_modules/prebuilt/addon.node': 'fixture binary',
    'node_modules/prebuilt/examples/binding.gyp': '{}',
  });
  assert.equal(result.status, 0, result.output);
});

test('dependency guard lists every offender and every reason', () => {
  const result = fixture({
    'node_modules/first': { hasInstallScript: true },
    'node_modules/second': {},
  }, {
    'node_modules/first/package.json': '{"scripts":{"install":"node setup.js"}}',
    'node_modules/first/binding.gyp': '{}',
    'node_modules/second/binding.gyp': '{}',
  });
  assert.equal(result.status, 1, result.output);
  assert.match(result.output, /node_modules\/first: hasInstallScript: true in lock; package.json scripts.install; binding.gyp at package root/);
  assert.match(result.output, /node_modules\/second: binding.gyp at package root/);
  assert.match(result.output, /2 runtime packages, 2 offenders/);
});

for (const location of ['../outside', '/outside', 'node_modules/plain/../outside']) {
  test(`dependency guard rejects malformed lock key ${location}`, () => {
    const result = fixture({ [location]: { dev: true } });
    assert.equal(result.status, 1, result.output);
    assert.match(result.output, /Malformed lock/);
    assert.match(result.output, /must not be absolute or contain "\.\." segments/);
  });
}

test('dependency guard ignores project and workspace entries on disk', () => {
  const result = fixture({ '': { hasInstallScript: true }, 'packages/local': { hasInstallScript: true } }, {
    'package.json': '{"scripts":{"install":"node setup.js"}}',
    'packages/local/package.json': 'invalid JSON',
  });
  assert.equal(result.status, 0, result.output);
  assert.match(result.output, /0 runtime packages/);
});

test('dependency guard skips a link whose target is dev-only', () => {
  const result = fixture({
    'node_modules/local': { link: true, resolved: 'packages/local' },
    'packages/local': { dev: true, hasInstallScript: true },
  });
  assert.equal(result.status, 0, result.output);
  assert.match(result.output, /0 runtime packages/);
});

test('dependency guard rejects a runtime link', () => {
  const result = fixture({
    'node_modules/local': { link: true, resolved: 'packages/local' },
    'packages/local': {},
  });
  assert.equal(result.status, 1, result.output);
  assert.match(result.output, /runtime dependency local is a linked local package; the judges' install cannot verify it/);
});

for (const path of ['node_modules/local', 'node_modules/local/package.json']) {
  test(`dependency guard refuses an external symlink at ${path}`, () => {
    const result = fixture({ 'node_modules/local': {} }, {
      'packages/local/package.json': 'invalid JSON',
    }, [], false, { [path]: path.endsWith('package.json') ? 'packages/local/package.json' : 'packages/local' });
    assert.equal(result.status, 1, result.output);
    assert.match(result.output, /symbolic link outside node_modules/);
    assert.ok(!result.output.includes('Unexpected token'), result.output);
  });
}
