import { getMonitorSnapshot, setMonitorAcknowledged } from '../src/platform/monitor.ts';
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { templates, importTemplate } from '../src/platform/templates.ts';
import { getApp, getState, setState, saveApp } from '../src/platform/storage.ts';
import { closeStorage } from '../src/platform/database.ts';
import { listUploads } from '../src/data/upload-store.ts';
import { exportApplication } from '../src/platform/export.ts';
import { runSavedApplication } from '../src/platform/execute.ts';
import { validateApplication } from '../src/validate/index.ts';
const directory = mkdtempSync(join(tmpdir(), 'blocks-template-tests-'));
process.env.BLOCKS_DB_PATH = join(directory, 'storage.sqlite');
after(() => { closeStorage(); rmSync(directory, { recursive: true, force: true }); });

test('all flagship imports contain Tushare requirements, install no invented rows and require user data after export/reimport', async () => {
  const originalFetch = globalThis.fetch; let network = 0;
  globalThis.fetch = async () => { network++; throw new Error('Unbound user data must be detected before network requests.'); };
  try {
    for (const template of templates) {
      const owner = `template_${template.id}`, profile = `browser:${owner}`;
      const result = await importTemplate(template.id, profile, owner, 'connect');
      assert.equal(result.kind, 'imported'); if (result.kind !== 'imported') throw new Error('Missing template');
      const app = (await getApp(result.appId))!;
      assert.equal(validateApplication(app.doc).ok, true);
      assert(app.doc.data.some(req => req.datasetHint?.startsWith('tushare:')));
      assert(app.doc.data.some(req => !req.datasetHint));
      assert.deepEqual(await getState(app.id, profile), {});
      assert.deepEqual(listUploads(owner), []);
      const run = await runSavedApplication({ appId: app.id, profile });
      assert.equal(run.kind, 'needs_data');
      const exported = exportApplication(app.doc), parsed = validateApplication(exported);
      assert(parsed.ok); if (!parsed.ok) throw new Error('Invalid export');
      assert.deepEqual(parsed.document, app.doc);
      const copy = await saveApp(parsed.document, profile);
      assert.equal((await runSavedApplication({ appId: copy.id, profile })).kind, 'needs_data');
    }
    assert.equal(network, 0);
  } finally { globalThis.fetch = originalFetch; }
});
test('retired demo requests cannot install invented data and legacy demo runs cannot invoke an adapter', async () => {
  await assert.rejects(importTemplate('alpha-vista', 'legacy', 'legacy', 'demo' as 'connect'), /no longer available/);
  const imported = await importTemplate('risk-rift', 'legacy', 'legacy', 'connect');
  assert(imported.kind === 'imported');
  await setState(imported.appId, 'legacy', { demo: { invented: true } });
  const adapter = { kind: 'real' as const, id: 'forbidden', label: 'Must not resolve', resolve: async (): Promise<never> => { throw new Error('Legacy inputs reached the adapter'); } };
  const reply = await runSavedApplication({ appId: imported.appId, profile: 'legacy', adapter });
  assert(reply.kind === 'completed'); assert.equal(reply.record.failure?.code, 'E_LEGACY_DEMO');
  const doc = structuredClone((await getApp(imported.appId))!.doc); doc.meta.description = `Demo inputs — invented. ${doc.meta.description}`.slice(0,400);
  const reimported = await saveApp(doc, 'legacy');
  const again = await runSavedApplication({ appId: reimported.id, profile: 'legacy', adapter });
  assert(again.kind === 'completed'); assert.equal(again.record.failure?.code, 'E_LEGACY_DEMO');
  assert.deepEqual(await importTemplate('../escape', 'legacy', 'legacy', 'connect'), { kind: 'missing' });
});

test('all flagship monitoring baselines and acknowledgments still work with explicit offline test fixtures', async () => {
  const { flagshipLogicDocument, fixtureSlices } = await import('./flagship-test-helpers.ts');
  const { readFileSync } = await import('node:fs');
  for (const template of templates) {
    const profile = `offline-monitor-${template.id}`;
    const source = JSON.parse(readFileSync(new URL(`../examples/${template.id}.fin.json`, import.meta.url), 'utf8'));
    const app = await saveApp(flagshipLogicDocument(template.id, source), profile);
    const input = fixtureSlices(template.id);
    const adapter = { kind: 'invented' as const, id: 'offline-fixture', label: 'Invented test inputs only', resolve: async () => ({ slices: input, datasetVersions: Object.fromEntries(Object.keys(input).map(key => [key, 'test-v1'])) }) };
    const reply = await runSavedApplication({ appId: app.id, profile, adapter, allowInventedData: true });
    assert(reply.kind === 'completed'); assert.equal(reply.record.status, 'ok', JSON.stringify(reply.record.failure));
    const monitor = await getMonitorSnapshot(app.id, profile); assert.equal(monitor.enabled, true); assert.equal(monitor.lastRunId, reply.record.id);
    assert.match(monitor.notice, /Baseline established/); assert.equal(monitor.changes.length, 0);
    const alert = monitor.alerts.find(item => item.status !== 'cleared'); assert(alert);
    assert.equal((await setMonitorAcknowledged(app.id, profile, {alertId:alert.id,acknowledged:true})).kind, 'saved');
    const rerun = await runSavedApplication({ appId: app.id, profile, adapter, allowInventedData: true });
    assert(rerun.kind === 'completed'); assert.equal(rerun.record.status, 'ok');
    const next = await getMonitorSnapshot(app.id, profile); assert.equal(next.changes.length, 0); assert(next.alerts.find(item=>item.id===alert.id)?.acknowledgedAt);
  }
});
