import { test } from 'node:test';
import assert from 'node:assert/strict';

import { runApplication, type Slice } from '../src/compute/run.ts';
import { solve } from '../src/compute/ops/irr.ts';
import { solveSymmetric } from '../src/compute/ops/regress_multi.ts';
import { compileFactor, SUPPORTED_FACTORS } from '../src/compute/ops/factor.ts';
import { OpCompileError, type OpCompileInput } from '../src/compute/ops/contract.ts';

/**
 * `irr`, `regress` over several columns, `adjust_price` and `factor`, run end to end
 * through the run loop, so the extra relations, the read-back path and single values are
 * all exercised the way a real application exercises them.
 *
 * All rows below are invented.
 */

type Step = { id: string; kind: 'operation'; op: string; input: string; params: Record<string, unknown>; key?: boolean };

async function run(slices: Record<string, Slice>, compute: Step[], want: string[]) {
  const outcome = await runApplication(
    { data: Object.keys(slices).map((key) => ({ key })), compute },
    { slices, want },
  );
  return outcome;
}

const near = (a: unknown, b: number, msg?: string) =>
  assert.ok(Math.abs(Number(a) - b) < 1e-9, `${msg ?? ''} expected ${b}, got ${a}`);

// ---------------------------------------------------------------- irr

const flows: Slice = {
  columns: [{ name: 'd', type: 'date' }, { name: 'amt', type: 'number' }],
  // Pay 1,000, receive 1,100 exactly 365 days later: 10% a year.
  rows: [{ d: '2026-01-01', amt: -1000 }, { d: '2027-01-01', amt: 1100 }],
};

test('irr: one year, 10 per cent, comes back as a single value later steps can use', async () => {
  const outcome = await run({ flows }, [
    { id: 'rate', kind: 'operation', op: 'irr', input: 'flows', params: { amount_col: 'amt', date_col: 'd', max_iter: 100 } },
    // Uses the single value by its id: keeps the payments larger than 1000 times the rate.
    { id: 'big', kind: 'operation', op: 'filter', input: 'flows', params: { where: 'abs(amt) > rate * 10500' } },
  ], ['rate', 'big']);

  assert.equal(outcome.failure, undefined, outcome.failure);
  near(outcome.results.get('rate')!.rows[0]!.irr, 0.1, 'irr');
  // 0.1 * 10500 = 1050: only the 1,100 receipt passes.
  assert.deepEqual(outcome.results.get('big')!.rows.map((r) => Number(r.amt)), [1100]);
});

test('irr: a formula declared before the irr it reads still runs after it', async () => {
  const outcome = await run({ flows }, [
    { id: 'big', kind: 'operation', op: 'filter', input: 'flows', params: { where: 'abs(amt) > rate * 10500' } },
    { id: 'rate', kind: 'operation', op: 'irr', input: 'flows', params: { amount_col: 'amt', date_col: 'd', max_iter: 100 } },
  ], ['big']);
  assert.equal(outcome.failure, undefined, outcome.failure);
  assert.deepEqual(outcome.steps.map((s) => s.id), ['rate', 'big']);
});

test('irr: refuses payments that are all one sign', async () => {
  const outcome = await run({ flows: { ...flows, rows: [{ d: '2026-01-01', amt: 5 }, { d: '2026-06-01', amt: 6 }] } }, [
    { id: 'rate', kind: 'operation', op: 'irr', input: 'flows', params: { amount_col: 'amt', date_col: 'd', max_iter: 100 } },
  ], ['rate']);
  assert.equal(outcome.status, 'failed');
  assert.match(outcome.failure ?? '', /negative.*positive/);
});

test('irr solver: falls back to halving when Newton starts badly', () => {
  // -100 now, +300 in two years: (1+r)^2 = 3, r = sqrt(3) - 1.
  const r = solve([{ a: -100, y: 0 }, { a: 300, y: 2 }], -0.99, 3);
  near(r, Math.sqrt(3) - 1, 'irr');
});

// ---------------------------------------------------------------- regress, several columns

const obs: Slice = {
  columns: [
    { name: 'g', type: 'string' }, { name: 'a', type: 'number' },
    { name: 'b', type: 'number' }, { name: 'y', type: 'number' },
  ],
  rows: [
    // group P: y = 1 + 2a + 3b exactly
    ...[[0, 0], [1, 0], [0, 1], [2, 3], [5, 1]].map(([a, b]) => ({ g: 'P', a, b, y: 1 + 2 * a! + 3 * b! })),
    // group Q: y = 5 - a + 0.5b exactly
    ...[[1, 2], [3, 1], [4, 4], [0, 6], [2, 2]].map(([a, b]) => ({ g: 'Q', a, b, y: 5 - a! + 0.5 * b! })),
    // group R: b is always 2a, so a and b cannot be told apart
    ...[[1, 2], [2, 4], [3, 6], [4, 8]].map(([a, b]) => ({ g: 'R', a, b, y: a! + b! })),
  ],
};

test('regress on two columns: exact coefficients per group, blank for a group that cannot be solved', async () => {
  const outcome = await run({ obs }, [
    { id: 'fit', kind: 'operation', op: 'regress', input: 'obs', params: { y: 'y', x: ['a', 'b'], by: ['g'] } },
  ], ['fit']);
  assert.equal(outcome.failure, undefined, outcome.failure);

  const rows = outcome.results.get('fit')!.rows;
  assert.deepEqual(outcome.results.get('fit')!.columns.map((c) => c.name), ['g', 'term', 'coefficient', 'r2', 'n']);
  const get = (g: string, term: string) => rows.find((r) => r.g === g && r.term === term)!;

  near(get('P', 'intercept').coefficient, 1);
  near(get('P', 'a').coefficient, 2);
  near(get('P', 'b').coefficient, 3);
  near(get('P', 'a').r2, 1);
  assert.equal(Number(get('P', 'a').n), 5);

  near(get('Q', 'intercept').coefficient, 5);
  near(get('Q', 'a').coefficient, -1);
  near(get('Q', 'b').coefficient, 0.5);

  assert.equal(get('R', 'a').coefficient, null);
  assert.equal(get('R', 'intercept').coefficient, null);
  assert.equal(rows.length, 9);
});

test('regress on two columns with no grouping', async () => {
  const outcome = await run({ obs: { ...obs, rows: obs.rows.filter((r) => r.g === 'P') } }, [
    { id: 'fit', kind: 'operation', op: 'regress', input: 'obs', params: { y: 'y', x: ['a', 'b'] } },
  ], ['fit']);
  assert.equal(outcome.failure, undefined, outcome.failure);
  const rows = outcome.results.get('fit')!.rows;
  assert.deepEqual(rows.map((r) => r.term), ['intercept', 'a', 'b']);
  near(rows[2]!.coefficient, 3);
});

test('solveSymmetric: singular system is null', () => {
  assert.equal(solveSymmetric([[1, 2], [2, 4]], [1, 2]), null);
  assert.deepEqual(solveSymmetric([[2, 0], [0, 4]], [2, 8]), [1, 2]);
});

// ---------------------------------------------------------------- adjust_price

const px: Slice = {
  columns: [{ name: 'code', type: 'string' }, { name: 'day', type: 'date' }, { name: 'close', type: 'number' }, { name: 'vol', type: 'number' }],
  rows: [
    { code: 'AAA', day: '2026-03-02', close: 10, vol: 1 },
    { code: 'AAA', day: '2026-03-03', close: 10, vol: 2 }, // no factor row this day: suspended
    { code: 'AAA', day: '2026-03-04', close: 5, vol: 3 },  // a 2-for-1 split
    { code: 'ZZZ', day: '2026-03-04', close: 7, vol: 4 },  // no factors at all
  ],
};
const adj: Slice = {
  columns: [{ name: 'ts_code', type: 'string' }, { name: 'trade_date', type: 'date' }, { name: 'adj_factor', type: 'number' }],
  rows: [
    { ts_code: 'AAA', trade_date: '2026-03-02', adj_factor: 1 },
    { ts_code: 'AAA', trade_date: '2026-03-04', adj_factor: 2 },
  ],
};
const adjustParams = { price_cols: ['close'], factor_table: 'adj', key: ['code', 'ts_code'], date: ['day', 'trade_date'], factor_col: 'adj_factor' };

async function adjusted(extra: Record<string, unknown>) {
  const outcome = await run({ px, adj }, [
    { id: 'out', kind: 'operation', op: 'adjust_price', input: 'px', params: { ...adjustParams, ...extra } },
  ], ['out']);
  assert.equal(outcome.failure, undefined, outcome.failure);
  const res = outcome.results.get('out')!;
  assert.deepEqual(res.columns.map((c) => c.name), ['code', 'day', 'close', 'vol'], 'same columns, same order');
  return [...res.rows].sort((a, b) => `${a.code}${a.day}`.localeCompare(`${b.code}${b.day}`)).map((r) => r.close === null ? null : Number(r.close));
}

test('adjust_price backward: price times the factor in force that day', async () => {
  assert.deepEqual(await adjusted({ mode: 'backward' }), [10, 10, 10, null]);
});

test('adjust_price forward: latest prices unchanged, older prices scaled down', async () => {
  assert.deepEqual(await adjusted({ mode: 'forward' }), [5, 5, 5, null]);
});

test('adjust_price forward from a base date', async () => {
  assert.deepEqual(await adjusted({ mode: 'forward', base_date: '2026-03-03' }), [10, 10, 10, null]);
});

test('adjust_price refuses a price column that is the date', async () => {
  const outcome = await run({ px, adj }, [
    { id: 'out', kind: 'operation', op: 'adjust_price', input: 'px', params: { ...adjustParams, mode: 'backward', price_cols: ['day'] } },
  ], ['out']);
  assert.equal(outcome.status, 'failed');
});

// ---------------------------------------------------------------- factor

const days = ['2026-04-01', '2026-04-02', '2026-04-03', '2026-04-06', '2026-04-07', '2026-04-08', '2026-04-09'];
const daily: Slice = {
  columns: [
    { name: 'ts_code', type: 'string' }, { name: 'trade_date', type: 'date' },
    { name: 'close', type: 'number' }, { name: 'pe', type: 'number' },
  ],
  rows: [
    // AAA closes 10, 11, ... 16
    ...days.map((d, i) => ({ ts_code: 'AAA', trade_date: d, close: 10 + i, pe: 20 })),
    // BBB has only three days and a loss
    ...days.slice(4).map((d) => ({ ts_code: 'BBB', trade_date: d, close: 8, pe: -5 })),
  ],
};
const universe: Slice = { columns: [{ name: 'ts_code', type: 'string' }], rows: [{ ts_code: 'AAA' }] };

test('factor momentum_5d: latest day per security, blank without five earlier days', async () => {
  const outcome = await run({ daily }, [
    { id: 'm', kind: 'operation', op: 'factor', input: 'daily', params: { factor: 'momentum_5d' } },
  ], ['m']);
  assert.equal(outcome.failure, undefined, outcome.failure);
  const rows = outcome.results.get('m')!.rows;
  assert.deepEqual(outcome.results.get('m')!.columns.map((c) => c.name), ['ts_code', 'trade_date', 'momentum_5d']);
  // AAA on 04-09: 16 / 11 - 1. BBB has three days, so no 5-day change.
  assert.equal(rows.length, 2);
  near(rows[0]!.momentum_5d, 16 / 11 - 1);
  assert.equal(rows[1]!.momentum_5d, null);
});

test('factor with as_of and a universe', async () => {
  const outcome = await run({ daily, universe }, [
    { id: 'm', kind: 'operation', op: 'factor', input: 'daily', params: { factor: 'momentum_5d', universe: 'universe', as_of: '2026-04-08' } },
  ], ['m']);
  assert.equal(outcome.failure, undefined, outcome.failure);
  const rows = outcome.results.get('m')!.rows;
  assert.deepEqual(rows.map((r) => r.ts_code), ['AAA']);
  assert.equal(String(rows[0]!.trade_date).slice(0, 10), '2026-04-08');
  near(rows[0]!.momentum_5d, 15 / 10 - 1);
});

test('factor volatility_20d is blank until twenty days exist; earnings_yield skips losses', async () => {
  const outcome = await run({ daily }, [
    { id: 'v', kind: 'operation', op: 'factor', input: 'daily', params: { factor: 'volatility_20d' } },
    { id: 'e', kind: 'operation', op: 'factor', input: 'daily', params: { factor: 'earnings_yield' } },
  ], ['v', 'e']);
  assert.equal(outcome.failure, undefined, outcome.failure);
  assert.ok(outcome.results.get('v')!.rows.every((r) => r.volatility_20d === null));
  const e = outcome.results.get('e')!.rows;
  near(e[0]!.earnings_yield, 0.05);
  assert.equal(e[1]!.earnings_yield, null);
});

test('factor refuses an unsupported name and lists the supported ones', () => {
  const input: OpCompileInput = {
    inputs: ['daily'],
    columns: new Map([['daily', daily.columns.map((c) => ({ name: c.name, type: 'DOUBLE' }))]]),
    params: new Map(),
    scalars: new Map(),
  };
  assert.throws(() => compileFactor({ factor: 'alpha_magic' }, input), (e: unknown) =>
    e instanceof OpCompileError && /not supported/.test(e.message) && (e.hint ?? '').includes('momentum_20d'));
  assert.throws(() => compileFactor({ factor: 'constructor' }, input), OpCompileError);
  assert.throws(() => compileFactor({ factor: 'avg_volume_20d' }, input), /vol/);
  assert.ok(SUPPORTED_FACTORS.length >= 18);
});

// ---------------------------------------------------------------- one test per review finding, 2026-10-14

test('review: regress solves with exactly k + 1 rows', async () => {
  const outcome = await run({ obs: { ...obs, rows: [
    { g: 'P', a: 0, b: 0, y: 1 }, { g: 'P', a: 1, b: 0, y: 3 }, { g: 'P', a: 0, b: 1, y: 4 },
  ] } }, [
    { id: 'fit', kind: 'operation', op: 'regress', input: 'obs', params: { y: 'y', x: ['a', 'b'] } },
  ], ['fit']);
  assert.equal(outcome.failure, undefined, outcome.failure);
  const rows = outcome.results.get('fit')!.rows;
  near(rows[0]!.coefficient, 1); near(rows[1]!.coefficient, 2); near(rows[2]!.coefficient, 3);
});

test('review: regress is not fooled by columns on very different scales', async () => {
  const rows = [[1, 1e7], [1, -1e7], [-1, 1e7], [-1, -1e7]].map(([a, b]) => ({ g: 'P', a, b, y: 2 * a! + 3 * b! }));
  const outcome = await run({ obs: { ...obs, rows } }, [
    { id: 'fit', kind: 'operation', op: 'regress', input: 'obs', params: { y: 'y', x: ['a', 'b'] } },
  ], ['fit']);
  assert.equal(outcome.failure, undefined, outcome.failure);
  const out = outcome.results.get('fit')!.rows;
  // Before the fix both were blank. Rounding on values near 3e7 leaves about 2e-9.
  assert.ok(Math.abs(Number(out[1]!.coefficient) - 2) < 1e-6);
  assert.ok(Math.abs(Number(out[2]!.coefficient) - 3) < 1e-6);
});

test('review: regress refuses a column name the platform uses internally', async () => {
  const outcome = await run({ obs: { columns: [...obs.columns, { name: '__gid', type: 'number' }], rows: obs.rows.map((r) => ({ ...r, __gid: 10 })) } }, [
    { id: 'fit', kind: 'operation', op: 'regress', input: 'obs', params: { y: 'y', x: ['a', 'b'], by: ['__gid'] } },
  ], ['fit']);
  assert.equal(outcome.status, 'failed');
  assert.match(outcome.failure ?? '', /reserved/);
});

test('review: a quoted name in a formula is not a dependency', async () => {
  const outcome = await run({ flows }, [
    { id: 'f', kind: 'operation', op: 'derive', input: 'flows', params: { columns: { label: "'rate'" } } },
    { id: 'rate', kind: 'operation', op: 'irr', input: 'f', params: { amount_col: 'amt', date_col: 'd', max_iter: 100 } },
  ], ['rate']);
  assert.equal(outcome.failure, undefined, outcome.failure);
  near(outcome.results.get('rate')!.rows[0]!.irr, 0.1);
});

test('review: a factor universe may be the input itself', async () => {
  const outcome = await run({ daily }, [
    { id: 'e', kind: 'operation', op: 'factor', input: 'daily', params: { factor: 'earnings_yield', universe: 'daily' } },
  ], ['e']);
  assert.equal(outcome.failure, undefined, outcome.failure);
  assert.equal(outcome.results.get('e')!.rows.length, 2);
});

test('review: an input column called __ret does not change volatility', async () => {
  const dates = Array.from({ length: 21 }, (_, i) => new Date(Date.UTC(2026, 0, 1 + i)).toISOString().slice(0, 10));
  const flat: Slice = {
    columns: [...daily.columns, { name: '__ret', type: 'number' }],
    rows: dates.map((d, i) => ({ ts_code: 'AAA', trade_date: d, close: 100, pe: 10, __ret: i })),
  };
  const outcome = await run({ flat }, [
    { id: 'v', kind: 'operation', op: 'factor', input: 'flat', params: { factor: 'volatility_20d' } },
  ], ['v']);
  assert.equal(outcome.failure, undefined, outcome.failure);
  near(outcome.results.get('v')!.rows[0]!.volatility_20d, 0);
});

test('review: irr finds a near-total loss', async () => {
  const outcome = await run({ flows: { ...flows, rows: [{ d: '2026-01-01', amt: -100 }, { d: '2027-01-01', amt: 0.001 }] } }, [
    { id: 'rate', kind: 'operation', op: 'irr', input: 'flows', params: { amount_col: 'amt', date_col: 'd', max_iter: 100 } },
  ], ['rate']);
  assert.equal(outcome.failure, undefined, outcome.failure);
  assert.ok(Math.abs(Number(outcome.results.get('rate')!.rows[0]!.irr) - -0.99999) < 1e-8);
});
