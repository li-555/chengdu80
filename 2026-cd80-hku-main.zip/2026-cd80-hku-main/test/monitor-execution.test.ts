import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { AppDocument } from '../src/app-schema/index.ts';
import { saveApp, getState, listRuns, setState } from '../src/platform/storage.ts';
import { closeStorage } from '../src/platform/database.ts';
import { runSavedApplication } from '../src/platform/execute.ts';
import { createScheduledTask, configureScheduledTask } from '../src/platform/schedules.ts';
import { getMonitorSnapshot, setMonitorAcknowledged } from '../src/platform/monitor.ts';
import type { InventedDataAdapter } from '../src/platform/execution-data.ts';
const directory = mkdtempSync(join(tmpdir(), 'blocks-monitor-execution-'));
process.env.BLOCKS_DB_PATH = join(directory, 'storage.sqlite');
after(() => { closeStorage(); rmSync(directory, { recursive: true, force: true }); });
function document() {
  return AppDocument.parse({ meta: { name: 'Invented monitored condition', description: 'Invented local monitoring fixture', spec_version: '1.0' }, params: [],
    data: [{ key: 'items', fields: [{ name: 'value', type: 'number', required: true }, { name: 'status', type: 'text', required: true }] }],
    compute: [{ id: 'monitor_events', kind: 'code', input: ['items'], key: true, carry_state: true,
      body: "const item=input.items[0]; return {rows:[{event_id:'FAKE-CONDITION',title:'Invented condition',status:item.status,value:String(item.value),detail:'Invented supplied value '+item.value,source_url:'https://example.invalid/fixture'}],state:{count:(state.count||0)+1}};",
      output: { columns: ['event_id','title','status','value','detail','source_url'].map(name => ({ name, type: 'text' })) } }],
    triggers: [{ kind: 'manual' }, { kind: 'schedule', cron: '0 8 * * *', tz: 'Asia/Shanghai' }],
    ui: { root: 'page', elements: { page: { type: 'Section', children: [] } } } });
}
test('manual and scheduled completions share monitoring, preserve acknowledgement, and completed retries cannot regress it', async () => {
  const app = await saveApp(document(), 'fake-monitor-execution');
  await setState(app.id, app.profile, { carry: { count: 0 }, bindings: { items: 'FAKE-UPLOAD' }, unrelated: 'FAKE-KEEP' });
  let value = 10; let status = 'active'; let fail = false;
  const adapter: InventedDataAdapter = { kind: 'invented', id: 'fake-monitor', label: 'Invented monitoring rows', resolve: async () => {
    if (fail) throw new Error('Invented unavailable input');
    return { slices: { items: { columns: [{ name: 'value', type: 'number' }, { name: 'status', type: 'string' }], rows: [{ value, status }] } }, datasetVersions: { items: 'fake-v1' } };
  } };
  async function run(runId: string, scheduled?: {taskId:string;scheduledFor:string}) {
    const reply = await runSavedApplication({ appId: app.id, profile: app.profile, runId, adapter, allowInventedData: true, ...(scheduled ? {scheduled} : {}) });
    assert.equal(reply.kind, 'completed'); if (reply.kind !== 'completed') throw new Error('No completion'); return reply;
  }
  assert.equal((await run('fake-monitor-first')).record.status, 'ok');
  const baseline = await getMonitorSnapshot(app.id, app.profile);
  assert.equal(baseline.enabled, true); assert.equal(baseline.counts.active, 1); assert.equal(baseline.changes.length, 0);
  const original = baseline.alerts.find(alert => alert.status === 'active')!;
  assert.equal((await setMonitorAcknowledged(app.id, app.profile, { alertId: original.id, acknowledged: true })).kind, 'saved');
  await run('fake-monitor-repeat');
  const repeated = await getMonitorSnapshot(app.id, app.profile);
  assert.equal(repeated.counts.active, 1); assert.equal(repeated.counts.acknowledged, 1); assert.equal(repeated.changes.length, 0);
  value = 20;
  const task = await createScheduledTask(app.id, app.profile, 1); const scheduledFor = '2026-01-01T08:00:00.000Z';
  await configureScheduledTask(task.id, app.profile, { enabled: true, nextRunAt: scheduledFor });
  const scheduled = await run('fake-monitor-scheduled', { taskId: task.id, scheduledFor });
  assert.equal(scheduled.record.status, 'ok');
  const changed = await getMonitorSnapshot(app.id, app.profile);
  assert.equal(changed.lastRunId, 'fake-monitor-scheduled'); assert.equal(changed.counts.unacknowledged, 1);
  assert.ok(changed.changes.some(change => change.kind === 'changed' && change.before === '10' && change.after === '20'));
  assert.notEqual(changed.alerts.find(alert => alert.status === 'active')!.id, original.id);
  assert.equal((await setMonitorAcknowledged(app.id, app.profile, { alertId: original.id, acknowledged: true })).kind, 'conflict');
  assert.equal((await run('fake-monitor-first')).reused, true);
  assert.equal((await getMonitorSnapshot(app.id, app.profile)).lastRunId, 'fake-monitor-scheduled');
  closeStorage(); assert.equal((await getMonitorSnapshot(app.id, app.profile)).counts.active, 1);
  status = 'clear'; value = 0; await run('fake-monitor-clear');
  const cleared = await getMonitorSnapshot(app.id, app.profile);
  assert.equal(cleared.counts.active, 0); assert.ok(cleared.changes.some(change => change.kind === 'cleared'));
  fail = true; assert.equal((await run('fake-monitor-failed')).record.status, 'failed');
  assert.equal((await getMonitorSnapshot(app.id, app.profile)).lastRunId, 'fake-monitor-clear');
  const state = await getState(app.id, app.profile); assert.deepEqual(state.bindings, {items:'FAKE-UPLOAD'}); assert.equal(state.unrelated, 'FAKE-KEEP');
  assert.equal((state.carry as {count:number}).count, 4); assert.equal((await listRuns(app.id)).length, 5);
});
