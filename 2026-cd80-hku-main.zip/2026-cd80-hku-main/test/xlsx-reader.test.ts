import { test } from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';
import { listSheets, readSheet } from '../src/data/xlsx-reader.ts';
import { registerUpload } from '../src/data/file-upload.ts';

const fixture = fileURLToPath(new URL('./fixtures/invented-clients.xlsx', import.meta.url));

const clients = [
  ['client_code', 'name', 'risk', 'joined'],
  ['000001', 'First Invented Ltd', '3', '20260114'],
  ['000002', 'Second Invented Ltd', '5', '20260115'],
  ['000010', '', '1', '20260116'],
];

test('listSheets preserves workbook order', () => {
  assert.deepEqual(listSheets(fixture), ['Clients', 'Notes']);
});

test('readSheet defaults to the first sheet and returns strings', () => {
  assert.deepEqual(readSheet(fixture), { name: 'Clients', rows: clients });
});

test('readSheet selects the second sheet by name', () => {
  assert.deepEqual(readSheet(fixture, 'Notes'), { name: 'Notes', rows: [['only'], ['second sheet']] });
});

test('an empty cell keeps the later columns in place', () => {
  const { rows } = readSheet(fixture, 'Clients');
  assert.equal(rows[3]?.[1], '');
  assert.equal(rows[3]?.[2], '1');
  assert.equal(rows[3]?.[3], '20260116');
  assert.ok(rows.every((row) => row.length === 4));
});

test('a missing sheet name throws', () => {
  assert.throws(() => readSheet(fixture, 'Missing'), /Sheet "Missing" does not exist/);
});

test('registerUpload infers client codes as text and risk as number', async () => {
  const { dataset } = await registerUpload(fixture, 'Invented clients');
  assert.equal(dataset.fields.find((field) => field.name === 'client_code')?.type, 'text');
  assert.equal(readSheet(fixture).rows[1]?.[0], '000001');
  assert.equal(dataset.fields.find((field) => field.name === 'risk')?.type, 'number');
  assert.equal(dataset.rowCount, 3);
});
