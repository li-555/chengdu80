import { flagshipLogicDocument } from './flagship-test-helpers.ts';
import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { validateApplication } from '../src/validate/index.ts';
import { runForScreen, type RunResult } from '../src/compute/result.ts';
import type { Slice } from '../src/compute/run.ts';
import { exportApplication } from '../src/platform/export.ts';
import { saveApp, getState, setState } from '../src/platform/storage.ts';
import { closeStorage } from '../src/platform/database.ts';
import { getListActions, saveListAction } from '../src/platform/list-actions.ts';
import { runSavedApplication } from '../src/platform/execute.ts';
import type { InventedDataAdapter } from '../src/platform/execution-data.ts';
const source = readFileSync(new URL('../examples/wealth-weave.fin.json', import.meta.url), 'utf8');
const validation = validateApplication(flagshipLogicDocument('wealth-weave', JSON.parse(source)));
assert.ok(validation.ok); if (!validation.ok) throw new Error('Invalid WealthWeave document');
const doc = validation.document;
type Fixture = { label: string; requirements: Record<string, { fields: { name: string; type: 'text' | 'number' | 'date' | 'boolean'; nullable?: boolean }[]; rows: Record<string, string | number | boolean | null>[] }> };
const fixture = JSON.parse(readFileSync(new URL('./fixtures/flagship-inputs/wealth-weave.json', import.meta.url), 'utf8')) as Fixture;
function slices(value: Fixture = fixture): Record<string, Slice> { return Object.fromEntries(Object.entries(value.requirements).map(([key, requirement]) => [key, { columns: requirement.fields.map((field) => ({ name: field.name, type: field.type === 'text' ? 'string' : field.type })), rows: requirement.rows }])); }
function rows(result: Pick<RunResult, 'outputs'>, relation: string): Record<string, unknown>[] { const table = result.outputs[relation]!; return table.rows.map((row) => Object.fromEntries(table.schema.map((column, index) => [column.name, row[index]]))); }
async function run(params: Record<string, unknown> = {}, value: Fixture = fixture) { const out = await runForScreen(doc, { slices: slices(value), params }); assert.equal(out.result.status, 'ok', out.result.failure?.message); return out.result; }
const directory = mkdtempSync(join(tmpdir(), 'wealth-weave-test-')); const previousPath = process.env.BLOCKS_DB_PATH;
before(() => { process.env.BLOCKS_DB_PATH = join(directory, 'state.sqlite'); });
after(() => { closeStorage(); if (previousPath === undefined) delete process.env.BLOCKS_DB_PATH; else process.env.BLOCKS_DB_PATH = previousPath; rmSync(directory, { recursive: true, force: true }); });

test('WealthWeave validates and exports a portable definition, with all invented rows separate', async () => {
  assert.equal(doc.compute.filter((step) => step.kind === 'code').length, 1);
  assert.match(fixture.label, /^Invented/);
  const exported = exportApplication(doc); assert.ok(validateApplication(exported).ok);
  for (const value of ['FAKE-C1', 'FAKE-P1', 'FAKE-T1', 'FAKE-DOC-P1']) assert.ok(!exported.includes(value));
  assert.equal(doc.data.length, 3);
  const result = await run(); assert.equal(rows(result, 'suitability').length, 60);
  const eligible = rows(result, 'ranked_products'); assert.equal(eligible.length, 2);
  assert.ok(eligible.every((row) => row.client_id === 'FAKE-C1' && row.hard_pass === true));
  assert.equal(eligible.find((row) => row.product_id === 'FAKE-P1')!.status, 'eligible');
  assert.equal(eligible.find((row) => row.product_id === 'FAKE-P3')!.status, 'review_required');
});
test('each mandatory missing-input class blocks ranking without a false score', async () => {
  const variants: [string, 'clients' | 'products', string][] = [
    ['S01', 'clients', 'assessment_valid'], ['S02', 'clients', 'consent_recorded'], ['S03', 'clients', 'risk_grade'],
    ['S04', 'clients', 'horizon_months'], ['S05', 'clients', 'liquidity_need'], ['S06', 'products', 'qualified_only'],
    ['S07', 'products', 'approved'], ['S08', 'clients', 'investable_amount'],
  ];
  for (const [rule, requirement, field] of variants) {
    const value = structuredClone(fixture); value.requirements[requirement]!.rows[0]![field] = null;
    const result = await run({ selected_client: 'FAKE-C1', selected_product: 'FAKE-P1' }, value);
    const check = rows(result, 'suitability').find((row) => row.rule_id === rule)!;
    assert.equal(check.rule_status, 'unknown', rule); assert.equal(check.status, 'blocked', rule); assert.equal(check.score, null, rule);
    assert.equal(rows(result, 'ranked_products').length, 0, rule);
  }
});
test('explicit hard failure and missing review evidence never turn into an approved product', async () => {
  const missing = structuredClone(fixture); missing.requirements.clients!.rows[0]!.issuer_exposure_value = null;
  const result = await run({ selected_client: 'FAKE-C1', selected_product: 'FAKE-P1', reviewed_case_ids: ['FAKE-C1:FAKE-P1'] }, missing);
  const checks = rows(result, 'suitability'); assert.equal(checks.find((row) => row.rule_id === 'S09')!.rule_status, 'unknown');
  assert.equal(checks[0]!.status, 'review_required'); assert.match(String(checks[0]!.local_review_note), /not institutional approval/);
  const failed = structuredClone(fixture); failed.requirements.products!.rows[0]!.approved = false;
  const blocked = await run({ selected_client: 'FAKE-C1', selected_product: 'FAKE-P1' }, failed);
  assert.equal(rows(blocked, 'suitability').find((row) => row.rule_id === 'S07')!.rule_status, 'block');
  assert.match(String(rows(blocked, 'pair_summary')[0]!.service_note), /evidence unavailable/);
});
test('stage requests are effective only with evidence and never manufacture institutional approval or a sale', async () => {
  const result = await run({ requested_stage_ids: ['FAKE-O1', 'FAKE-O2', 'FAKE-O3'] });
  const work = rows(result, 'ordered_work');
  assert.equal(work.find((row) => row.record_id === 'FAKE-O1')!.effective_stage, 'proposal');
  assert.equal(work.find((row) => row.record_id === 'FAKE-O2')!.effective_stage, 'assessment');
  assert.match(String(work.find((row) => row.record_id === 'FAKE-O2')!.request_status), /Blocked/);
  assert.equal(work.find((row) => row.record_id === 'FAKE-O3')!.effective_stage, 'review_requested');
  assert.ok(work.every((row) => row.institutional_approval === 'No institutional approval recorded'));
  const drafts = rows(result, 'pair_summary'); assert.match(String(drafts.find((row) => row.product_id === 'FAKE-P1')!.service_note), /FAKE-DOC-P1 \/ invented-v1 \/ Product terms/);
});
test('a persisted task action survives restart and changes actual saved-run output without editing the source', async () => {
  const app = await saveApp(doc, 'wealth-owner');
  await setState(app.id, app.profile, { carry: { marker: 'FAKE-CARRY' }, bindings: { clients: 'fake-clients' }, params: {} });
  const adapter: InventedDataAdapter = { kind: 'invented', id: 'wealth-fake', label: fixture.label, resolve: async () => ({ slices: slices(), datasetVersions: Object.fromEntries(doc.data.map((requirement) => [requirement.key, 'invented-v1'])) }) };
  const first = await runSavedApplication({ appId: app.id, profile: app.profile, runId: 'wealth-first', adapter, allowInventedData: true });
  assert.equal(first.kind, 'completed'); if (first.kind !== 'completed') throw new Error('No completed run');
  assert.equal(rows(first.record.result!, 'task_summary').find((r) => r.summary_label === 'overdue')!.records, 2);
  assert.equal(rows(first.record.result!, 'ordered_work').find((row) => row.record_id === 'FAKE-T1')!.task_status, 'outstanding');
  const snapshot = await getListActions(app.id, app.profile);
  const saved = await saveListAction(app.id, app.profile, { param: 'completed_task_ids', recordId: 'FAKE-T1', action: 'add', note: 'Invented follow-up completed locally', requestId: 'wealth-completion', revision: snapshot.revision });
  assert.equal(saved.kind, 'saved'); closeStorage();
  const reopened = await getListActions(app.id, app.profile); assert.deepEqual(reopened.params.find((param) => param.key === 'completed_task_ids')!.values, ['FAKE-T1']); assert.equal(reopened.history.length, 1);
  const later = await runSavedApplication({ appId: app.id, profile: app.profile, runId: 'wealth-later', adapter, allowInventedData: true });
  assert.equal(later.kind, 'completed'); if (later.kind !== 'completed') throw new Error('No completed run');
  assert.equal(rows(later.record.result!, 'task_summary').find((r) => r.summary_label === 'overdue')!.records, 1);
  assert.ok(rows(later.record.result!, 'task_queue').every((r) => r.record_id !== 'FAKE-T1'));
  assert.equal(rows(later.record.result!, 'ordered_work').find((row) => row.record_id === 'FAKE-T1')!.task_status, 'completed_local');
  assert.deepEqual((await getState(app.id, app.profile)).carry, { marker: 'FAKE-CARRY' });
  assert.equal(fixture.requirements.activities!.rows[0]!.stage, 'follow_up');
});

test('dated follow-ups sort by urgency, date and priority and exclude local completions', async () => {
  const result = await run({ selected_client: 'FAKE-C1', as_of: '2026-10-15' });
  const queue = rows(result, 'task_queue');
  assert.deepEqual(queue.map((r) => [r.record_id, r.due_status]), [['FAKE-T1', 'overdue'], ['FAKE-T2', 'due_today'], ['FAKE-T3', 'upcoming']]);
  assert.deepEqual(rows(result, 'task_summary').map((r) => [r.summary_label, r.records]), [['overdue', 1], ['due_today', 1], ['upcoming', 1], ['unknown', 0]]);
  const completed = await run({ selected_client: 'FAKE-C1', as_of: '2026-10-15', completed_task_ids: ['FAKE-T1'] });
  assert.equal(rows(completed, 'task_summary').find((r) => r.summary_label === 'overdue')!.records, 0);
  assert.equal(rows(completed, 'task_queue').length, 2);
  assert.equal(rows(completed, 'ordered_work').find((r) => r.record_id === 'FAKE-T1')!.task_status, 'completed_local');
  const later = await run({ selected_client: 'FAKE-C1', as_of: '2026-10-21' });
  assert.equal(rows(later, 'task_summary').find((r) => r.summary_label === 'overdue')!.records, 3);
  const value = structuredClone(fixture);
  const activities = value.requirements.activities!.rows;
  const overdue = activities.find((r) => r.record_id === 'FAKE-T1')!;
  activities.push({ ...overdue, record_id: 'FAKE-T5', due_date: '2026-10-12', priority: 1 }, { ...overdue, record_id: 'FAKE-T6', priority: 99 });
  assert.deepEqual(rows(await run({ selected_client: 'FAKE-C1' }, value), 'task_queue').map((r) => r.record_id), ['FAKE-T5', 'FAKE-T6', 'FAKE-T1', 'FAKE-T2', 'FAKE-T3']);
});

test('missing, invalid and impossible task dates stay unknown without fabricating a due date', async () => {
  for (const due of [null, '', 'not-a-date', '2026-02-30', '2026-13-01']) {
    const value = structuredClone(fixture); value.requirements.activities!.rows[0]!.due_date = due;
    const execution = await runForScreen(doc, { slices: slices(value), params: { selected_client: 'FAKE-C1', as_of: '2026-10-15' } });
    const result = execution.result;
    assert.ok(result.status === 'ok' || result.status === 'partial', result.failure?.message);
    const task = rows(result, 'task_queue').find((r) => r.record_id === 'FAKE-T1')!;
    assert.equal(task.due_status, 'unknown', String(due)); assert.equal(task.due_date, null);
    assert.equal(rows(result, 'task_summary').find((r) => r.summary_label === 'unknown')!.records, 1);
  }
  const invalid = await run({ selected_client: 'FAKE-C1', as_of: '2026-02-30' });
  assert.ok(rows(invalid, 'task_queue').every((r) => r.due_status === 'unknown'));
  assert.ok(rows(invalid, 'task_summary').every((r) => r.as_of_date === null));
  assert.equal(rows(invalid, 'task_summary').find((r) => r.summary_label === 'overdue')!.records, 0);
});

test('client snapshots preserve false and zero, show required gaps and scope to known or unknown selections', async () => {
  const value = structuredClone(fixture); const c = value.requirements.clients!.rows[0]!;
  c.assessment_valid = false; c.consent_recorded = false; c.qualified = false;
  for (const field of ['horizon_months', 'investable_amount', 'portfolio_value', 'issuer_exposure_value']) c[field] = 0;
  const known = rows(await run({ selected_client: 'FAKE-C1' }, value), 'client_overview');
  assert.equal(known.length, 1); assert.equal(known[0]!.missing_field_count, 0);
  assert.equal(known[0]!.assessment_status, 'recorded_false'); assert.equal(known[0]!.consent_status, 'recorded_false'); assert.equal(known[0]!.qualified_status, 'recorded_false');
  for (const field of ['horizon_months', 'investable_amount', 'portfolio_value', 'issuer_exposure_value']) assert.equal(known[0]![field], 0);
  c.investable_amount = null; c.objective = ''; c.assessment_valid = null;
  const missing = rows(await run({ selected_client: 'FAKE-C1' }, value), 'client_overview')[0]!;
  assert.equal(missing.investable_amount, null); assert.equal(missing.assessment_status, 'unknown'); assert.equal(missing.missing_field_count, 3);
  assert.equal(missing.missing_fields, 'assessment_valid, investable_amount, objective');
  const second = await run({ selected_client: 'FAKE-C2' });
  assert.deepEqual(rows(second, 'task_queue').map((r) => r.record_id), ['FAKE-T4']);
  assert.deepEqual(rows(second, 'client_overview').map((r) => r.client_id), ['FAKE-C2']);
  assert.equal(rows(second, 'client_overview')[0]!.missing_fields, 'consent_recorded, qualified');
  assert.equal(rows(await run(), 'client_overview').length, 2);
  const unknown = await run({ selected_client: 'UNKNOWN-CLIENT' });
  assert.equal(rows(unknown, 'client_overview')[0]!.client_record_status, 'unknown_client');
  assert.equal(rows(unknown, 'client_overview')[0]!.missing_field_count, null);
  assert.equal(rows(unknown, 'task_queue').length, 0);
  assert.ok(rows(unknown, 'task_summary').every((r) => r.records === 0));
});

test('pipeline stage counts reflect a single effective snapshot and evidence-guarded requests', async () => {
  const initial = rows(await run({ selected_client: 'FAKE-C1' }), 'pipeline_summary');
  assert.equal(initial.find((r) => r.summary_label === 'assessment')!.records, 2);
  assert.equal(initial.find((r) => r.summary_label === 'proposal')!.records, 1);
  const requested = rows(await run({ selected_client: 'FAKE-C1', requested_stage_ids: ['FAKE-O1', 'FAKE-O2', 'FAKE-O3'] }), 'pipeline_summary');
  assert.equal(requested.find((r) => r.summary_label === 'assessment')!.records, 1);
  assert.equal(requested.find((r) => r.summary_label === 'proposal')!.records, 1);
  assert.equal(requested.find((r) => r.summary_label === 'review_requested')!.records, 1);
  assert.equal(requested.reduce((n, r) => n + Number(r.records), 0), 3);
  assert.ok(rows(await run({ selected_client: 'FAKE-C2' }), 'pipeline_summary').every((r) => r.records === 0));
});

test('record choices remain available after selection and local actions retain completed tasks', async () => {
  const result = await run({ selected_client: 'FAKE-C1', selected_product: 'FAKE-P1', completed_task_ids: ['FAKE-T1'] });
  for (const [relation, requirement, key] of [['pick_selected_client', 'clients', 'client_id'], ['pick_selected_product', 'products', 'product_id']] as const) {
    const choices = rows(result, relation);
    assert.deepEqual(choices.map((r) => r.value), ['', ...fixture.requirements[requirement]!.rows.map((r) => r[key])]);
    assert.equal(choices[0]!.label, requirement === 'clients' ? 'All clients' : 'All products');
    assert.ok(choices.every((r) => String(r.label).includes(String(r.value))));
  }
  const tasks = rows(result, 'act_completed_task_ids');
  assert.deepEqual(tasks.map((r) => r.record_id), ['FAKE-T1', 'FAKE-T2', 'FAKE-T3']);
  assert.ok(tasks.every((r) => r.add_label === 'Complete task' && r.remove_label === 'Reopen task'));
  assert.equal(tasks[0]!.detail, 'Due 2026-10-14');
  assert.ok(String(tasks[0]!.label).includes('FAKE-T1'));
  const reviews = rows(result, 'act_reviewed_case_ids');
  assert.deepEqual(reviews.map((r) => r.record_id), ['FAKE-C1:FAKE-P1']);
  assert.equal(reviews[0]!.add_label, 'Note review'); assert.equal(reviews[0]!.remove_label, 'Reopen review');
  assert.match(String(reviews[0]!.detail), /not institutional approval/);
  const unknown = await run({ selected_client: 'UNKNOWN-CLIENT', selected_product: 'UNKNOWN-PRODUCT' });
  assert.equal(rows(unknown, 'act_completed_task_ids').length, 0);
  assert.equal(rows(unknown, 'act_reviewed_case_ids').length, 0);
  assert.equal(rows(unknown, 'pick_selected_client').length, 3);
});

test('choices and action IDs exclude invalid records, deduplicate and reject ambiguous task ownership', async () => {
  const value = structuredClone(fixture);
  const clients = value.requirements.clients!.rows; const products = value.requirements.products!.rows; const activities = value.requirements.activities!.rows;
  clients.push({ ...clients[0]! }, { ...clients[0]!, client_id: '' }, { ...clients[0]!, client_id: null });
  products.push({ ...products[0]! }, { ...products[0]!, product_id: ' ' });
  activities.push({ ...activities[0]! }, { ...activities[0]!, record_id: '' }, { ...activities[0]!, record_id: null });
  const execution = await runForScreen(doc, { slices: slices(value), params: { selected_client: 'FAKE-C1', selected_product: 'FAKE-P1' } });
  assert.ok(execution.result.status === 'ok' || execution.result.status === 'partial');
  const result = execution.result;
  for (const relation of ['pick_selected_client', 'pick_selected_product']) {
    const choices = rows(result, relation);
    assert.equal(choices[0]!.value, '');
    assert.ok(choices.slice(1).every((r) => typeof r.value === 'string' && r.value.trim().length > 0));
    assert.equal(choices.length, new Set(choices.map((r) => r.value)).size);
  }
  const tasks = rows(result, 'act_completed_task_ids');
  assert.deepEqual(tasks.map((r) => r.record_id), ['FAKE-T1', 'FAKE-T2', 'FAKE-T3']);
  assert.deepEqual(rows(result, 'act_reviewed_case_ids').map((r) => r.record_id), ['FAKE-C1:FAKE-P1']);
  activities.push({ ...activities[0]!, client_id: 'FAKE-C2' });
  const ambiguous = await runForScreen(doc, { slices: slices(value), params: { selected_client: 'FAKE-C1' } });
  assert.ok(rows(ambiguous.result, 'act_completed_task_ids').every((r) => r.record_id !== 'FAKE-T1'));
  const all = await runForScreen(doc, { slices: slices(value), params: {} });
  assert.ok(rows(all.result, 'act_reviewed_case_ids').every((r) => !String(r.record_id).startsWith(':') && !String(r.record_id).endsWith(': ') && !String(r.record_id).startsWith('null:')));
});
test('monitor overdue task identity persists through completion and missing dates stay unknown', async () => {
 const original=await run();assert.deepEqual(original.outputs.monitor_events!.schema.map(c=>[c.name,c.type]),['event_id','title','status','value','detail','source_url'].map(n=>[n,'text']));const events=rows(original,'monitor_events');const active=events.find(r=>r.status==='active'&&String(r.event_id).includes('followup'))!;assert(active);
 const id=JSON.parse(String(active.event_id))[2];
 const completed=rows(await run({completed_task_ids:[id]}),'monitor_events').find(r=>r.event_id===active.event_id)!;assert.equal(completed.status,'clear');
 const missing=structuredClone(fixture);missing.requirements.activities!.rows.find(r=>r.record_id===id)!.due_date=null;
 assert.equal(rows(await run({},missing),'monitor_events').find(r=>r.event_id===active.event_id)!.status,'unknown');
 const empty=structuredClone(fixture);for(const t of Object.values(empty.requirements))t.rows=[];
 assert.equal(rows(await run({},empty),'monitor_events').find(r=>r.event_id==='coverage')!.status,'unknown');
 for(const r of events)for(const k of ['event_id','title','status','value','detail','source_url'])assert.equal(typeof r[k],'string');
 assert.equal(rows(original,'ordered_work').length,fixture.requirements.activities!.rows.length);
});

test('descriptive segments and lifecycle counts scope to client selection and preserve false flags', async () => {
 const all = await run();
 const segments = rows(all,'client_segments');
 assert.deepEqual(segments.map(r => r.segment_label),['income | Risk grade 3','capital_preservation | Risk grades 1-2']);
 assert.equal(segments[0]!.record_flags,'Required records recorded');
 assert.equal(segments[0]!.qualified_status,'recorded_false');
 assert.equal(segments[1]!.record_flags,'Missing required records');
 assert.equal(rows(all,'segment_summary').reduce((n,r)=>n+Number(r.records),0),2);
 const life = rows(all,'client_lifecycle');
 assert.equal(life.find(r=>r.client_id==='FAKE-C1'&&r.lifecycle_kind==='assessment_expiry')!.lifecycle_status,'due_within');
 assert.equal(life.find(r=>r.client_id==='FAKE-C1'&&r.lifecycle_kind==='review_refresh')!.lifecycle_status,'overdue');
 assert.ok(life.filter(r=>r.client_id==='FAKE-C2').every(r=>r.lifecycle_status==='unknown'&&r.supplied_date==='Unknown'));
 const selected = await run({selected_client:'FAKE-C2',selected_product:'FAKE-P1'});
 assert.equal(rows(selected,'client_segments').length,1); assert.equal(rows(selected,'client_lifecycle').length,2);
 assert.equal(rows(selected,'segment_summary').reduce((n,r)=>n+Number(r.records),0),1);
 const unknown = await run({selected_client:'UNKNOWN'});
 assert.equal(rows(unknown,'client_lifecycle').length,0);
 assert.ok(rows(unknown,'lifecycle_summary').every(r=>r.records===0));
});

test('lifecycle strict calendar dates, leap days and inclusive reminder boundaries use selected As of', async () => {
 const value = structuredClone(fixture); const c=value.requirements.clients!.rows[0]!;
 for(const [expiry,expected] of [['2024-02-28','overdue'],['2024-02-29','due_within'],['2024-03-30','due_within'],['2024-03-31','up_to_date'],['2023-02-29','unknown'],['2024-02-30','unknown'],['2024-2-29','unknown']] as const){
  c.assessment_expires_on=expiry;
  const result=await run({selected_client:'FAKE-C1',as_of:'2024-02-29'},value);
  assert.equal(rows(result,'client_lifecycle').find(r=>r.lifecycle_kind==='assessment_expiry')!.lifecycle_status,expected,expiry);
 }
 c.assessment_expires_on='2024-02-29'; c.last_reviewed_on='2024-02-28';
 const zero=await run({selected_client:'FAKE-C1',as_of:'2024-02-29',reminder_days:0,stale_after_days:1},value);
 assert.ok(rows(zero,'client_lifecycle').every(r=>r.lifecycle_status==='due_within'&&r.days_remaining===0));
 const later=await run({selected_client:'FAKE-C1',as_of:'2024-03-01',reminder_days:0,stale_after_days:1},value);
 assert.ok(rows(later,'client_lifecycle').every(r=>r.lifecycle_status==='overdue'));
 c.last_reviewed_on='2024-03-01';
 assert.equal(rows(await run({selected_client:'FAKE-C1',as_of:'2024-02-29'},value),'client_lifecycle').find(r=>r.lifecycle_kind==='review_refresh')!.lifecycle_status,'unknown');
 assert.ok(rows(await run({selected_client:'FAKE-C1',as_of:'2024-02-30'},value),'client_lifecycle').every(r=>r.lifecycle_status==='unknown'));
});

test('optional missing lifecycle fields keep legacy flag eligibility with explicit Unknown; expired or invalid supplied expiry blocks', async () => {
 const value=structuredClone(fixture); const c=value.requirements.clients!.rows[0]!;
 value.requirements.clients!.fields=value.requirements.clients!.fields.filter(f=>!['assessment_expires_on','last_reviewed_on'].includes(f.name));
 for(const client of value.requirements.clients!.rows){delete client.assessment_expires_on;delete client.last_reviewed_on;}
 const legacy=await run({selected_client:'FAKE-C1',selected_product:'FAKE-P1'},value);
 assert.equal(rows(legacy,'ranked_products').length,1);
 assert.match(String(rows(legacy,'suitability').find(r=>r.rule_id==='S01')!.reason),/Unknown.*freshness not established/);
 assert.ok(rows(legacy,'client_lifecycle').every(r=>r.lifecycle_status==='unknown'));
 value.requirements.clients!.fields.push({name:'assessment_expires_on',type:'text',nullable:true});
 for(const [date,status] of [['2026-10-14','block'],['2026-02-30','unknown'],['bad','unknown']] as const){
  c.assessment_expires_on=date;
  const result=await run({selected_client:'FAKE-C1',selected_product:'FAKE-P1',completed_task_ids:['FAKE-T1'],reviewed_case_ids:['FAKE-C1:FAKE-P1']},value);
  assert.equal(rows(result,'suitability').find(r=>r.rule_id==='S01')!.rule_status,status);
  assert.equal(rows(result,'ranked_products').length,0);
 }
 c.assessment_expires_on='2026-11-14';c.assessment_valid=false;
 assert.equal(rows(await run({selected_client:'FAKE-C1',selected_product:'FAKE-P1'},value),'suitability').find(r=>r.rule_id==='S01')!.rule_status,'block');
});

test('lifecycle monitors have stable identity and exactly six text columns; completion cannot clear expiry', async () => {
 const value=structuredClone(fixture);value.requirements.clients!.rows[0]!.assessment_expires_on='2026-10-14';
 const original=await run({selected_client:'FAKE-C1'},value);
 assert.deepEqual(original.outputs.monitor_events!.schema.map(c=>[c.name,c.type]),['event_id','title','status','value','detail','source_url'].map(n=>[n,'text']));
 const expiry=rows(original,'monitor_events').find(r=>r.event_id===JSON.stringify(['client_lifecycle','FAKE-C1','assessment_expiry']))!;
 assert.equal(expiry.status,'active');
 const completed=rows(await run({selected_client:'FAKE-C1',completed_task_ids:['FAKE-T1','FAKE-T2','FAKE-T3']},value),'monitor_events');
 assert.equal(completed.find(r=>r.event_id===expiry.event_id)!.status,'active');
 assert.equal(completed.find(r=>r.event_id===JSON.stringify(['client_evidence','FAKE-C1','assessment_valid']))!.status,'active');
 value.requirements.clients!.rows[0]!.assessment_expires_on=null;
 assert.equal(rows(await run({selected_client:'FAKE-C1'},value),'monitor_events').find(r=>r.event_id===expiry.event_id)!.status,'unknown');
 value.requirements.clients!.rows[0]!.assessment_expires_on='2026-12-01';
 assert.equal(rows(await run({selected_client:'FAKE-C1'},value),'monitor_events').find(r=>r.event_id===expiry.event_id)!.status,'clear');
});

test('invalid lifecycle settings and review dates stay Unknown without a fabricated deadline', async () => {
 const value=structuredClone(fixture);const c=value.requirements.clients!.rows[0]!;
 for(const date of [null,'','bad','2026-02-30','2026-10-16']){
  c.last_reviewed_on=date;
  const row=rows(await run({selected_client:'FAKE-C1'},value),'client_lifecycle').find(r=>r.lifecycle_kind==='review_refresh')!;
  assert.equal(row.lifecycle_status,'unknown',String(date));assert.equal(row.days_remaining,null);
 }
 for(const setting of [-1,366,1.5]){
  const result=await run({selected_client:'FAKE-C1',reminder_days:setting},value);
  assert.ok(rows(result,'client_lifecycle').every(r=>r.lifecycle_status==='unknown'));
 }
 c.last_reviewed_on='2026-10-15';
 const max=rows(await run({selected_client:'FAKE-C1',reminder_days:365,stale_after_days:365},value),'client_lifecycle').find(r=>r.lifecycle_kind==='review_refresh')!;
 assert.equal(max.days_remaining,365);assert.equal(max.lifecycle_status,'due_within');
 const fractional=rows(await run({selected_client:'FAKE-C1',stale_after_days:0.5},value),'client_lifecycle').find(r=>r.lifecycle_kind==='review_refresh')!;
 assert.equal(fractional.lifecycle_status,'unknown');
});
