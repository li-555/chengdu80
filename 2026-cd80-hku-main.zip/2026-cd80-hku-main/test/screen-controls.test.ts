import { getLanguage, setLanguage } from '../web/src/i18n.ts';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ScreenControls, parseControlValue, renderScreenControl } from '../web/src/screen-controls.ts';
import { renderScreen, refreshScreenResults } from '../web/src/screen-elements.ts';
import type { UiSpec } from '../web/src/app-types.ts';
import type { ParamDecl } from '../web/src/app-types.ts';

// All parameter declarations and values below are invented fixtures.
const params: ParamDecl[] = [
  { key: 'amount', label: 'Invented amount', type: 'number', min: 1, max: 5, step: 0.5 },
  { key: 'choice', label: 'Invented choice', type: 'text', options: [{ value: 'a', label: 'Option A' }] },
  { key: 'enabled', label: 'Invented toggle', type: 'boolean' },
  { key: 'names', label: 'Invented names', type: 'text', list: true },
  { key: 'start', label: 'Start', type: 'date' }, { key: 'end', label: 'End', type: 'date' },
  { key: 'text', label: 'Invented text', type: 'text' },
];
function fixture() {
  const raw: Record<string, string> = { amount: '2', choice: 'a', enabled: 'false', names: 'FAKE001\nFAKE002', start: '2026-01-01', end: '2026-01-02', text: 'Invented' };
  let editable = true, runnable = true, runs = 0, reports = 0;
  const context = new ScreenControls({ params, getRaw: (key) => raw[key] ?? '', setRaw: (key, value) => { raw[key] = value; }, canEdit: () => editable, canRun: () => runnable, onRun: () => { runs++; }, reportValidity: () => { reports++; return true; } });
  return { raw, context, setEditable: (value: boolean) => { editable = value; }, setRunnable: (value: boolean) => { runnable = value; }, runs: () => runs, reports: () => reports };
}
test('parses every declared parameter type and rejects invalid numeric/choice/date values', () => {
  assert.deepEqual(parseControlValue(params[0]!, '2.5'), { ok: true, value: 2.5 });
  for (const raw of ['', 'Infinity', 'abc', '0', '6', '2.2']) assert.equal(parseControlValue(params[0]!, raw).ok, false);
  assert.deepEqual(parseControlValue(params[1]!, 'a'), { ok: true, value: 'a' }); assert.equal(parseControlValue(params[1]!, 'unknown').ok, false);
  assert.deepEqual(parseControlValue(params[2]!, 'false'), { ok: true, value: false }); assert.equal(parseControlValue(params[2]!, 'invalid').ok, false);
  assert.deepEqual(parseControlValue(params[3]!, ' FAKE001 \n\nFAKE002 '), { ok: true, value: ['FAKE001','FAKE002'] });
  assert.equal(parseControlValue(params[4]!, '2026-02-30').ok, false); assert.equal(parseControlValue(params[4]!, '2026-02-28').ok, true);
  assert.deepEqual(parseControlValue(params[6]!, 'Invented'), { ok: true, value: 'Invented' });
  assert.deepEqual(parseControlValue({ ...params[6]!, default: '' }, ''), { ok: true, value: '' });
  assert.deepEqual(parseControlValue(params[3]!, ''), { ok: true, value: [] });
});
test('duplicate peers and top-form draft synchronize in both directions without changing invalid raw text', () => {
  const fixtureValue = fixture(); const seen = ['', ''];
  for (let i = 0; i < 2; i++) fixtureValue.context.connect('amount', { value: (raw) => { seen[i] = raw; }, disabled: () => {}, error: () => {}, report: () => false });
  fixtureValue.context.update('amount', '3.5'); assert.equal(fixtureValue.raw.amount, '3.5'); assert.deepEqual(seen, ['3.5','3.5']);
  fixtureValue.raw.amount = ''; fixtureValue.context.sync(); assert.deepEqual(seen, ['', '']); assert.equal(fixtureValue.context.run(), false);
  fixtureValue.raw.amount = '4'; fixtureValue.context.sync(); assert.deepEqual(seen, ['4','4']);
});
test('empty text defaults and clearing ordinary text remain runnable', () => {
  const f = fixture(); f.raw.text = ''; assert.equal(f.context.run(), true);
  f.context.update('text', 'Invented search'); assert.equal(f.context.run(), true);
  f.context.update('text', ''); assert.equal(f.raw.text, ''); assert.equal(f.context.run(), true); assert.equal(f.runs(), 3);
});
test('routes run once through existing callback and blocks busy, pending, invalid connection and date ranges', () => {
  const f = fixture(); f.context.range('start','end'); assert.equal(f.context.run(), true); assert.equal(f.runs(),1);
  f.setRunnable(false); assert.equal(f.context.run(), false); assert.equal(f.runs(),1);
  f.setEditable(false); f.context.update('amount','4'); assert.equal(f.raw.amount,'2');
  f.setRunnable(true); f.raw.end = '2025-12-31'; assert.equal(f.context.run(),false); assert.equal(f.runs(),1);
  f.raw.end = '2026-01-02'; f.raw.choice = 'unknown'; assert.equal(f.context.run(),false);
});
class FakeElement extends EventTarget {
  tagName: string; children: FakeElement[] = []; attributes = new Map<string,string>();
  dataset: Record<string,string> = {}; parent: FakeElement | undefined;
  className = ''; textContent = ''; value = ''; type = ''; min = ''; max = ''; step = ''; required = false; disabled = false; placeholder = ''; error = '';
  constructor(tag: string) { super(); this.tagName = tag; }
  append(...children: FakeElement[]) { for (const child of children) { child.parent=this; this.children.push(child); } }
  querySelectorAll() { return this.descendants().filter((child) => child.dataset.elementId !== undefined); }
  replaceWith(next: FakeElement) { const index = this.parent?.children.indexOf(this) ?? -1; if (this.parent && index >= 0) { this.parent.children[index]=next; next.parent=this.parent; this.parent=undefined; } }
  setAttribute(key: string, value: string) { this.attributes.set(key,value); }
  setCustomValidity(error: string) { this.error = error; }
  reportValidity() { return !this.error; }
  descendants(): FakeElement[] { return this.children.flatMap((child) => [child,...child.descendants()]); }
}
class FakeInput extends FakeElement {}
class FakeArea extends FakeElement {}
test('renders all five embedded control types with declared constraints, keyboard-native elements and run wiring', (t) => {
  const previous = new Map(['document','HTMLInputElement','HTMLTextAreaElement'].map((key) => [key,Object.getOwnPropertyDescriptor(globalThis,key)]));
  Object.defineProperty(globalThis,'document',{ configurable:true,value:{ documentElement: { lang: 'en', dataset: {}, style: {} }, querySelectorAll: () => [], createElement: (tag: string) => tag === 'input' ? new FakeInput(tag) : tag === 'textarea' ? new FakeArea(tag) : new FakeElement(tag), createTextNode: (text: string) => { const node = new FakeElement('#text'); node.textContent=text; return node; } } });
  Object.defineProperty(globalThis,'HTMLInputElement',{configurable:true,value:FakeInput}); Object.defineProperty(globalThis,'HTMLTextAreaElement',{configurable:true,value:FakeArea});
  t.after(() => { for (const [key,descriptor] of previous) { if (descriptor) Object.defineProperty(globalThis,key,descriptor); else Reflect.deleteProperty(globalThis,key); } });
  const f = fixture();
  const render = (definition: Record<string,unknown>) => renderScreenControl(definition,f.context) as unknown as FakeElement;
  const number = render({type:'NumberInput',param:'amount',label:'Amount'}).descendants().find((element) => element.tagName === 'input')!;
  assert.deepEqual([number.type,number.min,number.max,number.step],['number','1','5','0.5']); number.value='3'; number.dispatchEvent(new Event('input')); assert.equal(f.raw.amount,'3');
  const choice = render({type:'SelectInput',param:'choice',label:'Choice'}).descendants().find((element) => element.tagName === 'select')!; assert.equal(choice.children[1]!.textContent,'Option A');
  const boolean = render({type:'SelectInput',param:'enabled',label:'Enabled'}).descendants().find((element) => element.tagName === 'select')!; boolean.value='true'; boolean.dispatchEvent(new Event('change')); assert.equal(f.raw.enabled,'true');
  const list = render({type:'TextInput',param:'names',list:true,label:'Names'}).descendants().find((element) => element.tagName === 'textarea')!; list.value='FAKE003'; list.dispatchEvent(new Event('input')); assert.equal(f.raw.names,'FAKE003');
  const text = render({type:'TextInput',param:'text',label:'Text',placeholder:'Invented hint'}).descendants().find((element) => element.tagName === 'input')!; assert.equal(text.placeholder,'Invented hint'); assert.equal(text.required,false); text.value=''; text.dispatchEvent(new Event('input')); assert.equal(f.raw.text,'');
  const dates = render({type:'DateRangeInput',fromParam:'start',toParam:'end',label:'Dates'}).descendants().filter((element) => element.tagName === 'input'); assert.equal(dates.length,2); assert(dates.every((date) => date.type === 'date'));
  const ui = { root: 'root', elements: { root: { type: 'Section', children: ['amount-control','run-control','metric'] }, 'amount-control': { type: 'NumberInput', param: 'amount', label: 'Amount' }, 'run-control': { type: 'RunButton', label: 'Run' }, metric: { type: 'Metric', from: 'invented-total', value: 'value', label: 'Invented total' } } } as UiSpec;
  const initial = new Map([['invented-total', { columns: [{ name: 'value', type: 'number' }], rows: [{ value: 2 }] }]]);
  const screen = renderScreen(ui, initial, f.context) as unknown as FakeElement;
  const oldNodes = screen.querySelectorAll(); const section = oldNodes.find((node) => node.dataset.elementId === 'root')!; const control = oldNodes.find((node) => node.dataset.elementId === 'amount-control')!; const oldMetric = oldNodes.find((node) => node.dataset.elementId === 'metric')!;
  refreshScreenResults(screen as unknown as HTMLElement, ui, new Map([['invented-total', { columns: [{ name: 'value', type: 'number' }], rows: [{ value: 4 }] }]]));
  assert(screen.querySelectorAll().includes(section)); assert(screen.querySelectorAll().includes(control)); assert(!screen.querySelectorAll().includes(oldMetric));
  const button = render({type:'RunButton',label:'Run'}).descendants().find((element) => element.tagName === 'button')!; assert.equal(button.type,'button'); button.dispatchEvent(new Event('click')); assert.equal(f.runs(),1);
  f.setRunnable(false); f.setEditable(false); f.context.sync(); assert.equal(button.disabled,true); assert.equal(number.disabled,true); button.dispatchEvent(new Event('click')); assert.equal(f.runs(),1);
  const language = getLanguage(); setLanguage('zh');
  try {
    const textScreen = renderScreen({ root: 'text', elements: { text: { type: 'Text', text: 'Invented unchanged text' } } } as UiSpec, new Map()) as unknown as FakeElement;
    assert.equal(textScreen.children[0]!.textContent, 'Invented unchanged text');
    const chartScreen = renderScreen({ root: 'chart', elements: { chart: { type: 'Chart', kind: 'line', from: 'invented-total', x: 'date', y: ['value'] } } } as UiSpec, new Map()) as unknown as FakeElement;
    assert.equal(chartScreen.children[0]!.className, 'screen-panel screen-chart');
    assert.notEqual(parseControlValue(params[0]!, '').ok ? '' : (parseControlValue(params[0]!, '') as { message: string }).message, 'Enter a finite number.');
  } finally { setLanguage(language); }
});
