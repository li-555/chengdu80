import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createTabs, filterApps } from '../web/src/workspace-ui.ts';
import type { AppSummary } from '../web/src/app-types.ts';

const apps: AppSummary[] = [
  { id: 'a', name: 'Alpha', description: 'Invented revenue report', createdAt: '2026-01-01', updatedAt: '2026-01-05' },
  { id: 'b', name: 'Beta', description: 'Invented balance report', createdAt: '2026-01-03', updatedAt: '2026-01-04' },
  { id: 'c', name: '虚构报告', description: '示例描述', createdAt: '2026-01-02', updatedAt: '2026-01-06' },
];
test('library search combines name and description, handles Chinese and leaves source order intact', () => {
  const original = structuredClone(apps);
  assert.deepEqual(filterApps(apps, '  REVENUE ', 'updated', 'en').map((app) => app.id), ['a']);
  assert.deepEqual(filterApps(apps, '示例', 'name', 'zh-CN').map((app) => app.id), ['c']);
  assert.deepEqual(filterApps(apps, 'missing', 'updated', 'en'), []);
  assert.deepEqual(filterApps(apps, '', 'updated', 'en').map((app) => app.id), ['c', 'a', 'b']);
  assert.deepEqual(filterApps(apps, '', 'created', 'en').map((app) => app.id), ['b', 'c', 'a']);
  assert.deepEqual(apps, original);
});

// Detached DOM contract: no rendering engine or browser acceptance is implied.
class Element extends EventTarget {
  children: Element[] = [];
  attributes = new Map<string, string>();
  hidden = false;
  tabIndex = -1;
  id = '';
  className = '';
  type = '';
  textContent = '';
  append(...items: Element[]) { this.children.push(...items); }
  setAttribute(name: string, value: string) { this.attributes.set(name, value); }
  focus() { documentStub.activeElement = this; }
}
const documentStub = { createElement: () => new Element(), activeElement: null as Element | null };
test('workspace tabs preserve panel nodes and user state while supporting keyboard selection', () => {
  const original = Object.getOwnPropertyDescriptor(globalThis, 'document');
  Object.defineProperty(globalThis, 'document', { configurable: true, value: documentStub });
  try {
    const one = new Element(); const two = new Element(); const draft = new Element(); draft.textContent = 'unsaved input'; one.append(draft);
    let activated = 0;
    const tabs = createTabs('example', 'Views', [
      { id: 'one', label: 'One', panel: one as unknown as HTMLElement },
      { id: 'two', label: 'Two', panel: two as unknown as HTMLElement, activate: () => activated++ },
    ]);
    const root = tabs.root as unknown as Element; const list = root.children[0]!;
    assert.equal(activated, 0, 'hidden panels do not fetch during construction');
    tabs.select('two', true);
    assert.equal(one.hidden, true); assert.equal(two.hidden, false);
    assert.equal(list.children[1]!.attributes.get('aria-selected'), 'true');
    assert.equal(list.children[1]!.tabIndex, 0); assert.equal(list.children[0]!.tabIndex, -1);
    assert.equal(documentStub.activeElement, list.children[1]);
    const key = new Event('keydown', { cancelable: true }); Object.defineProperty(key, 'key', { value: 'ArrowRight' }); list.dispatchEvent(key);
    assert.equal(key.defaultPrevented, true); assert.equal(one.hidden, false); assert.equal(two.hidden, true);
    assert.equal(one.children[0], draft); assert.equal(draft.textContent, 'unsaved input');
    assert.equal(root.children[1], one); assert.equal(root.children[2], two);
    assert.equal(one.attributes.get('aria-labelledby'), list.children[0]!.id);
    tabs.select('missing'); assert.equal(one.hidden, false);
  } finally {
    if (original) Object.defineProperty(globalThis, 'document', original); else Reflect.deleteProperty(globalThis, 'document');
  }
});
