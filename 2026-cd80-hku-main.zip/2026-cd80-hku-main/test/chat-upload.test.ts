import { test } from 'node:test';
import assert from 'node:assert/strict';
import { selectTable, chatPayload, uploadMetadata, type Upload } from '../web/src/chat-upload.ts';
import { describeUpload } from '../src/platform/upload-preview.ts';
import type { Dataset } from '../src/data/types.ts';

const file = (index: number): Upload => ({ id: `user:invented-${index}`, name: `Invented table ${index}`, fields: [{ name: 'amount', type: 'number' }], rowCount: 12 });
test('six worksheet choices respect the five-table message limit and can be deselected', () => {
  let selected: Upload[] = [];
  for (let index = 0; index < 5; index++) selected = selectTable(selected, file(index), true);
  assert.throws(() => selectTable(selected, file(5), true), /5 tables/);
  selected = selectTable(selected, file(2), false);
  selected = selectTable(selected, file(5), true);
  assert.deepEqual(chatPayload('Invented request', 'conversation', selected), {
    message: 'Invented request', conversationId: 'conversation', uploads: ['user:invented-0', 'user:invented-1', 'user:invented-3', 'user:invented-4', 'user:invented-5'],
  });
  assert.equal(selectTable(selected, file(5), true).length, 5);
  assert.throws(() => chatPayload('request', undefined, Array.from({ length: 6 }, (_, i) => file(i))), /5 tables/);
});
test('preview values and statistics cannot enter session metadata or chat payload', () => {
  const withPrivateValues = { ...file(1), preview: { rows: [['PRIVATE-CELL']] }, analysis: { stats: { sum: 987654321 } } };
  assert.deepEqual(uploadMetadata(withPrivateValues), file(1));
  assert.deepEqual(chatPayload('Build', undefined, [withPrivateValues]), { message: 'Build', uploads: [file(1).id] });
});
test('file and worksheet grouping retains only safe metadata and still sends dataset IDs', () => {
  const sheet = { ...file(2), sourceFile: 'invented.xlsx', sheetName: 'Sheet A', preview: { rows: [['PRIVATE-CELL']] } };
  const metadata = uploadMetadata(sheet);
  assert.equal(metadata.sourceFile, 'invented.xlsx');
  assert.equal(metadata.sheetName, 'Sheet A');
  assert.equal('preview' in metadata, false);
  assert.deepEqual(chatPayload('Build', undefined, [metadata]), { message: 'Build', uploads: [file(2).id] });
});
test('unrepresentable statistics retain a usable preview and explicit unavailable analysis', () => {
  const dataset: Dataset = { ...file(0), source: 'upload', fields: [{ name: 'amount', label: 'Amount', type: 'number', nullable: false }], rowCount: 2 };
  const details = describeUpload(dataset, [['1e308'], ['1e308']]);
  assert.equal(details.analysis, null);
  assert.equal(details.analysisWarning, 'ANALYSIS_UNAVAILABLE');
  assert.deepEqual(details.preview.rows, [['1e308'], ['1e308']]);
});

test('Markdown preparation separates prose and tables, preserving message and size limits', async () => {
  const { prepareChatUploads, appendDescription } = await import('../web/src/chat-upload.ts');
  const mixed = new File(['# Invented request\n\nSummarise this.\n\ncode | value\n--- | ---\nPRIVATE-ROW | 123'], 'invented.MD');
  const prepared = await prepareChatUploads([mixed, new File(['Add a chart.'], 'prose.md')], 'Keep my input.');
  assert.deepEqual(prepared.map(({ description, hasTables }) => ({ description, hasTables })), [
    { description: '# Invented request\n\nSummarise this.', hasTables: true }, { description: 'Add a chart.', hasTables: false },
  ]);
  const message = prepared.reduce((input, item) => appendDescription(input, item.description), 'Keep my input.');
  assert.doesNotMatch(message, /PRIVATE-ROW|123/);
  assert.match(message, /^Keep my input/);
  assert.match(message, /Add a chart\.$/);
  assert.equal((await prepareChatUploads([new File(['| x |\n| --- |\n| value |'], 'only-tables.md')], ''))[0]?.description, '');
  await assert.rejects(prepareChatUploads([new File([' '.repeat(4)], 'empty.md')], ''), /no description or tables/);
  await assert.rejects(prepareChatUploads([new File(['a'.repeat(4001)], 'long.md')], ''), /4,000/);
  await assert.rejects(prepareChatUploads([new File(['a'.repeat(2000)], 'a.md'), new File(['b'.repeat(2000)], 'b.md')], ''), /4,000/);
  await assert.rejects(prepareChatUploads([new File(['| a |\n| --- |\n| b | c |'], 'bad.md')], ''), /more cells/);
  await assert.rejects(prepareChatUploads([new File(['a'], 'bad.exe')], ''), /Markdown/);
});

test('merged session projection retains sheet grouping and blank counts without arbitrary data', async () => {
  const { metadataChatState } = await import('../web/src/chat-upload.ts');
  const sheet = { ...file(1), sourceFile: 'invented.md', sheetName: 'Table 1', fields: [{ name: 'amount', type: 'number', blankCount: 2 }], preview: { rows: [['PRIVATE-CELL']] } };
  const saved = metadataChatState({ input: 'Invented prose', messages: [{ role: 'user', files: [sheet] }], attachments: [sheet], available: [sheet] });
  assert.equal(saved.available?.[0]?.sourceFile, 'invented.md');
  assert.equal(saved.messages[0]?.files?.[0]?.fields[0]?.blankCount, 2);
  assert.doesNotMatch(JSON.stringify(saved), /PRIVATE-CELL|preview|rows/);
});
