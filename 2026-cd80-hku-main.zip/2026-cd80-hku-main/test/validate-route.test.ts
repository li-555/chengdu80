import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { createServer, IncomingMessage, ServerResponse } from 'node:http';
import { Socket } from 'node:net';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { validateRouter } from '../src/api/routes-validate.ts';
import { validateApplication, type ValidationReport } from '../src/validate/index.ts';

const EXAMPLE = new URL('../examples/ex-01-daily-movers.fin.json', import.meta.url);
const document = readFileSync(EXAMPLE, 'utf8');
const app = express();
app.use(validateRouter);

function post(body: string, contentType: string | null = 'application/json'): Promise<Response> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    const socket = new Socket();
    socket._write = (chunk, _encoding, callback) => { chunks.push(Buffer.from(chunk)); callback(); };
    socket._writev = (pending, callback) => {
      for (const { chunk } of pending) chunks.push(Buffer.from(chunk));
      callback();
    };
    const request = new IncomingMessage(new Socket());
    request.method = 'POST';
    request.url = '/api/validate';
    request.headers = { 'content-length': String(Buffer.byteLength(body)) };
    if (contentType !== null) request.headers['content-type'] = contentType;
    const response = new ServerResponse(request);
    response.assignSocket(socket);
    response.once('error', reject);
    response.once('finish', () => {
      const output = Buffer.concat(chunks).toString('utf8');
      resolve(new Response(output.slice(output.indexOf('\r\n\r\n') + 4), {
        status: response.statusCode,
        headers: { 'Content-Type': String(response.getHeader('Content-Type')) },
      }));
      socket.destroy();
      request.socket.destroy();
    });
    createServer(app).emit('request', request, response);
    request.push(Buffer.from(body));
    request.push(null);
  });
}

test('the validation route accepts the shipped example as JSON', async () => {
  const response = await post(document);
  assert.equal(response.status, 200);
  const report = await response.json() as ValidationReport;
  assert.equal(report.valid, true);
  assert.deepEqual(report.errors, []);
});

test('the validation route reads fenced text and reports the surrounding-text warning', async () => {
  const response = await post(`Here is the application.\n\n\`\`\`json\n${document}\n\`\`\``, 'text/plain');
  assert.equal(response.status, 200);
  const report = await response.json() as ValidationReport;
  assert.equal(report.valid, true);
  assert.ok(report.warnings.some((warning) => warning.code === 'W_SURROUNDING_TEXT'));
});

test('the validation route reports an unsupported operation at its pointer', async () => {
  const changed = JSON.parse(document);
  changed.compute[2].op = 'top_n';
  const response = await post(JSON.stringify(changed));
  assert.equal(response.status, 200);
  const report = await response.json() as ValidationReport;
  assert.equal(report.valid, false);
  assert.ok(report.errors.some((error) => error.code === 'E_SCHEMA_ENUM' && error.pointer === '/compute/2/op'));
});

test('malformed JSON reaches the validator for both JSON and text requests', async () => {
  for (const contentType of ['application/json', 'text/plain']) {
    const response = await post('{', contentType);
    assert.equal(response.status, 200);
    const report = await response.json() as ValidationReport;
    assert.equal(report.valid, false);
    assert.deepEqual(report.errors.map((error) => error.code), ['E_PARSE_JSON']);
  }
});

test('the validation route rejects bodies larger than 1 MB with a JSON error', async () => {
  for (const contentType of ['application/json', 'text/plain', 'application/octet-stream']) {
    const response = await post('x'.repeat(1.5 * 1024 * 1024), contentType);
    assert.equal(response.status, 413);
    assert.deepEqual(await response.json(), {
      error: { code: 'FILE_TOO_LARGE', message: 'Send an application no larger than 1 MB.' },
    });
  }
});

test('the validation route returns the same report as the command line', async () => {
  const response = await post(document);
  assert.equal(response.status, 200);
  const { checked_at: httpTime, ...httpReport } = await response.json() as ValidationReport;
  const output = execFileSync(process.execPath, [
    fileURLToPath(new URL('../scripts/validate.ts', import.meta.url)), fileURLToPath(EXAMPLE), '--json',
  ], { encoding: 'utf8' });
  const { checked_at: commandTime, ...commandReport } = JSON.parse(output) as ValidationReport;
  assert.ok(httpTime);
  assert.ok(commandTime);
  assert.deepEqual(httpReport, commandReport);
});

test('an empty body returns the validator empty-input report', async () => {
  for (const contentType of ['application/json', 'text/plain']) {
    const response = await post('', contentType);
    assert.equal(response.status, 200);
    const { checked_at, ...report } = await response.json() as ValidationReport;
    const { checked_at: expectedTime, ...expected } = validateApplication('').report;
    assert.ok(checked_at);
    assert.ok(expectedTime);
    assert.deepEqual(report, expected);
  }
});

test('other content types and a missing content type use the same text input path', async () => {
  for (const contentType of ['application/octet-stream', null]) {
    const response = await post(document, contentType);
    assert.equal(response.status, 200);
    const report = await response.json() as ValidationReport;
    assert.equal(report.valid, true);
  }
});

for (const step of [{ kind: { toString: null } }, { kind: 'operation', op: { toString: null } }]) {
  test(`the validation route returns 200 for an object in ${'op' in step ? 'op' : 'kind'}`, async () => {
    const response = await post(JSON.stringify({ meta: { spec_version: '1.0' }, compute: [step] }));
    assert.equal(response.status, 200);
    const report = await response.json() as ValidationReport;
    assert.equal(report.valid, false);
    assert.ok(report.errors.some((error) => error.code === 'E_SCHEMA_ENUM'));
  });
}
