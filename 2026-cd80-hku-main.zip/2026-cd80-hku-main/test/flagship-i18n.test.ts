import { flagshipLogicDocument, fixtureSlices } from './flagship-test-helpers.ts';
import { test, after } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { AppDocument } from '../web/src/app-types.ts';
import { isFlagshipDocument, localizeFlagshipDocument, localizeFlagshipDescription, localizeFlagshipResults, flagshipFieldLabel, flagshipText, flagshipValue } from '../web/src/flagship-i18n.ts';
import { getLanguage, setLanguage, t } from '../web/src/i18n.ts';
import { renderScreen, refreshScreenResults, type ScreenResults } from '../web/src/screen-elements.ts';
import { createListActionPanel } from '../web/src/list-actions.ts';
import { showTemplates } from '../web/src/templates.ts';
import { compareRuns } from '../web/src/compare.ts';
import { detachedDOM } from './dom-fixture.ts';
import { templates, importTemplate } from '../src/platform/templates.ts';
import { getApp, saveApp } from '../src/platform/storage.ts';
import { closeStorage } from '../src/platform/database.ts';
import { runSavedApplication } from '../src/platform/execute.ts';
import { validateApplication } from '../src/validate/index.ts';

const directory = mkdtempSync(join(tmpdir(), 'blocks-flagship-i18n-'));
process.env.BLOCKS_DB_PATH = join(directory, 'storage.sqlite');
after(() => { closeStorage(); rmSync(directory, { recursive: true, force: true }); });
const documents = templates.map((template) => JSON.parse(readFileSync(new URL(`../examples/${template.id}.fin.json`, import.meta.url), 'utf8')) as AppDocument);
const displayKeys = new Set(['title', 'text', 'label', 'emptyHint', 'placeholder']);
function staticLabels(value: unknown): string[] {
  if (!value || typeof value !== 'object') return [];
  return Object.entries(value).flatMap(([key, child]) => typeof child === 'string' && displayKeys.has(key) ? [child] : staticLabels(child));
}

test('all bundled labels translate without modifying app code, keys, defaults, schema or stored documents', () => {
  for (const doc of documents) {
    const saved = structuredClone(doc);
    const chinese = localizeFlagshipDocument(doc, 'zh');
    assert.equal(isFlagshipDocument(chinese), true);
    assert.equal(validateApplication(chinese).ok, true);
    for (const label of [...staticLabels(doc.ui), ...doc.params.flatMap((param) => [param.label, ...(param.options ?? []).map((option) => option.label)])]) {
      if (['RiskRift', 'CNY', '%'].includes(label)) continue;
      assert.notEqual(flagshipText(label, 'zh'), label, `${doc.meta.name}: untranslated label ${label}`);
    }
    assert.deepEqual(doc, saved);
    assert.deepEqual(chinese.compute, doc.compute);
    assert.deepEqual(chinese.data.map((data) => ({ ...data, purpose: undefined })), doc.data.map((data) => ({ ...data, purpose: undefined })));
    assert.deepEqual(chinese.params.map((param) => ({ ...param, label: undefined })), doc.params.map((param) => ({ ...param, label: undefined })));
    assert.strictEqual(localizeFlagshipDocument(doc, 'en'), doc);
    const custom = structuredClone(doc); custom.meta.name = 'My custom application';
    assert.strictEqual(localizeFlagshipDocument(custom, 'zh'), custom);
  }
});

test('Chinese and English switching uses the original application; custom prose, IDs and URLs are preserved', () => {
  const language = getLanguage();
  try {
    const doc = documents[0]!;
    setLanguage('zh');
    assert.match(localizeFlagshipDocument(doc).meta.description, /投研/);
    assert.match(localizeFlagshipDescription(doc.meta.name, `Demo inputs — invented. ${doc.meta.description}`), /^演示输入为虚构数据。使用 Tushare/);
    const raw = new Map([['table', { columns: [{ name: 'status', type: 'text' as const }], rows: [{ status: 'Available', code: 'Available', source_url: 'https://example.invalid/Available', detail: 'Actual English source wording stays intact.', return_pct: 2.5 }] }]]);
    const saved = structuredClone(raw);
    const shown = localizeFlagshipResults(doc, raw).get('table')!.rows[0]!;
    assert.equal(shown.status, '可用'); assert.equal(shown.code, 'Available'); assert.equal(shown.source_url, 'https://example.invalid/Available');
    assert.equal(shown.detail, 'Actual English source wording stays intact.'); assert.equal(shown.return_pct, 2.5);
    assert.deepEqual(raw, saved);
    assert.equal(flagshipValue('finding_id', 'pending_review', 'zh'), 'pending_review');
    assert.equal(flagshipText('Review indicator in supplied excerpt: Source evidence in its original language.', 'zh'), '所提供摘录中的复核指标：Source evidence in its original language.');
    setLanguage('en');
    assert.strictEqual(localizeFlagshipDocument(doc), doc); assert.strictEqual(localizeFlagshipResults(doc, raw), raw);
  } finally { setLanguage(language); }
});

test('non-default observations, missing data and changed document text retain numeric and source evidence', () => {
  for (const text of [
    'Volatility unavailable: needs 30 return observations',
    'Portfolio needs 30 common return observations',
    'Selected holding weights are invalid or inconsistent; Portfolio needs 30 common return observations',
    'Volatility unavailable: needs 30 return observations; No dated statement available by the research cutoff',
    'Adjusted close; annualisation 365 observed sessions',
    'Daily rebalanced selected holdings; 365 sessions/year; adjacent common dates assumed consecutive trading sessions; no fees, taxes, cash or slippage',
    'Observed adjusted-close change -10.50%; threshold 5%. End-of-day observation, not a trading instruction.',
    'Missing or invalid market date; Duplicate price date',
    'Historical adjusted-close measures; no forecast; Unavailable fields: pe, pb',
    'Local review noted; not institutional approval', 'reviewed_by_user', 'completed_local',
    'Blocked: outstanding review, disclosure or unsupported transition; no automatic approval or sale',
  ]) {
    const shown = flagshipText(text, 'zh');
    assert.notEqual(shown, text); assert.match(shown, /[\u3400-\u9fff]/);
    for (const number of text.match(/-?\d+(?:\.\d+)?/g) ?? []) assert.ok(shown.includes(number), text);
    assert.equal(flagshipText(text, 'en'), text);
  }
  const source = 'Supplied versions v3 → v4. Text changed; metadata changes: title, effective_at. Previous effective date 2025-01-01; current 2026-01-01. Previous text: Original source A. | Current text: Original source B.. Review supplied changes; no current-law or repeal determination.';
  const shown = flagshipText(source, 'zh');
  assert.match(shown, /文本已变/); assert.match(shown, /标题、生效日期/);
  assert.ok(shown.includes('Original source A.')); assert.ok(shown.includes('Original source B.'));
  for (const key of ['constructor', '__proto__', 'toString']) {
    assert.equal(flagshipText(key, 'zh'), key); assert.equal(flagshipFieldLabel(key, 'zh'), key);
  }
});

test('all three offline business-rule fixtures render Chinese static labels, computed explanations, status values and chart data without altering saved results', async () => {
  const originalFetch = globalThis.fetch; const language = getLanguage();
  globalThis.fetch = async () => { throw new Error('No network permitted for invented demo data.'); };
  try {
    setLanguage('zh');
    for (const template of templates) {
      const owner = `fake_i18n_${template.id}`, profile = `browser:${owner}`;
      const definition = documents.find(doc => doc.meta.name === template.name)!;
      const app = await saveApp(flagshipLogicDocument(template.id, definition), profile);
      const before = structuredClone(app.doc);
      const reply = await runSavedApplication({ appId: app.id, profile, allowInventedData: true,
        adapter: { kind: 'invented', id: 'offline-logic-fixture', label: 'Invented test inputs only',
          resolve: async () => ({ slices: fixtureSlices(template.id), datasetVersions: Object.fromEntries(Object.keys(fixtureSlices(template.id)).map(key => [key, 'offline-v1'])) }) } });
      assert.equal(reply.kind, 'completed'); if (reply.kind !== 'completed') throw new Error('Run failed');
      assert.equal(reply.record.status, 'ok', JSON.stringify(reply.record.failure)); const saved = structuredClone(reply.record);
      const raw: ScreenResults = new Map(Object.entries(reply.record.result!.outputs).map(([key, table]) => [key, { columns: table.schema.map((column) => ({ name: column.name, type: column.type })), rows: table.rows.map((row) => Object.fromEntries(table.schema.map((column, index) => [column.name, row[index]]))) }]));
      const shown = localizeFlagshipResults(app.doc, raw);
      let translated = 0;
      for (const [key, table] of shown) {
        const original = raw.get(key)!; assert.deepEqual(table.columns, original.columns);
        for (const [index, row] of table.rows.entries()) for (const [field, value] of Object.entries(row)) {
          const source = original.rows[index]![field];
          if (value !== source) { translated++; assert.equal(typeof source, 'string'); assert.match(String(value), /[\u3400-\u9fff]/); }
          if (typeof source !== 'string' || /(?:_id|_url)$/.test(field) || ['code', 'peer_code', 'date', 'period', 'published_at', 'available_at', 'rule_id'].includes(field)) assert.equal(value, source, field);
          // Runtime-generated display text must be localised. Source IDs/references and brands may remain.
          if (['status', 'explanation', 'detail', 'service_note', 'request_status', 'local_review_note', 'rule_status', 'effective_stage', 'institutional_approval'].includes(field) && typeof source === 'string' && source) assert.notEqual(value, source, `${template.id}: ${field}: ${source}`);
        }
      }
      assert.ok(translated > 10, template.id);
      const env = detachedDOM(`/apps/${app.id}`);
      try {
        const doc = localizeFlagshipDocument(app.doc);
        const screen = renderScreen(doc.ui, shown, undefined, flagshipFieldLabel); env.view.append(screen as never);
        assert.match(screen.textContent!, /[\u3400-\u9fff]/);
        assert.doesNotMatch(screen.textContent!, /Your research|Client servicing and suitability|pending_review|No stage request|Draft for human review only|CFO \/ net income|Computed fact:/);
        for (const th of Array.from(screen.querySelectorAll('th'))) assert.doesNotMatch(th.textContent!, /^(count|date|status|records|return_pct|weight_pct|indexed_price|correlation)$/);
        refreshScreenResults(screen, doc.ui, shown, flagshipFieldLabel);
        assert.doesNotMatch(screen.textContent!, /Draft for human review only|CFO \/ net income|Computed fact:/);
      } finally { env.restore(); }
      assert.deepEqual(app.doc, before); assert.deepEqual(reply.record, saved);
      assert.deepEqual((await getApp(app.id))!.doc, before);
      const compared = compareRuns(saved, saved, flagshipFieldLabel);
      assert.ok(compared.tables.every((table) => table.changedCells === 0));
    }
  } finally { globalThis.fetch = originalFetch; setLanguage(language); }
});

test('template entry and saved workflow actions use central Chinese labels without translating stored IDs', async () => {
  const env = detachedDOM('/examples'); const originalFetch = globalThis.fetch; const language = getLanguage();
  try {
    setLanguage('zh'); assert.equal(t('Flagship applications'), '旗舰应用');
    globalThis.fetch = async () => Response.json({ templates });
    await showTemplates(env.view as unknown as HTMLElement, () => {});
    assert.match(env.view.textContent, /旗舰应用/); assert.match(env.view.textContent, /连接我的数据/);
    let calls = 0;
    globalThis.fetch = async (_input, init) => { calls++; assert.equal(init?.method, undefined); return Response.json({ revision: 'FAKE-REV', params: [{ key: 'reviewed_finding_ids', label: 'Reviewed finding IDs', values: ['pending_review'] }], history: [{ time: '2026-10-15T00:00:00Z', param: 'reviewed_finding_ids', action: 'add', recordId: 'pending_review', note: 'Keep user note', before: [], after: ['pending_review'] }] }); };
    const panel = createListActionPanel('FAKE-APP', () => {}, () => true, flagshipText); env.view.append(panel as never);
    await new Promise((resolve) => setImmediate(resolve));
    assert.equal(calls, 1); assert.match(panel.textContent!, /已保存列表操作/); assert.match(panel.textContent!, /已复核的发现 ID/);
    assert.match(panel.textContent!, /添加 · pending_review/); assert.match(panel.textContent!, /Keep user note/);
    assert.doesNotMatch(panel.textContent!, /Saved list actions|Reviewed finding IDs| · add ·/);
  } finally { env.restore(); globalThis.fetch = originalFetch; setLanguage(language); }
});
