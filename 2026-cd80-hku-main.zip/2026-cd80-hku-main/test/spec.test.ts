import { test } from 'node:test';
import assert from 'node:assert/strict';
import { cpSync, mkdtempSync, readFileSync, rmSync, symlinkSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { IncomingMessage, ServerResponse } from 'node:http';
import { Socket } from 'node:net';
import express from 'express';
import { AppDocument, ExportEnvelope } from '../src/app-schema/document.ts';
import { BLOCK_INFO, COMPONENT_INFO, OPERATION_INFO } from '../src/app-schema/describe.ts';
import { OperationParams, OPERATION_SHAPE, type OperationName } from '../src/app-schema/operations.ts';
import { STEP_SCHEMA } from '../src/app-schema/compute.ts';
import { TriggerSpec } from '../src/app-schema/triggers.ts';
import { ELEMENT_TYPES } from '../src/app-schema/ui.ts';
import { FACTORS, SUPPORTED_FACTORS } from '../src/compute/ops/factor.ts';
import { ERROR_CODES } from '../src/validate/errors.ts';
import { specRouter } from '../src/api/routes-spec.ts';

const root = fileURLToPath(new URL('../', import.meta.url));
const published = (name: string): string => readFileSync(join(root, 'spec', name), 'utf8');

test('operation and component descriptions cover exactly their catalogues', () => {
  assert.deepEqual(Object.keys(OPERATION_INFO).sort(), Object.keys(OperationParams).sort());
  assert.deepEqual(Object.keys(COMPONENT_INFO).sort(), [...ELEMENT_TYPES].sort());
  assert.deepEqual(Object.keys(BLOCK_INFO.sections).sort(), Object.keys(AppDocument.shape).sort());
  assert.deepEqual(Object.keys(BLOCK_INFO.steps).sort(), Object.keys(STEP_SCHEMA).sort());
  assert.deepEqual(Object.keys(BLOCK_INFO.triggers).sort(), TriggerSpec.options.map((schema) => schema.shape.kind.value).sort());
});

test('every operation example parses with its own schema and has the declared output', () => {
  for (const name of Object.keys(OperationParams) as OperationName[]) {
    assert.equal(OperationParams[name].safeParse(OPERATION_INFO[name].example).success, true, name);
    assert.equal(OPERATION_INFO[name].output, OPERATION_SHAPE[name].output, name);
  }
});

test('section, step and trigger examples parse with their matching schemas', () => {
  for (const [name, info] of Object.entries(BLOCK_INFO.sections)) {
    const schema = AppDocument.shape[name as keyof typeof AppDocument.shape];
    assert.equal(schema.safeParse(info.example).success, true, name);
  }
  for (const [name, info] of Object.entries(BLOCK_INFO.steps)) {
    assert.equal(STEP_SCHEMA[name as keyof typeof STEP_SCHEMA].safeParse(info.example).success, true, name);
  }
  for (const [name, info] of Object.entries(BLOCK_INFO.triggers)) {
    const schema = TriggerSpec.options.find((option) => option.shape.kind.value === name)!;
    assert.equal(schema.safeParse(info.example).success, true, name);
    assert.equal(info.example.kind, name);
  }
});

test('the published application structure is draft 2020-12 and the example parses', () => {
  const raw = JSON.parse(readFileSync(join(root, 'examples/ex-01-daily-movers.fin.json'), 'utf8'));
  assert.equal(ExportEnvelope.safeParse(raw).success, true);
  const { $schema: _schema, ...document } = raw;
  assert.equal(AppDocument.safeParse(document).success, true);
  const schema = JSON.parse(published('application.schema.json'));
  assert.equal(schema.$schema, 'https://json-schema.org/draft/2020-12/schema');
  assert.deepEqual(schema.required.sort(), Object.keys(AppDocument.shape).sort());
  assert.deepEqual(Object.keys(schema.properties).sort(), Object.keys(ExportEnvelope.shape).sort());
});

test('published catalogues include parameter schemas, factor needs, component properties and error meanings', () => {
  const operations = JSON.parse(published('operations.json'));
  assert.deepEqual(Object.keys(operations).sort(), Object.keys(OperationParams).sort());
  for (const name of Object.keys(OperationParams) as OperationName[]) {
    assert.equal(operations[name].inputs, OPERATION_SHAPE[name].inputs);
    assert.equal(operations[name].params.type, 'object');
    assert.deepEqual(operations[name].example, OPERATION_INFO[name].example);
  }
  assert.deepEqual(Object.keys(operations.factor.supported).sort(), SUPPORTED_FACTORS);
  for (const name of SUPPORTED_FACTORS) {
    assert.deepEqual(operations.factor.supported[name], { meaning: FACTORS[name]!.meaning, needs: FACTORS[name]!.needs });
  }
  const components = JSON.parse(published('components.json'));
  assert.deepEqual(Object.keys(components).sort(), [...ELEMENT_TYPES].sort());
  for (const name of ELEMENT_TYPES) assert.equal(components[name].props.properties.type.const, name);
  assert.deepEqual(JSON.parse(published('blocks.json')), BLOCK_INFO);
  assert.deepEqual(JSON.parse(published('errors.json')), Object.fromEntries(Object.entries(ERROR_CODES).map(([code, meaning]) => [code, { meaning }])));
});

test('spec:check accepts a fresh build and rejects byte changes, missing files and extra files in a temporary copy', () => {
  const temporary = mkdtempSync(join(tmpdir(), 'blocks-spec-test-'));
  try {
    for (const directory of ['src', 'scripts', 'skill-src', 'examples', 'fixtures']) cpSync(join(root, directory), join(temporary, directory), { recursive: true });
    cpSync(join(root, 'package.json'), join(temporary, 'package.json'));
    symlinkSync(join(root, 'node_modules'), join(temporary, 'node_modules'), 'dir');
    const npm = (script: string) => spawnSync('npm', ['run', script], { cwd: temporary, encoding: 'utf8' });
    const build = npm('spec:build');
    assert.equal(build.status, 0, build.stderr);
    const check = npm('spec:check');
    assert.equal(check.status, 0, check.stderr);
    const operationFile = join(temporary, 'spec', 'operations.json');
    const original = readFileSync(operationFile);
    const changed = Buffer.from(original);
    changed[changed.length - 1] = 32;
    writeFileSync(operationFile, changed);
    const mismatch = npm('spec:check');
    assert.equal(mismatch.status, 1);
    assert.match(mismatch.stderr, /operations\.json: differs/);
    writeFileSync(operationFile, original);
    rmSync(join(temporary, 'spec', 'errors.json'));
    const missing = npm('spec:check');
    assert.equal(missing.status, 1);
    assert.match(missing.stderr, /errors\.json: missing file/);
    writeFileSync(join(temporary, 'spec', 'errors.json'), published('errors.json'));
    writeFileSync(join(temporary, 'spec', 'extra.json'), '{}\n');
    const extra = npm('spec:check');
    assert.equal(extra.status, 1);
    assert.match(extra.stderr, /extra\.json: unexpected file/);
  } finally {
    rmSync(temporary, { recursive: true, force: true });
  }
});

test('spec routes serve the published files and a complete bundle', async () => {
  const app = express();
  app.use(specRouter);
  const get = (url: string) => new Promise<{ response: ServerResponse; body: string }>((resolve, reject) => {
    const request = new IncomingMessage(new Socket());
    request.method = 'GET';
    request.url = url;
    const response = new ServerResponse(request);
    response.end = ((body: string | Buffer) => {
      resolve({ response, body: String(body) });
      return response;
    }) as typeof response.end;
    app(request as express.Request, response as express.Response,
      (error?: unknown) => reject(error ?? new Error(`No route for ${url}`)));
  });
  const markdown = await get('/api/spec');
  assert.equal(markdown.response.statusCode, 200);
  assert.match(String(markdown.response.getHeader('content-type')), /^text\/markdown/);
  assert.equal(markdown.body, published('SPEC.md'));
  const expected: Record<string, unknown> = { 'SPEC.md': published('SPEC.md') };
  for (const [endpoint, file] of Object.entries({ schema: 'application.schema.json', blocks: 'blocks.json', operations: 'operations.json', components: 'components.json', errors: 'errors.json' })) {
    const { response, body } = await get(`/api/spec/${endpoint}`);
    assert.equal(response.statusCode, 200);
    assert.match(String(response.getHeader('content-type')), /^application\/json/);
    expected[file] = JSON.parse(published(file));
    assert.deepEqual(JSON.parse(body), expected[file]);
  }
  const bundle = await get('/api/spec/bundle');
  assert.equal(bundle.response.statusCode, 200);
  assert.deepEqual(JSON.parse(bundle.body), expected);
});

test('every schema property retains its meaning in JSON Schema, including nested alternatives', async () => {
  const { schema } = await import('../src/spec/render.ts');
  const { FieldSpec, intOrParam } = await import('../src/app-schema/fields.ts');
  const visit = (value: unknown, path: string): void => {
    if (value === null || typeof value !== 'object') return;
    if (Array.isArray(value)) {
      value.forEach((item, i) => visit(item, `${path}[${i}]`));
      return;
    }
    const object = value as Record<string, unknown>;
    for (const [name, prop] of Object.entries(object.properties ?? {})) {
      const description = (prop as { description?: unknown }).description;
      assert.equal(typeof description, 'string', `${path}.${name} has no meaning`);
      assert.ok((description as string).trim(), `${path}.${name} has an empty meaning`);
    }
    for (const [key, item] of Object.entries(object)) visit(item, `${path}.${key}`);
  };
  for (const [name, value] of Object.entries({
    application: schema(ExportEnvelope), fields: schema(FieldSpec), integer: schema(intOrParam(0, 10)),
    ...Object.fromEntries(Object.entries(OperationParams).map(([name, value]) => [name, schema(value)])),
  })) visit(value, name);
});

test('every generated parameter and property table has a non-empty meaning for every row', async () => {
  const { buildSkill } = await import('../src/skill/build.ts');
  const documents = new Map([
    ['spec/SPEC.md', published('SPEC.md')],
    ...[...buildSkill()].filter(([path]) => path.startsWith('references/')),
  ]);
  let tables = 0;
  let rows = 0;
  for (const [path, markdown] of documents) {
    let meaningIndex = -1;
    let fenced = false;
    for (const line of markdown.split('\n')) {
      if (line.startsWith('```')) { fenced = !fenced; continue; }
      if (fenced) continue;
      if (!line.startsWith('|')) { meaningIndex = -1; continue; }
      const cells = line.split(/(?<!\\)\|/).slice(1, -1).map((cell) => cell.trim());
      if (cells.includes('Required')) {
        meaningIndex = cells.indexOf('Meaning');
        assert.ok(meaningIndex >= 0, `${path}: missing meaning column`);
        tables++;
      } else if (meaningIndex >= 0 && !cells.every((cell) => /^[-: ]+$/.test(cell))) {
        assert.ok(cells[meaningIndex], `${path}: empty meaning for ${cells[0]}`);
        rows++;
      }
    }
  }
  assert.ok(tables > 0);
  assert.ok(rows > 0);
});
