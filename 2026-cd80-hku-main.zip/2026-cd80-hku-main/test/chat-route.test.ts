import { test } from 'node:test';
import assert from 'node:assert/strict';
import express from 'express';
import type { AddressInfo } from 'node:net';
import { chatRouter } from '../src/api/routes-chat.ts';
import { addUpload } from '../src/data/catalogue.ts';

/** The checks /api/chat makes before any model is called. Datasets are invented. */

// No key, so the one accepted request ends at once without reaching any model.
delete process.env.GITEE_AI_API_KEY;

async function withServer(fn: (base: string) => Promise<void>): Promise<void> {
  const app = express();
  app.use(chatRouter);
  const server = app.listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  try {
    await fn(`http://127.0.0.1:${(server.address() as AddressInfo).port}`);
  } finally {
    await new Promise((r) => server.close(r));
  }
}

const post = (base: string, body: unknown, headers: Record<string, string> = {}) =>
  fetch(`${base}/api/chat`, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) });

test('chat: uploads must be a short list of known uploaded datasets', async () => {
  await withServer(async (base) => {
    for (const uploads of ['user:x', [1], Array.from({ length: 6 }, (_, i) => `user:${i}`)]) {
      const r = await post(base, { message: 'hi', uploads });
      assert.equal(r.status, 400);
      assert.equal((await r.json()).error.code, 'BAD_UPLOADS');
    }
    const unknown = await post(base, { message: 'hi', uploads: ['user:missing'] });
    assert.equal((await unknown.json()).error.code, 'UNKNOWN_UPLOAD');
    const notUpload = await post(base, { message: 'hi', uploads: ['daily'] });
    assert.equal(notUpload.status, 400, 'a catalogue dataset is not an attachment');
  });
});

test('chat: an empty message is refused unless it carries a file', async () => {
  addUpload({ id: 'user:chat-test', name: 'Invented holdings', source: 'upload', fields: [{ name: 'code', label: 'code', type: 'text', nullable: false }], rowCount: 2 });
  await withServer(async (base) => {
    assert.equal((await post(base, { message: '  ' })).status, 400);
    for (const message of [42, null, { text: 'hi' }, undefined]) {
      const bad = await post(base, { message, uploads: ['user:chat-test'] });
      assert.equal(bad.status, 400, `message ${JSON.stringify(message)} with a file`);
    }
    const r = await post(base, { message: '', uploads: ['user:chat-test'] });
    assert.equal(r.status, 200, 'accepted and streaming');
    assert.match(r.headers.get('content-type') ?? '', /text\/event-stream/);
    await r.body?.cancel();
  });
});

test('chat: a request from another site is refused', async () => {
  await withServer(async (base) => {
    const r = await post(base, { message: 'hi' }, { origin: 'https://elsewhere.example' });
    assert.equal(r.status, 403);
  });
});
