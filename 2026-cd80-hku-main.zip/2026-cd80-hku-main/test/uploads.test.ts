import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createServer, IncomingMessage, ServerResponse } from 'node:http';
import { Socket } from 'node:net';
import { execFileSync } from 'node:child_process';
import express from 'express';
import { uploadRouter } from '../src/api/routes-uploads.ts';
import { findDataset, getUploadRows, listAllDatasets, resetUploadsForTests } from '../src/data/catalogue.ts';
import { listUploads, loadUploads } from '../src/data/upload-store.ts';
import { fetchSlicesFor } from '../src/compute/slices.ts';
import type { Dataset } from '../src/data/types.ts';
import type { AppDocument } from '../src/app-schema/index.ts';
import type { WorkbookUpload, UploadDetails } from '../src/platform/upload-preview.ts';

const rows = [
  ['2026-01-01', 'MADEUP_A', '12.5'],
  ['2026-01-02', 'MADEUP_B', '15'],
  ['2026-01-03', 'MADEUP_C', '9'],
];
const csv = ['date,code,price', ...rows.map((row) => row.join(','))].join('\n');
type UploadResponse = { blankCounts: number[]; dataset: Dataset; preview: { columns: string[]; rows: string[][] } };

test('uploads API, profile listing and restart persistence using invented data', async (t) => {
  const directory = mkdtempSync(join(tmpdir(), 'blocks-uploads-test-'));
  const previousPath = process.env.BLOCKS_DB_PATH;
  process.env.BLOCKS_DB_PATH = join(directory, 'blocks.sqlite');
  resetUploadsForTests();
  const app = express();
  app.use(uploadRouter);
  const base = 'http://127.0.0.1';
  // Dispatch real HTTP streams through Express without opening a listening socket.
  function request(url: string, body?: string | Uint8Array, origin?: string, cookie?: string): Promise<Response> {
    return new Promise((resolve, reject) => {
      const chunks: Buffer[] = [];
      const socket = new Socket();
      socket._write = (chunk, _encoding, callback) => { chunks.push(Buffer.from(chunk)); callback(); };
      socket._writev = (pending, callback) => {
        for (const { chunk } of pending) chunks.push(Buffer.from(chunk));
        callback();
      };
      const incoming = new IncomingMessage(new Socket());
      incoming.method = body === undefined ? 'GET' : 'POST';
      incoming.url = url.replace(base, '');
      incoming.headers = { host: '127.0.0.1' };
      if (cookie) incoming.headers.cookie = cookie;
      if (body !== undefined) {
        incoming.headers['content-length'] = String(Buffer.byteLength(body));
        incoming.headers['content-type'] = 'application/octet-stream';
      }
      if (origin) incoming.headers.origin = origin;
      const outgoing = new ServerResponse(incoming);
      outgoing.assignSocket(socket);
      outgoing.once('error', reject);
      outgoing.once('finish', () => {
        const output = Buffer.concat(chunks).toString('utf8');
        resolve(new Response(output.slice(output.indexOf('\r\n\r\n') + 4), {
          status: outgoing.statusCode,
          headers: { 'Content-Type': String(outgoing.getHeader('Content-Type')), 'Cache-Control': String(outgoing.getHeader('Cache-Control')) },
        }));
        socket.destroy();
        incoming.socket.destroy();
      });
      createServer(app).emit('request', incoming, outgoing);
      if (body !== undefined) incoming.push(Buffer.from(body));
      incoming.push(null);
    });
  }
  t.after(() => {
    if (previousPath === undefined) delete process.env.BLOCKS_DB_PATH;
    else process.env.BLOCKS_DB_PATH = previousPath;
    resetUploadsForTests();
    rmSync(directory, { recursive: true, force: true });
  });
  const post = (query: string, body: string | Uint8Array = csv, origin = base) => request(`${base}/api/uploads?${query}`, body, origin);

  const response = await post('filename=invented.csv&name=Invented%20prices&profile=alice');
  assert.equal(response.status, 201);
  const uploaded = await response.json() as UploadResponse;
  assert.match(uploaded.dataset.id, /^user:/);
  assert.equal(uploaded.dataset.name, 'Invented prices');
  assert.equal(uploaded.dataset.source, 'upload');
  assert.equal(uploaded.dataset.rowCount, 3);
  assert.deepEqual(uploaded.dataset.fields.map(({ name, type }) => [name, type]), [['date', 'date'], ['code', 'text'], ['price', 'number']]);
  assert.deepEqual(uploaded.preview, { columns: ['date', 'code', 'price'], rows });

  assert.deepEqual(uploaded.blankCounts, [0, 0, 0]);
  const blanks = await post('filename=invented-blanks.csv&profile=blank_counts', 'code,amount,note\nMADEUP_A,0,\nMADEUP_B,,"   "\nMADEUP_C,5,hello');
  assert.equal(blanks.status, 201);
  const withBlanks = await blanks.json() as UploadResponse;
  assert.deepEqual(withBlanks.blankCounts, [0, 1, 2]);
  assert.equal(withBlanks.preview.rows[0]?.[1], '0');

  const many = await post('filename=six.csv', `${csv}\n${rows.map((row) => row.join(',')).join('\n')}`);
  assert.equal(many.status, 201);
  const six = await many.json() as UploadResponse;
  assert.equal(six.dataset.name, 'six');
  assert.equal(six.dataset.rowCount, 6);
  assert.equal(six.preview.rows.length, 5);

  const tsv = await post('filename=invented.TSV&profile=invalid!', ['date\tcode\tprice', ...rows.map((row) => row.join('\t'))].join('\n'));
  assert.equal(tsv.status, 201);
  const tabular = await tsv.json() as UploadResponse;
  assert.deepEqual(tabular.preview.rows, rows);
  const listing = await request(`${base}/api/uploads?profile=alice`);
  assert.equal(listing.status, 200);
  assert.deepEqual(await listing.json(), { datasets: [uploaded.dataset] });
  assert.deepEqual(await (await request(`${base}/api/uploads?profile=bob`)).json(), { datasets: [] });
  assert.deepEqual(listUploads('default').map((dataset) => dataset.id).sort(), [six.dataset.id, tabular.dataset.id].sort());

  for (const [query, body, code] of [
    ['filename=file.txt', csv, 'UNSUPPORTED_FILE_TYPE'],
    ['filename=empty.csv', '', 'EMPTY_FILE'],
    ['filename=blank.csv', ' \n', 'NO_COLUMNS'],
    ['filename=prices.csv&name=', csv, 'INVALID_NAME'],
    [`filename=prices.csv&name=${'a'.repeat(81)}`, csv, 'INVALID_NAME'],
    ['filename=broken.xlsx', 'not an Excel file', 'INVALID_FILE'],
  ]) {
    const rejected = await post(query!, body!);
    assert.equal(rejected.status, 400);
    const result = await rejected.json();
    assert.equal(result.error.code, code);
    assert.deepEqual(Object.keys(result.error).sort(), ['code', 'message']);
  }
  const crossOrigin = await post('filename=prices.csv', csv, 'https://other.example');
  assert.equal(crossOrigin.status, 403);
  assert.equal((await crossOrigin.json()).error.code, 'ORIGIN_NOT_ALLOWED');
  const oversized = await post('filename=large.csv', new Uint8Array(20 * 1024 * 1024 + 1));
  assert.equal(oversized.status, 413);
  assert.equal((await oversized.json()).error.code, 'FILE_TOO_LARGE');

  const stored = join(directory, 'uploads');
  assert.equal(readdirSync(stored).length, 4, 'only successful uploads are stored, with no temporary files');
  writeFileSync(join(stored, 'corrupt.json'), '{broken');
  writeFileSync(join(stored, 'invalid.json'), JSON.stringify({ dataset: { id: 'user:bad' }, rows: [], profile: 'alice' }));
  resetUploadsForTests();
  loadUploads();
  assert.deepEqual(findDataset(uploaded.dataset.id), uploaded.dataset);
  assert.deepEqual(getUploadRows(uploaded.dataset.id), rows);
  loadUploads();
  assert.equal(listAllDatasets().filter((dataset) => dataset.id === uploaded.dataset.id).length, 1);
  for (const read of [() => getUploadRows(uploaded.dataset.id), () => findDataset(uploaded.dataset.id), () => listAllDatasets()]) {
    resetUploadsForTests();
    read();
    assert.deepEqual(getUploadRows(uploaded.dataset.id), rows);
  }
  const child = execFileSync(process.execPath, ['--input-type=module', '-e', `
    import { findDataset, getUploadRows } from './src/data/catalogue.ts';
    console.log(JSON.stringify({ dataset: findDataset(${JSON.stringify(uploaded.dataset.id)}), rows: getUploadRows(${JSON.stringify(uploaded.dataset.id)}) }));
  `], { encoding: 'utf8' });
  assert.deepEqual(JSON.parse(child), { dataset: uploaded.dataset, rows });

  resetUploadsForTests();
  const doc: AppDocument = {
    meta: { name: 'Invented prices', description: 'Test upload', spec_version: '1.0' },
    params: [], compute: [], triggers: [], ui: { root: 'table', elements: {} },
    data: [{ key: 'prices', datasetHint: uploaded.dataset.id, fields: [
      { name: 'date', type: 'date', required: true },
      { name: 'code', type: 'text', required: true },
      { name: 'price', type: 'number', required: true },
    ] }],
  };
  const { slices, sources } = await fetchSlicesFor(doc);
  assert.deepEqual(slices.prices!.rows, rows.map(([date, code, price]) => ({ date, code, price: Number(price) })));
  assert.equal(sources[0]!.datasetSource, 'upload');
  assert.equal(sources[0]!.rows, 3);

  const owner = 'blocks_profile=11111111-1111-4111-8111-111111111111';
  const stranger = 'blocks_profile=22222222-2222-4222-8222-222222222222';
  const fixture = (name: string) => readFileSync(new URL(`./fixtures/${name}`, import.meta.url));
  const workbookResponse = await request(`${base}/api/uploads?filename=Invented.xlsx&profile=forged`, fixture('invented-upload-review.xlsx'), base, owner);
  assert.equal(workbookResponse.status, 201);
  assert.equal(workbookResponse.headers.get('cache-control'), 'no-store');
  const workbook = await workbookResponse.json() as WorkbookUpload;
  assert.deepEqual(workbook.sheets.map((sheet) => sheet.sheetName), ['Numbers', 'Notes', 'Headers only', 'Extra A', 'Extra B', 'Extra C']);
  assert.deepEqual(workbook.skippedSheets, [{ sheetName: 'Empty', reason: 'NO_COLUMNS' }]);
  assert.deepEqual(workbook.dataset, workbook.sheets[0]!.dataset);
  assert.deepEqual(workbook.preview, workbook.sheets[0]!.preview);
  assert.equal(workbook.dataset.name, 'Invented · Numbers');
  assert.equal(workbook.preview.rows.length, 5);
  assert.equal(workbook.analysis!.rowCount, 12);
  const amounts = workbook.analysis!.columns.find((column) => column.name === 'amount')!;
  assert.deepEqual(amounts.stats, { count: 12, min: 0, max: 1000, mean: 1000 / 12, sum: 1000 });
  assert.equal(amounts.outliers, 1, 'the outlier lies beyond the preview rows');
  assert.equal(workbook.analysis!.columns.find((column) => column.name === 'note')!.nulls, 1);
  assert.equal(workbook.sheets[2]!.dataset.rowCount, 0);
  assert.deepEqual(workbook.sheets[2]!.preview.rows, []);
  assert.equal(listUploads('forged').length, 0, 'browser ownership takes precedence over the query profile');
  assert.equal(listUploads(owner.split('=')[1]!).length, 6);
  for (const sheet of workbook.sheets) {
    const path = `${base}/api/uploads/${encodeURIComponent(sheet.dataset.id)}/preview?profile=${owner.split('=')[1]}`;
    resetUploadsForTests();
    const again = await request(path, undefined, base, owner);
    assert.equal(again.status, 200);
    const value = await again.json() as UploadDetails;
    assert.deepEqual(value.dataset, sheet.dataset);
    assert.deepEqual(value.preview, sheet.preview);
    assert.deepEqual(value.analysis, sheet.analysis);
    assert.equal((await request(path, undefined, base, stranger)).status, 404);
    assert.equal((await request(path, undefined, 'https://other.example', owner)).status, 403);
  }
  const restarted = execFileSync(process.execPath, ['--input-type=module', '-e', `
    import { listUploads } from './src/data/upload-store.ts';
    import { getUploadRows } from './src/data/catalogue.ts';
    import { describeUpload } from './src/platform/upload-preview.ts';
    console.log(JSON.stringify(listUploads('11111111-1111-4111-8111-111111111111').map(d => describeUpload(d, getUploadRows(d.id)))));
  `], { encoding: 'utf8' });
  const persisted = JSON.parse(restarted) as UploadDetails[];
  assert.equal(persisted.length, 6);
  for (const sheet of workbook.sheets) assert.deepEqual(persisted.find((value) => value.dataset.id === sheet.dataset.id)?.analysis, sheet.analysis);

  const single = await post('filename=Single.xlsx', fixture('invented-single-upload.xlsx'));
  assert.equal(single.status, 201);
  const one = await single.json() as WorkbookUpload;
  assert.equal(one.sheets.length, 1); assert.equal(one.dataset.name, 'Single');
  assert.deepEqual(one.preview.rows, [['000001', '10'], ['000002', '20']]);
  const beforeInvalid = readdirSync(stored).length;
  for (const [name, code] of [['invented-empty-upload.xlsx', 'NO_COLUMNS'], ['invented-invalid-upload.xlsx', 'INVALID_FILE']]) {
    const failed = await post('filename=Invalid.xlsx', fixture(name!));
    assert.equal(failed.status, 400); assert.equal((await failed.json()).error.code, code);
  }
  assert.equal(readdirSync(stored).length, beforeInvalid, 'an invalid later sheet must not partially store the workbook');

  const markdown = '# Invented description\n\ncode | amount\n--- | ---\nPRIVATE-MARKDOWN-CANARY | 10\nINVENTED_B |\n\n| | |\n| --- | --- |\n| skip | 0 |\n\n| name | note |\n| --- | --- |\n| INVENTED_C | note |';
  const markdownReply = await request(`${base}/api/uploads?filename=invented.MD`, markdown, base, owner);
  assert.equal(markdownReply.status, 201);
  const md = await markdownReply.json() as WorkbookUpload;
  assert.deepEqual(md.sheets.map((sheet) => sheet.sheetName), ['Table 1', 'Table 3']);
  assert.deepEqual(md.skippedSheets, [{ sheetName: 'Table 2', reason: 'NO_COLUMNS' }]);
  assert.deepEqual(md.blankCounts, [0, 1]);
  assert.deepEqual(md.sheets[0]?.preview.rows, [['PRIVATE-MARKDOWN-CANARY', '10'], ['INVENTED_B', '']]);
  assert.deepEqual(md.dataset, md.sheets[0]?.dataset);
  resetUploadsForTests(); loadUploads();
  assert.deepEqual(getUploadRows(md.sheets[1]!.dataset.id), [['INVENTED_C', 'note']]);
  const reopened = await request(`${base}/api/uploads/${encodeURIComponent(md.dataset.id)}/preview`, undefined, base, owner);
  assert.deepEqual((await reopened.json()).blankCounts, [0, 1]);
  assert.equal((await request(`${base}/api/uploads/${encodeURIComponent(md.dataset.id)}/preview`, undefined, base, stranger)).status, 404);
  const beforeBadMarkdown = readdirSync(stored).length;
  const malformed = await post('filename=bad.md', markdown + '\n| too | many | cells |');
  assert.equal(malformed.status, 400);
  const malformedBody = await malformed.json();
  assert.equal(malformedBody.error.code, 'INVALID_FILE');
  assert.match(malformedBody.error.message, /more cells/);
  assert.equal(readdirSync(stored).length, beforeBadMarkdown, 'invalid later Markdown tables must not partially save the file');
  const proseOnly = await post('filename=prose.md', '# Invented prose only');
  assert.equal(proseOnly.status, 400); assert.equal((await proseOnly.json()).error.code, 'NO_COLUMNS');

  const partialDirectory = join(directory, 'partial');
  const { mkdirSync } = await import('node:fs');
  mkdirSync(join(partialDirectory, 'uploads'), { recursive: true });
  // A simulated write failure on one sheet is reported without hiding saved sheets.
  const { syncBuiltinESMExports } = await import('node:module');
  const fs = (await import('node:fs')).default;
  const originalWrite = fs.writeFileSync;
  process.env.BLOCKS_DB_PATH = join(partialDirectory, 'blocks.sqlite');
  try {
    let writes = 0;
    fs.writeFileSync = ((...args: Parameters<typeof originalWrite>) => { if (++writes === 2) throw new Error('Invented storage failure'); return originalWrite(...args); }) as typeof originalWrite;
    syncBuiltinESMExports();
    const partial = await post('filename=Partial.xlsx', fixture('invented-clients.xlsx'));
    assert.equal(partial.status, 201);
    const saved = await partial.json() as WorkbookUpload;
    assert.equal(saved.sheets.length, 1);
    assert.deepEqual(saved.skippedSheets, [{ sheetName: 'Notes', reason: 'SAVE_FAILED' }]);
  } finally { fs.writeFileSync = originalWrite; syncBuiltinESMExports(); process.env.BLOCKS_DB_PATH = join(directory, 'blocks.sqlite'); }
});
