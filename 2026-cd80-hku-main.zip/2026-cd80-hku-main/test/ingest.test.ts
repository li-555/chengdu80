import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';

import { RunContext } from '../src/compute/context.ts';
import {
  createRelationFromRows,
  jsonSchemaArgument,
  IngestError,
  type IngestColumn,
} from '../src/compute/ingest.ts';

/** All rows invented. */

let ctx: RunContext;
before(async () => { ctx = await RunContext.create(); });
after(() => ctx?.close());

const cols: IngestColumn[] = [
  { name: 'code', type: 'string' },
  { name: 'd', type: 'date' },
  { name: 'px', type: 'number' },
  { name: 'n', type: 'integer' },
  { name: 'flag', type: 'boolean' },
];

test('rows become a typed relation and the count is read back from the database', async () => {
  const { rows: n } = await createRelationFromRows(ctx, 'r1', cols, [
    { code: 'AAA', d: '2026-01-05', px: 10.5, n: 3, flag: true },
    { code: 'BBB', d: '2026-01-06', px: 20, n: 4, flag: false },
  ]);
  assert.equal(n, 2);

  const res = await ctx.query('SELECT * FROM r1 ORDER BY code');
  assert.deepEqual(res.columns.map((c) => c.name), ['code', 'd', 'px', 'n', 'flag']);
  assert.equal(res.rows[0]?.code, 'AAA');
  assert.equal(Number(res.rows[0]?.px), 10.5);
  assert.equal(res.rows[1]?.flag, false);
});

test('the types really are the declared types, not all text', async () => {
  await createRelationFromRows(ctx, 'r2', cols, [
    { code: 'AAA', d: '2026-01-05', px: 1.5, n: 1, flag: true },
  ]);
  const res = await ctx.query(
    `SELECT data_type FROM information_schema.columns
     WHERE table_name = 'r2' ORDER BY ordinal_position`,
  );
  assert.deepEqual(
    res.rows.map((r) => String(r.data_type)),
    ['VARCHAR', 'DATE', 'DOUBLE', 'BIGINT', 'BOOLEAN'],
  );
});

test('arithmetic works on an ingested number, so it was not stored as text', async () => {
  await createRelationFromRows(ctx, 'r3', cols, [
    { code: 'AAA', d: '2026-01-05', px: 10, n: 2, flag: true },
    { code: 'BBB', d: '2026-01-06', px: 20, n: 3, flag: true },
  ]);
  const res = await ctx.query('SELECT sum(px) AS total, max(d) AS last FROM r3');
  assert.equal(Number(res.rows[0]?.total), 30);
  assert.ok(res.rows[0]?.last, 'a date column must come back as a date');
});

test('a missing value becomes null rather than failing the load', async () => {
  const { rows: n } = await createRelationFromRows(ctx, 'r4', cols, [
    { code: 'AAA', d: '2026-01-05', px: 10, n: 1, flag: true },
    { code: 'BBB' },
  ]);
  assert.equal(n, 2);
  const res = await ctx.query('SELECT count(px) AS with_px FROM r4');
  assert.equal(Number(res.rows[0]?.with_px), 1);
});

test('an extra key in a row does not add a column', async () => {
  await createRelationFromRows(ctx, 'r5', cols, [
    { code: 'AAA', d: '2026-01-05', px: 10, n: 1, flag: true, surprise: 'nope' },
  ]);
  const res = await ctx.query('SELECT * FROM r5');
  assert.deepEqual(res.columns.map((c) => c.name), ['code', 'd', 'px', 'n', 'flag']);
});

test('no rows still produces a relation with the right columns', async () => {
  const { rows: n } = await createRelationFromRows(ctx, 'r6', cols, []);
  assert.equal(n, 0);
  const res = await ctx.query('SELECT * FROM r6');
  assert.deepEqual(res.columns.map((c) => c.name), ['code', 'd', 'px', 'n', 'flag']);
  assert.equal(res.rows.length, 0);
});

test('a hostile value arrives as data and is never executed', async () => {
  const hostile = "'; DROP TABLE r7; --";
  await createRelationFromRows(ctx, 'r7', [{ name: 'note', type: 'string' }], [
    { note: hostile },
    { note: 'DROP TABLE r7' },
  ]);
  const res = await ctx.query('SELECT note FROM r7 ORDER BY note');
  assert.equal(res.rows.length, 2, 'the table must still exist with both rows');
  assert.ok(res.rows.some((r) => r.note === hostile), 'the value must survive verbatim');
});

test('a column name containing a quote is handled as a name, not as SQL', async () => {
  const weird = 'odd"name';
  const { rows: n } = await createRelationFromRows(ctx, 'r8', [{ name: weird, type: 'string' }], [
    { [weird]: 'kept' },
  ]);
  assert.equal(n, 1);
  const res = await ctx.query('SELECT * FROM r8');
  assert.equal(res.columns[0]?.name, weird);
  assert.equal(res.rows[0]?.[weird], 'kept');
});

test('a bad relation name is refused before anything runs', async () => {
  for (const bad of ['has space', 'Capital', '1leading', 'semi;colon', '"quoted"', '']) {
    await assert.rejects(
      () => createRelationFromRows(ctx, bad, cols, []),
      IngestError,
      `'${bad}' should be refused`,
    );
  }
});

test('a duplicate or empty column declaration is refused', async () => {
  await assert.rejects(
    () => createRelationFromRows(ctx, 'rx', [
      { name: 'a', type: 'string' }, { name: 'A', type: 'string' },
    ], []),
    /two columns called/,
  );
  await assert.rejects(() => createRelationFromRows(ctx, 'ry', [], []), /no columns/);
});

test('a value the engine cannot read is counted, not passed over in silence', async () => {
  /**
   * `from_json` does not fail on a bad value: it writes null and loads the row. Measured
   * 2026-10-14. So the load succeeds and the loss is reported instead, because a run that
   * quietly computes on a gap is worse than one that says a value could not be read.
   */
  const result = await createRelationFromRows(
    ctx,
    'rbad',
    [{ name: 'd', type: 'date' }, { name: 'px', type: 'number' }],
    [
      { d: '2026-01-05', px: 1 },
      { d: 'not a date at all', px: 2 },
      { d: '2026-01-07', px: 'also not a number' },
    ],
  );

  assert.equal(result.rows, 3, 'every row still loads');
  assert.deepEqual(result.coercedToNull, { d: 1, px: 1 });
});

test('a genuinely absent value is not counted as a failure to read one', async () => {
  const result = await createRelationFromRows(
    ctx,
    'rgap',
    [{ name: 'd', type: 'date' }, { name: 'px', type: 'number' }],
    [{ d: '2026-01-05', px: 1 }, { d: null, px: undefined }, {}],
  );
  assert.equal(result.rows, 3);
  assert.deepEqual(result.coercedToNull, {}, 'a missing value is a gap, not a bad value');
});

test('the schema argument is built as JSON, so a quote in a name cannot break out', () => {
  const arg = jsonSchemaArgument([{ name: 'odd"name', type: 'string' }]);
  assert.equal(arg, '[{"odd\\"name":"VARCHAR"}]');
  assert.deepEqual(JSON.parse(arg), [{ 'odd"name': 'VARCHAR' }]);
});

test('two hundred thousand rows load in a reasonable time', async () => {
  const many = Array.from({ length: 200_000 }, (_, i) => ({
    code: `C${i % 997}`,
    px: i / 7,
  }));
  const t0 = Date.now();
  const { rows: n } = await createRelationFromRows(
    ctx,
    'big',
    [{ name: 'code', type: 'string' }, { name: 'px', type: 'number' }],
    many,
  );
  const took = Date.now() - t0;
  assert.equal(n, 200_000);
  assert.ok(took < 10_000, `200k rows took ${took} ms, which is far longer than expected`);
});
