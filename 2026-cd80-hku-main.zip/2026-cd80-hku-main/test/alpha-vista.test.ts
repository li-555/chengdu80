import { flagshipLogicDocument } from './flagship-test-helpers.ts';
import { readFileSync } from 'node:fs';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { validateApplication } from '../src/validate/index.ts';
import { runForScreen } from '../src/compute/result.ts';
import type { Slice } from '../src/compute/run.ts';
type Fixture = { label: string; requirements: Record<string, { fields: { name: string; type: 'text' | 'number' | 'date' | 'boolean'; nullable?: boolean }[]; rows: Record<string, string | number | boolean | null>[] }> };
const raw = JSON.parse(readFileSync(new URL('../examples/alpha-vista.fin.json', import.meta.url), 'utf8'));
const validation = validateApplication(flagshipLogicDocument('alpha-vista', raw));
assert.equal(validation.ok, true, validation.ok ? undefined : JSON.stringify(validation.errors));
if (!validation.ok) throw new Error('AlphaVista must validate before execution');
const doc = validation.document;
function fixture(): Fixture { return JSON.parse(readFileSync(new URL('./fixtures/flagship-inputs/alpha-vista.json', import.meta.url), 'utf8')); }
async function run(change?: (value: Fixture) => void, params: Record<string, unknown> = {}) {
  const input = fixture(); change?.(input);
  const slices: Record<string, Slice> = Object.fromEntries(Object.entries(input.requirements).map(([key, table]) => [key, { columns: table.fields.map((field) => ({ name: field.name, type: field.type === 'text' ? 'string' : field.type })), rows: table.rows }]));
  return runForScreen(doc, { slices, params });
}
function records(outcome: Awaited<ReturnType<typeof run>>, key: string) {
  const table = outcome.result.outputs[key]; assert(table, `Expected ${key}: ${JSON.stringify(outcome.result.failure)}`);
  return table.rows.map((values) => Object.fromEntries(table.schema.map((field,index) => [field.name, values[index]])));
}
function close(actual: unknown, expected: number) { assert.equal(typeof actual, 'number'); assert(Math.abs((actual as number)-expected)<1e-7, `${actual} must equal ${expected}`); }
test('AlphaVista is portable, declarative and uses only three separately labelled invented requirements', () => {
  assert.equal(doc.meta.name,'AlphaVista'); assert.equal(fixture().label,'Invented AlphaVista demo inputs');
  assert.deepEqual(Object.keys(fixture().requirements).sort(),doc.data.map((requirement) => requirement.key).sort());
  assert.equal(doc.compute.filter((step) => step.kind === 'code').length,1); assert.equal(doc.triggers.some((trigger) => trigger.kind === 'alert'),false);
  assert.equal(JSON.stringify(raw).includes('Invented Meadow Works'),false); assert.equal(JSON.stringify(raw).includes('example.invalid'),false);
});
test('calculates initial-capital drawdown, weighted risk and percentage-point financial measures from invented inputs', async () => {
  const result = await run(); assert.equal(result.result.status,'ok',JSON.stringify(result.result.failure));
  const portfolio = records(result,'portfolio_view')[0]!;
  close(portfolio.return_pct,-1); close(portfolio.drawdown_pct,-10); close(portfolio.concentration,52); close(portfolio.largest_weight_pct,60); close(portfolio.volatility_pct,Math.sqrt(252*.02/19)*100);
  assert.equal(portfolio.observations,20);
  const path = records(result,'portfolio_path_view'); close(path[0]!.indexed_price,100); close(path[1]!.indexed_price,90);
  const company = records(result,'company_view').find((record) => record.code==='FAKE-A')!;
  close(company.revenue_growth_pct,50); close(company.profit_growth_pct,20); close(company.cash_profit_pct,50);
  const correlations = records(result,'correlation_view'); close(correlations.find((record) => record.code==='FAKE-A'&&record.peer_code==='FAKE-B')!.correlation,1);
  assert(records(result,'disclosure_view').every((record) => String(record.detail).includes('No independent full-document review')));
});
test('changed prices and parameters change results, focus and observations without changing the document', async () => {
  const original = JSON.stringify(raw);
  const result = await run((value) => { const rows=value.requirements.market!.rows; const last=rows.filter((row) => row.code==='FAKE-A').at(-1)!; last.close=108.9; }, { focus_company:'FAKE-B',move_threshold:0.5 });
  close(records(result,'portfolio_view')[0]!.return_pct,4.94);
  assert.equal(records(result,'focus_view')[0]!.code,'FAKE-B'); assert(records(result,'observation_view').some((record) => record.title==='Movement threshold reached'));
  assert.equal(JSON.stringify(raw),original);
});
test('missing fundamentals, future disclosures and undated evidence remain visibly unavailable', async () => {
  const result = await run((value) => {
    value.requirements.fundamentals!.rows.find((row) => row.code==='FAKE-A')!.prior_profit=0;
    value.requirements.fundamentals!.rows.find((row) => row.code==='FAKE-B')!.basis='parent_only';
    value.requirements.disclosures!.rows[0]!.date='2026-10-20';
    value.requirements.disclosures!.rows[1]!.date=null;
  });
  const companies=records(result,'company_view'); assert.equal(companies.find((row) => row.code==='FAKE-A')!.profit_growth_pct,null); assert.equal(companies.find((row) => row.code==='FAKE-B')!.revenue_growth_pct,null);
  assert.equal(records(result,'disclosure_view').length,0); assert(records(result,'observation_view').some((record) => record.title==='Disclosure evidence unavailable'));
  assert(String(companies.find((row) => row.code==='FAKE-A')!.detail).includes('Unavailable fields'));
});
test('negative prices, duplicate dates and insufficient common history never produce apparently valid risk values', async () => {
  for (const change of [
    (value: Fixture) => { value.requirements.market!.rows[1]!.close=-90; },
    (value: Fixture) => { value.requirements.market!.rows.push({...value.requirements.market!.rows[0]!}); },
    (value: Fixture) => { value.requirements.market!.rows=value.requirements.market!.rows.filter((row) => row.date!=='2026-09-17'); },
  ]) {
    const result=await run(change); assert.equal(result.result.status,'ok'); const portfolio=records(result,'portfolio_view')[0]!; assert.equal(portfolio.status,'Unavailable'); assert.equal(portfolio.volatility_pct,null); assert.equal(portfolio.return_pct,null);
  }
});
test('watchlist filtering normalises supplied weights only by explicit setting and short-window risk reports missing history', async () => {
  const selected=await run(undefined,{watchlist:['FAKE-A']}); close(records(selected,'portfolio_view')[0]!.concentration,100);
  const unnormalised=await run(undefined,{watchlist:['FAKE-A'],normalise_weights:false}); assert.equal(records(unnormalised,'portfolio_view')[0]!.status,'Unavailable');
  const short=await run(undefined,{start_date:'2026-10-12'}); assert.equal(records(short,'portfolio_view')[0]!.volatility_pct,null); assert(String(records(short,'portfolio_view')[0]!.detail).includes('common return observations'));
});
test('invalid holding weights suppress concentration as well as historical risk; constant-return correlation stays null', async () => {
  const invalid=await run((value) => { for(const row of value.requirements.market!.rows)if(row.code==='FAKE-A')row.weight=-0.6; });
  const portfolio=records(invalid,'portfolio_view')[0]!; assert.equal(portfolio.status,'Unavailable'); assert.equal(portfolio.concentration,null); assert.equal(portfolio.largest_weight_pct,null); assert.equal(portfolio.return_pct,null);
  const constant=await run((value) => { for(const row of value.requirements.market!.rows)if(row.code==='FAKE-B')row.close=100; });
  assert.equal(records(constant,'correlation_view').find((record) => record.code==='FAKE-A'&&record.peer_code==='FAKE-B')!.correlation,null);
});
test('valuation cutoff, duplicate statement versions and source failures are shown instead of silently selecting numbers', async () => {
  const result=await run((value) => {
    value.requirements.fundamentals!.rows[0]!.valuation_date='2026-10-15';
    value.requirements.fundamentals!.rows.push({...value.requirements.fundamentals!.rows[1]!});
    value.requirements.disclosures!.rows[0]!.source_url='javascript:alert(1)';
  });
  const companies=records(result,'company_view'); assert.equal(companies.find((row) => row.code==='FAKE-A')!.pe,null); assert.equal(companies.find((row) => row.code==='FAKE-A')!.valuation_date,null);
  const duplicate=companies.find((row) => row.code==='FAKE-B')!; assert.equal(duplicate.revenue_growth_pct,null); assert(String(duplicate.detail).includes('Duplicate statement version')); assert(String(duplicate.peer_status).includes('not comparable'));
  assert(records(result,'observation_view').some((record) => record.title==='Disclosure evidence unavailable'));
});
test('unknown focus and empty watchlist matches are explicit, while invalid dates/nonfinite input cannot become valid results', async () => {
  const unknown=await run(undefined,{focus_company:'NOT-IN-INVENTED-DATA'}); assert.equal(records(unknown,'focus_view').length,0); assert(records(unknown,'observation_view').some((record) => record.title==='Focus company unavailable'));
  const empty=await run(undefined,{watchlist:['NOT-IN-INVENTED-DATA']}); assert.equal(records(empty,'company_view').length,0); assert(records(empty,'observation_view').some((record) => record.title==='No matching companies'));
  const reversed=await run(undefined,{start_date:'2026-10-14',end_date:'2026-09-01'}); assert.equal(reversed.result.status,'failed');
  const infinite=await run((value) => { value.requirements.market!.rows[0]!.close=Infinity; }); assert.equal(infinite.result.status,'partial'); assert.equal(records(infinite,'portfolio_view')[0]!.volatility_pct,null); assert.equal(records(infinite,'portfolio_view')[0]!.status,'Unavailable');
});
function fiveCloses(value: Fixture) {
  const rows=value.requirements.market!.rows.filter((row) => row.code==='FAKE-A').slice(0,5);
  [10,12,9,15,18].forEach((price,index) => { rows[index]!.close=price; });
  value.requirements.market!.rows=rows.reverse();
}
test('sorted historical closes produce hand-calculated full-window averages and observed-session momentum', async () => {
  const result=await run(fiveCloses,{average_window:3,momentum_lookback:2});
  const path=records(result,'trend_view'); assert.deepEqual(path.map((row) => row.date),['2026-09-16','2026-09-17','2026-09-18','2026-09-21','2026-09-22']);
  assert.equal(path[0]!.moving_average,null); assert.equal(path[1]!.moving_average,null); assert.equal(path[1]!.momentum_pct,null);
  close(path[2]!.moving_average,31/3); close(path[2]!.momentum_pct,-10); assert.equal(path[2]!.trend_status,'Below average');
  const latest=records(result,'trend_summary_view')[0]!; close(latest.moving_average,14); close(latest.momentum_pct,100); close(latest.price_vs_average_pct,100*(18/14-1)); assert.equal(latest.trend_status,'Above average');
  const changed=await run(fiveCloses,{average_window:2,momentum_lookback:1});
  close(records(changed,'trend_summary_view')[0]!.moving_average,16.5); close(records(changed,'trend_summary_view')[0]!.momentum_pct,20);
  assert.equal(records(changed,'trend_view')[0]!.momentum_pct,null);
});
test('trend windows distinguish missing history from genuine zero change and respect focus selection', async () => {
  const short=await run(fiveCloses,{average_window:6,momentum_lookback:5});
  const latest=records(short,'trend_summary_view')[0]!; assert.equal(latest.moving_average,null); assert.equal(latest.momentum_pct,null); assert.equal(latest.price_vs_average_pct,null); assert.equal(latest.trend_status,'Unavailable');
  assert(String(latest.detail).includes('6 observed closes'));
  const constant=await run(undefined,{focus_company:'FAKE-C'}); const flat=records(constant,'trend_summary_view')[0]!;
  assert.equal(flat.code,'FAKE-C'); close(flat.moving_average,100); close(flat.momentum_pct,0); close(flat.price_vs_average_pct,0); assert.equal(flat.trend_status,'At average');
  const defaults=await run(); close(records(defaults,'trend_summary_view')[0]!.moving_average,99); close(records(defaults,'trend_summary_view')[0]!.momentum_pct,0);
  close(records(defaults,'portfolio_view')[0]!.return_pct,-1); close(records(defaults,'portfolio_view')[0]!.drawdown_pct,-10);
});
test('invalid or duplicate prices suppress trend comparisons instead of skipping to a false valid trend', async () => {
  for(const change of [
    (value: Fixture) => { fiveCloses(value); value.requirements.market!.rows[1]!.close=0; },
    (value: Fixture) => { fiveCloses(value); value.requirements.market!.rows[1]!.close=null; },
    (value: Fixture) => { fiveCloses(value); value.requirements.market!.rows.push({...value.requirements.market!.rows[0]!}); },
  ]) {
    const result=await run(change,{average_window:2,momentum_lookback:1});
    const latest=records(result,'trend_summary_view')[0]!; assert.equal(latest.moving_average,null); assert.equal(latest.momentum_pct,null); assert.equal(latest.price_vs_average_pct,null); assert.equal(latest.close_price,null); assert.equal(latest.trend_status,'Unavailable');
    assert(records(result,'trend_view').every((row) => row.moving_average===null&&row.momentum_pct===null));
  }
  const invalid=await run(undefined,{average_window:2.5}); assert.equal(invalid.result.status,'failed');
});
test('company choices follow the watchlist, remain independent of focus and exclude invalid or future IDs', async () => {
  const result=await run(value=>{
    const row=value.requirements.market!.rows[0]!;
    for(const code of ['', ' ', ' bad ', 'bad\ncode'])value.requirements.market!.rows.push({...row,code});
    value.requirements.market!.rows.push({...row,code:'FUTURE',date:'2026-10-20'});
  },{watchlist:['FAKE-A'],focus_company:'FAKE-A'});
  const choices=records(result,'pick_focus_company');
  assert.equal(choices.find(r=>r.value==='')!.label,'First company in watchlist');
  assert.deepEqual(choices.map(r=>r.value).sort(),['','FAKE-A']);
  const allChoices=records(await run(undefined,{focus_company:'FAKE-A'}),'pick_focus_company');
  assert.equal(new Set(choices.map(r=>r.value)).size,choices.length);
  assert(choices.every(r=>typeof r.value==='string'&&typeof r.label==='string'&&String(r.label).includes(String(r.value))));
  const switched=await run(undefined,{focus_company:String(allChoices.find(r=>r.value==='FAKE-B')!.value)});
  assert.equal(records(switched,'focus_view')[0]!.code,'FAKE-B');
  assert.equal(records(switched,'pick_focus_company').length,4);
  const table=result.result.outputs.pick_focus_company!;
  assert(table.schema.filter(f=>['value','label'].includes(f.name)).every(f=>f.type==='text'));
});
test('monitor conditions keep identity across values and distinguish clear from missing evidence', async () => {
 const first=await run(); assert.deepEqual(first.result.outputs.monitor_events!.schema.map(c=>[c.name,c.type]),['event_id','title','status','value','detail','source_url'].map(n=>[n,'text'])); const events=records(first,'monitor_events'); const price=events.find(r=>String(r.event_id).includes('price_move'))!;
 assert(price); assert.equal(events.filter(r=>r.event_id==='coverage').length,1);
 const changed=records(await run(undefined,{move_threshold:0}),'monitor_events').find(r=>r.event_id===price.event_id)!;
 assert.equal(changed.status,'active');
 const clear=records(await run(undefined,{move_threshold:1000}),'monitor_events').find(r=>r.event_id===price.event_id)!; assert.equal(clear.status,'clear');
 const missing=records(await run(v=>{for(const r of v.requirements.market!.rows)r.close=null;}),'monitor_events').find(r=>r.event_id===price.event_id)!;assert.equal(missing.status,'unknown');
 for(const r of events)for(const k of ['event_id','title','status','value','detail','source_url'])assert.equal(typeof r[k],'string');
 assert.equal(records(first,'company_view').length,3);
 const empty=records(await run(v=>{for(const t of Object.values(v.requirements))t.rows=[];}),'monitor_events');assert.equal(empty.find(r=>r.event_id==='coverage')!.status,'unknown');
});
