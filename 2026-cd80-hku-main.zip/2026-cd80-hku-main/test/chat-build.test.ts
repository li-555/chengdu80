import { test, before, after, beforeEach } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import express from 'express';
import type { AddressInfo } from 'node:net';
import { MockLanguageModelV4 } from 'ai/test';
import { createChatRouter } from '../src/api/routes-chat.ts';
import { getApp, listApps, getDraft, listDrafts } from '../src/platform/storage.ts';
import { closeStorage } from '../src/platform/database.ts';
import type { AppDocument } from '../src/app-schema/index.ts';

/**
 * The chat route with a scripted model: the first build saves a new app, a follow-up in the
 * same conversation changes that app, and a failed build leaves a draft. Everything is invented.
 */

const directory = mkdtempSync(join(tmpdir(), 'blocks-chat-build-'));
const previousPath = process.env.BLOCKS_DB_PATH;
before(() => { process.env.BLOCKS_DB_PATH = join(directory, 'storage.sqlite'); });
after(() => {
  closeStorage();
  if (previousPath === undefined) delete process.env.BLOCKS_DB_PATH;
  else process.env.BLOCKS_DB_PATH = previousPath;
  rmSync(directory, { recursive: true, force: true });
});

const VALID: AppDocument = JSON.parse(readFileSync(new URL('../examples/ex-01-daily-movers.fin.json', import.meta.url), 'utf8'));
const usage = { inputTokens: { total: 1, noCache: 1, cacheRead: 0, cacheWrite: 0 }, outputTokens: { total: 1, text: 1, reasoning: 0 } };
let n = 0;
const submit = (application: unknown) => ({
  content: [{ type: 'tool-call' as const, toolCallId: `c${++n}`, toolName: 'submit_application', input: JSON.stringify({ application }) }],
  finishReason: { unified: 'tool-calls' as const, raw: 'tool_calls' }, usage, warnings: [],
});

/** Every model call submits the next document in the queue. */
const queue: unknown[] = [];
const model = new MockLanguageModelV4({ doGenerate: async () => submit(queue.shift()) });

beforeEach(() => { queue.length = 0; });

async function chat(body: Record<string, unknown>): Promise<Record<string, unknown>[]> {
  const app = express();
  app.use(createChatRouter({ model: () => model }));
  const server = app.listen(0, '127.0.0.1');
  await new Promise((r) => server.once('listening', r));
  try {
    const r = await fetch(`http://127.0.0.1:${(server.address() as AddressInfo).port}/api/chat`, {
      method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ profile: 'tester', ...body }),
    });
    const text = await r.text();
    return text.split('\n').filter((l) => l.startsWith('data: ')).map((l) => JSON.parse(l.slice(6)));
  } finally {
    await new Promise((r) => server.close(r));
  }
}

test('chat: a follow-up changes the same app; a failed build leaves a draft', async () => {
  queue.push(VALID);
  const first = await chat({ message: 'show me the biggest movers' });
  const conversationId = first[0]!.conversationId;
  const built = first.at(-1)!;
  assert.equal(built.kind, 'built', JSON.stringify(built));
  assert.equal(built.updated, false);

  const renamed = structuredClone(VALID);
  renamed.meta.name = 'Movers, renamed';
  queue.push(renamed);
  const second = (await chat({ conversationId, message: 'call it Movers, renamed' })).at(-1)!;
  assert.equal(second.kind, 'built', JSON.stringify(second));
  assert.equal(second.appId, built.appId, 'the same app, not a new one');
  assert.equal(second.updated, true);
  assert.equal((await listApps('tester')).length, 1);
  const stored = await getApp(built.appId as string);
  assert.equal(stored!.doc.meta.name, 'Movers, renamed');
  assert.equal(stored!.rev, 2);
  assert.equal(stored!.history!.length, 1);

  const broken = structuredClone(VALID) as unknown as { compute: { op: string }[] };
  broken.compute[0]!.op = 'not_an_operation';
  queue.push(broken, broken, broken, broken);
  const failed = (await chat({ message: 'something new' })).at(-1)!;
  assert.equal(failed.kind, 'failed', JSON.stringify(failed));
  assert.equal(failed.draft, undefined, 'the draft document is not sent to the screen');
  assert.equal(typeof failed.draftId, 'string');
  const draft = await getDraft(failed.draftId as string, 'tester');
  assert.ok(draft && draft.errors.length > 0);
  assert.equal((await listDrafts('tester')).length, 1);
  assert.equal((await listApps('tester')).length, 1, 'a failed build saves no app');
});

test('chat: another profile never continues a conversation, so it never changes that profile\'s app', async () => {
  queue.push(VALID);
  const first = await chat({ message: 'movers', profile: 'alice' });
  const built = first.at(-1)!;
  queue.push(VALID);
  const other = await chat({ conversationId: first[0]!.conversationId, message: 'rename it', profile: 'bob' });
  assert.notEqual(other[0]!.conversationId, first[0]!.conversationId, 'a new conversation');
  assert.equal(other.at(-1)!.updated, false);
  const renamed = structuredClone(VALID);
  renamed.meta.name = 'Alice renamed';
  queue.push(renamed);
  const back = (await chat({ conversationId: first[0]!.conversationId, message: 'rename it', profile: 'alice' })).at(-1)!;
  assert.equal(back.appId, built.appId, 'alice still updates her own app');
  assert.equal((await listApps('alice')).length, 1);
});

test('chat: when the draft cannot be kept, the failure says so and carries no draft', async () => {
  const huge = structuredClone(VALID) as unknown as Record<string, unknown> & { compute: { op: string }[] };
  huge.compute[0]!.op = 'not_an_operation';
  // Over the 2 MB draft limit: invented filler, the same in every submission.
  huge.filler = 'x'.repeat(2_200_000);
  queue.push(huge, huge, huge, huge);
  const events = await chat({ message: 'something too big', profile: 'carol' });
  const last = events.at(-1)!;
  assert.equal(events.filter((e) => e.kind === 'failed').length, 1);
  assert.equal(last.kind, 'failed');
  assert.equal(last.draftId, undefined);
  assert.equal(last.draft, undefined);
  assert.equal(last.errors, undefined);
  assert.doesNotMatch(String(last.summary), /saved my draft/);
  assert.equal((await listDrafts('carol')).length, 0);
});
