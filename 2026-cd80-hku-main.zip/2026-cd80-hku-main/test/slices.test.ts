import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import type { AppDocument } from '../src/app-schema/index.ts';
import type { DataRequirement, RequirementFilter } from '../src/app-schema/data.ts';
import type { Dataset, FieldSpec, SliceRequest } from '../src/data/types.ts';
import { fetchSlicesFor, NeedsBindingError, NeedsMappingError, type FetchSlicesOptions } from '../src/compute/slices.ts';
import { runForScreen } from '../src/compute/result.ts';
import { validateApplication } from '../src/validate/index.ts';

const checked = validateApplication(JSON.parse(readFileSync(new URL('../examples/ex-01-daily-movers.fin.json', import.meta.url), 'utf8')));
if (!checked.ok) throw new Error('the example must be valid');
const example = checked.document;

function field(name: string, type: FieldSpec['type'] = 'text'): FieldSpec {
  return { name, label: name, type, nullable: true };
}

const dataset: Dataset = {
  id: 'invented:prices', name: 'Invented prices', source: 'tushare',
  fields: [field('ts_code'), field('trade_date', 'date'), field('close', 'number'), field('pre_close', 'number'), field('name')],
};

function document(data: DataRequirement[], params: AppDocument['params'] = []): AppDocument {
  return { ...example, data, params, compute: [] };
}

function requirement(key = 'prices'): DataRequirement {
  return {
    key, datasetHint: dataset.id,
    fields: [{ name: 'close', type: 'number', required: true }],
  };
}

function fixture(rows: unknown[][] = [[12]], schema = [field('close', 'number')]) {
  const requests: SliceRequest[] = [];
  const deps: NonNullable<FetchSlicesOptions['deps']> = {
    getDataset: async (id) => id === dataset.id || id === 'tushare:daily' ? { ...dataset, id } : null,
    isTradingDay: async (date) => {
      const day = new Date(`${date}T00:00:00Z`).getUTCDay();
      return day !== 0 && day !== 6 && date !== '2026-01-19';
    },
    resolve: async (request) => {
      requests.push(request);
      return { schema, rows, asOfDate: '2026-02-14', datasetVersion: 'invented-v1' };
    },
  };
  return { requests, deps };
}

test('daily movers binds semantic fields, sends default watchlist and runs on invented prices', async () => {
  const { requests, deps } = fixture([
    ['600000.SH', '20260213', 12.5, 10],
    ['000001.SZ', '20260213', 45, 50],
    ['600000.SH', '20260212', 10.2, 10],
  ], dataset.fields.slice(0, 4));
  const fetched = await fetchSlicesFor(example, {
    today: '2026-02-14', deps,
    mappings: { prices: { px: 'close', prev_px: 'pre_close' } },
  });
  assert.deepEqual(requests, [{
    datasetId: 'tushare:daily', fields: ['ts_code', 'trade_date', 'close', 'pre_close'],
    dateFrom: '2026-01-02', dateTo: '2026-02-14', filter: { ts_code: '600000.SH,000001.SZ' },
  }]);
  const { result } = await runForScreen(example, { slices: fetched.slices });
  assert.equal(result.status, 'ok', result.failure?.message);
  assert.deepEqual(result.outputs.movers!.rows.map((r) => [r[0], r[2], r[4]]), [
    ['600000.SH', 12.5, 25], ['000001.SZ', 45, -10],
  ]);
  assert.equal(fetched.sources[0]!.rows, 3);
  assert.equal(fetched.sources[0]!.asOfDate, '2026-02-14');
  assert.equal(fetched.sources[0]!.datasetVersion, 'invented-v1');
  assert.ok(fetched.sources[0]!.durationMs >= 0);
  assert.deepEqual(JSON.parse(JSON.stringify(fetched)), fetched);
});

test('collects missing bindings and unknown datasets before requests', async () => {
  const { deps, requests } = fixture();
  await assert.rejects(fetchSlicesFor(document([
    { ...requirement('first'), datasetHint: undefined },
    { ...requirement('second'), datasetHint: 'missing:table' },
  ]), { deps }), (error: unknown) => {
    assert.ok(error instanceof NeedsBindingError);
    assert.deepEqual(error.problems, [{ key: 'first' }, { key: 'second', datasetId: 'missing:table' }]);
    assert.match(error.message, /first.*second.*missing:table/);
    return true;
  });
  assert.equal(requests.length, 0);
});

test('collects every required unmatched field with dataset suggestions', async () => {
  const { deps, requests } = fixture();
  const req = requirement();
  req.fields = ['price', 'quantity'].map((name) => ({ name, type: 'number', required: true }));
  await assert.rejects(fetchSlicesFor(document([req, { ...req, key: 'other' }]), { deps }), (error: unknown) => {
    assert.ok(error instanceof NeedsMappingError);
    assert.deepEqual(error.problems.map((p) => `${p.key}.${p.field}`), ['prices.price', 'prices.quantity', 'other.price', 'other.quantity']);
    assert.deepEqual(error.problems[0]!.suggestions, dataset.fields.map((f) => f.name));
    assert.match(error.message, /close/);
    return true;
  });
  assert.equal(requests.length, 0);
});

test('bindings override hints; explicit mappings, case matching and repeated mappings retain app names', async () => {
  const { deps, requests } = fixture();
  const req = requirement();
  req.datasetHint = 'missing';
  req.fields = [
    { name: 'CLOSE', type: 'number', required: true },
    { name: 'price', type: 'text', required: true },
    { name: 'absent', type: 'number', required: false },
  ];
  const { slices } = await fetchSlicesFor(document([req]), {
    deps, bindings: { prices: dataset.id }, mappings: { prices: { price: 'close' } },
  });
  assert.deepEqual(requests[0]!.fields, ['close']);
  assert.deepEqual(slices.prices, {
    columns: [{ name: 'CLOSE', type: 'number' }, { name: 'price', type: 'string' }, { name: 'absent', type: 'number' }],
    rows: [{ CLOSE: 12, price: '12', absent: null }],
  });
});

test('an invalid explicit mapping does not fall back to matching by name', async () => {
  const { deps } = fixture();
  await assert.rejects(fetchSlicesFor(document([requirement()]), {
    deps, mappings: { prices: { close: 'missing' } },
  }), NeedsMappingError);
});

test('number and contains filters run after conversion; empty lists are skipped and noted', async () => {
  const { deps, requests } = fixture([['9', 'ALPHA'], ['12', 'Alpha company'], ['15', 'Beta']], [field('close', 'number'), field('name')]);
  const req = requirement();
  req.fields.push({ name: 'name', type: 'text', required: true });
  req.filters = [
    { field: 'close', op: 'gt', param: 'min' },
    { field: 'name', op: 'contains', param: 'search' },
    { field: 'name', op: 'in', param: 'empty' },
  ];
  const { slices, sources } = await fetchSlicesFor(document([req], [
    { key: 'min', label: 'Minimum', type: 'number', default: 10 },
    { key: 'search', label: 'Search', type: 'text', default: 'aLpHa' },
    { key: 'empty', label: 'Empty', type: 'text', list: true, default: [] },
  ]), { deps });
  assert.deepEqual(requests[0]!.filter, {});
  assert.deepEqual(slices.prices!.rows, [{ close: 12, name: 'Alpha company' }]);
  assert.deepEqual(sources[0]!.filtersAppliedAfter, ['close > 10', 'name contains aLpHa', 'skipped: name has no value']);
});

for (const bad of ['600000.SH,000001.SZ', '600000 SH']) {
  test(`refuses invalid watchlist entry ${JSON.stringify(bad)} before requests`, async () => {
    const { deps, requests } = fixture();
    await assert.rejects(fetchSlicesFor(example, {
      deps, today: '2026-02-14', params: { watchlist: [bad] },
      mappings: { prices: { px: 'close', prev_px: 'pre_close' } },
    }), /prices:.*invalid security code/);
    assert.equal(requests.length, 0);
  });
}

test('uploads and external APIs resolve with date bounds and apply every filter locally without provider parameters', async () => {
  const uploadedRows = [
    ['Invented A', '2026-02-11', '12'],
    ['Invented A', '2026-02-12', '12'],
    ['Invented A', '2026-02-13', '14'],
    ['Invented B', '2026-02-13', '20'],
    ['Invented A', '2026-02-13', '8'],
    ['Invented A', '2026-02-14', '16'],
    ['Invented A', '2026-02-15', '18'],
  ];
  for (const source of ['upload', 'api'] as const) for (const op of ['eq', 'in'] as const) {
    const { deps, requests } = fixture();
    deps.getDataset = async () => ({ ...dataset, source });
    deps.resolve = async (request) => {
      requests.push(request);
      return {
        schema: dataset.fields.slice(0, 3),
        rows: uploadedRows.filter((row) => row[1]! >= request.dateFrom! && row[1]! <= request.dateTo!),
        datasetVersion: 'invented-v1',
      };
    };
    const req = requirement();
    req.fields = [
      { name: 'code', type: 'text', required: true, semantic: 'security_code' },
      { name: 'date', type: 'date', required: true, semantic: 'trade_date' },
      ...req.fields,
    ];
    req.filters = [{ field: 'code', op, param: 'codes' }, { field: 'close', op: 'gt', param: 'minimum' }];
    req.window = { field: 'date', lookbackDays: 2 };
    const doc = document([req], [
      { key: 'codes', label: 'Codes', type: 'text' },
      { key: 'minimum', label: 'Minimum', type: 'number' },
    ]);
    const { slices, sources } = await fetchSlicesFor(doc, {
      deps, today: '2026-02-14', params: { codes: op === 'in' ? ['Invented A'] : 'Invented A', minimum: 10 },
    });
    assert.deepEqual(requests, [{
      datasetId: dataset.id, fields: ['ts_code', 'trade_date', 'close'],
      dateFrom: '2026-02-12', dateTo: '2026-02-14',
    }]);
    assert.deepEqual(slices.prices!.rows, [
      { code: 'Invented A', date: '2026-02-12', close: 12 },
      { code: 'Invented A', date: '2026-02-13', close: 14 },
      { code: 'Invented A', date: '2026-02-14', close: 16 },
    ]);
    assert.deepEqual(sources[0]!.filtersSentToProvider, {});
    assert.deepEqual(sources[0]!.filtersAppliedAfter, [
      op === 'in' ? 'code in ["Invented A"]' : 'code = Invented A', 'close > 10',
    ]);
    assert.equal(sources[0]!.datasetSource, source);
    assert.equal(sources[0]!.dateFrom, '2026-02-12');
    assert.equal(sources[0]!.dateTo, '2026-02-14');
  }
});

test('reads returned schema by name, normalises dates and counts unreadable values', async () => {
  const { deps } = fixture([
    ['20260213', 'bad', 'true'], ['20260230', '14.5', '0'], [null, null, 'unknown'],
  ], [field('trade_date', 'date'), field('close', 'text'), field('flag', 'boolean')]);
  deps.getDataset = async () => ({ ...dataset, fields: [...dataset.fields, field('flag', 'boolean')] });
  const req = requirement();
  req.fields.push({ name: 'd', type: 'date', required: true, semantic: 'trade_date' }, { name: 'flag', type: 'boolean', required: true });
  const { slices, sources } = await fetchSlicesFor(document([req]), { deps });
  assert.deepEqual(slices.prices!.rows, [
    { close: null, d: '2026-02-13', flag: true }, { close: 14.5, d: null, flag: false }, { close: null, d: null, flag: null },
  ]);
  assert.equal(sources[0]!.warnings.length, 3);
  assert.match(sources[0]!.warnings[0]!, /close: 1 value.*null/);
});

test('one trading day on Saturday starts on Friday', async () => {
  const { deps, requests } = fixture();
  const req = requirement();
  req.window = { field: 'close', lookbackDays: 1 };
  await fetchSlicesFor(document([req]), { deps, today: '2026-02-14' });
  assert.equal(requests[0]!.dateFrom, '2026-02-13');
  assert.equal(requests[0]!.dateTo, '2026-02-14');
});

test('window includes today when open, refuses unknown fields and bounds calendar searches', async () => {
  const { deps, requests } = fixture();
  const req = requirement();
  req.window = { field: 'close', lookbackDays: 1 };
  await fetchSlicesFor(document([req]), { deps, today: '2026-02-13' });
  assert.equal(requests[0]!.dateFrom, '2026-02-13');
  req.window.field = 'missing';
  await assert.rejects(fetchSlicesFor(document([req]), { deps }), /prices: window field 'missing'/);
  req.window.field = 'close';
  let calls = 0;
  deps.isTradingDay = async () => { calls++; return false; };
  await assert.rejects(fetchSlicesFor(document([req]), { deps, today: '2026-02-14' }), /within 32 calendar days/);
  assert.equal(calls, 32);
});

test('settings overrides and explicit missing values follow run parameter resolution', async () => {
  for (const value of [undefined, null, []]) {
    const { deps, requests } = fixture();
    const { sources } = await fetchSlicesFor(example, {
      deps, today: '2026-02-14', params: { watchlist: value },
      mappings: { prices: { px: 'close', prev_px: 'pre_close' } },
    });
    assert.deepEqual(requests[0]!.filter, {});
    assert.deepEqual(sources[0]!.filtersAppliedAfter, ['skipped: code has no value']);
  }
});

for (const [op, value, expected] of [
  ['eq', '10', [10]], ['neq', 10, [9, 11]], ['gt', 10, [11]], ['gte', 10, [10, 11]],
  ['lt', 10, [9]], ['lte', 10, [9, 10]], ['in', ['9', '11'], [9, 11]], ['not_in', ['9', '11'], [10]],
] as const) {
  test(`applies ${op} locally with numeric comparisons`, async () => {
    const { deps } = fixture([[9], [10], [11], [null]]);
    const req = requirement();
    req.filters = [{ field: 'close', op, param: 'value' }];
    const doc = document([req], [{ key: 'value', label: 'Value', type: 'number' }]);
    const { slices } = await fetchSlicesFor(doc, { deps, params: { value } });
    assert.deepEqual(slices.prices!.rows.map((r) => r.close), expected);
  });
}

test('requirements resolve one at a time and failures carry the key and cause', async () => {
  const { deps } = fixture();
  let active = 0;
  const seen: string[] = [];
  const failure = new Error('invented provider failure');
  deps.resolve = async (request) => {
    assert.equal(active, 0);
    active++;
    await new Promise((done) => setImmediate(done));
    seen.push(request.datasetId);
    active--;
    if (seen.length === 2) throw failure;
    return { schema: [field('close', 'number')], rows: [[10]], datasetVersion: 'invented-v1' };
  };
  await assert.rejects(fetchSlicesFor(document([requirement('first'), requirement('second')]), { deps }), (error: unknown) => {
    assert.ok(error instanceof Error);
    assert.equal(error.message, 'second: invented provider failure');
    assert.equal(error.cause, failure);
    return true;
  });
  assert.equal(seen.length, 2);
});
