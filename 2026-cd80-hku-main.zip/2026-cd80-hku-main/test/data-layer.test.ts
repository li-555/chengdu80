import { test } from 'node:test';
import assert from 'node:assert/strict';
import { writeFileSync, mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import { inferSchema } from '../src/data/file-upload.ts';
import {
  isTradingDay,
  nextTradingDay,
  marketTimes,
  primeCalendar,
  clearCalendarCache,
} from '../src/data/trading-cal.ts';
import { listDatasets, registerUpload } from '../src/data/index.ts';
import { resolveSliceWith, clearSliceCache } from '../src/data/resolve-slice.ts';

/**
 * Every row in this file is invented. Nothing here is real market data.
 */

// ---------------------------------------------------------------- type inference

test('a code column keeps its leading zero instead of becoming a number', () => {
  const { fields } = inferSchema(['ts_code', 'close'], [
    ['000001', '12.5'],
    ['000002', '13.0'],
  ]);
  assert.equal(fields[0]?.type, 'text', 'ts_code must be text, or 000001 becomes 1');
  assert.equal(fields[1]?.type, 'number');
});

test('a digits-only column with a leading zero is text even when its name says nothing', () => {
  const { fields } = inferSchema(['thing'], [['001'], ['002']]);
  assert.equal(fields[0]?.type, 'text');
});

test('a plain integer column is still a number', () => {
  const { fields } = inferSchema(['volume'], [['1200'], ['340']]);
  assert.equal(fields[0]?.type, 'number');
});

test('eight digits in a date column is read as a date, not twenty million', () => {
  const { fields } = inferSchema(['trade_date', 'px'], [
    ['20260114', '9.9'],
    ['20260115', '9.8'],
  ]);
  assert.equal(fields[0]?.type, 'date');
  assert.equal(fields[1]?.type, 'number');
});

test('a column that is empty throughout is text and nullable', () => {
  const { fields } = inferSchema(['note'], [[''], ['']]);
  assert.equal(fields[0]?.type, 'text');
  assert.equal(fields[0]?.nullable, true);
});

test('a short row does not shift the columns after it', () => {
  const { fields } = inferSchema(['a', 'b', 'c'], [['1', '2'], ['3', '4', '5']]);
  assert.equal(fields.length, 3);
  assert.equal(fields[2]?.nullable, true);
});

test('a CSV upload round-trips through registerUpload', async () => {
  const dir = mkdtempSync(join(tmpdir(), 'blocks-upload-'));
  const file = join(dir, 'clients.csv');
  writeFileSync(file, 'client_code,risk_level\n000001,3\n000002,5\n', 'utf-8');

  const ds = await registerUpload(file, 'clients');
  assert.equal(ds.fields.length, 2);
  assert.equal(ds.fields[0]?.type, 'text', 'client_code must survive as text');
  assert.equal(ds.source, 'upload');
});

// ---------------------------------------------------------------- trading calendar

const dec2026 = [
  { date: '2026-12-29', open: true },
  { date: '2026-12-30', open: true },
  { date: '2026-12-31', open: false },
];
const jan2027 = [
  { date: '2027-01-01', open: false },
  { date: '2027-01-02', open: false },
  { date: '2027-01-03', open: false },
  { date: '2027-01-04', open: true },
];

test('a closed day reports closed and has no market times', async () => {
  clearCalendarCache();
  primeCalendar('2026', dec2026);
  assert.equal(await isTradingDay('2026-12-31'), false);
  assert.equal(await marketTimes('2026-12-31'), null);
});

test('an open day reports its opening and closing time', async () => {
  clearCalendarCache();
  primeCalendar('2026', dec2026);
  assert.deepEqual(await marketTimes('2026-12-30'), { open: '09:30', close: '15:00' });
});

test('the next trading day is found across the year boundary', async () => {
  clearCalendarCache();
  primeCalendar('2026', dec2026);
  primeCalendar('2027', jan2027);
  assert.equal(
    await nextTradingDay('2026-12-30'),
    '2027-01-04',
    'a search starting in December must reach January',
  );
});

test('a date the calendar has no record of raises an error, never a quiet false', async () => {
  clearCalendarCache();
  primeCalendar('2026', dec2026);
  await assert.rejects(
    () => isTradingDay('2026-06-01'),
    /no record of 2026-06-01/,
    'a quiet false is indistinguishable from a holiday, so a trigger would never fire',
  );
});

test('a calendar year that returned nothing raises an error rather than closing the market', async () => {
  clearCalendarCache();
  primeCalendar('2030', []);
  await assert.rejects(() => isTradingDay('2030-03-04'), /no record of/);
});

// ---------------------------------------------------------------- the rest

// ---------------------------------------------------------------- resolveSlice

test('resolveSlice maps rows by column name, never by position', async () => {
  clearSliceCache();
  const slice = await resolveSliceWith(
    { datasetId: 'tushare:daily', fields: ['ts_code', 'close', 'trade_date'] },
    async () => ({
      fields: ['trade_date', 'close', 'ts_code'], // reversed on purpose
      rows: [['20261012', 11.32, '000001.SZ']],
    }),
  );
  assert.deepEqual(slice.schema.map((f) => f.name), ['ts_code', 'close', 'trade_date']);
  assert.deepEqual(slice.rows, [['000001.SZ', 11.32, '20261012']]);
  assert.equal(slice.asOfDate, '2026-10-12');
  assert.equal(slice.datasetVersion, '1.0.0');
});

test('resolveSlice fails loudly for an unknown dataset', async () => {
  await assert.rejects(
    () => resolveSliceWith({ datasetId: 'tushare:nope', fields: ['close'] }, async () => ({ fields: [], rows: [] })),
    /not found/,
    'a typo in a dataset id must not read as an empty result',
  );
});

test('resolveSlice fails loudly for a field the dataset does not have', async () => {
  await assert.rejects(
    () => resolveSliceWith({ datasetId: 'tushare:daily', fields: ['not_a_field'] }, async () => ({ fields: [], rows: [] })),
    /not in dataset/,
  );
});

test('resolveSlice respects its row limit', async () => {
  clearSliceCache();
  const rows = [
    ['000001.SZ', '20261012', 1],
    ['000001.SZ', '20261011', 2],
    ['000001.SZ', '20261010', 3],
  ];
  const slice = await resolveSliceWith(
    { datasetId: 'tushare:daily', fields: ['ts_code', 'trade_date', 'close'], limit: 2 },
    async () => ({ fields: ['ts_code', 'trade_date', 'close'], rows }),
  );
  assert.equal(slice.rows.length, 2);
});

test('resolveSlice reads rows of an uploaded file', async () => {
  clearSliceCache();
  const dir = mkdtempSync(join(tmpdir(), 'blocks-upload-'));
  const file = join(dir, 'clients.csv');
  writeFileSync(file, 'client_code,risk_level\n000001,3\n000002,5\n', 'utf-8');

  const ds = await registerUpload(file, 'clients');
  const slice = await resolveSliceWith(
    { datasetId: ds.id, fields: ['client_code', 'risk_level'] },
    async () => ({ fields: [], rows: [] }),
  );

  assert.deepEqual(slice.schema.map((f) => f.name), ['client_code', 'risk_level']);
  assert.deepEqual(slice.rows, [['000001', '3'], ['000002', '5']]);
  assert.equal(slice.datasetVersion, '1.0.0');
});

test('the catalogue loads and every dataset declares its fields', async () => {
  const all = await listDatasets();
  assert.ok(all.length > 0, 'the catalogue must not be empty');
  for (const ds of all) {
    assert.ok(ds.id, 'every dataset needs an id');
    assert.ok(Array.isArray(ds.fields), `${ds.id} must declare its fields`);
  }
});

test('no catalogue entry carries a data value', async () => {
  /**
   * A catalogue entry goes into a model prompt, so it must describe data without
   * containing any. If a sample-row field ever appears, this fails.
   */
  const all = await listDatasets();
  for (const ds of all) {
    for (const forbidden of ['sampleRows', 'samples', 'examples', 'rows', 'items']) {
      assert.equal(
        forbidden in (ds as Record<string, unknown>),
        false,
        `${ds.id} must not carry '${forbidden}'`,
      );
    }
  }
});
