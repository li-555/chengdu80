import { test } from 'node:test';
import assert from 'node:assert/strict';
import { writeFileSync, mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

import { parseMarkdownTables, parseMarkdownDocument } from '../src/data/markdown-tables.ts';
import { parseUploadFile } from '../src/data/file-upload.ts';

/**
 * Every row in this file is invented. Nothing here is real market data.
 */

test('parseMarkdownTables extracts every pipe table and strips inline formatting', () => {
  const md = [
    '# Title',
    '',
    '| code | price |',
    '| --- | ---: |',
    '| **000001** | `12.5` |',
    '| 000002 | 13 |',
    '',
    '| name | note |',
    '| :--- | --- |',
    '| A | x |',
  ].join('\n');

  const tables = parseMarkdownTables(md);
  assert.equal(tables.length, 2);
  assert.deepEqual(tables[0]!.headers, ['code', 'price']);
  assert.deepEqual(tables[0]!.rows, [['000001', '12.5'], ['000002', '13']]);
  assert.deepEqual(tables[1]!.headers, ['name', 'note']);
  assert.deepEqual(tables[1]!.rows, [['A', 'x']]);
});

test('parseMarkdownTables ignores tables inside code fences', () => {
  const md = [
    '```',
    '| not | a |',
    '| --- | --- |',
    '| table | row |',
    '```',
    '',
    '| real | col |',
    '| --- | --- |',
    '| 1 | 2 |',
  ].join('\n');

  const tables = parseMarkdownTables(md);
  assert.equal(tables.length, 1);
  assert.deepEqual(tables[0]!.headers, ['real', 'col']);
});

test('parseUploadFile reads each Markdown table as a sheet', (t) => {
  const dir = mkdtempSync(join(tmpdir(), 'blocks-md-'));
  t.after(() => rmSync(dir, { recursive: true, force: true }));
  const file = join(dir, 'data.md');
  writeFileSync(file, '| code | price |\n| --- | --- |\n| 000001 | 10 |\n| 000002 | 20 |\n', 'utf-8');

  const sheets = parseUploadFile(file);
  assert.equal(sheets.length, 1);
  const sheet = sheets[0]!;
  assert.deepEqual(sheet.headers, ['code', 'price']);
  assert.equal(sheet.rows.length, 2);
  assert.equal(sheet.fields.find((f) => f.name === 'code')?.type, 'text');
  assert.equal(sheet.fields.find((f) => f.name === 'price')?.type, 'number');
});

test('parseMarkdownDocument separates the prose description from the tables', () => {
  const md = [
    '# My App',
    '',
    'Shows the biggest daily movers.',
    '',
    '| code | price |',
    '| --- | --- |',
    '| 000001 | 10 |',
    '',
    '## Notes',
    '',
    'Uses daily data.',
  ].join('\n');

  const document = parseMarkdownDocument(md);
  assert.equal(document.tables.length, 1);
  assert.match(document.description, /# My App/);
  assert.match(document.description, /Shows the biggest daily movers/);
  assert.match(document.description, /## Notes/);
  assert.doesNotMatch(document.description, /\| code \|/);
});

test('optional outer pipes, CRLF and BOM use the same table boundaries as description removal', () => {
  const doc = parseMarkdownDocument('\uFEFF# Invented app\r\n\r\ncode | amount\r\n--- | ---\r\nPRIVATE-ROW-CANARY | 10\r\n\r\nBuild a summary.');
  assert.deepEqual(doc.tables[0]?.rows, [['PRIVATE-ROW-CANARY', '10']]);
  assert.equal(doc.description, '# Invented app\n\nBuild a summary.');
  assert.doesNotMatch(doc.description, /PRIVATE-ROW|amount|10/);
});

test('missing cells and fully blank rows are kept while extra cells reject the document', () => {
  const markdown = '| code | amount |\n| --- | --- |\n| INVENTED_A | 10 |\n| INVENTED_B |\n| | |';
  assert.deepEqual(parseMarkdownTables(markdown)[0]?.rows, [['INVENTED_A', '10'], ['INVENTED_B', ''], ['', '']]);
  assert.throws(() => parseMarkdownDocument(markdown + '\n| INVENTED_C | 30 | extra |'), /line 6.*more cells/);
  assert.throws(() => parseMarkdownDocument('| code | amount |\n| --- |\n| A | 10 |'), /header and separator/);
});

test('paths, trailing backslashes, escaped pipes and escaped formatting retain cell values', () => {
  const markdown = String.raw`| path | note |
| --- | --- |
| C:\new\file | left\|right |
| C:\new\ | \*literal\* |
| folder\\file | escaped slash |`;
  assert.deepEqual(parseMarkdownTables(markdown)[0]?.rows, [
    [String.raw`C:\new\file`, 'left|right'], ['C:\\new\\', '*literal*'], ['folder\\file', 'escaped slash'],
  ]);
  const trailing = 'path | note\n--- | ---\nA | tail' + '\\';
  assert.equal(parseMarkdownTables(trailing)[0]?.rows[0]?.[1], 'tail\\');
});

test('tilde and variable-length fences never become datasets or builder descriptions', () => {
  const hidden = '| code | amount |\n| --- | --- |\n| PRIVATE-FENCED-CANARY | 10 |';
  for (const markdown of [
    `Intro\n~~~md\n${hidden}\n~~~\nEnd`,
    `Intro\n\x60\x60\x60\x60md\n\x60\x60\x60\n${hidden}\n\x60\x60\x60\x60\nEnd`,
    `Intro\n~~~\n${hidden}\n\x60\x60\x60\n${hidden}\n~~~\nEnd`,
  ]) {
    assert.deepEqual(parseMarkdownDocument(markdown), { description: 'Intro\nEnd', tables: [] });
  }
  assert.deepEqual(parseMarkdownDocument(`Intro\n~~~\n${hidden}`), { description: 'Intro', tables: [] });
});

test('empty-header tables remain available to the API skippedSheets policy', () => {
  const doc = parseMarkdownDocument('| | |\n| --- | --- |\n| A | 10 |\n\nSummary');
  assert.deepEqual(doc.tables[0]?.headers, ['', '']);
  assert.equal(doc.description, 'Summary');
});
