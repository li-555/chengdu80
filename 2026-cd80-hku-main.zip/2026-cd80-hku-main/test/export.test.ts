import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import express from 'express';
import type { AddressInfo } from 'node:net';
import { mkdtempSync, rmSync, readdirSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { AppDocument } from '../src/app-schema/index.ts';
import { appRoutes } from '../src/api/routes-apps.ts';
import { saveApp, setState } from '../src/platform/index.ts';
import { closeStorage } from '../src/platform/database.ts';
import { exportApplication, exportFilename } from '../src/platform/export.ts';
import { validateApplication } from '../src/validate/index.ts';
const directory = mkdtempSync(join(tmpdir(), 'blocks-export-'));
const previous = process.env.BLOCKS_DB_PATH;
before(() => { process.env.BLOCKS_DB_PATH = join(directory, 'storage.sqlite'); });
after(() => { closeStorage(); if (previous === undefined) delete process.env.BLOCKS_DB_PATH; else process.env.BLOCKS_DB_PATH = previous; rmSync(directory, { recursive: true, force: true }); });
function document() {
  return AppDocument.parse({ meta: { name: '../../fake\r\n"name', description: 'Invented export fixture', spec_version: '1.0' },
    params: [], data: [], compute: [{ id: 'fake', kind: 'sql', sql: 'SELECT 7 AS value' }], triggers: [{ kind: 'manual' }],
    ui: { root: 'root', elements: { root: { type: 'Section', children: ['metric'] }, metric: { type: 'Metric', label: 'Fake value', from: 'fake', value: 'value' } } } });
}
test('export projects nested fields and removes local dataset hints', () => {
  const doc = document();
  doc.data.push({ key: 'invented', datasetHint: 'user:private-local-id', fields: [{ name: 'value', type: 'number', required: true }] });
  const inject = (value: unknown): void => {
    if (Array.isArray(value)) { value.forEach(inject); return; }
    if (value && typeof value === 'object') { Object.values(value).forEach(inject); Object.assign(value, { privateStorageField: 'PRIVATE-CANARY' }); }
  };
  inject(doc);
  const text = exportApplication(doc);
  assert.ok(!text.includes('PRIVATE-CANARY'));
  assert.ok(!text.includes('private-local-id'));
  assert.ok(validateApplication(text).ok);
  assert.match(exportFilename(doc.meta.name), /^[A-Za-z0-9_-]+\.fin\.json$/);
  assert.equal(exportFilename('////'), 'application.fin.json');
});
test('export keeps operation parameter maps and strips nested private additions', () => {
  const doc = document();
  doc.params = [{ key: 'limit', label: 'Fake limit', type: 'number', default: 2 }];
  doc.compute.push(
    { id: 'derived', kind: 'operation', op: 'derive', input: 'fake', params: { columns: { doubled: 'value * 2' } } },
    { id: 'top', kind: 'operation', op: 'sort_limit', input: 'derived', params: { by: [{ col: 'doubled', dir: 'desc' }], limit: { param: 'limit' } } },
  );
  const last = doc.compute[2]! as unknown as { params: { by: object[]; limit: object } };
  Object.assign(last.params, { credential: 'NESTED-CANARY' });
  Object.assign(last.params.by[0]!, { rows: 'NESTED-CANARY' });
  Object.assign(last.params.limit, { savedValue: 'NESTED-CANARY' });
  const text = exportApplication(doc);
  assert.ok(!text.includes('NESTED-CANARY'));
  assert.ok(validateApplication(text).ok);
  assert.deepEqual(JSON.parse(text).compute[1].params.columns, { doubled: 'value * 2' });
  assert.deepEqual(JSON.parse(text).compute[2].params.limit, { param: 'limit' });
});
test('export/import/validate/list/run round trip uses invented SQL values and isolates profiles', async () => {
  const server = express().use(...appRoutes).listen(0, '127.0.0.1');
  await new Promise<void>((resolve) => server.once('listening', resolve));
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  try {
    const initial = await fetch(`${base}/api/apps`);
    const cookie = initial.headers.get('set-cookie')!.split(';')[0]!;
    const profile = `browser:${cookie.split('=')[1]}`;
    const saved = await saveApp(document(), profile);
    await setState(saved.id, profile, { params: { private: 'SAVED-PARAM-CANARY' }, bindings: { fake: 'user:local' }, mappings: { fake: { value: 'private' } }, carry: { secret: 'STATE-CANARY' }, credential: 'CREDENTIAL-CANARY' });
    const exported = await fetch(`${base}/api/apps/${saved.id}/export`, { headers: { cookie } });
    assert.equal(exported.status, 200);
    assert.match(exported.headers.get('content-type')!, /application\/json/);
    assert.equal(exported.headers.get('cache-control'), 'no-store');
    assert.match(exported.headers.get('content-disposition')!, /^attachment; filename="[A-Za-z0-9_-]+\.fin\.json"$/);
    const text = await exported.text();
    for (const privateValue of [saved.id, profile, 'SAVED-PARAM-CANARY', 'STATE-CANARY', 'CREDENTIAL-CANARY', 'user:local']) assert.ok(!text.includes(privateValue));
    assert.ok(validateApplication(text).ok);
    const postHeaders = { cookie, 'X-Blocks-Request': '1', 'Content-Type': 'application/json' };
    const importedResponse = await fetch(`${base}/api/apps/import`, { method: 'POST', headers: postHeaders, body: text });
    assert.equal(importedResponse.status, 201);
    const imported = (await importedResponse.json()).app;
    assert.notEqual(imported.id, saved.id);
    const list = await (await fetch(`${base}/api/apps`, { headers: { cookie } })).json();
    assert.ok(list.apps.some((app: { id: string }) => app.id === imported.id));
    const runResponse = await fetch(`${base}/api/apps/${imported.id}/run`, { method: 'POST', headers: postHeaders, body: JSON.stringify({ runId: 'fake-export-roundtrip' }) });
    assert.equal(runResponse.status, 200);
    const run = await runResponse.json();
    assert.equal(run.kind, 'completed');
    assert.equal(run.record.status, 'ok');
    assert.deepEqual(run.record.result.outputs.fake.rows, [[7]]);
    assert.equal((await fetch(`${base}/api/apps/${saved.id}/export`)).status, 404);
    assert.equal((await fetch(`${base}/api/apps/missing/export`, { headers: { cookie } })).status, 404);
    assert.equal((await fetch(`${base}/api/apps/${saved.id}/export`, { headers: { cookie, origin: 'https://elsewhere.example' } })).status, 403);
  } finally { await new Promise<void>((resolve) => server.close(() => resolve())); }
});

test('all shipped invented examples retain their complete document after export', () => {
  const directory = new URL('../examples/', import.meta.url);
  for (const filename of readdirSync(directory).filter((name) => name.endsWith('.fin.json'))) {
    const validation = validateApplication(readFileSync(new URL(filename, directory), 'utf8'));
    assert.ok(validation.ok, filename);
    if (!validation.ok) continue;
    const exported = validateApplication(exportApplication(validation.document));
    assert.ok(exported.ok, filename);
    if (exported.ok) assert.deepEqual(exported.document, validation.document, filename);
  }
});
test('export preserves numeric union literals, text-list defaults, step outputs and chart shapes', () => {
  const doc = document();
  doc.params.push({ key: 'list', label: 'Fake list', type: 'text', list: true, default: ['fake-a', 'fake-b'] });
  doc.compute.push(
    { id: 'top', kind: 'operation', op: 'sort_limit', input: 'fake', params: { by: [{ col: 'value', dir: 'asc' }], limit: 2, offset: 0 } },
    { id: 'rolling', kind: 'operation', op: 'window', input: 'fake', params: { fn: 'mean', of: 'value', order_by: [{ col: 'value', dir: 'asc' }], frame: { kind: 'rows', preceding: 2, following: 0 }, as: 'average' } },
    { id: 'coded', kind: 'code', input: ['fake'], output: { columns: [{ name: 'value', type: 'number' }] }, carry_state: true, body: 'return { columns: ["value"], rows: [[7]] };' },
  );
  for (const [index, output] of [{ kind: 'text' }, { kind: 'enum', values: ['fake-a', 'fake-b'] }, { kind: 'object', fields: { fake: 'number' } }].entries()) {
    doc.compute.push({ id: `interpret${index}`, kind: 'ai', input: 'fake', params: { mode: 'whole', instructions: 'Describe invented values', output, max_rows: 3 } } as typeof doc.compute[number]);
  }
  for (const [index, chart] of [
    { chart: 'line', y: ['value'] }, { chart: 'bar', y: ['value'], series: 'company' },
    { chart: 'candlestick', ohlc: { open: 'value', high: 'value', low: 'value', close: 'value' } },
    { chart: 'heatmap', heat: { y: 'company', value: 'value' } },
  ].entries()) doc.ui.elements[`chart${index}`] = { type: 'Chart', from: 'fake', x: 'day', ...chart } as typeof doc.ui.elements[string];
  const normalized = AppDocument.parse(doc);
  const exported = JSON.parse(exportApplication(normalized));
  delete exported.$schema;
  assert.deepEqual(exported, normalized);
});
