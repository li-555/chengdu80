import { test } from 'node:test';
import assert from 'node:assert/strict';
import { fileURLToPath } from 'node:url';

import { analyzeTable } from '../src/data/analyze.ts';
import { parseUploadFile } from '../src/data/file-upload.ts';
import type { FieldSpec } from '../src/data/types.ts';

/**
 * Every row in this file is invented. Nothing here is real market data.
 */

function field(name: string, type: FieldSpec['type']): FieldSpec {
  return { name, label: name, type, nullable: true };
}

// ---------------------------------------------------------------- analysis

test('analyzeTable reports overview, numeric stats, nulls and outliers', () => {
  const fields = [field('code', 'text'), field('price', 'number')];
  const rows = [
    ['000001', '10'],
    ['000002', '20'],
    ['000003', ''],
    ['000004', '30'],
  ];

  const analysis = analyzeTable(fields, rows);
  assert.equal(analysis.rowCount, 4);
  assert.equal(analysis.columnCount, 2);

  const code = analysis.columns.find((c) => c.name === 'code')!;
  assert.equal(code.type, 'text');
  assert.equal(code.nulls, 0);
  assert.equal(code.stats, undefined);

  const price = analysis.columns.find((c) => c.name === 'price')!;
  assert.equal(price.type, 'number');
  assert.equal(price.nulls, 1);
  assert.deepEqual(price.stats, { count: 3, min: 10, max: 30, mean: 20, sum: 60 });
  assert.equal(price.outliers, 0);
});

// ---------------------------------------------------------------- multi-sheet parsing

test('parseUploadFile reads every sheet of a workbook', () => {
  const file = fileURLToPath(new URL('./fixtures/invented-clients.xlsx', import.meta.url));
  const sheets = parseUploadFile(file);

  assert.deepEqual(sheets.map((s) => s.name), ['Clients', 'Notes']);

  const clients = sheets[0]!;
  assert.deepEqual(clients.headers, ['client_code', 'name', 'risk', 'joined']);
  assert.equal(clients.rows.length, 3);
  assert.equal(clients.fields.find((f) => f.name === 'client_code')?.type, 'text');
  assert.equal(clients.fields.find((f) => f.name === 'risk')?.type, 'number');

  const notes = sheets[1]!;
  assert.deepEqual(notes.headers, ['only']);
  assert.deepEqual(notes.rows, [['second sheet']]);
});
