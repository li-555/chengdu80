import { test } from 'node:test';
import assert from 'node:assert/strict';
import { createThemeTransition, themeCircle } from '../web/src/theme-transition.ts';

function deferred<T = void>() {
  let resolve!: (value: T | PromiseLike<T>) => void;
  let reject!: (reason?: unknown) => void;
  const promise = new Promise<T>((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}

function browser(options: { reduced?: boolean; unsupported?: boolean; holdUpdate?: boolean; rejected?: boolean } = {}) {
  const previous = Object.fromEntries(['window', 'document'].map((key) => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  const ready = deferred(); const finished = deferred(); const updated = deferred(); const animation = deferred();
  let update: (() => Promise<void>) | undefined;
  let starts = 0; let frames = 0; let skips = 0;
  const animations: Array<{ frames: PropertyIndexedKeyframes; options: KeyframeAnimationOptions }> = [];
  const root = {
    dataset: {} as Record<string, string>,
    animate(keyframes: PropertyIndexedKeyframes, settings: KeyframeAnimationOptions) {
      animations.push({ frames: keyframes, options: settings });
      return { finished: animation.promise, cancel: () => animation.reject(new Error('Cancelled')) };
    },
  };
  const performUpdate = async () => {
    await update?.(); updated.resolve();
    if (options.rejected) ready.reject(new Error('Snapshot unavailable'));
    else ready.resolve();
  };
  const doc = {
    documentElement: root, visibilityState: 'visible',
    startViewTransition: options.unsupported ? undefined : (callback: () => Promise<void>) => {
      starts++; update = callback;
      if (!options.holdUpdate) queueMicrotask(() => void performUpdate());
      return {
        ready: ready.promise, finished: finished.promise, updateCallbackDone: updated.promise,
        skipTransition() { skips++; ready.reject(new Error('Skipped')); finished.resolve(); },
      };
    },
  };
  const win = {
    innerWidth: 1440, innerHeight: 900,
    matchMedia: () => ({ matches: !!options.reduced }),
    setTimeout, clearTimeout,
    requestAnimationFrame(callback: () => void) { frames++; queueMicrotask(callback); return frames; },
    cancelAnimationFrame() {},
  };
  Object.defineProperty(globalThis, 'document', { configurable: true, value: doc });
  Object.defineProperty(globalThis, 'window', { configurable: true, value: win });
  return {
    root, animations, starts: () => starts, frames: () => frames, skips: () => skips,
    performUpdate,
    animationComplete() { animation.resolve(); },
    complete() { animation.resolve(); finished.resolve(); },
    restore() {
      for (const [key, descriptor] of Object.entries(previous)) {
        if (descriptor) Object.defineProperty(globalThis, key, descriptor);
        else Reflect.deleteProperty(globalThis, key);
      }
    },
  };
}
const trigger = { getBoundingClientRect: () => ({ left: 1200, top: 20, width: 80, height: 40 }) } as HTMLElement;
const settle = () => new Promise<void>((resolve) => setImmediate(resolve));

test('theme reveal radius covers all viewport corners, including an offscreen origin', () => {
  for (const rect of [{ left: 1200, top: 20, width: 80, height: 40 }, { left: -50, top: 950, width: 20, height: 20 }]) {
    const circle = themeCircle(rect, 1440, 900);
    assert.ok(circle.x >= 0 && circle.x <= 1440);
    assert.ok(circle.y >= 0 && circle.y <= 900);
    for (const [x, y] of [[0, 0], [1440, 0], [0, 900], [1440, 900]]) {
      assert.ok(Math.hypot(x! - circle.x, y! - circle.y) <= circle.radius);
    }
  }
});

test('unsupported snapshots and reduced motion commit directly without frames or animation', async () => {
  for (const options of [{ unsupported: true }, { reduced: true }]) {
    const b = browser(options);
    try {
      const transition = createThemeTransition(); let committed = 0;
      await transition.run(trigger, 'dark', () => committed++);
      assert.equal(committed, 1); assert.equal(transition.running, false);
      assert.equal(b.starts(), 0); assert.equal(b.frames(), 0); assert.equal(b.animations.length, 0);
    } finally { b.restore(); }
  }
});

test('theme snapshots wait for chart paints, use opposite reveal directions and prevent reentry', async () => {
  for (const next of ['dark', 'light'] as const) {
    const b = browser();
    try {
      const transition = createThemeTransition(); let committed = 0;
      const pending = transition.run(trigger, next, () => committed++);
      await transition.run(trigger, next, () => committed++);
      await settle();
      assert.equal(transition.running, true); assert.equal(committed, 1); assert.equal(b.starts(), 1);
      assert.equal(b.frames(), 2, 'existing theme observers get two frames before snapshot readiness');
      const effect = b.animations[0]!;
      assert.equal(effect.options.pseudoElement, `::view-transition-${next === 'dark' ? 'new' : 'old'}(root)`);
      const clips = effect.frames.clipPath as string[];
      assert.match(clips[next === 'dark' ? 0 : 1]!, /^circle\(0px /);
      assert.doesNotMatch(clips[next === 'dark' ? 1 : 0]!, /^circle\(0px /);
      b.animationComplete(); await settle();
      assert.equal(transition.running, true, 'WAAPI completion must not unlock a still-active view transition');
      assert.ok(b.root.dataset.themeTransition, 'snapshot styling must survive until ViewTransition.finished');
      b.complete(); await pending;
      assert.equal(transition.running, false); assert.equal(b.root.dataset.themeTransition, undefined);
    } finally { b.restore(); }
  }
});

test('storage cancellation cannot let a delayed snapshot overwrite the newer preference', async () => {
  const b = browser({ holdUpdate: true });
  try {
    const transition = createThemeTransition(); let committed = 0;
    const pending = transition.run(trigger, 'dark', () => committed++);
    transition.cancel();
    await b.performUpdate(); await pending;
    assert.equal(committed, 0); assert.equal(transition.running, false);
    assert.equal(b.animations.length, 0); assert.equal(b.root.dataset.themeTransition, undefined);
  } finally { b.restore(); }
});

test('reduced-motion changes finish the requested preference and snapshot failure falls back once', async () => {
  for (const rejected of [false, true]) {
    const b = browser({ holdUpdate: !rejected, rejected });
    try {
      const transition = createThemeTransition(); let committed = 0;
      const pending = transition.run(trigger, 'dark', () => committed++);
      if (!rejected) { transition.finish(); await b.performUpdate(); }
      await pending;
      assert.equal(committed, 1); assert.equal(transition.running, false);
      assert.equal(b.animations.length, 0); assert.ok(b.skips() >= 1);
    } finally { b.restore(); }
  }
});

test('theme and language controls retain focus and DOM identity across changes and storage synchronization', async () => {
  const { detachedDOM, TestElement, testDocument } = await import('./dom-fixture.ts');
  const { mountPreferences } = await import('../web/src/preferences.ts');
  const { setLanguage, setTheme, getTheme } = await import('../web/src/i18n.ts');
  const dom = detachedDOM('/apps');
  const baseDocument = globalThis.document;
  Object.defineProperty(globalThis, 'document', { configurable: true, value: {
    ...testDocument,
    querySelector: (selector: string) => testDocument.documentElement.querySelector(selector),
    createElementNS: (_ns: string, tag: string) => new TestElement(tag),
  } });
  dom.view.dataset.preferences = '';
  try {
    setTheme('light'); setLanguage('en'); mountPreferences();
    const theme = testDocument.getElementById('theme-picker')!;
    const language = testDocument.getElementById('language-picker')!;
    theme.focus(); theme.click(); await settle();
    assert.equal(getTheme(), 'dark'); assert.equal(testDocument.activeElement, theme);
    assert.equal(testDocument.getElementById('theme-picker'), theme);
    language.focus(); language.value = 'zh'; language.dispatchEvent(new Event('change'));
    assert.equal(testDocument.activeElement, language);
    assert.equal(testDocument.getElementById('language-picker'), language);
    window.dispatchEvent(Object.assign(new Event('storage'), { key: 'blocks:theme', newValue: 'light', storageArea: window.localStorage }));
    assert.equal(getTheme(), 'light'); assert.equal(testDocument.getElementById('theme-picker'), theme);
    assert.equal(theme.getAttribute('aria-disabled'), 'false');
    setLanguage('en');
  } finally {
    Object.defineProperty(globalThis, 'document', { configurable: true, value: baseDocument });
    dom.restore();
  }
});
