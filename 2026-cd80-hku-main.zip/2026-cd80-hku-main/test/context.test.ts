import { test } from 'node:test';
import assert from 'node:assert/strict';
import { RunContext, RunTimeoutError } from '../src/compute/context.ts';

test('an ordinary query works and types come back', async () => {
  const ctx = await RunContext.create();
  try {
    const r = await ctx.query("SELECT 1 AS a, 'x' AS b, DATE '2026-10-13' AS c");
    assert.deepEqual(r.columns.map((c) => c.name), ['a', 'b', 'c']);
    assert.deepEqual(r.columns.map((c) => c.type), ['INTEGER', 'VARCHAR', 'DATE']);
    assert.deepEqual(r.rows, [{ a: 1, b: 'x', c: '2026-10-13' }]);
  } finally { ctx.close(); }
});

test('a whole number comes back as a number, not as text', async () => {
  const ctx = await RunContext.create();
  try {
    const r = await ctx.query('SELECT count(*) AS n FROM range(42)');
    assert.deepEqual(r.rows, [{ n: 42 }], 'a count must be a number so the screen can format it');
    assert.equal(typeof r.rows[0]!.n, 'number');

    // a value too large for a JavaScript number keeps all its digits as text
    const big = await ctx.query('SELECT 123456789012345678901234567890::HUGEINT AS h');
    assert.equal(big.rows[0]!.h, '123456789012345678901234567890');
  } finally { ctx.close(); }
});

test('a bound value is a value, never SQL', async () => {
  const ctx = await RunContext.create();
  try {
    const nasty = "'; DROP TABLE nothing; --";
    const r = await ctx.query('SELECT ? AS given', [nasty]);
    assert.deepEqual(r.rows, [{ given: nasty }]);
  } finally { ctx.close(); }
});

// --- isolation, by construction ------------------------------------------

test('a run cannot reach the host file system or the network', async () => {
  const ctx = await RunContext.create();
  try {
    const refused: [string, string][] = [
      ['read a host file', "SELECT * FROM read_csv('/etc/passwd')"],
      ['read a host file as text', "SELECT * FROM read_text('/etc/hosts')"],
      ['write a host file', "COPY (SELECT 1 AS a) TO '/tmp/blocks-escape-test.csv'"],
      ['attach another database', "ATTACH '/tmp/other.duckdb' AS other"],
      ['install an extension', 'INSTALL httpfs'],
      ['load an extension', 'LOAD httpfs'],
      ['read over http', "SELECT * FROM read_csv('https://raw.githubusercontent.com/duckdb/duckdb/main/README.md')"],
      ['read a directory', "SELECT * FROM glob('/etc/*')"],
    ];
    for (const [what, sql] of refused) {
      await assert.rejects(() => ctx.query(sql), (e: Error) => {
        // The reason matters, not just the refusal. A network attempt that merely failed
        // to connect would prove nothing about the engine forbidding it, so the message
        // must say the engine refused it.
        assert.match(e.message, /Permission Error/,
          `${what}: must be refused BY THE ENGINE, got -> ${e.message}`);
        return true;
      }, `${what} must be refused`);
    }
  } finally { ctx.close(); }
});

test('the configuration cannot be unlocked from inside a query', async () => {
  const ctx = await RunContext.create();
  try {
    for (const sql of [
      'SET enable_external_access=true',
      "SET memory_limit='8GB'",
      'SET autoload_known_extensions=true',
      'SET lock_configuration=false',
    ]) {
      await assert.rejects(() => ctx.query(sql), `${sql} must be refused`);
    }
    // and the database still works afterwards
    assert.deepEqual((await ctx.query('SELECT 1 AS a')).rows, [{ a: 1 }]);
  } finally { ctx.close(); }
});

// --- stopping a runaway query --------------------------------------------

test('a runaway query is stopped, and the connection still works afterwards', async () => {
  const ctx = await RunContext.create({ statementTimeoutMs: 1000 });
  try {
    const startedAt = Date.now();
    await assert.rejects(
      () => ctx.query('SELECT count(*) FROM range(1000000000000) t1, range(1000000) t2'),
      (e: Error) => {
        assert.ok(e instanceof RunTimeoutError, `expected a timeout, got ${e.name}: ${e.message}`);
        assert.equal((e as RunTimeoutError).code, 'E_STEP_TIMEOUT');
        return true;
      },
    );
    const took = Date.now() - startedAt;
    assert.ok(took < 6000, `should have been stopped near the 1 second budget, took ${took} ms`);

    // the point of interrupting rather than killing: the run can report the failure
    assert.deepEqual((await ctx.query('SELECT 1 AS a')).rows, [{ a: 1 }],
      'the connection must still be usable, so a failed step can be reported');
  } finally { ctx.close(); }
});

test('the whole-run deadline is separate from one statement', async () => {
  const ctx = await RunContext.create({ runTimeoutMs: 1, statementTimeoutMs: 10_000 });
  try {
    await new Promise((r) => setTimeout(r, 20));
    assert.equal(ctx.remainingMs, 0);
    assert.throws(() => ctx.checkDeadline(), (e: Error) => {
      assert.ok(e instanceof RunTimeoutError);
      assert.equal((e as RunTimeoutError).code, 'E_RUN_TIMEOUT');
      return true;
    });
    await assert.rejects(() => ctx.query('SELECT 1'), RunTimeoutError);
  } finally { ctx.close(); }
});

test('closing twice is harmless, and a closed context refuses work', async () => {
  const ctx = await RunContext.create();
  ctx.close();
  ctx.close();
  await assert.rejects(() => ctx.query('SELECT 1'), /closed/);
});

test('two runs do not share anything', async () => {
  const a = await RunContext.create();
  const b = await RunContext.create();
  try {
    await a.query('CREATE TABLE only_in_a (x INTEGER)');
    assert.deepEqual((await a.query('SELECT count(*) AS n FROM only_in_a')).rows, [{ n: 0 }]);
    await assert.rejects(() => b.query('SELECT * FROM only_in_a'), /only_in_a|Catalog Error/);
  } finally { a.close(); b.close(); }
});

// ---------------------------------------------------------------------------
// Regressions for the review of 2026-10-13. All seven findings were accepted.
// ---------------------------------------------------------------------------

test('review 1: a query that would spill to disk fails in the engine instead of writing', async () => {
  // DuckDB writes intermediate results to a temporary directory when a query exceeds
  // its memory limit. That is a host write, and `enable_external_access=false` does not
  // prevent it -- it locks the temp directory's path and leaves its size at 90% of the
  // disk. The budget is set to zero instead.
  const ctx = await RunContext.create({ memoryMb: 16, statementTimeoutMs: 30_000 });
  try {
    const setting = await ctx.query("SELECT current_setting('max_temp_directory_size') AS mx");
    assert.equal(setting.rows[0]!.mx, '0 bytes', 'spilling must have no budget at all');

    await assert.rejects(
      () => ctx.query(
        'SELECT count(*) FROM (SELECT i, repeat(md5(i::VARCHAR), 4) AS s FROM range(1000000) t(i) ORDER BY s)',
      ),
      (e: Error) => {
        assert.match(e.message, /Out of Memory/,
          `must run out of memory rather than write to disk, got -> ${e.message}`);
        return true;
      },
    );
    // and the budget cannot be raised afterwards
    await assert.rejects(() => ctx.query("SET max_temp_directory_size='10GB'"));
  } finally { ctx.close(); }
});

test('review 2: a query that overruns its budget cannot report success', async () => {
  // Reading and converting a large result blocks this thread, so the timer cannot fire
  // during it. A 500,000 row select returned in 89 ms under a 20 ms budget.
  const ctx = await RunContext.create({ statementTimeoutMs: 20 });
  try {
    await assert.rejects(
      () => ctx.query('SELECT i, md5(i::VARCHAR) AS h FROM range(500000) t(i)'),
      (e: Error) => {
        assert.ok(e instanceof RunTimeoutError, `expected a timeout, got ${e.name}: ${e.message}`);
        return true;
      },
    );
  } finally { ctx.close(); }
});

test('review 2b: an active query crossing the whole-run deadline is not reported as success', async () => {
  const ctx = await RunContext.create({ runTimeoutMs: 25, statementTimeoutMs: 10_000 });
  try {
    await assert.rejects(
      () => ctx.query('SELECT i, md5(i::VARCHAR) AS h FROM range(500000) t(i)'),
      (e: Error) => {
        assert.ok(e instanceof RunTimeoutError, `expected a timeout, got ${e.name}: ${e.message}`);
        assert.equal((e as RunTimeoutError).code, 'E_RUN_TIMEOUT');
        return true;
      },
    );
  } finally { ctx.close(); }
});

test('review 3: one query cannot be killed by another query timer', async () => {
  // interrupt() acts on the connection, not on a statement. Two overlapping queries
  // meant the fast one's timer interrupted the slow one, and the fast one then reported
  // success. Queries are serialised now.
  const ctx = await RunContext.create({ statementTimeoutMs: 30_000 });
  try {
    const slow = ctx.query(
      'SELECT count(*) FROM range(1000000000000) t1, range(1000000) t2',
      [],
      1000,
    );
    const quick = ctx.query('SELECT 42 AS a', [], 30);

    const slowResult = await slow.then(() => 'resolved', (e: Error) => e);
    const quickResult = await quick.then((r) => r, (e: Error) => e);

    assert.ok(slowResult instanceof RunTimeoutError,
      `the slow query must fail on its OWN budget, got ${String(slowResult)}`);
    assert.ok(!(quickResult instanceof Error),
      `the quick query must not be collateral damage, got ${String(quickResult)}`);
    assert.deepEqual((quickResult as { rows: unknown[] }).rows, [{ a: 42 }]);
  } finally { ctx.close(); }
});

test('review 5: a number that cannot round-trip exactly stays as text', async () => {
  const ctx = await RunContext.create();
  try {
    const r = await ctx.query(`SELECT
      9007199254740993::DECIMAL(20,0) AS too_big_decimal,
      0.123456789012345678901234567890::DECIMAL(38,30) AS long_fraction,
      123456789012345678901234567890::HUGEINT AS too_big_integer,
      42::BIGINT AS fits,
      1.5::DECIMAL(10,2) AS short_decimal`);
    const row = r.rows[0]!;
    assert.equal(row.too_big_decimal, '9007199254740993', 'must keep every digit, not round to ...992');
    assert.equal(row.long_fraction, '0.123456789012345678901234567890');
    assert.equal(row.too_big_integer, '123456789012345678901234567890');
    assert.equal(row.fits, 42);
    assert.equal(row.short_decimal, 1.5, 'an ordinary money value must be a number, not the text "1.50"');
    assert.equal(typeof row.short_decimal, 'number');
  } finally { ctx.close(); }
});

test('review 5b: text that merely looks like a number is left alone', async () => {
  const ctx = await RunContext.create();
  try {
    const r = await ctx.query("SELECT '007' AS code, '42' AS also_text");
    assert.equal(r.rows[0]!.code, '007', 'a leading-zero code must never become a number');
    assert.equal(r.rows[0]!.also_text, '42');
    assert.equal(typeof r.rows[0]!.also_text, 'string');
  } finally { ctx.close(); }
});

test('review 6: the honest boundary — what configuration does NOT stop', async () => {
  // These reach neither the file system nor the network, and they are NOT refused by
  // configuration. They are excluded because an application's SQL may only ever be a
  // single SELECT or WITH. This test records the real boundary so the claim in the
  // module comment cannot quietly drift away from it.
  const ctx = await RunContext.create();
  try {
    await ctx.query("ATTACH ':memory:' AS extra");
    await ctx.query('LOAD json');
    await ctx.query('LOAD parquet');
    // but a file-backed attach is still refused by the engine
    await assert.rejects(() => ctx.query("ATTACH '/tmp/x.duckdb' AS ondisk"), /Permission Error/);
  } finally { ctx.close(); }
});
