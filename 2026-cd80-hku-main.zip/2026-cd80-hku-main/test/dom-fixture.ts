/** Minimal detached DOM for state/lifecycle tests, not a browser or layout engine. */
export class TestElement extends EventTarget {
  tagName: string;
  children: TestElement[] = [];
  parentElement?: TestElement;
  dataset: Record<string, string> = {};
  style: Record<string, string> = {};
  attributes = new Map<string, string>();
  className = ''; id = ''; hidden = false; disabled = false; checked = false; open = false;
  tabIndex = -1; type = ''; rows = 0; maxLength = 0; placeholder = ''; htmlFor = '';
  scrollTop = 0; scrollHeight = 100; clientHeight = 100;
  private text = ''; private selected?: string;
  constructor(tag: string) { super(); this.tagName = tag.toUpperCase(); }
  get value(): string { return this.selected ?? (this.tagName === 'SELECT' ? this.children[0]?.value ?? '' : ''); }
  set value(value: string) { this.selected = value; }
  get textContent(): string { return this.text + this.children.map((child) => child.textContent).join(''); }
  set textContent(value: string) { this.replaceChildren(); this.text = value; }
  get isConnected(): boolean { return this.tagName === 'HTML' || !!this.parentElement?.isConnected; }
  append(...items: TestElement[]) { for (const item of items) { item.remove(); item.parentElement = this; this.children.push(item); } }
  replaceChildren(...items: TestElement[]) { for (const child of this.children) child.parentElement = undefined; this.children = []; this.text = ''; this.append(...items); }
  remove() { if (this.parentElement) this.parentElement.children = this.parentElement.children.filter((child) => child !== this); this.parentElement = undefined; }
  replaceWith(item: TestElement) {
    const parent = this.parentElement;
    if (!parent || item === this) return;
    item.remove();
    parent.children.splice(parent.children.indexOf(this), 1, item);
    item.parentElement = parent; this.parentElement = undefined;
  }
  setAttribute(key: string, value: string) { this.attributes.set(key, value); }
  getAttribute(key: string) { return this.attributes.get(key) ?? null; }
  contains(target: TestElement): boolean { return target === this || this.children.some((child) => child.contains(target)); }
  querySelectorAll(selector: string): TestElement[] {
    const matches = (item: TestElement) => {
      if (selector.startsWith('.')) return item.className.split(' ').includes(selector.slice(1));
      if (selector.startsWith('#')) return item.id === selector.slice(1);
      const attr = /^([\w-]*)\[([\w-]+)\]$/.exec(selector);
      if (attr) return (!attr[1] || item.tagName === attr[1].toUpperCase()) && (attr[2]!.startsWith('data-')
        ? Object.hasOwn(item.dataset, attr[2]!.slice(5).replace(/-([a-z])/g, (_, c: string) => c.toUpperCase())) : item.attributes.has(attr[2]!));
      return item.tagName === selector.toUpperCase();
    };
    const all = this.children.flatMap((child): TestElement[] => [child, ...child.querySelectorAll('*')]);
    return selector === '*' ? all : all.filter(matches);
  }
  querySelector(selector: string) { return this.querySelectorAll(selector)[0] ?? null; }
  focus(_options?: unknown) { testDocument.activeElement = this; }
  click() { this.dispatchEvent(new Event('click')); }
  requestSubmit() { this.dispatchEvent(new Event('submit', { cancelable: true })); }
  classList = { add: (name: string) => { this.className += ` ${name}`; }, remove: (name: string) => { this.className = this.className.split(' ').filter((part) => part !== name).join(' '); } };
}
export const testDocument = {
  documentElement: new TestElement('html'), activeElement: null as TestElement | null,
  createElement: (tag: string) => new TestElement(tag), createTextNode: (text: string) => { const node = new TestElement('text'); node.textContent = text; return node; },
  querySelectorAll: (selector: string) => testDocument.documentElement.querySelectorAll(selector),
  getElementById: (id: string) => testDocument.documentElement.querySelector(`#${id}`),
};
export function detachedDOM(pathname: string, saved: Record<string, string> = {}) {
  const values = new Map(Object.entries(saved));
  const storage = { getItem: (key: string) => values.get(key) ?? null, setItem: (key: string, value: string) => values.set(key, value), removeItem: (key: string) => values.delete(key) };
  const changes: Record<string, unknown> = { document: testDocument, location: { pathname }, sessionStorage: storage,
    window: Object.assign(new EventTarget(), { setTimeout, clearTimeout, localStorage: storage, matchMedia: () => ({ matches: false }) }) };
  const previous = Object.fromEntries(Object.keys(changes).map((key) => [key, Object.getOwnPropertyDescriptor(globalThis, key)]));
  for (const [key, value] of Object.entries(changes)) Object.defineProperty(globalThis, key, { configurable: true, value });
  testDocument.documentElement.replaceChildren();
  const view = new TestElement('div'); testDocument.documentElement.append(view);
  return { view, restore: () => { for (const [key, descriptor] of Object.entries(previous)) { if (descriptor) Object.defineProperty(globalThis, key, descriptor); else Reflect.deleteProperty(globalThis, key); } } };
}
