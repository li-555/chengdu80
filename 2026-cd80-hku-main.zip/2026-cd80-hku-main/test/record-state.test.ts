import { test } from 'node:test';
import assert from 'node:assert/strict';
import { sameSettings, settingsAfterListAction } from '../web/src/record-state.ts';
import type { ListActionSnapshot } from '../src/platform/list-actions.ts';
const previous = { params: { selected: 'FAKE-A', amount: 123, done: [] }, bindings: { clients: 'FAKE-UPLOAD' }, mappings: { clients: { name: 'display_name' } } };
const snapshot: ListActionSnapshot = { appVersion: 'FAKE', revision: 'FAKE', params: [{ key: 'done', label: 'Done', values: ['FAKE-T1'] }, { key: 'other', label: 'Other', values: ['FAKE-OTHER'] }], history: [] };
test('list reconciliation changes only the affected saved setting without mutating its previous snapshot', () => {
  const next = settingsAfterListAction(previous, snapshot, 'done')!;
  assert.deepEqual(next.params, { selected: 'FAKE-A', amount: 123, done: ['FAKE-T1'] });
  assert.deepEqual(previous.params.done, []); assert.deepEqual(next.bindings, previous.bindings); assert.deepEqual(next.mappings, previous.mappings);
  assert.equal(settingsAfterListAction(undefined, snapshot, 'done'), undefined); assert.equal(settingsAfterListAction(previous, snapshot, 'missing'), undefined);
});
test('revision reconciliation ignores object order but detects concurrent binding, scalar and list changes', () => {
  const next = settingsAfterListAction(previous, snapshot, 'done')!;
  assert.equal(sameSettings(next, { mappings: previous.mappings, bindings: previous.bindings, params: { done: ['FAKE-T1'], amount: 123, selected: 'FAKE-A' } }), true);
  for (const changed of [ { ...next, bindings: { clients: 'FAKE-OTHER' } }, { ...next, params: { ...next.params, amount: 124 } }, { ...next, params: { ...next.params, done: ['FAKE-T2'] } } ]) assert.equal(sameSettings(next, changed), false);
});
