import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';

import { RunContext } from '../src/compute/context.ts';
import { checkSqlStep, stripCommentsAndStrings, referencedNames, forbiddenNameIn } from '../src/compute/sql.ts';

/**
 * The gate is a security boundary: a document's SQL may have been written by a model or
 * by a stranger. Every case below is a thing we must refuse, or a thing an ordinary
 * application needs and must therefore be allowed.
 */

let ctx: RunContext;
/** The connection a step is checked against. It holds only `prices`, the step's input. */
let conn: never;

before(async () => {
  ctx = await RunContext.create();
  await ctx.query(`CREATE TABLE prices AS SELECT * FROM (VALUES
    ('AAA', 10), ('BBB', 20)
  ) AS t(code, px)`);
  // The gate needs the raw connection; RunContext keeps it private, so reach it the way
  // the run loop will once it owns both.
  conn = (ctx as unknown as { connection: never }).connection;
});

after(() => ctx?.close());

const ok = async (sql: string) => {
  const problems = await checkSqlStep(conn, sql);
  assert.deepEqual(problems, [], `${sql}\n  should be allowed, got: ${problems.map((p) => p.message).join(' | ')}`);
};

const no = async (sql: string, expectInMessage?: string) => {
  const problems = await checkSqlStep(conn, sql);
  assert.ok(problems.length > 0, `${sql}\n  should have been refused`);
  assert.equal(problems[0]?.code, 'E_BAD_SQL');
  if (expectInMessage) {
    assert.ok(
      problems[0]?.message.includes(expectInMessage) || problems[0]?.hint?.includes(expectInMessage),
      `expected "${expectInMessage}" in: ${problems[0]?.message} / ${problems[0]?.hint}`,
    );
  }
};

// ------------------------------------------------------------------ what must be allowed

test('a plain query over the step\'s own relation is allowed', async () => {
  await ok('SELECT code, px FROM prices');
  await ok('SELECT * FROM prices WHERE px > 5');
});

test('a WITH query is allowed', async () => {
  await ok('WITH big AS (SELECT * FROM prices WHERE px > 5) SELECT count(*) FROM big');
});

test('the three pure table functions are allowed', async () => {
  await ok('SELECT * FROM range(5)');
  await ok('SELECT * FROM generate_series(1, 10)');
  await ok('SELECT * FROM unnest([1, 2, 3])');
});

test('a comment and a string literal do not make a valid query invalid', async () => {
  await ok("-- a note about prices\nSELECT code FROM prices WHERE code = 'AAA'");
  await ok("/* a block note */ SELECT code FROM prices WHERE code = 'it''s fine'");
});

// ------------------------------------------------------------------ what must be refused

test('more than one statement is refused', async () => {
  await no('SELECT 1; SELECT 2', 'one statement');
  await no('SELECT * FROM prices; DROP TABLE prices', 'one statement');
});

test('a statement that is not a query is refused', async () => {
  await no('CREATE TABLE sneaky (a INT)');
  await no('DROP TABLE prices');
  await no('INSERT INTO prices VALUES (\'CCC\', 1)');
  await no('UPDATE prices SET px = 0');
  await no('DELETE FROM prices');
});

test('writing to the host is refused', async () => {
  await no("COPY (SELECT * FROM prices) TO '/tmp/leak.csv'");
  await no("EXPORT DATABASE '/tmp/leak'");
});

test('reaching another database is refused', async () => {
  await no("ATTACH '/tmp/other.db'");
  await no("ATTACH ':memory:' AS scratch");
  await no('DETACH scratch');
});

test('loading an extension is refused', async () => {
  await no('INSTALL httpfs');
  await no('LOAD json');
});

test('a PRAGMA is refused even though the parser calls it a SELECT', async () => {
  /**
   * This is the case the leading-keyword check exists for: `statementType` reports 1 for
   * a PRAGMA, exactly as it does for a real SELECT, so the type alone would let it past.
   */
  await no('PRAGMA database_list', 'SELECT or WITH');
  await no('PRAGMA show_tables');
  await no('SET memory_limit = \'1GB\'');
});

test('a keyword hidden behind a comment is still refused', async () => {
  await no('/* SELECT */ ATTACH \':memory:\' AS scratch', 'SELECT or WITH');
  await no('-- SELECT 1\nPRAGMA database_list', 'SELECT or WITH');
});

test('reading a file through a table function is refused', async () => {
  await no("SELECT * FROM read_csv('/etc/passwd')", 'may not use');
  await no("SELECT * FROM read_parquet('/tmp/x.parquet')", 'may not use');
  await no("SELECT * FROM glob('/**')", 'may not use');
});

test('the engine\'s own metadata functions are refused', async () => {
  await no('SELECT * FROM duckdb_settings()', 'may not use');
  await no('SELECT * FROM duckdb_tables()', 'may not use');
  // Every way of writing it that walked past the old FROM/JOIN check.
  await no('SELECT * FROM a, duckdb_settings()', 'may not use');
  await no('SELECT * FROM LATERAL duckdb_settings()', 'may not use');
  await no('SELECT * FROM main.duckdb_settings()', 'may not use');
  await no('SELECT * FROM "duckdb_settings"()', 'may not use');
  await no('SELECT * FROM information_schema.tables', 'may not use');
});

test('a relation the step did not declare cannot be reached', async () => {
  await no('SELECT * FROM something_else', 'cannot use');
});

test('nonsense is reported as unparseable, not allowed through', async () => {
  await no('SELECT FROM WHERE');
  await no('');
});

// ------------------------------------------------------------------ the helpers

test('comments and string values are stripped, quoted names are kept', () => {
  assert.equal(stripCommentsAndStrings('SELECT 1 -- note').trim(), 'SELECT 1');
  assert.equal(stripCommentsAndStrings("SELECT 'abc'"), "SELECT ''");
  // The quotes are dropped so a name cannot hide from the checks by being quoted.
  assert.ok(stripCommentsAndStrings('SELECT "my col" FROM t').includes('my col'));
  assert.ok(stripCommentsAndStrings('SELECT "duckdb_settings"() FROM t').includes('duckdb_settings'));
  assert.equal(stripCommentsAndStrings("SELECT 'it''s'"), "SELECT ''");
});

test('a forbidden name is found wherever it appears, however it is written', () => {
  for (const sql of [
    'SELECT * FROM duckdb_settings()',
    'SELECT * FROM a, duckdb_settings()',
    'SELECT * FROM LATERAL duckdb_settings()',
    'SELECT * FROM main.duckdb_settings()',
    'SELECT * FROM "duckdb_settings"()',
    'SELECT * FROM information_schema.tables',
    "SELECT * FROM read_csv('/etc/passwd')",
    'SELECT (SELECT count(*) FROM duckdb_tables()) AS n',
  ]) {
    assert.ok(forbiddenNameIn(sql) !== undefined, `should be caught: ${sql}`);
  }

  for (const sql of [
    'SELECT abs(px) FROM prices',
    'SELECT * FROM range(3)',
    'SELECT * FROM generate_series(1, 10)',
    'SELECT count(*) FROM prices',
  ]) {
    assert.equal(forbiddenNameIn(sql), undefined, `should be allowed: ${sql}`);
  }
});

test('a nested block comment is stripped whole', () => {
  const stripped = stripCommentsAndStrings('/* outer /* inner */ SELECT */ PRAGMA version');
  assert.ok(!stripped.includes('SELECT'), `the comment must not leak a keyword: ${stripped}`);
  assert.ok(stripped.includes('PRAGMA'), 'the real statement must survive');
});

test('a dollar-quoted string does not swallow the rest of the statement', () => {
  const stripped = stripCommentsAndStrings("SELECT $$it's$$ AS s FROM duckdb_settings()");
  assert.ok(stripped.includes('duckdb_settings'), `the tail must survive: ${stripped}`);
  assert.deepEqual(referencedNames("SELECT $$it's$$ AS s FROM duckdb_settings()"), ['duckdb_settings']);
});
