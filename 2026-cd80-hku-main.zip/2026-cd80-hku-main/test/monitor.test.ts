import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { AppDocument } from '../src/app-schema/index.ts';
import { saveApp, getState, setState, updateApp } from '../src/platform/storage.ts';
import { closeStorage, storageOperation, storageTransaction } from '../src/platform/database.ts';
import { applyMonitorRun, getMonitorSnapshot, setMonitorAcknowledged } from '../src/platform/monitor.ts';
import type { RunRecord, StoredApp } from '../src/platform/types.ts';
const directory = mkdtempSync(join(tmpdir(), 'blocks-monitor-')); const previousPath = process.env.BLOCKS_DB_PATH;
before(() => { process.env.BLOCKS_DB_PATH = join(directory, 'state.sqlite'); });
after(() => { closeStorage(); if (previousPath === undefined) delete process.env.BLOCKS_DB_PATH; else process.env.BLOCKS_DB_PATH = previousPath; rmSync(directory, { recursive: true, force: true }); });
function document() { return AppDocument.parse({ meta: { name: 'Invented monitor', description: 'Invented monitor fixture', spec_version: '1.0' }, params: [{ key: 'watch', label: 'Watch', type: 'text', list: true, default: [] }, { key: 'done', label: 'Done', type: 'text', list: true, default: [] }], data: [], compute: [{ id: 'monitor_events', key: true, kind: 'sql', sql: "SELECT 'fake' AS event_id" }, { id: 'act_done', kind: 'sql', sql: 'SELECT 1' }], triggers: [{ kind: 'manual' }], ui: { root: 'root', elements: { root: { type: 'Section', children: [] } } } }); }
const row = (status = 'active', value = '7', id = 'FAKE-A') => [id, 'Invented condition', status, value, 'Invented evidence', ''];
function run(app: StoredApp, id: string, rows: string[][], params: Record<string, unknown> = { watch: [], done: [] }): RunRecord { return { id, appId: app.id, appVersion: app.version, startedAt: '2026-10-15T01:00:00Z', completedAt: '2026-10-15T01:01:00Z', status: 'ok', params, result: { status: 'ok', startedAt: '2026-10-15T01:00:00Z', durationMs: 1, outputs: { monitor_events: { schema: ['event_id', 'title', 'status', 'value', 'detail', 'source_url'].map((name) => ({ name, label: name, type: 'text', nullable: false })), rows } } } }; }
async function apply(app: StoredApp, record: RunRecord, captured?: Record<string, unknown>) { const state = captured ?? await getState(app.id, app.profile); storageOperation((db) => storageTransaction(db, () => applyMonitorRun(db, app, record, state))); return getMonitorSnapshot(app.id, app.profile); }
test('baseline, acknowledgement, repeated runs, changed evidence, explicit clear and stale IDs', async () => {
 const app = await saveApp(document(), 'fake-owner'); let snapshot = await apply(app, run(app, 'one', [row()])); assert.equal(snapshot.changes.length, 0); assert.match(snapshot.notice, /Baseline/); const initial = snapshot.alerts[0]!.id;
 assert.equal((await setMonitorAcknowledged(app.id, app.profile, { alertId: initial, acknowledged: true })).kind, 'saved'); const acknowledged = await getMonitorSnapshot(app.id, app.profile);
 await setMonitorAcknowledged(app.id, app.profile, { alertId: initial, acknowledged: true }); assert.deepEqual(await getMonitorSnapshot(app.id, app.profile), acknowledged);
 snapshot = await apply(app, run(app, 'two', [row()])); assert.equal(snapshot.changes.length, 0); assert.equal(snapshot.alerts[0]!.id, initial); assert.equal(snapshot.counts.acknowledged, 1);
 snapshot = await apply(app, run(app, 'three', [row('active', '8')])); assert.equal(snapshot.changes[0]!.kind, 'changed'); assert.equal(snapshot.counts.unacknowledged, 1); assert.equal((await setMonitorAcknowledged(app.id, app.profile, { alertId: initial, acknowledged: true })).kind, 'conflict');
 snapshot = await apply(app, run(app, 'four', [row('clear', '8')])); assert.equal(snapshot.changes[0]!.kind, 'cleared'); assert.equal(snapshot.counts.active, 0); assert.equal((await setMonitorAcknowledged(app.id, app.profile, { alertId: snapshot.alerts[0]!.id, acknowledged: true })).kind, 'conflict');
});
test('missing and unknown are never cleared; malformed, partial and failed preserve last good baseline', async () => {
 const app = await saveApp(document(), 'fake-unknown'); await apply(app, run(app, 'one', [row()])); let snapshot = await apply(app, run(app, 'two', [])); assert.equal(snapshot.alerts[0]!.status, 'unknown'); assert.equal(snapshot.changes[0]!.kind, 'unknown');
 snapshot = await apply(app, run(app, 'three', [])); assert.equal(snapshot.changes.length, 0); const id = snapshot.alerts[0]!.id;
 for (const [index, bad] of [run(app, 'bad', [row(), row()]), { ...run(app, 'partial', [row('clear')]), status: 'partial' as const }, { ...run(app, 'failed', []), status: 'failed' as const }, run(app, 'malformed', [row('bad')])].entries()) { snapshot = await apply(app, { ...bad, id: `bad-${index}` }); assert.match(snapshot.notice, /preserved/); assert.equal(snapshot.alerts[0]!.id, id); assert.equal(snapshot.lastRunId, 'three'); }
 snapshot = await apply(app, run(app, 'four', [row('unknown')])); assert.equal(snapshot.counts.unknown, 1);
});
test('context resets for substantive settings, excludes matching local action, and preserves latest state and acknowledgements', async () => {
 const app = await saveApp(document(), 'fake-context'); await setState(app.id, app.profile, { params: { watch: [], done: [] }, carry: { keep: 1 }, bindings: {}, mappings: {} });
 let snapshot = await apply(app, run(app, 'one', [row()])); const id = snapshot.alerts[0]!.id; const captured = await getState(app.id, app.profile);
 await setMonitorAcknowledged(app.id, app.profile, { alertId: id, acknowledged: true }); const latest = await getState(app.id, app.profile); await setState(app.id, app.profile, { ...latest, params: { watch: [], done: ['FAKE'] }, carry: { keep: 2 } });
 snapshot = await apply(app, run(app, 'two', [row()], { watch: [], done: ['FAKE'] }), captured); assert.equal(snapshot.alerts[0]!.id, id); assert.equal(snapshot.counts.acknowledged, 1); assert.deepEqual((await getState(app.id, app.profile)).carry, { keep: 2 });
 const state = await getState(app.id, app.profile); await setState(app.id, app.profile, { ...state, params: { watch: ['FAKE'], done: [] } }); assert.equal((await setMonitorAcknowledged(app.id, app.profile, { alertId: id, acknowledged: true })).kind, 'conflict');
 snapshot = await apply(app, run(app, 'three', [row()], { watch: ['FAKE'], done: [] })); assert.match(snapshot.notice, /context changed/); assert.equal(snapshot.changes.length, 0); assert.notEqual(snapshot.alerts[0]!.id, id);
 closeStorage(); assert.deepEqual(await getMonitorSnapshot(app.id, app.profile), snapshot); await assert.rejects(getMonitorSnapshot(app.id, 'foreign'), /not found/);
 const same = await apply(app, run(app, 'three', [row('clear')])); assert.deepEqual(same, snapshot);
 const changed = document(); changed.meta.name = 'Changed invented app'; await updateApp(app.id, app.profile, changed); snapshot = await apply(app, run(app, 'old-run', [row('clear')])); assert.match(snapshot.notice, /context changed/);
 assert.equal((await setMonitorAcknowledged(app.id, app.profile, { alertId: id, acknowledged: true, extra: true })).kind, 'invalid');
});
test('clear evidence changes are changed; revisions and acknowledgements remain in bounded history', async () => {
 const app = await saveApp(document(), 'fake-history'); let snapshot = await apply(app, run(app, 'history-1', [row(), row('active', '2', 'FAKE-B')])); const [a, b] = snapshot.alerts;
 await setMonitorAcknowledged(app.id, app.profile, { alertId: a!.id, acknowledged: true }); await setMonitorAcknowledged(app.id, app.profile, { alertId: b!.id, acknowledged: true });
 let monitor = (await getState(app.id, app.profile)).monitor as { acknowledgements: Record<string, { actor: string; time: string; acknowledged: boolean }> };
 assert.equal(Object.keys(monitor.acknowledgements).length, 2); assert.equal(monitor.acknowledgements[a!.id]!.actor, app.profile);
 await apply(app, run(app, 'history-2', [row('clear'), row('active', '3', 'FAKE-B')])); snapshot = await apply(app, run(app, 'history-3', [row('clear', '9'), row('active', '3', 'FAKE-B')])); assert.equal(snapshot.changes[0]!.kind, 'changed');
 assert.ok(snapshot.history!.find((event) => event.id === b!.id)?.acknowledgedAt);
 const state = await getState(app.id, app.profile); await setState(app.id, app.profile, { ...state, params: { watch: ['FAKE'], done: [] } }); snapshot = await apply(app, run(app, 'history-reset', [row()], { watch: ['FAKE'], done: [] }));
 assert.ok(snapshot.history!.find((event) => event.id === a!.id)?.acknowledgedAt); assert.equal(snapshot.counts.acknowledged, 0); assert.equal(snapshot.alerts.length, 1);
 monitor = (await getState(app.id, app.profile)).monitor as typeof monitor; assert.equal(monitor.acknowledgements[a!.id]!.acknowledged, true); assert.equal(monitor.acknowledgements[b!.id]!.acknowledged, true);
});
test('comparison overflow preserves unresolved alerts and baseline with a visible notice', async () => {
 const app = await saveApp(document(), 'fake-overflow'); const rows = Array.from({ length: 200 }, (_, i) => row('active', '1', `FAKE-${i}`)); const baseline = await apply(app, run(app, 'limit-1', rows));
 const snapshot = await apply(app, run(app, 'limit-2', [row('active', '2', 'FAKE-NEW')])); assert.match(snapshot.notice, /200-condition limit/); assert.equal(snapshot.lastRunId, baseline.lastRunId); assert.deepEqual(snapshot.alerts, baseline.alerts);
 const recovered = await apply(app, run(app, 'limit-3', rows)); assert.equal(recovered.changes.length, 0); assert.equal(recovered.alerts.length, 200);
});
