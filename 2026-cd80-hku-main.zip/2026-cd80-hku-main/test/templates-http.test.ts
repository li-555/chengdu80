import { test } from 'node:test';
import assert from 'node:assert/strict';
import express from 'express';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { once } from 'node:events';
import { templateRouter } from '../src/api/routes-templates.ts';
import { appRoutes } from '../src/api/routes-apps.ts';
import { closeStorage } from '../src/platform/database.ts';
import { listApps } from '../src/platform/storage.ts';
import { listUploads } from '../src/data/upload-store.ts';

// Loopback HTTP only, connect mode only; no invented input rows or external service calls.
test('template HTTP routes enforce browser ownership, origin, headers and bounded JSON', async (t) => {
  const directory = mkdtempSync(join(tmpdir(), 'blocks-template-http-'));
  const previous = process.env.BLOCKS_DB_PATH;
  process.env.BLOCKS_DB_PATH = join(directory, 'storage.sqlite');
  const app = express(); app.use(templateRouter); app.use(...appRoutes);
  const server = app.listen(0, '127.0.0.1');
  await once(server, 'listening');
  const address = server.address(); assert.ok(address && typeof address !== 'string');
  const origin = `http://127.0.0.1:${address.port}`;
  t.after(async () => {
    await new Promise<void>((resolve, reject) => server.close(error => error ? reject(error) : resolve()));
    closeStorage();
    if (previous === undefined) delete process.env.BLOCKS_DB_PATH; else process.env.BLOCKS_DB_PATH = previous;
    rmSync(directory, { recursive: true, force: true });
  });
  const request = (path: string, options: RequestInit = {}) => fetch(origin + path, options);
  const library = await request('/api/apps'); assert.equal(library.status, 200);
  const cookie = library.headers.get('set-cookie')!.split(';')[0]!;
  assert.match(cookie, /^blocks_profile=[0-9a-f-]+$/);
  const foreign = (await request('/api/apps')).headers.get('set-cookie')!.split(';')[0]!;
  assert.notEqual(cookie, foreign);
  const post = (body = JSON.stringify({ mode: 'connect' }), headers: Record<string, string> = {}, id = 'wealth-weave') => request(`/api/examples/${id}/import`, {
    method: 'POST', headers: { 'Content-Type': 'application/json', Cookie: cookie, Origin: origin, 'X-Blocks-Request': '1', ...headers }, body,
  });
  const listing = await request('/api/examples'); assert.equal(listing.status, 200);
  assert.equal(listing.headers.get('cache-control'), 'no-store');
  assert.equal((await listing.json()).templates.length, 3);
  for (const headers of ([{ Cookie: '' }, { Cookie: 'blocks_profile=invalid' }, { Cookie: `${cookie}; ${cookie}` }, { 'X-Blocks-Request': '' }, { Origin: 'https://example.invalid' }] as Record<string, string>[])) {
    const reply = await post(undefined, headers); assert.equal(reply.status, 403);
    assert.ok((await reply.json()).error.code);
  }
  for (const body of [JSON.stringify({ mode: 'demo' }), JSON.stringify({ mode: 'invalid' }), JSON.stringify({ mode: 'connect', private: true }), '{}']) {
    assert.equal((await post(body)).status, 400);
  }
  const unknown = await post(undefined, {}, 'unknown'); assert.equal(unknown.status, 404);
  assert.equal((await unknown.json()).error.code, 'TEMPLATE_NOT_FOUND');
  assert.equal((await post(undefined, {}, '%2E%2E%2Fescape')).status, 404);
  const malformed = await post('{"mode":"connect",');
  assert.equal(malformed.status, 400);
  assert.match(malformed.headers.get('content-type') ?? '', /application\/json/, 'body errors must be safe structured JSON');
  const malformedBody = await malformed.text();
  assert.ok(!malformedBody.includes('SyntaxError') && !malformedBody.includes('node_modules') && !malformedBody.includes('"mode":"connect",'));
  const oversized = await post(JSON.stringify({ mode: 'connect', padding: 'x'.repeat(5000) }));
  assert.equal(oversized.status, 413);
  const created = await post(); assert.equal(created.status, 201);
  const result = await created.json(); assert.equal(result.mode, 'connect');
  assert.ok(typeof result.appId === 'string');
  const own = await request('/api/apps', { headers: { Cookie: cookie } });
  assert.equal((await own.json()).apps.length, 1);
  const foreignList = await request('/api/apps', { headers: { Cookie: foreign } });
  assert.deepEqual((await foreignList.json()).apps, []);
  const foreignDetail = await request(`/api/apps/${encodeURIComponent(result.appId)}`, { headers: { Cookie: foreign } });
  assert.equal(foreignDetail.status, 404);
  assert.ok(!(await foreignDetail.text()).includes('WealthWeave'));
  const profile = cookie.slice('blocks_profile='.length);
  assert.equal((await listApps(`browser:${profile}`)).length, 1);
  assert.equal(listUploads(profile).length, 0, 'connect imports never install demonstration records');
});
