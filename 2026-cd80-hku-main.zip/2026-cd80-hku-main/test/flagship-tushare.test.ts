import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { validateApplication } from '../src/validate/index.ts';
import { fetchSlicesFor } from '../src/compute/slices.ts';
import { getDataset } from '../src/data/index.ts';
import type { Dataset, SliceRequest } from '../src/data/types.ts';
import { runForScreen } from '../src/compute/result.ts';
import { exportApplication } from '../src/platform/export.ts';
const read = (id: string) => {
  const checked = validateApplication(readFileSync(new URL(`../examples/${id}.fin.json`, import.meta.url), 'utf8'));
  assert(checked.ok); return checked.document;
};
// Invented values only, isolated from production templates and storage.
const statement = (year: number, extra = {}) => ({ ts_code: '600519.SH', ann_date: `${year+1}-03-01`, f_ann_date: `${year+1}-03-02`, end_date: `${year}-12-31`, report_type: '1', comp_type: '1', revenue: year === 2024 ? '150' : '100', n_income: year === 2024 ? '12' : '10', n_cashflow_act: '6', accounts_receiv: '10', total_cur_assets: '20', total_cur_liab: '10', ...extra });
function tables() {
  return {
    'tushare:daily': [{ts_code:'600519.SH',trade_date:'2025-09-15',close:'100',vol:'1000'}, {ts_code:'600519.SH',trade_date:'2025-09-16',close:'50',vol:'1200'}, {ts_code:'600519.SH',trade_date:'2025-09-17',close:'55',vol:'1100'}],
    'tushare:adj_factor': [{ts_code:'600519.SH',trade_date:'2025-09-15',adj_factor:'1'}, {ts_code:'600519.SH',trade_date:'2025-09-16',adj_factor:'2'}, {ts_code:'600519.SH',trade_date:'2025-09-17',adj_factor:'2'}],
    'tushare:stock_basic': [{ts_code:'600519.SH',name:'Test company',industry:'Test sector'}],
    'tushare:income': [statement(2024),statement(2023)],
    'tushare:cashflow': [statement(2024),statement(2023)],
    'tushare:balancesheet': [statement(2024),statement(2023)],
    'tushare:daily_basic': [{ts_code:'600519.SH',trade_date:'2025-09-17',pe:'20',pb:'3'}],
    'tushare:fund_nav': [{ts_code:'000001.OF',nav_date:'2025-09-15',ann_date:'2025-09-16',unit_nav:'1.25',accum_nav:'2.50'}, {ts_code:'000001.OF',nav_date:'2025-09-19',ann_date:'2025-09-20',unit_nav:'1.50',accum_nav:'2.75'}],
  } as Record<string, Record<string, unknown>[]>;
}
async function resolve(id: string, data = tables(), params: Record<string, unknown> = {}) {
  const doc = read(id), requests: SliceRequest[] = [];
  const uploads: Record<string, Dataset> = Object.fromEntries(doc.data.filter(req => !req.datasetHint).map(req => [`user:${req.key}`, {id:`user:${req.key}`,name:'Offline test collection',source:'upload',fields:req.fields.map(f => ({...f,label:f.name,nullable:true}))}]));
  const result = await fetchSlicesFor(doc, { params: { start_date:'2025-09-15',end_date:'2025-09-19',as_of:'2025-09-19',...params },
    bindings: Object.fromEntries(Object.keys(uploads).map(key => [key.slice(5),key])), deps: {
      getDataset: async id => uploads[id] ?? getDataset(id),
      resolve: async request => {
        requests.push(request); const dataset = uploads[request.datasetId] ?? await getDataset(request.datasetId); assert(dataset);
        const records = request.datasetId === 'user:holdings' ? [{code:'600519.SH',weight:1}] : data[request.datasetId] ?? [];
        const fields = request.fields!;
        const selected = records.filter(row => !request.filter?.ts_code || String(request.filter.ts_code).split(',').includes(String(row.ts_code)));
        return {schema:fields.map(name => dataset.fields.find(f => f.name === name)!), rows:selected.map(row => fields.map(name => row[name] ?? null)),datasetVersion:'offline-test-v1'};
      },
    } });
  return {doc,requests,...result};
}
const rows = (out: Awaited<ReturnType<typeof runForScreen>>, key: string) => {
  const table=out.result.outputs[key];assert(table,JSON.stringify(out.result.failure));return table.rows.map(values => Object.fromEntries(table.schema.map((f,i)=>[f.name,values[i]])));
};
test('AlphaVista joins adjusted prices, annual statements, prior periods and user weights; exported app calculates identically', async () => {
  const {doc,slices,requests}=await resolve('alpha-vista');
  const params={start_date:'2025-09-15',end_date:'2025-09-19',minimum_returns:2};
  const result=await runForScreen(doc,{slices,params});
  assert.equal(result.result.status,'ok',JSON.stringify(result.result.failure));
  const company=rows(result,'company_view')[0]!;
  assert(Math.abs(Number(company.return_pct)-10)<1e-9); assert.equal(company.revenue_growth_pct,50); assert(Math.abs(Number(company.profit_growth_pct)-20)<1e-9); assert.equal(company.cash_profit_pct,50);
  assert.equal(company.report_period,'2024-12-31'); assert.equal(company.published_at,'2025-03-02'); assert.equal(company.pe,20);
  assert.equal(rows(result,'portfolio_view')[0]!.status,'Available');
  const prices=requests.find(r=>r.datasetId==='tushare:daily')!; assert.equal(prices.dateFrom,'2025-09-15');assert.equal(prices.dateTo,'2025-09-19');
  assert.equal(requests.find(r=>r.datasetId==='tushare:income')!.dateFrom,undefined);
  const restored=validateApplication(exportApplication(doc));assert(restored.ok);
  const rerun=await runForScreen(restored.document,{slices,params});assert.deepEqual(rerun.result.outputs,result.result.outputs);
});
test('RiskRift uses the correct consolidated report type and same-period cash flow; conflicts remain unavailable', async () => {
  const normal=await resolve('risk-rift');
  const out=await runForScreen(normal.doc,{slices:normal.slices,params:{as_of:'2025-09-19'}});
  assert.equal(out.result.status,'ok',JSON.stringify(out.result.failure));
  const findings=rows(out,'financial_findings');assert.equal(findings.find(r=>r.rule==='R7')!.observed,2);
  assert.equal(findings.find(r=>r.rule==='R1')!.observed,0.5);
  const data=tables();data['tushare:income']!.push(statement(2024,{revenue:'999',report_type:'4'}));
  data['tushare:balancesheet']!.push(statement(2024,{total_cur_assets:'999'}));
  const conflict=await resolve('risk-rift',data); const checked=await runForScreen(conflict.doc,{slices:conflict.slices,params:{as_of:'2025-09-19'}});
  assert.equal(rows(checked,'financial_findings').find(r=>r.rule==='R7')!.status,'not_evaluable');
});
test('Tushare bounds and publication cutoffs are retained locally; financial requests fan out by code', async () => {
  const data=tables();data['tushare:income']!.push(statement(2024,{f_ann_date:'2025-10-01'}));
  const result=await resolve('risk-rift',data,{companies:['600519.SH','000001.SZ']});
  assert.equal(result.slices.income!.rows.length,2);
  assert.deepEqual(result.requests.filter(r=>r.datasetId==='tushare:income').map(r=>r.filter?.ts_code),['600519.SH','000001.SZ']);
  assert(result.requests.filter(r=>r.datasetId==='tushare:income').every(r=>r.dateTo==='2025-09-19'));
});
test('WealthWeave shows published Tushare NAV without manufacturing any client or product records', async () => {
  const {doc,slices,requests}=await resolve('wealth-weave');assert.equal(slices.fund_nav!.rows.length,1);assert.equal(slices.clients!.rows.length,0);assert.equal(slices.products!.rows.length,0);
  assert.equal(requests.find(r=>r.datasetId==='tushare:fund_nav')!.dateFrom,'2025-09-15');
  const run=await runForScreen(doc,{slices});assert.equal(run.result.status,'ok',JSON.stringify(run.result.failure));
  assert.equal(rows(run,'fund_nav')[0]!.unit_nav,1.25);assert.equal(rows(run,'ranked_products').length,0);
});
test('empty or oversized flagship code selections and reversed dates fail before any provider request', async () => {
  const app=read('alpha-vista'), doc={...app,data:app.data.filter(req=>req.datasetHint)};
  let requests=0;
  for(const params of [{watchlist:[]},{watchlist:Array.from({length:21},(_,i)=>`${String(i).padStart(6,'0')}.SH`)},{start_date:'2025-09-20',end_date:'2025-09-19'}]) {
    await assert.rejects(fetchSlicesFor(doc,{params,deps:{resolve:async()=>{requests++;throw new Error('Invalid parameters reached the provider');}}}), /enter at least one|at most 20|start date/);
  }
  assert.equal(requests,0);
});
test('conflicting restated annual figures stay unavailable rather than silently becoming comparable growth', async () => {
  const data=tables();data['tushare:income']!.push(statement(2023,{report_type:'4',revenue:'80',n_income:'8'}));
  const resolved=await resolve('alpha-vista',data);
  const run=await runForScreen(resolved.doc,{slices:resolved.slices,params:{start_date:'2025-09-15',end_date:'2025-09-19',minimum_returns:2}});
  assert.equal(run.result.status,'ok');const company=rows(run,'company_view')[0]!;
  assert.equal(company.revenue_growth_pct,null);assert.equal(company.profit_growth_pct,null);
  assert(Math.abs(Number(company.return_pct)-10)<1e-9);
});
