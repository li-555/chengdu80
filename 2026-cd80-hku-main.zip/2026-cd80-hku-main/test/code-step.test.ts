import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runApplication, type Slice } from '../src/compute/run.ts';

// All rows are invented.
const items: Slice = { columns: [{ name: 'amount', type: 'number' }], rows: [{ amount: 3 }, { amount: 7 }, { amount: -2 }] };
const columns = [{ name: 'total', type: 'number' as const }];
async function run(body: string, extra: { carry_state?: boolean } = {}, carriedState?: Record<string, unknown>, failLater = false, slice = items) {
  return runApplication({ data: [{ key: 'items' }], compute: [
    { id: 'calculated', kind: 'code', input: ['items'], output: { columns }, body, key: true, ...extra },
    { id: 'later', kind: 'sql', input: ['calculated'], sql: failLater ? 'SELECT missing FROM calculated' : 'SELECT * FROM calculated', key: true },
  ] }, { slices: { items: slice }, carriedState });
}

test('a running total uses the previous row and later SQL reads the result', async () => {
  const out = await run('let total = 0; return { rows: input.items.map(r => ({ total: total += r.amount })) };');
  assert.equal(out.status, 'ok', out.failure);
  assert.deepEqual(out.results.get('later')?.rows, [{ total: 3 }, { total: 10 }, { total: 8 }]);
});

test('an infinite loop is interrupted and the next run still works', async () => {
  const started = Date.now();
  const stopped = await run('while (true) {}');
  assert.equal(stopped.status, 'failed');
  assert.match(stopped.failure ?? '', /E_CODE_TIMEOUT/);
  assert.ok(Date.now() - started < 3500, `took ${Date.now() - started} ms`);
  const next = await run('return { rows: [{ total: 1 }] };');
  assert.equal(next.status, 'ok', next.failure);
});

test('host APIs and state without carry_state are undefined', async () => {
  const out = await run(`
    log([typeof fetch, typeof require, typeof process, typeof setTimeout,
      typeof setInterval, typeof XMLHttpRequest, typeof Deno, typeof fs, typeof state].join(','));
    return { rows: [{ total: 1 }] };
  `);
  assert.equal(out.status, 'ok', out.failure);
  assert.deepEqual(out.steps[0]?.logs, [Array(9).fill('undefined').join(',')]);
});

test('20001 output rows are refused', async () => {
  const out = await run('return { rows: Array.from({ length: 20001 }, () => ({ total: 1 })) };');
  assert.equal(out.status, 'failed');
  assert.match(out.failure ?? '', /output exceeds 20000/);
});

test('state carries across runs and is withheld after a later failure', async () => {
  const body = 'const n = (state.n || 0) + 1; return { rows: [{ total: n }], state: { n } };';
  const first = await run(body, { carry_state: true });
  assert.equal(first.status, 'ok', first.failure);
  assert.deepEqual(first.newState, { n: 1 });
  const second = await run(body, { carry_state: true }, first.newState);
  assert.deepEqual(second.newState, { n: 2 });
  assert.deepEqual(second.results.get('later')?.rows, [{ total: 2 }]);
  const failed = await run(body, { carry_state: true }, second.newState, true);
  assert.equal(failed.status, 'failed');
  assert.equal(Object.hasOwn(failed, 'newState'), false);
  assert.deepEqual(second.newState, { n: 2 });
  const partial = await run('return { rows: [{}], state: { n: 3 } };', { carry_state: true });
  assert.equal(partial.status, 'partial', partial.failure);
  assert.deepEqual(partial.newState, { n: 3 });
});

test('undeclared output keys are refused', async () => {
  const out = await run('return { rows: [{ total: 1, secret: 2 }] };');
  assert.equal(out.status, 'failed');
  assert.match(out.failure ?? '', /undeclared output key.*secret/);
});

test('logs are capped at 100 lines, including multiline messages', async () => {
  const out = await run('for (let i = 0; i < 80; i++) log(i + "\\nnext"); return { rows: [] };');
  assert.equal(out.status, 'ok', out.failure);
  assert.equal(out.steps[0]?.logs?.length, 100);
  assert.deepEqual(out.steps[0]?.logs?.slice(-2), ['49', 'next']);
});

test('missing and wrongly typed values become blanks with warnings', async () => {
  const out = await run('return { rows: [{}, { total: "12" }, { total: false }, { total: null }, { total: 12 }] };');
  assert.equal(out.status, 'partial', out.failure);
  assert.deepEqual(out.results.get('later')?.rows, [{ total: null }, { total: null }, { total: null }, { total: null }, { total: 12 }]);
  assert.match(out.warnings.join('\n'), /3 missing or wrongly typed/);
});

test('input row, output size and carried state caps are enforced', async () => {
  const oversizedInput = await run('return { rows: [] };', {}, undefined, false, { ...items, rows: Array.from({ length: 50001 }, () => ({ amount: 1 })) });
  assert.match(oversizedInput.failure ?? '', /input 'items' exceeds 50000/);
  const oversizedOutput = await runApplication({ data: [{ key: 'items' }], compute: [{
    id: 'large', kind: 'code', input: ['items'], output: { columns: [{ name: 'label', type: 'text' }] },
    body: 'return { rows: [{ label: "x".repeat(4 * 1024 * 1024) }] };',
  }] }, { slices: { items } });
  assert.match(oversizedOutput.failure ?? '', /output JSON exceeds 4 MB/);
  const oversizedState = await run('return { rows: [], state: { text: "x".repeat(65536) } };', { carry_state: true });
  assert.match(oversizedState.failure ?? '', /state exceeds 64 KB/);
  const oversizedCarried = await run('return { rows: [] };', { carry_state: true }, { text: 'x'.repeat(65536) });
  assert.match(oversizedCarried.failure ?? '', /state exceeds 64 KB/);
});

test('only one code step may run', async () => {
  const out = await runApplication({ compute: ['first', 'second'].map((id) => ({ id, kind: 'code', input: ['items'], output: { columns }, body: 'return { rows: [] };' })) }, { slices: {} });
  assert.equal(out.status, 'failed');
  assert.match(out.failure ?? '', /E_LIMIT_CODE_STEPS/);
  assert.equal(out.steps.length, 0);
});

test('memory exhaustion and recursive stack overflow leave the process usable', async () => {
  for (const body of ['const a = []; while (true) a.push(new Array(10000).fill(1));', 'function f() { return f(); } f();']) {
    const out = await run(body);
    assert.equal(out.status, 'failed');
  }
  const out = await run('return { rows: [{ total: 2 }] };');
  assert.equal(out.status, 'ok', out.failure);
});

test('declared text, number, boolean and date fields use the common ingest types', async () => {
  const out = await runApplication({ data: [{ key: 'items' }], compute: [{
    id: 'typed', kind: 'code', input: ['items'], key: true,
    output: { columns: [{ name: 'label', type: 'text' }, { name: 'amount', type: 'number' }, { name: 'valid', type: 'boolean' }, { name: 'day', type: 'date' }] },
    body: 'return { rows: [{ label: "Invented", amount: 2, valid: true, day: "2026-01-02" }, { label: 2, amount: "2", valid: 1, day: "bad-date" }] };',
  }] }, { slices: { items } });
  assert.equal(out.status, 'partial', out.failure);
  assert.deepEqual(out.results.get('typed')?.rows, [{ label: 'Invented', amount: 2, valid: true, day: '2026-01-02' }, { label: null, amount: null, valid: null, day: null }]);
  assert.match(out.warnings.join('\n'), /typed.day/);
});

for (const body of [
  'return { rows: [{ total: 1, extra: undefined }] };',
  'return { rows: [{ total: 1, extra: () => 2 }] };',
  'return { rows: [{ total: 1, extra: Symbol("extra") }] };',
]) {
  test(`extra keys are checked before JSON serialization: ${body}`, async () => {
    const out = await run(body);
    assert.equal(out.status, 'failed');
    assert.match(out.failure ?? '', /undeclared output key.*extra/);
  });
}

test('non-finite code numbers become blanks with a warning', async () => {
  const out = await run('return { rows: [{ total: NaN }, { total: Infinity }, { total: -Infinity }] };');
  assert.equal(out.status, 'partial', out.failure);
  assert.deepEqual(out.results.get('later')?.rows, [{ total: null }, { total: null }, { total: null }]);
  assert.match(out.warnings.join('\n'), /3 missing or wrongly typed/);
});

for (const cell of ['1n', 'new Date("2026-01-02")', '(() => { const v = {}; v.self = v; return v; })()', '({ toJSON() { return "hidden"; } })']) {
  test(`wrongly typed guest cells become blanks before serialization: ${cell}`, async () => {
    const out = await runApplication({ data: [{ key: 'items' }], compute: [{
      id: 'typed', kind: 'code', input: ['items'], key: true,
      output: { columns: [{ name: 'label', type: 'text' }, { name: 'amount', type: 'number' }] },
      body: `return { rows: [{ label: ${cell}, amount: ${cell} }] };`,
    }] }, { slices: { items } });
    assert.equal(out.status, 'partial', out.failure);
    assert.deepEqual(out.results.get('typed')?.rows, [{ label: null, amount: null }]);
    assert.equal(out.warnings.length, 2);
  });
}
