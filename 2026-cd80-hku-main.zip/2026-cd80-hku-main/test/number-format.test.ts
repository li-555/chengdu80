import { test } from 'node:test';
import assert from 'node:assert/strict';
import { formatNumber } from '../web/src/i18n.ts';
import { formatScreenValue, renderScreen } from '../web/src/screen-elements.ts';
import { detachedDOM } from './dom-fixture.ts';
import type { UiSpec } from '../web/src/app-types.ts';

test('prices, money and percentage points use fixed two decimals; counts stay integers', () => {
  assert.equal(formatScreenValue(11.7, 'number'), '11.70');
  assert.equal(formatScreenValue(1488.8, 'money'), '1,488.80');
  assert.equal(formatScreenValue(25, 'percent'), '25.00%');
  assert.equal(formatScreenValue(0.25, 'percent'), '0.25%');
  assert.equal(formatScreenValue(5, 'integer'), '5');
  assert.equal(formatScreenValue(null, 'money'), '—');
  assert.equal(formatScreenValue(Number.NaN, 'number'), '—');
  assert.equal(formatScreenValue('000001.SZ', 'text'), '000001.SZ');
  assert.equal(formatScreenValue('2025-09-15', 'date'), '2025-09-15');
});

test('rounded zero never carries a minus sign, while negative nonzero values keep theirs', () => {
  for (const value of [-0, -0.00001, -0.0013624071008645705, -0.0049, 0, 0.0049]) {
    assert.equal(formatScreenValue(value, 'number'), '0.00');
    assert.equal(formatScreenValue(value, 'money'), '0.00');
    assert.equal(formatScreenValue(value, 'percent'), '0.00%');
  }
  assert.equal(formatScreenValue(-0.005, 'number'), '-0.01');
  assert.equal(formatScreenValue(0.005, 'number'), '0.01');
  assert.equal(formatScreenValue(-1.9759, 'percent'), '-1.98%');
  assert.equal(formatScreenValue(-0.49, 'integer'), '0');
  assert.equal(formatScreenValue(-0.5, 'integer'), '-1');
});

test('exact runtime decimal strings and large integers format without losing precision', () => {
  assert.equal(formatScreenValue('9007199254740993.10', 'money'), '9,007,199,254,740,993.10');
  assert.equal(formatScreenValue('9007199254740993', 'integer'), '9,007,199,254,740,993');
  assert.equal(formatScreenValue(9007199254740993n, 'money'), '9,007,199,254,740,993.00');
  assert.equal(formatNumber('9.999'), '10.00');
  assert.equal(formatNumber('-0.0049'), '0.00');
  assert.equal(formatNumber('-0.005'), '-0.01');
  assert.equal(formatNumber('-0.12'), '-0.12');
  assert.equal(formatNumber('-1.999'), '-2.00');
  assert.equal(formatNumber('-0.49', 0), '0');
});

test('metric, result table and chart source table share formatting without mutating results', () => {
  const dom = detachedDOM('/apps/invented-format-check');
  const ui: UiSpec = { root: 'root', elements: {
    root: { type: 'Section', columns: 1, children: ['price', 'profit', 'return', 'count', 'table', 'chart'] },
    price: { type: 'Metric', label: 'Price', from: 'values', value: 'price', format: 'number' },
    profit: { type: 'Metric', label: 'Profit', from: 'values', value: 'profit', format: 'money' },
    return: { type: 'Metric', label: 'Return', from: 'values', value: 'return', format: 'percent' },
    count: { type: 'Metric', label: 'Count', from: 'values', value: 'count', format: 'integer' },
    table: { type: 'Table', from: 'values', columns: [{ col: 'price', format: 'number' }, { col: 'profit', format: 'money' }, { col: 'return', format: 'percent' }] },
    chart: { type: 'Chart', chart: 'line', from: 'values', x: 'code', y: ['price'] },
  } };
  const values = { columns: [{ name: 'code', type: 'text' }, { name: 'price', type: 'number' }, { name: 'profit', type: 'number' }, { name: 'return', type: 'number' }, { name: 'count', type: 'integer' }], rows: [{ code: '001', price: 11.7, profit: -0.001, return: 25, count: 5 }] };
  const original = structuredClone(values);
  try {
    dom.view.append(renderScreen(ui, new Map([['values', values]])) as unknown as typeof dom.view);
    assert.deepEqual(dom.view.querySelectorAll('.screen-metric-value').map((item) => item.textContent), ['11.70', '0.00', '25.00%', '5']);
    assert.deepEqual(dom.view.querySelectorAll('td').map((item) => item.textContent), ['11.70', '0.00', '25.00%', '001', '11.70']);
    assert.deepEqual(values, original);
  } finally { dom.restore(); }
});
