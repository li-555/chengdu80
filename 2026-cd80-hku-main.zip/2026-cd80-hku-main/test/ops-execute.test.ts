import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';

import { RunContext } from '../src/compute/context.ts';
import type { OpCompileInput } from '../src/compute/ops/contract.ts';
import { compileFilter } from '../src/compute/ops/filter.ts';
import { compileDerive } from '../src/compute/ops/derive.ts';
import { compileJoin } from '../src/compute/ops/join.ts';
import { compileAggregate } from '../src/compute/ops/aggregate.ts';
import { compileSortLimit } from '../src/compute/ops/sort_limit.ts';

/**
 * The operations' own tests assert on the SQL text they produce. That proves the text is
 * the text we meant to write; it does not prove the database accepts it. These tests run
 * every compiled statement against the real engine, which is the only way a missing
 * comma, a reserved word or a dialect difference is ever found.
 *
 * All rows below are invented.
 */

let ctx: RunContext;

const PRICES = [
  { code: 'AAA', d: '2026-01-05', px: 10, vol: 1000 },
  { code: 'AAA', d: '2026-01-06', px: 12, vol: 2000 },
  { code: 'BBB', d: '2026-01-05', px: 50, vol: 300 },
  { code: 'BBB', d: '2026-01-06', px: 45, vol: 900 },
  { code: 'CCC', d: '2026-01-06', px: 7, vol: 50 },
];

const SECTORS = [
  { code: 'AAA', sector: 'tools' },
  { code: 'BBB', sector: 'paper' },
];

before(async () => {
  ctx = await RunContext.create();
  await ctx.query(`CREATE TABLE prices AS SELECT * FROM (VALUES
    ('AAA', DATE '2026-01-05', 10, 1000),
    ('AAA', DATE '2026-01-06', 12, 2000),
    ('BBB', DATE '2026-01-05', 50, 300),
    ('BBB', DATE '2026-01-06', 45, 900),
    ('CCC', DATE '2026-01-06', 7, 50)
  ) AS t(code, d, px, vol)`);
  await ctx.query(`CREATE TABLE sectors AS SELECT * FROM (VALUES
    ('AAA', 'tools'), ('BBB', 'paper')
  ) AS t(code, sector)`);
});

after(() => ctx?.close());

const priceCols = [
  { name: 'code', type: 'VARCHAR' },
  { name: 'd', type: 'DATE' },
  { name: 'px', type: 'INTEGER' },
  { name: 'vol', type: 'INTEGER' },
];
const sectorCols = [
  { name: 'code', type: 'VARCHAR' },
  { name: 'sector', type: 'VARCHAR' },
];

function input(
  inputs: string[],
  params: Record<string, unknown> = {},
): OpCompileInput {
  return {
    inputs,
    columns: new Map([
      ['prices', priceCols],
      ['sectors', sectorCols],
    ]),
    params: new Map(Object.entries(params)),
    scalars: new Map(),
  };
}

/** Compile, then actually run it. */
async function run(step: { sql: string; bindings: unknown[] }) {
  return ctx.query(step.sql, step.bindings as never[]);
}

test('filter runs and keeps only the matching rows', async () => {
  const step = compileFilter({ where: 'px > 10' }, input(['prices']));
  const res = await run(step);
  assert.equal(res.rows.length, 3);
  for (const r of res.rows) assert.ok(Number(r.px) > 10);
});

test('filter binds a setting rather than writing it into the text', async () => {
  const step = compileFilter(
    { where: 'px > $params.floor' },
    input(['prices'], { floor: 40 }),
  );
  assert.ok(!step.sql.includes('40'), 'the value must not appear in the SQL text');
  assert.deepEqual(step.bindings, [40]);
  const res = await run(step);
  assert.equal(res.rows.length, 2);
  for (const r of res.rows) assert.ok(Number(r.px) > 40);
});

test('derive runs and adds the calculated column', async () => {
  const step = compileDerive(
    { columns: { turnover: 'px * vol' } },
    input(['prices']),
  );
  const res = await run(step);
  assert.equal(res.rows.length, 5);
  assert.ok(res.columns.some((c) => c.name === 'turnover'));
  const aaa = res.rows.find((r) => r.code === 'AAA' && Number(r.px) === 12);
  assert.equal(Number(aaa?.turnover), 24000);
});

test('aggregate runs, groups, and names its metrics', async () => {
  const step = compileAggregate(
    {
      by: ['code'],
      metrics: [
        { fn: 'sum', of: 'vol', as: 'total_vol' },
        { fn: 'mean', of: 'px', as: 'avg_px' },
        { fn: 'count', as: 'days' },
      ],
    },
    input(['prices']),
  );
  const res = await run(step);
  assert.equal(res.rows.length, 3);
  const aaa = res.rows.find((r) => r.code === 'AAA');
  assert.equal(Number(aaa?.total_vol), 3000);
  assert.equal(Number(aaa?.avg_px), 11);
  assert.equal(Number(aaa?.days), 2);
});

test('aggregate runs a quantile with its p bound', async () => {
  const step = compileAggregate(
    { by: [], metrics: [{ fn: 'quantile', of: 'px', as: 'median_px', p: 0.5 }] },
    input(['prices']),
  );
  assert.deepEqual(step.bindings, [0.5]);
  const res = await run(step);
  assert.equal(res.rows.length, 1);
  assert.equal(Number(res.rows[0]?.median_px), 12);
});

test('aggregate runs count_distinct', async () => {
  const step = compileAggregate(
    { by: [], metrics: [{ fn: 'count_distinct', of: 'code', as: 'n' }] },
    input(['prices']),
  );
  const res = await run(step);
  assert.equal(Number(res.rows[0]?.n), 3);
});

test('sort_limit runs, orders, and limits', async () => {
  const step = compileSortLimit(
    { by: [{ col: 'px', dir: 'desc' }], limit: 2 },
    input(['prices']),
  );
  assert.ok(!step.sql.includes('2 '), 'the limit must be bound, not written in');
  const res = await run(step);
  assert.equal(res.rows.length, 2);
  assert.equal(Number(res.rows[0]?.px), 50);
  assert.equal(Number(res.rows[1]?.px), 45);
});

test('sort_limit runs with its limit supplied by a setting', async () => {
  const step = compileSortLimit(
    { by: [{ col: 'px', dir: 'asc' }], limit: { param: 'top_n' } },
    input(['prices'], { top_n: 3 }),
  );
  const res = await run(step);
  assert.equal(res.rows.length, 3);
  assert.equal(Number(res.rows[0]?.px), 7);
});

test('sort_limit runs with an offset', async () => {
  const step = compileSortLimit(
    { by: [{ col: 'px', dir: 'asc' }], limit: 2, offset: 1 },
    input(['prices']),
  );
  const res = await run(step);
  assert.equal(res.rows.length, 2);
  assert.equal(Number(res.rows[0]?.px), 10);
});

test('an inner join runs and matches on the key', async () => {
  const step = compileJoin(
    { right: 'sectors', on: [['code', 'code']], how: 'inner' },
    input(['prices', 'sectors']),
  );
  const res = await run(step);
  assert.equal(res.rows.length, 4, 'CCC has no sector, so it drops out');
});

test('a left join runs and keeps the unmatched row', async () => {
  const step = compileJoin(
    { right: 'sectors', on: [['code', 'code']], how: 'left' },
    input(['prices', 'sectors']),
  );
  const res = await run(step);
  assert.equal(res.rows.length, 5);
});

test('aggregate refuses to produce two columns with the same name', () => {
  assert.throws(
    () =>
      compileAggregate(
        { by: ['code'], metrics: [{ fn: 'sum', of: 'vol', as: 'code' }] },
        input(['prices']),
      ),
    /both be called 'code'/,
    'a later step reading that name would get whichever the engine returned first',
  );
});

test('every compiled operation keeps its SQL to a single statement', async () => {
  const steps = [
    compileFilter({ where: 'px > 10' }, input(['prices'])),
    compileDerive({ columns: { t: 'px * vol' } }, input(['prices'])),
    compileSortLimit({ by: [{ col: 'px', dir: 'asc' }], limit: 2 }, input(['prices'])),
    compileAggregate(
      { by: ['code'], metrics: [{ fn: 'sum', of: 'vol', as: 'v' }] },
      input(['prices']),
    ),
    compileJoin(
      { right: 'sectors', on: [['code', 'code']], how: 'inner' },
      input(['prices', 'sectors']),
    ),
  ];
  for (const step of steps) {
    assert.equal(step.sql.includes(';'), false, `a statement separator appeared in: ${step.sql}`);
  }
});

test('a join names its output columns and drops the duplicated key', async () => {
  const step = compileJoin(
    { right: 'sectors', on: [['code', 'code']], how: 'inner' },
    input(['prices', 'sectors']),
  );
  const res = await run(step);
  const names = res.columns.map((c) => c.name);
  assert.deepEqual(names, ['code', 'd', 'px', 'vol', 'sector'],
    'the right-hand key must not come through as a second column called code');
  assert.equal(new Set(names).size, names.length, 'no two output columns may share a name');
});

test('a join suffixes a non-key collision instead of emitting it twice', async () => {
  await ctx.query(`CREATE TABLE notes AS SELECT * FROM (VALUES
    ('AAA', 'a note', 99)
  ) AS t(code, note, px)`);

  const withNotes: OpCompileInput = {
    inputs: ['prices', 'notes'],
    columns: new Map([
      ['prices', priceCols],
      ['notes', [
        { name: 'code', type: 'VARCHAR' },
        { name: 'note', type: 'VARCHAR' },
        { name: 'px', type: 'INTEGER' },
      ]],
    ]),
    params: new Map(),
    scalars: new Map(),
  };

  const step = compileJoin(
    { right: 'notes', on: [['code', 'code']], how: 'inner' },
    withNotes,
  );
  const res = await run(step);
  const names = res.columns.map((c) => c.name);
  assert.deepEqual(names, ['code', 'd', 'px', 'vol', 'note', 'px_notes']);
  assert.equal(Number(res.rows[0]?.px_notes), 99, 'the right-hand px must survive under its new name');
});

test('a join refuses to join a relation to itself', () => {
  assert.throws(
    () => compileJoin({ right: 'prices', on: [['code', 'code']], how: 'inner' },
      { ...input(['prices', 'prices']) }),
    /itself/,
  );
});

test('a join alias never collides with a column that already has that name', async () => {
  /**
   * With a left `px` and a right holding both `px` and `px_notes`, the renamed `px` and
   * the real `px_notes` both claimed `px_notes`, and reading it returned the wrong one.
   */
  await ctx.query(`CREATE TABLE twin AS SELECT * FROM (VALUES
    ('AAA', 30, 40)
  ) AS t(code, px, px_notes)`);

  const withTwin: OpCompileInput = {
    inputs: ['prices', 'twin'],
    columns: new Map([
      ['prices', priceCols],
      ['twin', [
        { name: 'code', type: 'VARCHAR' },
        { name: 'px', type: 'INTEGER' },
        { name: 'px_notes', type: 'INTEGER' },
      ]],
    ]),
    params: new Map(),
    scalars: new Map(),
  };

  const res = await run(compileJoin({ right: 'twin', on: [['code', 'code']], how: 'inner' }, withTwin));
  const names = res.columns.map((c) => c.name);
  assert.equal(new Set(names).size, names.length, `names must be unique: ${names.join(', ')}`);

  const row = res.rows[0];
  assert.equal(Number(row?.px_twin), 30, 'the right-hand px is renamed after its relation');
  assert.equal(
    Number(row?.px_notes),
    40,
    'the right-hand px_notes keeps its own name and its own value',
  );
  assert.deepEqual(names, ['code', 'd', 'px', 'vol', 'px_twin', 'px_notes']);
});
