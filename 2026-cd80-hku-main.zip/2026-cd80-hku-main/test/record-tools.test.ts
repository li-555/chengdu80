import { test } from 'node:test';
import assert from 'node:assert/strict';
import { detachedDOM, type TestElement } from './dom-fixture.ts';
import { createRecordTools } from '../web/src/record-tools.ts';
import { createListActionPanel } from '../web/src/list-actions.ts';
import type { ParamDecl } from '../src/app-schema/index.ts';
import type { ListActionSnapshot } from '../src/platform/list-actions.ts';
import type { RunResult } from '../src/compute/result.ts';
const params: ParamDecl[] = [{ key: 'selected', label: 'Selected record', type: 'text', default: 'FAKE-A' }, { key: 'done', label: 'Saved records', type: 'text', list: true }];
function table(names: string[], rows: unknown[][]): RunResult['outputs'][string] { return { schema: names.map((name) => ({ name, label: name, type: 'text', nullable: false })), rows }; }
function fixture(declarations: ParamDecl[] = params) {
  const dom = detachedDOM('/apps/fake'); let raw = 'FAKE-A', busy = false, editable = true, runs = 0;
  let snapshot: ListActionSnapshot | undefined = { appVersion: 'fake', revision: 'fake', params: [{ key: 'done', label: 'Saved records', values: [] }], history: [] };
  const saves: unknown[] = [], sets: unknown[] = [];
  const tools = createRecordTools({ params: declarations, getRaw: () => raw, setParam: (key, value) => { sets.push([key, value]); raw = value; }, run: () => { runs++; }, canEdit: () => editable, actions: { snapshot: () => snapshot, isBusy: () => busy, saveRecordAction: async (value) => { saves.push(value); return true; } } });
  dom.view.append(tools.element as unknown as TestElement);
  return { ...dom, tools, saves, sets, runs: () => runs, raw: (value: string) => { raw = value; }, busy: (value: boolean) => { busy = value; }, editable: (value: boolean) => { editable = value; }, snapshot: (value: ListActionSnapshot | undefined) => { snapshot = value; }, elements: (tag: string) => dom.view.querySelectorAll(tag) };
}
test('picker uses fresh bounded choices, explicit unknown selection and safe labels', () => {
  const f = fixture(); try {
    f.tools.show({ pick_selected: table(['value', 'label'], [['FAKE-A', '<img src=x>'], ['FAKE-B', 'Second'], ['FAKE-B', 'Duplicate'], [2, 'Invalid']]) });
    assert.equal(f.elements('option').length, 2); assert.equal(f.elements('img').length, 0); assert.match(f.view.textContent, /<img src=x>/);
    const select = f.elements('select')[0]!; select.value = 'FAKE-B'; select.dispatchEvent(new Event('change')); f.elements('button')[0]!.click();
    assert.deepEqual(f.sets, [['selected', 'FAKE-B']]); assert.equal(f.runs(), 1); assert.deepEqual(f.saves, []);
    f.tools.sync(); f.raw('FAKE-UNKNOWN'); f.tools.sync(); assert.equal(f.elements('select')[0]!.value, 'FAKE-UNKNOWN'); assert.equal(f.elements('button')[0]!.disabled, true); f.raw('FAKE-B'); f.tools.sync();
    f.tools.show({ pick_selected: table(['value', 'label'], [['FAKE-C', 'Fresh']]) });
    assert.match(f.elements('option')[0]!.textContent, /FAKE-B.*not in latest results/); assert.equal(f.elements('select')[0]!.value, 'FAKE-B'); assert.equal(f.elements('button')[0]!.disabled, true);
    f.tools.show({ pick_selected: table(['value', 'label'], Array.from({ length: 600 }, (_, i) => [`FAKE-${i}`, `Choice ${i}`])) });
    assert.equal(f.elements('option').length, 501);
    f.tools.clear(); assert.equal(f.elements('select').length, 0); assert.equal(f.tools.element.hidden, true);
  } finally { f.restore(); }
});
test('explicit empty picker value is runnable while an unknown placeholder is disabled', () => {
  const f = fixture(); try {
    f.raw('');
    f.tools.show({ pick_selected: table(['value', 'label'], [['', 'All invented records'], [' ', 'Invalid whitespace'], [null, 'Invalid type'], ['FAKE-A', 'Record A']]) });
    assert.equal(f.elements('option').length, 2); assert.equal(f.elements('select')[0]!.value, '');
    assert.equal(f.elements('option')[0]!.textContent, 'All invented records'); assert.equal(f.elements('button')[0]!.disabled, false);
    f.elements('button')[0]!.click(); assert.deepEqual(f.sets, [['selected', '']]); assert.equal(f.runs(), 1);
    f.tools.show({ pick_selected: table(['value', 'label'], [['FAKE-A', 'Record A']]) });
    assert.equal(f.elements('select')[0]!.value, ''); assert.match(f.elements('option')[0]!.textContent, /not in latest results/); assert.equal(f.elements('button')[0]!.disabled, true);
    f.elements('button')[0]!.click(); assert.equal(f.runs(), 1);
    f.tools.show({ act_done: table(['record_id', 'label', 'add_label', 'remove_label'], [['', 'Empty ID', 'Add', 'Remove'], [' ', 'Whitespace ID', 'Add', 'Remove']]) });
    assert.equal(f.tools.element.hidden, true);
  } finally { f.restore(); }
});
test('record actions use current saved membership and stop while busy, readonly or missing snapshot', () => {
  const f = fixture(); try {
    f.tools.show({ act_done: table(['record_id', 'label', 'add_label', 'remove_label', 'detail'], [['FAKE-A', 'Record A', 'Mark done', 'Reopen', '<b>Safe detail</b>']]) });
    const button = f.elements('button')[0]!; assert.equal(button.textContent, 'Mark done'); button.click();
    f.snapshot({ appVersion: 'fake', revision: 'new', params: [{ key: 'done', label: 'Saved records', values: ['FAKE-A'] }], history: [] }); f.tools.sync();
    assert.equal(button.textContent, 'Reopen'); button.click();
    assert.deepEqual(f.saves, [{ param: 'done', recordId: 'FAKE-A', action: 'add', note: '' }, { param: 'done', recordId: 'FAKE-A', action: 'remove', note: '' }]); assert.equal(f.elements('b').length, 0);
    f.busy(true); f.tools.sync(); assert.equal(button.disabled, true); button.click(); assert.equal(f.saves.length, 2);
    f.busy(false); f.editable(false); f.tools.sync(); assert.equal(button.disabled, true);
    f.editable(true); f.snapshot(undefined); f.tools.sync(); assert.equal(button.disabled, true);
  } finally { f.restore(); }
});
test('undeclared and wrong-kind tables are ignored; action rows are bounded and deduplicated', () => {
  const f = fixture(); try {
    f.tools.show({ pick_unknown: table(['value', 'label'], [['x', 'X']]), act_selected: table(['record_id', 'label', 'add_label', 'remove_label'], [['x', 'X', 'Add', 'Remove']]), pick_done: table(['value', 'label'], [['x', 'X']]), act_done: table(['record_id', 'label'], [['x', 'X']]) });
    assert.equal(f.tools.element.hidden, true);
    f.tools.show({ act_done: table(['record_id', 'label', 'add_label', 'remove_label'], [['FAKE-A', 'A', 'Add', 'Remove'], ['FAKE-A', 'Duplicate', 'Add', 'Remove'], ...Array.from({ length: 80 }, (_, i) => [`FAKE-${i}`, 'Record', 'Add', 'Remove'])]) });
    assert.equal(f.elements('button').length, 50);
  } finally { f.restore(); }
});
test('action accordions retain rows, count records and open only short lists', () => {
  const f = fixture(); try {
    const columns = ['record_id', 'label', 'add_label', 'remove_label'];
    const rows = Array.from({ length: 10 }, (_, i) => [`FAKE-${i}`, `Record ${i}`, 'Mark done', 'Reopen']);
    f.tools.show({ pick_selected: table(['value', 'label'], [['FAKE-A', 'Record A']]), act_done: table(columns, rows) });
    assert.equal(f.elements('.run-setting').length, 1); assert.equal(f.elements('details').length, 1);
    assert.equal(f.elements('details')[0]!.open, false); assert.equal(f.elements('summary')[0]!.textContent, 'Saved records (10)');
    assert.equal(f.elements('h4').length, 10); assert.equal(f.elements('details')[0]!.querySelectorAll('.screen-panel').length, 10);
    const first = f.elements('details')[0]!.querySelectorAll('button')[0]!;
    f.snapshot({ appVersion: 'fake', revision: 'new', params: [{ key: 'done', label: 'Saved records', values: ['FAKE-0'] }], history: [] }); f.tools.sync();
    assert.equal(first.textContent, 'Reopen'); first.click(); assert.deepEqual(f.saves, [{ param: 'done', recordId: 'FAKE-0', action: 'remove', note: '' }]);
    f.tools.show({ act_done: table(columns, rows.slice(0, 3)) });
    assert.equal(f.elements('details')[0]!.open, true); assert.equal(f.elements('summary')[0]!.textContent, 'Saved records (3)'); assert.equal(f.elements('button').length, 3);
  } finally { f.restore(); }
});
test('pickers precede actions even when the list parameter is declared first', () => {
  const f = fixture([...params].reverse()); try {
    f.tools.show({ act_done: table(['record_id', 'label', 'add_label', 'remove_label'], [['FAKE-A', 'Record A', 'Add', 'Remove']]), pick_selected: table(['value', 'label'], [['FAKE-A', 'Record A']]) });
    const groups = f.view.querySelector('[data-record-tools]')!.children;
    assert.equal(groups[0]!.className, 'run-setting'); assert.equal(groups[0]!.querySelector('select')!.value, 'FAKE-A');
    assert.equal(groups[1]!.tagName, 'DETAILS'); assert.equal(groups[1]!.querySelector('summary')!.textContent, 'Saved records (1)');
  } finally { f.restore(); }
});
test('panel rejects overlapping and unconfirmed new actions and retries the exact original payload', async () => {
  const dom = detachedDOM('/apps/fake'); const originalFetch = globalThis.fetch; const bodies: string[] = []; let posts = 0;
  const snapshot: ListActionSnapshot = { appVersion: 'fake', revision: 'fake', params: [{ key: 'done', label: 'Saved records', values: [] }], history: [] };
  let saved: unknown;
  globalThis.fetch = (async (_url, init) => { if (!init?.method) return { ok: true, json: async () => snapshot } as Response; bodies.push(String(init.body)); posts++; if (posts === 1) throw new Error('Invented unconfirmed response'); return { ok: true, json: async () => ({ snapshot: { ...snapshot, params: [{ ...snapshot.params[0]!, values: ['FAKE-A'] }] } }) } as Response; }) as typeof fetch;
  try {
    const panel = createListActionPanel('fake', (value, key) => { saved = [value.params[0]?.values, key]; }); dom.view.append(panel as unknown as TestElement); await panel.refresh();
    const action = { param: 'done', recordId: 'FAKE-A', action: 'add' as const, note: 'Invented note' };
    const pending = panel.saveRecordAction(action); assert.equal(panel.isBusy(), true); assert.equal(await panel.saveRecordAction(action), false); assert.equal(await pending, false);
    assert.equal(panel.isBusy(), true); assert.equal(await panel.saveRecordAction({ ...action, recordId: 'FAKE-B' }), false); assert.equal(bodies.length, 1);
    dom.view.querySelector('form')!.requestSubmit(); await new Promise((resolve) => setTimeout(resolve, 0));
    assert.equal(bodies.length, 2); assert.equal(bodies[0], bodies[1]); assert.deepEqual(saved, [['FAKE-A'], 'done']); assert.equal(panel.isBusy(), false); assert.deepEqual(panel.snapshot()?.params[0]?.values, ['FAKE-A']);
  } finally { globalThis.fetch = originalFetch; dom.restore(); }
});
