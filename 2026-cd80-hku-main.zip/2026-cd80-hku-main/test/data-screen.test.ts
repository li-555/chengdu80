import { test } from 'node:test';
import assert from 'node:assert/strict';
import { visibleDatasets } from '../web/src/data-screen.ts';
import type { Dataset } from '../src/data/types.ts';

const fake = (id: string, source: Dataset['source']): Dataset => ({ id, name: `Invented ${id}`, source, fields: [{ name: 'fake_date', label: 'Invented date', type: 'date', nullable: false }], rowCount: 7 });

test('data screen exposes shared metadata and profile uploads, never unowned sources', () => {
  const shared = fake('tushare:invented', 'tushare');
  const mine = fake('user:invented-mine', 'upload');
  const other = fake('user:invented-other', 'upload');
  const api = fake('api:invented-other', 'api');
  assert.deepEqual(visibleDatasets([shared, mine, other, api], [mine]), [shared, mine]);
  assert.deepEqual(visibleDatasets([shared, other, api], []), [shared]);
});

test('profile upload metadata replaces duplicate entries and unknown API ownership stays hidden', () => {
  const mine = fake('user:invented-mine', 'upload');
  assert.deepEqual(visibleDatasets([mine], [mine, mine, fake('api:invented', 'api')]), [mine]);
  assert.deepEqual(visibleDatasets([], []), []);
});
