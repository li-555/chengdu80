import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';

import { RunContext } from '../src/compute/context.ts';
import type { CompiledStep, OpCompileInput } from '../src/compute/ops/contract.ts';
import { compileWindow } from '../src/compute/ops/window.ts';
import { compileLagChange } from '../src/compute/ops/lag_change.ts';
import { compileRank } from '../src/compute/ops/rank.ts';
import { compileZscore } from '../src/compute/ops/zscore.ts';
import { compileResample } from '../src/compute/ops/resample.ts';
import { compilePivot } from '../src/compute/ops/pivot.ts';
import { compileDescribe } from '../src/compute/ops/describe.ts';
import { compileCorrelate } from '../src/compute/ops/correlate.ts';
import { compileRegress } from '../src/compute/ops/regress.ts';

/** All rows below are invented. Expected answers are calculated beside each test. */
let ctx: RunContext;

before(async () => {
  ctx = await RunContext.create();
  await ctx.query(`CREATE TABLE samples AS SELECT * FROM (VALUES
    ('AAA', DATE '2026-01-01', 0, 1, 3, 'red'),
    ('AAA', DATE '2026-01-02', 2, 2, 5, 'blue'),
    ('AAA', DATE '2026-01-04', 4, 3, 7, 'red'),
    ('AAA', DATE '2026-02-01', 4, 4, 9, 'blue'),
    ('BBB', DATE '2026-01-01', 10, 1, 3, 'red'),
    ('BBB', DATE '2026-01-02', 15, 2, 5, 'blue')
  ) AS t(code, d, v, x, y, category)`);
  await ctx.query(`CREATE TABLE nonlinear AS SELECT * FROM (VALUES
    (1, 1), (2, 4), (3, 9), (4, 16), (NULL, 0), (0, NULL)
  ) AS t(x, y)`);
  await ctx.query(`CREATE TABLE monotonic AS SELECT * FROM (VALUES
    (1, 1), (2, 4), (3, 9), (NULL, 0), (0, NULL)
  ) AS t(x, y)`);
  await ctx.query(`CREATE TABLE ties AS SELECT * FROM (VALUES
    (1, 1), (1, 2), (3, 2), (4, 4), (NULL, 0), (0, NULL)
  ) AS t(x, y)`);
});

after(() => ctx?.close());

function input(relation = 'samples', params: Record<string, unknown> = {}): OpCompileInput {
  return {
    inputs: [relation],
    columns: new Map([
      ['samples', [
        { name: 'code', type: 'VARCHAR' }, { name: 'd', type: 'DATE' },
        { name: 'v', type: 'INTEGER' }, { name: 'x', type: 'INTEGER' },
        { name: 'y', type: 'INTEGER' }, { name: 'category', type: 'VARCHAR' },
      ]],
      ['nonlinear', [{ name: 'x', type: 'INTEGER' }, { name: 'y', type: 'INTEGER' }]],
      ['monotonic', [{ name: 'x', type: 'INTEGER' }, { name: 'y', type: 'INTEGER' }]],
      ['ties', [{ name: 'x', type: 'INTEGER' }, { name: 'y', type: 'INTEGER' }]],
    ]),
    params: new Map(Object.entries(params)),
    scalars: new Map(),
  };
}

async function run(step: CompiledStep) {
  return ctx.query(step.sql, step.bindings as never[]);
}

const order = [{ col: 'd', dir: 'asc' as const }];

function close(actual: unknown, expected: number): void {
  assert.ok(Math.abs(Number(actual) - expected) < 1e-12, `${actual} should equal ${expected}`);
}

test('window executes a bound rolling two-row mean', async () => {
  const result = await run(compileWindow({ fn: 'mean', of: 'v', partition_by: ['code'], order_by: order,
    frame: { kind: 'rows', preceding: { param: 'back' }, following: 0 }, as: 'rolling' }, input('samples', { back: 1 })));
  // AAA: 0, (0+2)/2=1, (2+4)/2=3, (4+4)/2=4; BBB: 10, (10+15)/2=12.5.
  assert.deepEqual(result.rows.filter((r) => r.code === 'AAA').sort((a, b) => String(a.d).localeCompare(String(b.d))).map((r) => r.rolling), [0, 1, 3, 4]);
  assert.deepEqual(result.rows.filter((r) => r.code === 'BBB').sort((a, b) => String(a.d).localeCompare(String(b.d))).map((r) => r.rolling), [10, 12.5]);
});

test('range window executes with bound DATE intervals', async () => {
  const result = await run(compileWindow({ fn: 'mean', of: 'v', partition_by: ['code'], order_by: order,
    frame: { kind: 'range', preceding: 1, following: 0 }, as: 'rolling' }, input()));
  // Jan 4 is two days after Jan 2, so its one-day frame contains only 4.
  assert.deepEqual(result.rows.filter((r) => r.code === 'AAA').sort((a, b) => String(a.d).localeCompare(String(b.d))).map((r) => r.rolling), [0, 1, 4, 4]);
});

test('lag_change executes partitioned percentage changes and protects zero', async () => {
  const result = await run(compileLagChange({ of: 'v', periods: 1, mode: 'pct', partition_by: ['code'], order_by: order, as: 'change' }, input()));
  // AAA: first=NULL, 2/0=NULL, 4/2-1=1, 4/4-1=0; BBB: first=NULL, 15/10-1=0.5.
  assert.deepEqual(result.rows.filter((r) => r.code === 'AAA').sort((a, b) => String(a.d).localeCompare(String(b.d))).map((r) => r.change), [null, null, 1, 0]);
  assert.deepEqual(result.rows.filter((r) => r.code === 'BBB').sort((a, b) => String(a.d).localeCompare(String(b.d))).map((r) => r.change), [null, 0.5]);
});

test('lag_change executes difference and positive-only logarithms', async () => {
  for (const mode of ['diff', 'log'] as const) {
    const result = await run(compileLagChange({ of: 'v', periods: 1, mode, partition_by: ['code'], order_by: order, as: 'change' }, input()));
    const rows = result.rows.filter((r) => r.code === 'AAA').sort((a, b) => String(a.d).localeCompare(String(b.d)));
    // Differences: NULL, 2-0=2, 4-2=2, 4-4=0. Logs require both values positive.
    if (mode === 'diff') assert.deepEqual(rows.map((r) => r.change), [null, 2, 2, 0]);
    else {
      assert.deepEqual(rows.slice(0, 2).map((r) => r.change), [null, null]);
      close(rows[2]?.change, Math.log(2));
      close(rows[3]?.change, 0);
    }
  }
});

test('rank and dense rank execute with ties', async () => {
  for (const method of ['rank', 'dense'] as const) {
    const result = await run(compileRank({ by: 'v', direction: 'desc', within: ['code'], method, as: 'position' }, input()));
    // AAA descending values 4,4,2,0: rank=1,1,3,4; dense=1,1,2,3.
    const rows = result.rows.filter((r) => r.code === 'AAA').sort((a, b) => Number(b.v) - Number(a.v));
    assert.deepEqual(rows.map((r) => r.position), method === 'rank' ? [1, 1, 3, 4] : [1, 1, 2, 3]);
  }
});

test('zscore executes a full rolling frame and zero-variance protection', async () => {
  const result = await run(compileZscore({ of: 'v', within: ['code'], window: 2, order_by: order, as: 'z' }, input()));
  // A pair differing by 2 has sample std=sqrt(2); newest deviation=1, so z=1/sqrt(2).
  // The initial frame has one row, and the final pair 4,4 has std=0: both give NULL.
  const rows = result.rows.filter((r) => r.code === 'AAA').sort((a, b) => String(a.d).localeCompare(String(b.d)));
  assert.equal(rows[0]?.z, null);
  close(rows[1]?.z, 1 / Math.sqrt(2));
  close(rows[2]?.z, 1 / Math.sqrt(2));
  assert.equal(rows[3]?.z, null);
});

test('resample executes monthly buckets per code and shared quantiles', async () => {
  const result = await run(compileResample({ date_col: 'd', by: ['code'], to: 'month', metrics: [
    { fn: 'sum', of: 'v', as: 'total' }, { fn: 'quantile', of: 'v', as: 'mid', p: 0.5 },
  ] }, input()));
  // AAA Jan=0+2+4=6, median=2; AAA Feb=4; BBB Jan=10+15=25, median=12.5.
  assert.deepEqual(result.columns.map((c) => c.name), ['code', 'd', 'total', 'mid']);
  assert.deepEqual(result.rows.map((r) => [r.code, r.d, Number(r.total), r.mid]), [
    ['AAA', '2026-01-01', 6, 2], ['AAA', '2026-02-01', 4, 4], ['BBB', '2026-01-01', 25, 12.5],
  ]);
});

test('pivot executes inside CREATE TABLE AS and returns two category columns', async () => {
  const step = compilePivot({ index: ['code'], on: 'category', values: 'v', agg: 'sum' }, input());
  await ctx.query('CREATE TABLE pivoted AS ' + step.sql, step.bindings as never[]);
  const result = await ctx.query('SELECT * FROM pivoted ORDER BY code');
  // AAA blue=2+4=6, red=0+4=4; BBB blue=15, red=10.
  assert.deepEqual(result.rows.map((r) => [r.code, Number(r.blue), Number(r.red)]), [['AAA', 6, 4], ['BBB', 15, 10]]);
});

test('describe executes two numeric columns with the promised types', async () => {
  const result = await run(compileDescribe({ columns: ['x', 'y'] }, input('nonlinear')));
  // Non-null x sorted: 0,1,2,3,4. Mean=2, sample std=sqrt(10/4), quartiles=1,2,3.
  // Non-null y sorted: 0,1,4,9,16. Mean=6, std=sqrt(174/4), quartiles=1,4,9.
  assert.deepEqual(result.columns.map((c) => c.type), ['VARCHAR', 'BIGINT', ...Array(7).fill('DOUBLE')]);
  assert.deepEqual(result.rows.map((r) => [r.column, r.count, r.mean, r.min, r.q25, r.median, r.q75, r.max]), [
    ['x', 5, 2, 0, 1, 2, 3, 4], ['y', 5, 6, 0, 1, 4, 9, 16],
  ]);
  close(result.rows[0]?.std, Math.sqrt(2.5));
  close(result.rows[1]?.std, Math.sqrt(43.5));
});

test('correlate executes pairwise complete Spearman ranks and min_periods', async () => {
  const result = await run(compileCorrelate({ columns: ['x', 'y'], method: 'spearman' }, input('monotonic')));
  // The three complete rows have ranks 1,2,3 on both sides, so correlation is exactly 1.
  assert.deepEqual(result.rows, [{ col_a: 'x', col_b: 'y', corr: 1, n: 3 }]);
  const short = await run(compileCorrelate({ columns: ['x', 'y'], method: 'spearman', min_periods: 4 }, input('monotonic')));
  assert.deepEqual(short.rows, [{ col_a: 'x', col_b: 'y', corr: null, n: 3 }]);
});

test('correlate executes average ranks for ties and Pearson complete pairs', async () => {
  const tied = await run(compileCorrelate({ columns: ['x', 'y'], method: 'spearman' }, input('ties')));
  // Average ranks: a=[1.5,1.5,3,4], b=[1,2.5,2.5,4]. Centered dot=3.75, sums of squares=4.5 each.
  close(tied.rows[0]?.corr, 3.75 / 4.5);
  assert.equal(tied.rows[0]?.n, 4);
  const pearson = await run(compileCorrelate({ columns: ['x', 'y'], method: 'pearson' }, input('nonlinear')));
  // Complete x mean=2.5, y mean=7.5. Centered dot=25, squares=5 and 129.
  close(pearson.rows[0]?.corr, 25 / Math.sqrt(5 * 129));
  assert.equal(pearson.rows[0]?.n, 4);
});

test('regress executes y=2x+1 per group and without groups', async () => {
  for (const by of [[], ['code']]) {
    const result = await run(compileRegress({ y: 'y', x: ['x'], by }, input()));
    // Every complete point lies on y=2x+1: slope=2, intercept=1, squared correlation=1.
    assert.equal(result.rows.length, by.length === 0 ? 2 : 4);
    for (const row of result.rows) {
      close(row.coefficient, row.term === 'intercept' ? 1 : 2);
      close(row.r2, 1);
      assert.equal(row.n, by.length === 0 ? 6 : row.code === 'AAA' ? 4 : 2);
    }
    assert.deepEqual(result.columns.map((c) => c.name), [...by, 'term', 'coefficient', 'r2', 'n']);
    assert.deepEqual(result.columns.slice(by.length).map((c) => c.type), ['VARCHAR', 'DOUBLE', 'DOUBLE', 'BIGINT']);
  }
});
