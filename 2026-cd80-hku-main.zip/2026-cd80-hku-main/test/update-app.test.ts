import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { AppDocument, appVersion } from '../src/app-schema/index.ts';
import { closeStorage } from '../src/platform/database.ts';
import { saveApp, updateApp, getApp, setState, getState, saveRun, listRuns, createScheduledTask, listScheduledTasks } from '../src/platform/index.ts';

const directory = mkdtempSync(join(tmpdir(), 'blocks-update-'));
const previousPath = process.env.BLOCKS_DB_PATH;
before(() => { process.env.BLOCKS_DB_PATH = join(directory, 'storage.sqlite'); });
after(() => {
  closeStorage();
  if (previousPath === undefined) delete process.env.BLOCKS_DB_PATH;
  else process.env.BLOCKS_DB_PATH = previousPath;
  rmSync(directory, { recursive: true, force: true });
});
function document() {
  return AppDocument.parse({
    meta: { name: 'Invented app', description: 'Invented test application', spec_version: '1.0' },
    params: [], data: [], compute: [], triggers: [{ kind: 'schedule', cron: '0 8 * * *' }],
    ui: { root: 'root', elements: { root: { type: 'Section', children: [] } } },
  });
}

test('updates preserve identity, state, runs and scheduled tasks while bumping revision and recording history', async () => {
  const saved = await saveApp(document(), 'owner');
  await setState(saved.id, 'owner', { params: { invented: 42 } });
  const run = { id: 'invented-run', appId: saved.id, appVersion: saved.version, startedAt: saved.createdAt, status: 'ok' as const, params: {} };
  await saveRun(run);
  const task = await createScheduledTask(saved.id, 'owner', 0);
  const input = document();
  input.meta.name = 'Updated invented app';
  await new Promise((resolve) => setTimeout(resolve, 5));
  const updated = await updateApp(saved.id, 'owner', input);
  assert.equal(updated.id, saved.id);
  assert.equal(updated.profile, saved.profile);
  assert.equal(updated.createdAt, saved.createdAt);
  assert.ok(updated.updatedAt > saved.updatedAt);
  assert.equal(updated.rev, 2);
  assert.equal(updated.version, appVersion(updated.doc));
  assert.notEqual(updated.version, saved.version);
  assert.deepEqual(updated.history, [{ version: saved.version, doc: saved.doc, updatedAt: saved.updatedAt }]);
  assert.deepEqual(await getApp(saved.id), updated);
  assert.deepEqual(await getState(saved.id, 'owner'), { params: { invented: 42 } });
  assert.deepEqual(await listRuns(saved.id), [run]);
  assert.deepEqual(await listScheduledTasks('owner'), [task]);
  const again = await updateApp(saved.id, 'owner', document());
  assert.equal(again.rev, 3);
});

test('history retains exactly the most recent ten prior documents and can restore their content', async () => {
  let current = await saveApp(document(), 'history');
  const prior = [];
  for (let index = 0; index < 12; index += 1) {
    prior.push({ version: current.version, doc: current.doc, updatedAt: current.updatedAt });
    const doc = document();
    doc.meta.name = `Invented version ${index}`;
    current = await updateApp(current.id, 'history', doc);
  }
  assert.deepEqual(current.history, prior.slice(-10));
  const restored = await updateApp(current.id, 'history', current.history![0]!.doc);
  assert.equal(restored.doc.meta.name, current.history![0]!.doc.meta.name);
  assert.equal(restored.rev, 14);
  assert.equal(restored.history!.length, 10);
});

test('unknown ids and other profiles fail clearly and invalid documents leave the app unchanged', async () => {
  const saved = await saveApp(document(), 'isolated');
  await assert.rejects(updateApp('unknown', 'isolated', document()), /Application not found for this profile/);
  await assert.rejects(updateApp(saved.id, 'other', document()), /Application not found for this profile/);
  const invalid = document();
  invalid.meta.name = '';
  await assert.rejects(updateApp(saved.id, 'isolated', invalid));
  assert.deepEqual(await getApp(saved.id), saved);
  const updated = await updateApp(saved.id, 'isolated', document());
  assert.equal(updated.rev, 2);
});
