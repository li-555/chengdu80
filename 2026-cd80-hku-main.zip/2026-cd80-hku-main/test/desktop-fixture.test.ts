import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { validateApplication } from '../src/validate/index.ts';
import { runApplication } from '../src/compute/run.ts';

test('desktop acceptance fixture runs without external data and produces the documented totals', async () => {
  const validated = validateApplication(readFileSync(new URL('./fixtures/desktop-workspace.fin.json', import.meta.url), 'utf8'));
  assert.equal(validated.ok, true, JSON.stringify(validated.report.errors));
  if (!validated.ok) return;
  assert.deepEqual(validated.document.data, []);
  for (const multiplier of [1, 2]) {
    const outcome = await runApplication(validated.document as Parameters<typeof runApplication>[0], { slices: {}, params: { multiplier }, want: ['total', 'values'] });
    assert.equal(outcome.status, 'ok', JSON.stringify(outcome.failure));
    assert.equal(Number(outcome.results.get('total')!.rows[0]!.total), 30 * multiplier);
    assert.deepEqual(outcome.results.get('values')!.rows.map((row) => Number(row.amount)), [10 * multiplier, 20 * multiplier]);
  }
});
