import { test } from 'node:test';
import assert from 'node:assert/strict';
import { detachedDOM, type TestElement } from './dom-fixture.ts';
import { createMonitorPanel } from '../web/src/monitor-panel.ts';
const baseline = () => ({ enabled: true, notice: 'Partial data: invented fixture', lastRunId: 'run-new', lastRunAt: '2026-10-15', counts: { active: 1, unacknowledged: 1, acknowledged: 0, unknown: 0 }, changes: [], alerts: [{ id: 'revision-1', eventId: 'event', title: '<img src=x>', detail: '<script>bad</script>', value: '7', status: 'active', firstSeenAt: 'first', lastSeenAt: 'last', runId: 'run-new', sourceUrl: 'https://example.test/path' }] });
const tick = () => new Promise<void>((resolve) => setImmediate(resolve));
function setup(handler: typeof fetch, editable = () => true) {
  const dom = detachedDOM('/'); const original = globalThis.fetch; globalThis.fetch = handler;
  const panel = createMonitorPanel('app / id', editable); dom.view.append(panel.element as unknown as TestElement);
  return { ...panel, view: panel.element as unknown as TestElement, close() { globalThis.fetch = original; dom.restore(); } };
}
function json(value: unknown, status = 200) { return new Response(JSON.stringify(value), { status }); }
function button(view: TestElement, name: string) { return view.querySelectorAll('button').find((item) => item.textContent === name)!; }
test('baseline, repeated refresh, notices and safe source links', async () => {
  let calls = 0; const panel = setup(async (url, init) => { calls++; assert.equal(url, '/api/apps/app%20%2F%20id/monitor'); assert.equal(init?.credentials, 'same-origin'); return json(baseline()); });
  try { assert.equal(panel.view.querySelectorAll('.notice')[0]!.hidden, true); await panel.refresh(); await panel.refresh(); assert.equal(panel.view.querySelectorAll('.notice')[0]!.hidden, true); assert.equal(calls, 2); assert.match(panel.view.textContent, /Baseline recorded/); assert.match(panel.view.textContent, /Partial data/); assert.match(panel.view.textContent, /historical run/); assert.equal(panel.view.querySelectorAll('script').length, 0); assert.match(panel.view.textContent, /<script>bad/); assert.equal(panel.view.querySelectorAll('a').length, 1); assert.equal(panel.view.querySelectorAll('article').length, 1); } finally { panel.close(); }
});
test('unknown is explicit, caps keep authoritative counts, unsafe links are omitted', async () => {
  const value = baseline(); value.counts.unknown = 80; value.counts.active = 99;
  value.alerts = Array.from({ length: 60 }, (_, i) => ({ ...value.alerts[0]!, id: String(i), status: 'unknown', sourceUrl: ['javascript:alert(1)', 'https://user:pass@example.test', 'http://example.test'][i % 3]! }));
  const data = { ...value, previousRunId: 'old', changes: Array.from({ length: 60 }, (_, i) => ({ id: String(i), title: 'Change', kind: 'unknown', before: null, after: null, detail: 'Unknown' })) };
  const panel = setup(async () => json(data)); try { await panel.refresh(); assert.match(panel.view.textContent, /99 active/); assert.match(panel.view.textContent, /do not mean all clear/); assert.equal(panel.view.querySelectorAll('article').length, 50); assert.equal(panel.view.querySelectorAll('details').length, 50); assert.equal(panel.view.querySelectorAll('a').length, 0); assert.doesNotMatch(panel.view.textContent, /Baseline recorded/); } finally { panel.close(); }
});
test('acknowledge and reopen send idempotent set payload and read authoritative state', async () => {
  const value = baseline(); const bodies: unknown[] = [];
  const panel = setup(async (url, init) => { if (String(url).endsWith('/ack')) { assert.equal((init?.headers as Record<string, string>)['X-Blocks-Request'], '1'); bodies.push(JSON.parse(init?.body as string)); if (bodies.length === 1) Object.assign(value.alerts[0]!, { acknowledgedAt: 'saved-time' }); else delete (value.alerts[0] as { acknowledgedAt?: string }).acknowledgedAt; } return json(value); });
  try { await panel.refresh(); button(panel.view, 'Acknowledge').click(); await tick(); assert.match(panel.view.textContent, /Acknowledged: saved-time/); button(panel.view, 'Reopen').click(); await tick(); assert.deepEqual(bodies, [{ alertId: 'revision-1', acknowledged: true }, { alertId: 'revision-1', acknowledged: false }]); } finally { panel.close(); }
});
test('stale revisions and uncertain network failures require refresh without repeat', async () => {
  for (const stale of [true, false]) {
    let posts = 0; const panel = setup(async (url) => { if (String(url).endsWith('/ack')) { posts++; if (stale) return json({}, 409); throw new DOMException('Timed out', 'AbortError'); } return json(baseline()); });
    try { await panel.refresh(); button(panel.view, 'Acknowledge').click(); await tick(); assert.match(panel.view.textContent, stale ? /alert changed/ : /unconfirmed/); button(panel.view, 'Acknowledge').click(); await tick(); assert.equal(posts, 1); assert.equal(button(panel.view, 'Acknowledge').disabled, true); await panel.refresh(); assert.equal(button(panel.view, 'Acknowledge').disabled, false); } finally { panel.close(); }
  }
});
test('overlap, read-only state and detached lifecycle block writes', async () => {
  let editable = true, posts = 0; let finish: ((value: Response) => void) | undefined;
  const panel = setup(async (_url, init) => { if (init?.method === 'POST') { posts++; return await new Promise<Response>((resolve) => { finish = resolve; }); } return json(baseline()); }, () => editable);
  try { await panel.refresh(); editable = false; panel.sync(); assert.equal(button(panel.view, 'Acknowledge').disabled, true); button(panel.view, 'Acknowledge').click(); await tick(); assert.equal(posts, 0); editable = true; panel.sync(); button(panel.view, 'Acknowledge').click(); button(panel.view, 'Acknowledge').click(); await panel.refresh(); assert.equal(posts, 1); panel.view.remove(); finish!(json({})); await tick(); assert.doesNotMatch(panel.view.textContent, /Acknowledgment saved/); } finally { panel.close(); }
});
test('disabled monitor explains absence and cleared alerts have no action', async () => {
  const value = baseline(); value.enabled = false; const panel = setup(async () => json(value));
  try { await panel.refresh(); assert.match(panel.view.textContent, /No monitoring events are configured/); value.enabled = true; value.alerts[0]!.status = 'cleared'; await panel.refresh(); assert.equal(button(panel.view, 'Acknowledge'), undefined); } finally { panel.close(); }
});
test('requests abort at the 30 second deadline and keep acknowledgment unconfirmed', async () => {
  const panel = setup(async (_url, init) => {
    if (init?.method !== 'POST') return json(baseline());
    return await new Promise<Response>((_resolve, reject) => { init.signal?.addEventListener('abort', () => reject(new DOMException('Deadline', 'AbortError'))); });
  });
  const originalTimer = window.setTimeout;
  try {
    await panel.refresh();
    let deadline: (() => void) | undefined;
    window.setTimeout = ((callback: () => void, milliseconds: number) => { assert.equal(milliseconds, 30_000); deadline = callback; return originalTimer(() => {}, 60_000); }) as typeof window.setTimeout;
    button(panel.view, 'Acknowledge').click(); deadline!(); await tick();
    assert.match(panel.view.textContent, /unconfirmed/); assert.equal(button(panel.view, 'Acknowledge').disabled, true);
  } finally { window.setTimeout = originalTimer; panel.close(); }
});
test('overlapping refreshes queue one authoritative GET after the earlier response', async () => {
  let calls = 0; let resolveOld: ((value: Response) => void) | undefined;
  const panel = setup(async () => { calls++; if (calls === 1) return await new Promise<Response>(resolve => { resolveOld = resolve; }); return json({ ...baseline(), lastRunId: 'newest-run' }); });
  try {
    const loading = panel.refresh(); await panel.refresh(); await panel.refresh(); assert.equal(calls, 1);
    resolveOld!(json({ ...baseline(), lastRunId: 'old-run' })); await loading;
    assert.equal(calls, 2); assert.match(panel.view.textContent, /Latest data record: newest-run/);
    assert.doesNotMatch(panel.view.textContent, /Latest data record: old-run/);
  } finally { panel.close(); }
});
test('refresh during acknowledgment queues a follow-up and detachment cancels queued reads', async () => {
  for (const detach of [false, true]) {
    let reads = 0; let resolveAck: ((value: Response) => void) | undefined;
    const panel = setup(async (_url, init) => { if (init?.method === 'POST') return await new Promise<Response>(resolve => { resolveAck = resolve; }); reads++; return json({ ...baseline(), lastRunId: `read-${reads}` }); });
    try {
      await panel.refresh(); button(panel.view, 'Acknowledge').click(); await panel.refresh(); await panel.refresh();
      if (detach) panel.view.remove(); resolveAck!(json({})); await tick();
      assert.equal(reads, detach ? 1 : 3);
      if (!detach) assert.match(panel.view.textContent, /Latest data record: read-3/);
    } finally { panel.close(); }
  }
});
test('failed GET disables stale acknowledgment until successful refresh', async () => {
  let fail = false;
  const panel = setup(async () => { if (fail) throw new Error('Unavailable'); return json(baseline()); });
  try {
    await panel.refresh(); fail = true; await panel.refresh();
    assert.equal(button(panel.view, 'Acknowledge').disabled, true);
    fail = false; await panel.refresh(); assert.equal(button(panel.view, 'Acknowledge').disabled, false);
  } finally { panel.close(); }
});
