import { test } from 'node:test';
import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import { readFileSync } from 'node:fs';
import { createServer, IncomingMessage, ServerResponse } from 'node:http';
import { Socket } from 'node:net';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { appRoutes } from '../src/api/routes-apps.ts';
import { validateRouter } from '../src/api/routes-validate.ts';
import { validateApplication, type ValidationReport } from '../src/validate/index.ts';

const EXAMPLE = new URL('../examples/ex-01-daily-movers.fin.json', import.meta.url);
const document = readFileSync(EXAMPLE, 'utf8');
const app = express();
app.use(validateRouter);
app.use(appRoutes);

function post(body: string, contentType: string | null = 'application/json', origin?: string, url = '/api/validate'): Promise<Response> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    const socket = new Socket();
    socket._write = (chunk, _encoding, callback) => { chunks.push(Buffer.from(chunk)); callback(); };
    socket._writev = (pending, callback) => {
      for (const { chunk } of pending) chunks.push(Buffer.from(chunk));
      callback();
    };
    const request = new IncomingMessage(new Socket());
    request.method = 'POST';
    request.url = url;
    request.headers = { host: 'localhost', 'content-length': String(Buffer.byteLength(body)) };
    if (origin) request.headers.origin = origin;
    if (contentType !== null) request.headers['content-type'] = contentType;
    const response = new ServerResponse(request);
    response.assignSocket(socket);
    response.once('error', reject);
    response.once('finish', () => {
      const output = Buffer.concat(chunks).toString('utf8');
      resolve(new Response(output.slice(output.indexOf('\r\n\r\n') + 4), {
        status: response.statusCode,
        headers: { 'Content-Type': String(response.getHeader('Content-Type')) },
      }));
      socket.destroy();
      request.socket.destroy();
    });
    createServer(app).emit('request', request, response);
    request.push(Buffer.from(body));
    request.push(null);
  });
}

const unknownKeys = Object.fromEntries(Array.from({ length: 30_000 }, (_, i) => ['x' + i, 0]));
const hostile = { meta: { spec_version: '1.0', ...unknownKeys } };

function bounded(report: ValidationReport): void {
  assert.equal(report.valid, false);
  assert.equal(report.errors.length, 200);
  assert.equal(report.errors.at(-1)?.code, 'E_TOO_MANY_ERRORS');
  assert.ok(Buffer.byteLength(JSON.stringify(report)) < 200_000);
  for (const entry of [...report.errors, ...report.warnings]) {
    assert.ok(entry.message.length <= 500);
    assert.ok((entry.hint?.length ?? 0) <= 500);
  }
}

test('30,000 unknown keys produce a bounded route report within two seconds', async () => {
  const start = performance.now();
  const response = await post(JSON.stringify(hostile));
  assert.equal(response.status, 200);
  const report = await response.json() as ValidationReport;
  assert.ok(performance.now() - start < 2000);
  bounded(report);
  assert.match(report.errors[2]!.hint!, /and 29990 more/);
  assert.equal(report.errors.at(-1)?.received, '29808');
});

test('30,000 unknown keys produce the same bounded direct report', () => {
  bounded(validateApplication(hostile).report);
  bounded(validateApplication(JSON.stringify(hostile)).report);
});

test('30,000 unknown keys validate with a 128 MB heap', () => {
  const module = new URL('../src/validate/index.ts', import.meta.url).href;
  const output = execFileSync(process.execPath, ['--max-old-space-size=128', '--input-type=module', '--eval', `
    import { validateApplication } from ${JSON.stringify(module)};
    const doc = { meta: { spec_version: '1.0', ...Object.fromEntries(Array.from({ length: 30000 }, (_, i) => ['x' + i, 0])) } };
    const report = validateApplication(JSON.stringify(doc)).report;
    if (report.errors.length !== 200 || report.errors.at(-1).code !== 'E_TOO_MANY_ERRORS') process.exit(1);
    console.log('REPORT_SIZE=' + JSON.stringify(report).length);
  `], { encoding: 'utf8', timeout: 10_000, env: { ...process.env, NODE_OPTIONS: '' } });
  // Read only our own marked line: anything else a machine prints to stdout is ignored.
  const size = Number(/REPORT_SIZE=(\d+)/.exec(output)?.[1]);
  assert.ok(size < 200_000, `report size ${size}; child printed: ${output.slice(0, 500)}`);
});

test('validation refuses cross-origin requests exactly like import', async () => {
  const validation = await post(document, 'application/json', 'https://other.example');
  const importing = await post(document, 'application/json', 'https://other.example', '/api/apps/import');
  assert.equal(validation.status, 403);
  assert.equal(importing.status, 403);
  assert.deepEqual(await validation.json(), await importing.json());
});

test('validation accepts requests from the platform page', async () => {
  const response = await post(document, 'application/json', 'http://localhost');
  assert.equal(response.status, 200);
  assert.equal((await response.json() as ValidationReport).valid, true);
});

test('root keys and array schema errors are capped without losing the total', () => {
  const rootReport = validateApplication({ ...JSON.parse(document), ...unknownKeys }).report;
  bounded(rootReport);
  assert.equal(rootReport.errors.at(-1)?.received, '29801');
  const doc = JSON.parse(document);
  doc.params = Array.from({ length: 30_000 }, () => null);
  const arrayReport = validateApplication(doc).report;
  bounded(arrayReport);
  assert.equal(arrayReport.errors.at(-1)?.received, '29801');
});

test('reference warnings and warnings carried between phases share one cap', () => {
  const doc = JSON.parse(document);
  doc.params = Array.from({ length: 40 }, (_, i) => ({ key: 'unused_' + i, type: 'number', default: 0, label: 'Unused' }));
  doc.data = Array.from({ length: 12 }, (_, i) => ({ key: 'data_' + i, fields: [{ name: 'value', type: 'number', required: true }] }));
  doc.compute = Array.from({ length: 60 }, (_, i) => ({ id: 'step_' + i, kind: 'sql', sql: 'select * from data_0' }));
  doc.ui = { root: 'page', elements: { page: { type: 'Section', children: [] }, ...Object.fromEntries(
    Array.from({ length: 59 }, (_, i) => ['unused_' + i, { type: 'Callout', text: 'Unused' }]),
  ) } };
  doc.meta.icon = 'unknown';
  const report = validateApplication(doc).report;
  assert.equal(report.stopped_in, 'limits');
  assert.equal(report.warnings.length, 200);
  const summary = report.warnings.at(-1)!;
  assert.equal(summary.code, 'E_TOO_MANY_ERRORS');
  assert.equal(summary.severity, 'warning');
  assert.equal(summary.received, '32');
});

test('long input strings cannot inflate report fields', () => {
  const key = 'x'.repeat(300_000);
  const report = validateApplication({ meta: { spec_version: '1.0', [key]: 0 } }).report;
  for (const entry of report.errors) {
    for (const value of Object.values(entry)) if (typeof value === 'string') assert.ok(value.length <= 500);
  }
  assert.ok(Buffer.byteLength(JSON.stringify(report)) < 20_000);
});
