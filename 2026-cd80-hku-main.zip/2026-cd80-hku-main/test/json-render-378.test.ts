import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { z } from 'zod';
import { defineSchema, defineCatalog } from '@json-render/core';
import { UiElement, ELEMENT_SCHEMA, ELEMENT_TYPES } from '../src/app-schema/index.ts';

/**
 * A permanent reproduction of the screen-rendering library's own validation defect.
 *
 * Measured on 2026-10-13 against the pinned version, and it is broader than the upstream
 * report says:
 *
 *   spec shape                        1 component   2 or more
 *   nested, a single root object      correct       WRONGLY ACCEPTS
 *   flat, a map of elements           WRONGLY       WRONGLY ACCEPTS
 *                                     ACCEPTS
 *
 * Blocks uses the flat shape -- `ui.root` plus `ui.elements` -- so the library validates
 * element props **not at all**, whatever the number of element types. The component count
 * in the upstream issue is a red herring for us.
 *
 * Therefore our own per-element check is not a second pass over a working one. It is the
 * only check that happens. C02 rests entirely on it.
 *
 * This test exists so a version bump cannot quietly change the situation in either
 * direction. If the library is fixed, these tests fail and tell us so.
 */

// The package does not export ./package.json, so read it from disk.
const CORE_VERSION: string = JSON.parse(
  readFileSync(new URL('../node_modules/@json-render/core/package.json', import.meta.url), 'utf8'),
).version;

const schema = defineSchema((s) => ({
  spec: s.object({
    root: s.string(),
    elements: s.map({
      type: s.ref('catalog.components'),
      props: s.propsOf('catalog.components'),
      children: s.array(s.string()),
    }),
  }),
  catalog: s.object({
    components: s.map({ props: s.zod(), description: s.string() }),
  }),
}));

/** Both components demand the same strict numeric prop, so neither is the permissive one. */
const strictProps = z.strictObject({ value: z.number() });

/** The shape Blocks uses: a root key and a flat map of elements. */
const flatSchema = schema;
const flatSpec = (props: unknown) => ({
  root: 'root',
  elements: { root: { type: 'A', props, children: [] } },
});

/** The shape the library's own documentation shows: one nested root object. */
const nestedSchema = defineSchema((s) => ({
  spec: s.object({
    root: s.object({
      type: s.ref('catalog.components'),
      props: s.propsOf('catalog.components'),
      children: s.array(s.string()),
    }),
  }),
  catalog: s.object({ components: s.map({ props: s.zod(), description: s.string() }) }),
}));
const nestedSpec = (props: unknown) => ({ root: { type: 'A', props, children: [] } });

const withComponents = (n: number) => ({
  components: Object.fromEntries(
    ['A', 'B', 'C'].slice(0, n).map((k) => [k, { props: strictProps, description: `component ${k}` }]),
  ),
});

const BAD_PROPS: [string, unknown][] = [
  ['a string where a number is required', { value: 'wrong' }],
  ['a missing required prop', {}],
  ['an unknown extra prop', { value: 42, extra: true }],
];

test('the pinned version is the one this defect was measured against', () => {
  assert.equal(CORE_VERSION, '0.21.0',
    'the version changed: re-run this file and re-check every claim below');
});

test('valid props are accepted in every configuration', () => {
  for (const n of [1, 2, 3]) {
    assert.equal(defineCatalog(flatSchema, withComponents(n)).validate(flatSpec({ value: 42 })).success, true);
    assert.equal(defineCatalog(nestedSchema, withComponents(n)).validate(nestedSpec({ value: 42 })).success, true);
  }
});

test('in the FLAT shape Blocks uses, the library validates props NOT AT ALL', () => {
  for (const n of [1, 2, 3]) {
    const catalog = defineCatalog(flatSchema, withComponents(n));
    for (const [what, props] of BAD_PROPS) {
      assert.equal(strictProps.safeParse(props).success, false, `${what} really is invalid`);
      assert.equal(catalog.validate(flatSpec(props)).success, true,
        `the defect has changed: with ${n} component(s) the flat shape now rejects ${what}. ` +
        'Re-measure before relying on it, and do not remove our own check.');
    }
  }
});

test('in the NESTED shape, the defect needs two or more components, as reported upstream', () => {
  const one = defineCatalog(nestedSchema, withComponents(1));
  for (const [what, props] of BAD_PROPS) {
    assert.equal(one.validate(nestedSpec(props)).success, false,
      `one component in the nested shape should still reject ${what}`);
  }
  for (const n of [2, 3]) {
    const many = defineCatalog(nestedSchema, withComponents(n));
    for (const [what, props] of BAD_PROPS) {
      assert.equal(many.validate(nestedSpec(props)).success, true,
        `${n} components in the nested shape should wrongly accept ${what}`);
    }
  }
});

test('our own check catches every case the library lets through', () => {
  // Not a second pass over a working check. The only check there is.
  const ourEquivalents: unknown[] = [
    { type: 'Metric', label: 'x', from: 'd', value: 'v', format: 'nonsense' },
    { type: 'Metric', label: 'x', from: 'd' },
    { type: 'Metric', label: 'x', from: 'd', value: 'v', extra: true },
    { type: 'Table', from: 'd', columns: [] },
    { type: 'Chart', chart: 'candlestick', from: 'd', x: 'd' },
  ];
  for (const el of ourEquivalents) {
    assert.equal(UiElement.safeParse(el).success, false, `our check must reject ${JSON.stringify(el)}`);
  }
});

test('we hold a schema of our own for every element type, so the second pass can never be partial', () => {
  for (const type of ELEMENT_TYPES) {
    assert.ok(ELEMENT_SCHEMA[type], `no schema of our own for ${type}`);
    assert.equal(typeof ELEMENT_SCHEMA[type]!.safeParse, 'function', `${type}'s schema is not usable`);
  }
  assert.equal(Object.keys(ELEMENT_SCHEMA).length, ELEMENT_TYPES.length);
});
