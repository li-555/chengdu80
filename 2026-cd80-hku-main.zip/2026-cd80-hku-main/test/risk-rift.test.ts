import { flagshipLogicDocument } from './flagship-test-helpers.ts';
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { validateApplication } from '../src/validate/index.ts';
import { runForScreen } from '../src/compute/result.ts';
import type { Slice } from '../src/compute/run.ts';

const raw = JSON.parse(readFileSync(new URL('../examples/risk-rift.fin.json', import.meta.url), 'utf8'));
const checked = validateApplication(flagshipLogicDocument('risk-rift', raw));
if (!checked.ok) throw new Error(JSON.stringify(checked.errors));
const fixture = JSON.parse(readFileSync(new URL('./fixtures/flagship-inputs/risk-rift.json', import.meta.url), 'utf8')) as {
  label: string; requirements: Record<string, { fields: { name: string; type: string }[]; rows: Record<string, string | number | boolean | null>[] }>;
};
async function execute(change?: (data: typeof fixture) => void, params: Record<string, string | number | string[]> = {}) {
  const data = structuredClone(fixture);
  change?.(data);
  const slices = Object.fromEntries(Object.entries(data.requirements).map(([key, r]) => [key, {
    columns: r.fields.map(f => ({ name: f.name, type: f.type === 'text' ? 'string' : f.type })), rows: r.rows,
  }])) as Record<string, Slice>;
  const { result } = await runForScreen(checked.ok ? checked.document : neverDoc(), { slices, params });
  assert.equal(result.status, 'ok', result.failure?.message);
  assert.deepEqual(result.outputs.monitor_events!.schema.map(c=>[c.name,c.type]),['event_id','title','status','value','detail','source_url'].map(n=>[n,'text']));
  const objects = (name: string) => result.outputs[name]!.rows.map(row => Object.fromEntries(result.outputs[name]!.schema.map((c, i) => [c.name, row[i]])));
  return { events: objects('monitor_events'), picks: objects('pick_selected_finding_id'), actions: objects('act_reviewed_finding_ids'), conventionSchemas: { picks: result.outputs.pick_selected_finding_id!.schema, actions: result.outputs.act_reviewed_finding_ids!.schema }, rows: objects('financial_findings'), disclosures: objects('disclosure_findings'), documents: objects('document_findings'), digest: objects('digest'), counts: objects('status_counts'), queue: objects('pending_queue'), priorities: objects('priority_summary'), detail: objects('selected_detail') };
}
function neverDoc(): never { throw new Error('Invalid app'); }
const find = (rows: Record<string, unknown>[], company: string, rule: string) => rows.find(r => r.company === company && r.rule === rule)!;

test('RiskRift validates and calculates independent invented financial checks', async () => {
  assert.equal(fixture.label, 'Invented RiskRift demo inputs');
  const r = await execute();
  assert.equal(find(r.rows, 'DEMO_A', 'R1').status, 'triggered');
  assert.equal(find(r.rows, 'DEMO_A', 'R1').observed, 1 / 3);
  assert.ok(Math.abs(Number(find(r.rows, 'DEMO_A', 'R2').observed) - 0.5) < 1e-12);
  assert.equal(find(r.rows, 'DEMO_A', 'R2').status, 'triggered');
  assert.equal(find(r.rows, 'DEMO_A', 'R7').observed, 0.75);
  assert.equal(find(r.rows, 'DEMO_B', 'R1').status, 'not_evaluable');
  assert.equal(find(r.rows, 'DEMO_B', 'R2').status, 'triggered');
  assert.equal(find(r.rows, 'DEMO_B', 'R7').status, 'not_triggered');
  assert.equal(find(r.rows, 'DEMO_A', 'R1').available_at, '2026-04-02');
  assert.ok(!JSON.stringify(raw).includes('DEMO_A'), 'fixture rows must stay out of the portable app');
});

test('zero and negative denominators remain not_evaluable; missing CFO leaves R2 and R7', async () => {
  for (const denominator of [0, -100, null]) {
    const r = await execute(d => { const row = d.requirements.financials!.rows[1]!; row.current_liabilities = denominator; row.net_income = denominator; row.cfo = null; });
    assert.equal(find(r.rows, 'DEMO_A', 'R1').status, 'not_evaluable');
    assert.equal(find(r.rows, 'DEMO_A', 'R2').status, 'triggered');
    assert.equal(find(r.rows, 'DEMO_A', 'R7').status, 'not_evaluable');
  }
});

test('cross-period CFO and nonconsecutive reports do not fabricate comparisons', async () => {
  const mismatch = await execute(d => { d.requirements.financials!.rows[1]!.cfo_period_end = '2024-12-31'; });
  assert.equal(find(mismatch.rows, 'DEMO_A', 'R1').status, 'not_evaluable');
  assert.equal(find(mismatch.rows, 'DEMO_A', 'R2').status, 'triggered');
  const gap = await execute(d => { const r = d.requirements.financials!.rows[0]!; r.period_end = '2023-12-31'; r.cfo_period_end = '2023-12-31'; });
  assert.equal(find(gap.rows, 'DEMO_A', 'R1').status, 'not_evaluable');
  assert.equal(find(gap.rows, 'DEMO_A', 'R2').status, 'not_evaluable');
  assert.equal(find(gap.rows, 'DEMO_A', 'R7').status, 'triggered');
});

test('as-of eligibility, ambiguous revisions and scope are fail closed', async () => {
  const future = await execute(d => { d.requirements.financials!.rows[1]!.cfo_published_at = '2027-01-01'; });
  assert.equal(find(future.rows, 'DEMO_A', 'R1').status, 'not_evaluable');
  assert.equal(find(future.rows, 'DEMO_A', 'R7').status, 'triggered');
  const duplicate = await execute(d => { d.requirements.financials!.rows.push({ ...d.requirements.financials!.rows[1]! }); });
  assert.equal(find(duplicate.rows, 'DEMO_A', 'R7').status, 'not_evaluable');
  const scope = await execute(d => { d.requirements.financials!.rows[1]!.nonfinancial = false; });
  assert.equal(find(scope.rows, 'DEMO_A', 'R7').status, 'not_evaluable');
  const missing = await execute(undefined, { companies: ['UNKNOWN'] });
  assert.equal(missing.rows.length, 5);
  assert.ok(missing.rows.every(r => r.status === 'not_evaluable'));
});

test('title screening is not verified evidence; disclosure dates are enforced', async () => {
  const r = await execute();
  assert.equal(r.disclosures[0]!.status, 'not_evaluable');
  assert.equal(r.disclosures[0]!.evidence_basis, 'supplied title only');
  assert.equal(r.disclosures[1]!.status, 'triggered');
  assert.match(String(r.disclosures[1]!.evidence_basis), /human-verified excerpt/);
  const future = await execute(d => { d.requirements.disclosures!.rows[1]!.published_at = '2027-01-01'; });
  assert.equal(future.disclosures[1]!.status, 'not_evaluable');
  assert.equal(future.disclosures[1]!.source_ref, '');
});

test('review IDs change the pending digest without erasing flagged evidence', async () => {
  const initial = await execute();
  const id = String(find(initial.rows, 'DEMO_A', 'R7').finding_id);
  const r = await execute(undefined, { reviewed_finding_ids: [id] });
  assert.equal(find(r.rows, 'DEMO_A', 'R7').status, 'triggered');
  assert.equal(find(r.rows, 'DEMO_A', 'R7').review_status, 'reviewed_by_user');
  assert.ok(!r.digest.some(x => x.finding_id === id));
  const thresholds = await execute(undefined, { companies: ['DEMO_A'], cash_ratio: 0.1, growth_gap: 0.6, current_ratio: 0.5 });
  assert.ok(thresholds.rows.every(r => r.status === 'not_triggered'));
});

test('supplied document metadata changes are detected even when text is unchanged', async () => {
  const r = await execute();
  assert.equal(r.documents[0]!.status, 'triggered');
  assert.match(String(r.documents[0]!.explanation), /Text unchanged; metadata changes: effective_at/);
  const same = await execute(d => { d.requirements.documents!.rows[1]!.effective_at = '2025-01-01'; });
  assert.equal(same.documents[0]!.status, 'not_triggered');
  const missing = await execute(d => { d.requirements.documents!.rows.pop(); });
  assert.equal(missing.documents[0]!.status, 'not_evaluable');
  assert.match(String(missing.documents[0]!.explanation), /collection gap, not evidence of repeal/);
  const unapproved = await execute(d => { d.requirements.documents!.rows[1]!.approved = false; });
  assert.equal(unapproved.documents[0]!.status, 'not_evaluable');
});


test('review IDs expire when source evidence or the applied threshold changes', async () => {
  const initial = await execute();
  const ids = [...initial.rows, ...initial.documents].map(r => String(r.finding_id));
  const changed = await execute(d => { d.requirements.documents!.rows[1]!.text = 'A revised invented paragraph.'; d.requirements.financials!.rows[1]!.current_assets = 170; }, { reviewed_finding_ids: ids });
  assert.equal(changed.documents[0]!.review_status, 'pending_review');
  assert.equal(find(changed.rows, 'DEMO_A', 'R7').review_status, 'pending_review');
  const threshold = await execute(undefined, { reviewed_finding_ids: ids, current_ratio: 0.9 });
  assert.equal(find(threshold.rows, 'DEMO_A', 'R7').review_status, 'pending_review');
});


test('illustrative priority queue orders indicators and separates unranked evidence gaps', async () => {
  const r = await execute();
  assert.equal(raw.compute.filter((s: { kind: string }) => s.kind === 'code').length, 1);
  assert.equal(r.detail[0]!.finding_id, r.queue[0]!.finding_id);
  const indicators = r.queue.filter(x => x.status === 'triggered');
  const gaps = r.queue.filter(x => x.status === 'not_evaluable');
  assert.ok(indicators.length > 0 && gaps.length > 0);
  assert.ok(gaps.every(x => x.priority_category === 'evidence_gap' && x.priority_rank === null && x.observed === null));
  assert.ok(indicators.every(x => x.priority_category === 'review_indicator' && /Illustrative configured/.test(String(x.priority_reason))));
  assert.deepEqual(r.queue.slice(0, indicators.length), indicators);
  assert.equal(r.priorities.reduce((n, x) => n + Number(x.count), 0), r.digest.length);
  const reordered = await execute(undefined, { financial_priority: 9, disclosure_priority: 1, document_priority: 2 });
  assert.equal(reordered.queue[0]!.lane, 'disclosure');
  assert.equal(reordered.queue[0]!.priority_rank, 1);
  assert.equal(find(reordered.rows, 'DEMO_A', 'R7').finding_id, find(r.rows, 'DEMO_A', 'R7').finding_id);
});

test('selected reviewed finding retains values, dates and source evidence but leaves pending counts', async () => {
  const initial = await execute();
  const finding = find(initial.rows, 'DEMO_A', 'R7');
  const id = String(finding.finding_id);
  const r = await execute(undefined, { selected_finding_id: id, reviewed_finding_ids: [id] });
  assert.equal(r.detail.length, 1);
  assert.equal(r.detail[0]!.finding_id, id);
  assert.equal(r.detail[0]!.review_status, 'reviewed_by_user');
  assert.equal(r.detail[0]!.observed, 0.75);
  assert.equal(r.detail[0]!.threshold, 1);
  assert.equal(r.detail[0]!.source_url, finding.source_url);
  const source = fixture.requirements.financials!.rows[1]!;
  assert.equal(Number(source.current_assets) / Number(source.current_liabilities), r.detail[0]!.observed);
  const evidence = String(r.detail[0]!.evidence_values);
  assert.ok(evidence.includes('Current assets: '+source.current_assets));
  assert.ok(evidence.includes('Current liabilities: '+source.current_liabilities));
  assert.ok(evidence.includes('Report period: 2025-12-31'));
  assert.ok(evidence.includes('Published at: '+source.published_at));
  assert.ok(evidence.includes('Source reference: '+source.source_ref));
  assert.ok(!evidence.includes('"current_assets"'));
  assert.ok(!r.queue.some(x => x.finding_id === id));
  assert.equal(r.priorities.reduce((n, x) => n + Number(x.count), 0), initial.digest.length - 1);
  const gap = initial.queue.find(x => x.status === 'not_evaluable')!;
  const detail = await execute(undefined, { selected_finding_id: String(gap.finding_id) });
  assert.match(String(detail.detail[0]!.missing_inputs), /Requires|verification|assessment/);
});

test('unknown selected ID has explicit empty detail and never silently selects another finding', async () => {
  const r = await execute(undefined, { selected_finding_id: 'UNKNOWN:ID' });
  assert.equal(r.detail.length, 0);
  assert.ok(r.queue.length > 0);
  assert.match(raw.ui.elements.detail.emptyHint, /Unknown finding ID/);
});
test('finding choices and local review actions preserve fingerprints and include reviewed findings', async () => {
  const initial=await execute();
  assert.equal(initial.picks.find(r=>r.value==='')!.label,'First pending finding');
  const id=String(initial.detail[0]!.finding_id);
  const reviewed=await execute(undefined,{reviewed_finding_ids:[id],selected_finding_id:id});
  assert.equal(reviewed.detail[0]!.review_status,'reviewed_by_user');
  assert(reviewed.picks.some(r=>r.value===id&&String(r.label).includes('reviewed_by_user')));
  assert.deepEqual(reviewed.actions.map(r=>r.record_id),[id]);
  assert.equal(reviewed.actions[0]!.add_label,'Mark reviewed');
  assert.equal(reviewed.actions[0]!.remove_label,'Reopen review');
  assert(String(reviewed.actions[0]!.detail).includes('not institutional approval'));
  assert.equal(reviewed.picks.length,initial.picks.length);
  assert.equal(new Set(reviewed.picks.map(r=>r.value)).size,reviewed.picks.length);
  for(const name of ['value','label'])assert.equal(reviewed.conventionSchemas.picks.find(f=>f.name===name)!.type,'text');
  for(const name of ['record_id','label','add_label','remove_label','detail'])assert.equal(reviewed.conventionSchemas.actions.find(f=>f.name===name)!.type,'text');
  const next=String(reviewed.picks.find(r=>r.value!==''&&r.value!==id)!.value);
  const switched=await execute(undefined,{selected_finding_id:next,reviewed_finding_ids:[id]});
  assert.equal(switched.detail[0]!.finding_id,next);
  assert.deepEqual(switched.actions.map(r=>r.record_id),[next]);
  const reopened=await execute(undefined,{selected_finding_id:id,reviewed_finding_ids:[]});
  assert.equal(reopened.detail[0]!.review_status,'pending_review');
  for(const unknown of ['UNKNOWN',' bad ', 'bad\nID']){
    const missing=await execute(undefined,{selected_finding_id:unknown,reviewed_finding_ids:[unknown]});
    assert.equal(missing.detail.length,0);assert.equal(missing.actions.length,0);
  }
  assert.equal((await execute(undefined,{selected_finding_id:''})).actions.length,1);
});
test('monitor identity survives changed evidence and local review never resolves a finding', async () => {
 const original=await execute();const finding=original.rows.find(r=>r.status==='triggered')!;assert(finding);
 const event=original.events.find(r=>r.event_id===finding.event_id)!;
 assert.equal(event.status,'active');assert(original.events.some(r=>r.status==='clear'));assert(original.events.some(r=>r.status==='unknown'));
 const reviewed=await execute(undefined,{reviewed_finding_ids:[String(finding.finding_id)]});assert.deepEqual(reviewed.events,original.events);
 const changed=await execute(v=>{for(const r of v.requirements.financials!.rows)if(r.company_id===finding.company)r.cfo=999999;});
 assert(changed.events.some(r=>r.event_id===event.event_id));
 const missing=await execute(v=>{for(const r of v.requirements.financials!.rows)r.cfo=null;});
 assert.equal(missing.events.find(r=>r.event_id===event.event_id)!.status,'unknown');
 assert.equal(original.counts.reduce((n,r)=>n+Number(r.count),0),original.rows.length+original.disclosures.length+original.documents.length);
 for(const r of original.events)for(const k of ['event_id','title','status','value','detail','source_url'])assert.equal(typeof r[k],'string');
});

test('annual revenue decline uses a strict configurable percent and permits zero current revenue', async () => {
  for (const [current, prior, threshold, status, observed] of [
    [75, 100, 25, 'not_triggered', 25],
    [70, 100, 30, 'not_triggered', 30],
    [69.9999999999, 100, 30, 'not_triggered', 30.0000000001],
    [69.99999999, 100, 30, 'triggered', 30.00000001],
    [74, 100, 25, 'triggered', 26],
    [100, 100, 10, 'not_triggered', 0],
    [125, 100, 10, 'not_triggered', -25],
    [0, 100, 10, 'triggered', 100],
    [-1, 100, 10, 'not_evaluable', null],
    [null, 100, 10, 'not_evaluable', null],
    [50, 0, 10, 'not_evaluable', null],
    [50, -100, 10, 'not_evaluable', null],
    [50, null, 10, 'not_evaluable', null],
  ] as const) {
    const r = await execute(d => {
      d.requirements.financials!.rows[0]!.revenue = prior;
      d.requirements.financials!.rows[1]!.revenue = current;
      d.requirements.financials!.rows[1]!.cfo = null;
    }, { revenue_decline_pct: threshold });
    const f = find(r.rows, 'DEMO_A', 'Annual revenue decline');
    assert.equal(f.status, status);
    if (observed === null) assert.equal(f.observed, null);
    else assert.ok(Math.abs(Number(f.observed) - observed) < 1e-10);
    assert.equal(f.threshold, threshold);
  }
});

test('annual net loss is independent of CFO and prior income, with zero a clear result', async () => {
  for (const [income, status] of [[-1, 'triggered'], [0, 'not_triggered'], [1, 'not_triggered'], [null, 'not_evaluable']] as const) {
    const r = await execute(d => {
      d.requirements.financials!.rows[0]!.net_income = null;
      Object.assign(d.requirements.financials!.rows[1]!, { net_income: income, cfo: null, cfo_period_end: null, cfo_published_at: null });
    });
    const f = find(r.rows, 'DEMO_A', 'Annual net loss');
    assert.equal(f.status, status);
    assert.equal(f.observed, income);
    assert.equal(f.threshold, 0);
    assert.equal(f.period, '2025-12-31');
    assert.equal(find(r.rows, 'DEMO_A', 'R1').status, 'not_evaluable');
  }
});

test('extra annual checks require comparable, eligible, unambiguous supplied evidence', async () => {
  const rules = ['Annual revenue decline', 'Annual net loss'];
  for (const patch of [
    { nonfinancial: false }, { nonfinancial: null }, { report_basis: 'quarterly consolidated' },
    { currency: null }, { unit: null }, { period_end: '2025-06-30' },
    { period_end: '2027-12-31' }, { published_at: '2027-01-01' },
  ]) {
    const r = await execute(d => {
      const row = { ...d.requirements.financials!.rows[1]!, net_income: -1 };
      Object.assign(row, patch);
      d.requirements.financials!.rows = [row];
    });
    for (const rule of rules) assert.equal(find(r.rows, 'DEMO_A', rule).status, 'not_evaluable', JSON.stringify(patch));
  }
  for (const patch of [{ currency: 'USD' }, { unit: 'millions' }, { period_end: '2023-12-31' }, { report_basis: 'parent only' }]) {
    const r = await execute(d => { Object.assign(d.requirements.financials!.rows[0]!, patch); });
    assert.equal(find(r.rows, 'DEMO_A', rules[0]!).status, 'not_evaluable');
    assert.equal(find(r.rows, 'DEMO_A', rules[1]!).status, 'not_triggered');
  }
  const duplicate = await execute(d => { d.requirements.financials!.rows.push({ ...d.requirements.financials!.rows[1]! }); });
  for (const rule of rules) assert.equal(find(duplicate.rows, 'DEMO_A', rule).status, 'not_evaluable');
  const priorDuplicate = await execute(d => { d.requirements.financials!.rows.push({ ...d.requirements.financials!.rows[0]! }); });
  assert.equal(find(priorDuplicate.rows, 'DEMO_A', rules[0]!).status, 'not_evaluable');
  assert.equal(find(priorDuplicate.rows, 'DEMO_A', rules[1]!).status, 'not_triggered');
  const missing = await execute(undefined, { companies: ['UNKNOWN'] });
  for (const rule of rules) assert.equal(find(missing.rows, 'UNKNOWN', rule).status, 'not_evaluable');
});

test('extra checks expose formula, evidence, review priorities and stable monitoring through changes', async () => {
  const decline = (d: typeof fixture) => {
    d.requirements.financials!.rows[0]!.revenue = 100;
    Object.assign(d.requirements.financials!.rows[1]!, { revenue: 50, net_income: -5, cfo: null });
  };
  const initial = await execute(decline, { financial_priority: 4 });
  for (const rule of ['Annual revenue decline', 'Annual net loss']) {
    const f = find(initial.rows, 'DEMO_A', rule);
    assert.equal(f.status, 'triggered');
    assert.equal(f.priority_rank, 4);
    assert.equal(f.priority_category, 'review_indicator');
    assert.match(String(f.explanation), /strictly|strict/);
    assert.match(String(f.explanation), /not a regulatory rule or fraud score/);
    assert.match(String(f.evidence_values), /Report period: 2025-12-31/);
    assert.match(String(f.evidence_values), /Published at:/);
    const id = String(f.finding_id);
    const reviewed = await execute(decline, { reviewed_finding_ids: [id], selected_finding_id: id });
    assert.equal(reviewed.detail[0]!.finding_id, id);
    assert.equal(reviewed.detail[0]!.review_status, 'reviewed_by_user');
    assert.ok(!reviewed.digest.some(r => r.finding_id === id));
    assert.equal(reviewed.events.find(r => r.event_id === f.event_id)!.status, 'active');
    const clear = await execute(d => { decline(d); Object.assign(d.requirements.financials!.rows[1]!, { revenue: 100, net_income: 0 }); }, { reviewed_finding_ids: [id] });
    const next = find(clear.rows, 'DEMO_A', rule);
    assert.equal(next.event_id, f.event_id);
    assert.notEqual(next.finding_id, id);
    assert.equal(next.review_status, 'pending_review');
    assert.equal(clear.events.find(r => r.event_id === f.event_id)!.status, 'clear');
    const unknown = await execute(d => { decline(d); Object.assign(d.requirements.financials!.rows[1]!, { revenue: null, net_income: null }); });
    assert.equal(unknown.events.find(r => r.event_id === f.event_id)!.status, 'unknown');
  }
  const old = find(initial.rows, 'DEMO_A', 'Annual revenue decline');
  const changed = await execute(decline, { revenue_decline_pct: 60, reviewed_finding_ids: [String(old.finding_id)] });
  const next = find(changed.rows, 'DEMO_A', 'Annual revenue decline');
  assert.equal(next.event_id, old.event_id);
  assert.notEqual(next.finding_id, old.finding_id);
  assert.equal(next.review_status, 'pending_review');
  assert.equal(next.status, 'not_triggered');
  assert.match(String(old.explanation), /\(1 - current revenue \/ prior revenue\) \* 100/);
  assert.match(String(old.evidence_values), /Revenue: 50/);
  assert.equal(new Set(initial.events.map(r => r.event_id)).size, initial.events.length);
});
