import { test } from 'node:test';
import assert from 'node:assert/strict';
import { checkExpression, compileExpression, FUNCTIONS, quoteIdentifier } from '../src/compute/expr.ts';

const scope = {
  columns: ['close', 'open', 'pct_move', 'code', 'band', 'android', 'notional', 'close_or_open'],
  params: ['move_threshold', 'watchlist', 'top_n'],
  scalars: ['avg_px'],
};

const ok = (expr: string) => {
  const problems = checkExpression(expr, scope);
  assert.deepEqual(problems, [], `${expr} should be accepted, got: ${problems.map((p) => p.message).join(' | ')}`);
};
const no = (expr: string, expectInMessage?: string) => {
  const problems = checkExpression(expr, scope);
  assert.ok(problems.length > 0, `${expr} should be refused`);
  if (expectInMessage) {
    assert.ok(
      problems.some((p) => p.message.toLowerCase().includes(expectInMessage.toLowerCase())),
      `${expr}: expected a message mentioning "${expectInMessage}", got: ${problems.map((p) => p.message).join(' | ')}`,
    );
  }
};

test('the function list is exactly the published one', () => {
  assert.deepEqual(Object.keys(FUNCTIONS).sort(), [
    'abs', 'ceil', 'clamp', 'coalesce', 'contains', 'date_diff', 'exp', 'floor',
    'if_null', 'len', 'log', 'lower', 'max', 'min', 'pow', 'round', 'sqrt',
    'starts_with', 'upper',
  ].sort());
  assert.equal(Object.keys(FUNCTIONS).length, 19);
});

test('ordinary finance formulas are accepted', () => {
  ok('(close - open) / open');
  ok('abs(pct_move) >= $params.move_threshold');
  ok('pct_move > 3 and close > 10');
  ok('pct_move > 3 or close > 10');
  ok('not (close > open)');
  ok('not close');
  ok('close > open ? close : open');
  ok('round(close, 2)');
  ok('clamp(pct_move, -10, 10)');
  ok('min(close, open)');
  ok('max(close, open, pct_move)');
  ok('contains(code, "SH")');
  ok('starts_with(code, "60")');
  ok('coalesce(close, open)');
  ok('if_null(close, 0)');
  ok('date_diff(close, open)');
  ok('close > avg_px');
  ok('close ?? open');
  ok('pow(close, 2)');
  ok('close ** 2');
  ok('len(code) == 9');
});

test('a column whose name contains a word operator still works', () => {
  ok('band > 1');
  ok('android > 1');
  ok('notional > 1');
  ok('close_or_open > 1');
});

test('reaching outside the formula is refused, by name', () => {
  no('close.constructor', 'property');
  no('close["x"]', 'property');
  no('close.__proto__', 'property');
  no('obj.prop', 'property');
  no('this', 'this');
  no('[1, 2, 3]', 'list');
  no('f()()', 'named function');
  no('frobnicate(close)', 'no function called');
  no('new Date()');
  no('close & open');
  no('close | open');
});

test('wrong argument counts are refused with the right number', () => {
  no('abs(close, open)', 'takes 1');
  no('clamp(close)', 'takes 3');
  no('min(close)', 'takes 2 to 8');
});

test('unknown columns and unknown settings are named', () => {
  no('nosuchcol > 1', 'nosuchcol');
  no('$params.nope > 1', 'nope');
});

test('scope checks are skipped for a set that was not supplied', () => {
  // the validator knows the parameters long before it knows a relation's columns
  assert.deepEqual(checkExpression('anything_at_all > 1', { params: ['x'] }), []);
  assert.deepEqual(checkExpression('$params.x > 1', { params: ['x'] }), []);
  assert.ok(checkExpression('$params.y > 1', { params: ['x'] }).length > 0);
});

test('a formula that does not parse says so instead of throwing', () => {
  no('1 + (', 'could not be read');
  no('', 'could not be read');
  no(')(', 'could not be read');
});

// --- compiling to SQL ----------------------------------------------------

test('an identifier is quoted, and a quote inside a name is doubled', () => {
  assert.equal(quoteIdentifier('close'), '"close"');
  assert.equal(quoteIdentifier('we"ird'), '"we""ird"');
});

test('no literal and no setting value is ever pasted into the SQL text', () => {
  const { sql, bindings } = compileExpression('abs(pct_move) >= $params.move_threshold', {
    scope, params: new Map([['move_threshold', 3.5]]),
  });
  assert.equal(sql, '(abs("pct_move") >= ?)');
  assert.deepEqual(bindings, [3.5]);
  assert.ok(!sql.includes('3.5'), 'the value must be a placeholder, not text');
});

test('a hostile setting value cannot change the SQL', () => {
  const nasty = "'; DROP TABLE prices; --";
  const { sql, bindings } = compileExpression('pct_move >= $params.move_threshold', {
    scope, params: new Map([['move_threshold', nasty]]),
  });
  assert.equal(sql, '("pct_move" >= ?)');
  assert.deepEqual(bindings, [nasty]);
  assert.ok(!sql.includes('DROP'), 'the value must never reach the SQL text');
});

test('the shapes that need rewriting for SQL are rewritten', () => {
  const c = (e: string) => compileExpression(e, { scope }).sql;
  assert.equal(c('min(close, open)'), 'least("close", "open")');       // SQL min is an aggregate
  assert.equal(c('max(close, open)'), 'greatest("close", "open")');
  assert.equal(c('ceil(close)'), 'ceiling("close")');
  assert.equal(c('log(close)'), 'ln("close")');
  assert.equal(c('pow(close, 2)'), 'power("close", ?)');
  assert.equal(c('len(code)'), 'length("code")');
  assert.equal(c('if_null(close, 0)'), 'coalesce("close", ?)');
  assert.equal(c('close ?? open'), 'coalesce("close", "open")');
  assert.equal(c('clamp(pct_move, -10, 10)'), 'least(greatest("pct_move", (-?)), ?)');
  assert.equal(c('contains(code, "SH")'), '(strpos("code", ?) > 0)');
  assert.equal(c('date_diff(close, open)'), '("close"::DATE - "open"::DATE)');
});

test('operators and conditionals become SQL', () => {
  const c = (e: string) => compileExpression(e, { scope }).sql;
  assert.equal(c('close > open and pct_move > 1'), '(("close" > "open") AND ("pct_move" > ?))');
  assert.equal(c('close > open or pct_move > 1'), '(("close" > "open") OR ("pct_move" > ?))');
  assert.equal(c('not (close > open)'), '(NOT ("close" > "open"))');
  assert.equal(c('close == open'), '("close" = "open")');
  assert.equal(c('close != open'), '("close" <> "open")');
  assert.equal(c('close > open ? 1 : 0'), '(CASE WHEN ("close" > "open") THEN ? ELSE ? END)');
});

test('compiling refuses an invalid formula instead of producing SQL', () => {
  assert.throws(() => compileExpression('close.constructor', { scope }), /refusing to compile/);
  assert.throws(() => compileExpression('1 + (', { scope }), /refusing to compile/);
});

test('compiling refuses when a setting has no value', () => {
  assert.throws(
    () => compileExpression('pct_move > $params.move_threshold', { scope }),
    /no value supplied for the setting "move_threshold"/,
  );
});

// ---------------------------------------------------------------------------
// Regressions for the review of 2026-10-13. All seven findings were accepted.
// ---------------------------------------------------------------------------

test('review 1: no function reorders its arguments, so bound values stay aligned', async () => {
  const { RunContext } = await import('../src/compute/context.ts');
  const ctx = await RunContext.create();
  try {
    // date_diff(later, earlier) must be positive. The earlier version swapped the
    // arguments in the SQL text but not the values, and returned the wrong sign.
    const c = compileExpression('date_diff($params.later, $params.earlier)', {
      scope: { params: ['later', 'earlier'] },
      params: new Map([['later', '2026-01-03'], ['earlier', '2026-01-01']]),
    });
    const r = await ctx.query(`SELECT ${c.sql} AS days`, c.bindings as never[]);
    assert.equal(r.rows[0]!.days, 2, `expected 2 days, got ${JSON.stringify(r.rows[0])} from ${c.sql}`);

    // and every other multi-argument function agrees with the database
    const cases: [string, Map<string, unknown>, unknown][] = [
      ['clamp($params.v, $params.lo, $params.hi)', new Map([['v', 50], ['lo', 0], ['hi', 10]]), 10],
      ['clamp($params.v, $params.lo, $params.hi)', new Map([['v', -5], ['lo', 0], ['hi', 10]]), 0],
      ['pow($params.a, $params.b)', new Map([['a', 2], ['b', 10]]), 1024],
      ['min($params.a, $params.b)', new Map([['a', 7], ['b', 3]]), 3],
      ['max($params.a, $params.b)', new Map([['a', 7], ['b', 3]]), 7],
      ['if_null($params.a, $params.b)', new Map([['a', null], ['b', 9]]), 9],
      ['round($params.a, $params.b)', new Map([['a', 1.2345], ['b', 2]]), 1.23],
      ['contains($params.a, $params.b)', new Map([['a', '600000.SH'], ['b', 'SH']]), true],
      ['starts_with($params.a, $params.b)', new Map([['a', '600000.SH'], ['b', '60']]), true],
    ];
    for (const [expr, params, expected] of cases) {
      const compiled = compileExpression(expr, { scope: { params: [...params.keys()] }, params });
      const out = await ctx.query(`SELECT ${compiled.sql} AS v`, compiled.bindings as never[]);
      assert.equal(out.rows[0]!.v, expected, `${expr} with ${JSON.stringify([...params])} -> ${compiled.sql}`);
    }
  } finally { ctx.close(); }
});

test('review 2: a formula nested too deep returns a problem instead of blowing the stack', () => {
  const deep = '1' + '+1'.repeat(5000);
  const problems = checkExpression(deep, {});
  assert.ok(problems.length > 0, 'must report a problem');
  assert.equal(problems.length, 1, 'and only one, not one per level');
  assert.match(problems[0]!.message, /too complicated|nested more than/);

  const nested = `${'('.repeat(2000)}1${')'.repeat(2000)}`;
  assert.doesNotThrow(() => checkExpression(nested, {}));
});

test('review 3: an earlier single value is bound, not written out as a column name', () => {
  const c = compileExpression('avg_px + 1', {
    scope: { columns: ['close'], scalars: ['avg_px'] },
    scalars: new Map([['avg_px', 10]]),
  });
  assert.equal(c.sql, '(? + ?)', 'a scalar step is a value, not a column of this relation');
  assert.deepEqual(c.bindings, [10, 1]);
  assert.ok(!c.sql.includes('avg_px'), 'its name must not appear as an identifier');

  assert.throws(
    () => compileExpression('avg_px + 1', { scope: { columns: ['close'], scalars: ['avg_px'] } }),
    /no value supplied for the earlier step "avg_px"/,
  );
});

test('review 4: an empty scope means nothing is declared, not "do not check"', () => {
  assert.ok(checkExpression('nope', { columns: [], scalars: [] }).length > 0);
  assert.ok(checkExpression('$params.nope', { params: [] }).length > 0);
  // and an omitted set still means "not known yet"
  assert.deepEqual(checkExpression('anything', {}), []);
  assert.deepEqual(checkExpression('$params.anything', { columns: ['a'] }), []);
});

test('review 5: configuring the parser only adds, and survives another module removing an operator', async () => {
  const jsep = (await import('jsep')).default;
  // bitwise operators belong to whoever else imports jsep; we must not have removed them
  assert.doesNotThrow(() => jsep('a & b'), 'we must not remove operators from the shared parser');
  ok('close > open');                         // ours still work

  // if something else removes one of ours, the next formula must still parse
  jsep.removeUnaryOp('not');
  ok('not (close > open)');
});

test('review 5b: an inherited property name is not an operator', () => {
  // `constructor` must never be treated as a unary operator even if something registers it
  for (const word of ['constructor', 'toString', 'valueOf', '__proto__']) {
    const problems = checkExpression(`${word} 1`, { columns: ['close'] });
    assert.ok(problems.length > 0, `"${word} 1" must be refused`);
  }
});

test('review 6: not next to a comparison needs brackets', () => {
  no('not close > open', 'brackets');
  no('not close == open', 'brackets');
  no('! close > open', 'brackets');
  no('close > not open', 'brackets');
  ok('not (close > open)');
  ok('not close');
});

test('review 7: a literal really is bound, not pasted', () => {
  const nasty = "'; DROP TABLE prices; --";
  const c = compileExpression('contains(code, "LITERAL")'.replace('LITERAL', nasty), { scope });
  assert.equal(c.sql, '(strpos("code", ?) > 0)');
  assert.deepEqual(c.bindings, [nasty]);
  assert.ok(!c.sql.includes('DROP'), 'the literal must never reach the SQL text');

  const n = compileExpression('close > 3.5', { scope });
  assert.equal(n.sql, '("close" > ?)');
  assert.deepEqual(n.bindings, [3.5]);
  assert.ok(!n.sql.includes('3.5'), 'a number literal is bound too');
});
