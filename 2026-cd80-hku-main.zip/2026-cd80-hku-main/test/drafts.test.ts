import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { createServer, IncomingMessage, ServerResponse } from 'node:http';
import { Socket } from 'node:net';
import express from 'express';
import { randomUUID } from 'node:crypto';
import { appRoutes } from '../src/api/routes-apps.ts';
import { closeStorage } from '../src/platform/database.ts';
import { saveDraft, listDrafts, getDraft, deleteDraft } from '../src/platform/index.ts';

const directory = mkdtempSync(join(tmpdir(), 'blocks-drafts-'));
const previousPath = process.env.BLOCKS_DB_PATH;
before(() => { process.env.BLOCKS_DB_PATH = join(directory, 'storage.sqlite'); });
after(() => {
  closeStorage();
  if (previousPath === undefined) delete process.env.BLOCKS_DB_PATH;
  else process.env.BLOCKS_DB_PATH = previousPath;
  rmSync(directory, { recursive: true, force: true });
});

test('invalid documents round trip as isolated drafts, with name fallback and deletion', async () => {
  const input = { doc: { meta: { name: 'Invented draft' }, broken: true }, errors: [{ message: 'Missing sections' }], reason: 'Validation failed', name: 'Fallback' };
  const saved = await saveDraft('one', input);
  assert.equal(saved.name, 'Invented draft');
  assert.deepEqual(await getDraft(saved.id, 'one'), saved);
  assert.deepEqual((await listDrafts('one')).map((draft) => draft.id), [saved.id]);
  assert.deepEqual(await listDrafts('two'), []);
  assert.equal(await getDraft(saved.id, 'two'), null);
  await deleteDraft(saved.id, 'two');
  assert.ok(await getDraft(saved.id, 'one'));
  await deleteDraft(saved.id, 'one');
  assert.equal(await getDraft(saved.id, 'one'), null);
  assert.deepEqual(await listDrafts('one'), []);
  assert.equal((await saveDraft('fallback', { ...input, doc: null })).name, 'Fallback');
  assert.equal((await saveDraft('fallback', { doc: [], errors: [], reason: 'Failed' })).name, 'Untitled draft');
});

test('size limit measures the complete encoded record in UTF-8 bytes', async () => {
  await assert.rejects(saveDraft('size', { doc: 'é'.repeat(1024 * 1024), errors: [], reason: 'Failed' }), /2 MB/);
  await assert.rejects(saveDraft('size', { doc: {}, errors: ['x'.repeat(2 * 1024 * 1024)], reason: 'Failed' }), /2 MB/);
  assert.deepEqual(await listDrafts('size'), []);
  await saveDraft('size', { doc: 'x'.repeat(1024 * 1024), errors: [], reason: 'Failed' });
});

const app = express();
app.use(appRoutes);
function request(path: string, method = 'GET', headers: Record<string, string> = {}): Promise<Response> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    const socket = new Socket();
    socket._write = (chunk, _encoding, callback) => { chunks.push(Buffer.from(chunk)); callback(); };
    socket._writev = (pending, callback) => { for (const { chunk } of pending) chunks.push(Buffer.from(chunk)); callback(); };
    const input = new IncomingMessage(new Socket());
    input.method = method;
    input.url = path;
    input.headers = { host: 'blocks.test', ...headers };
    const output = new ServerResponse(input);
    output.assignSocket(socket);
    output.once('error', reject);
    output.once('finish', () => {
      const raw = Buffer.concat(chunks).toString('utf8');
      resolve(new Response(raw.slice(raw.indexOf('\r\n\r\n') + 4), {
        status: output.statusCode,
        headers: { 'Content-Type': String(output.getHeader('Content-Type')), 'Set-Cookie': String(output.getHeader('Set-Cookie') ?? ''), 'Cache-Control': String(output.getHeader('Cache-Control') ?? '') },
      }));
      socket.destroy(); input.socket.destroy();
    });
    createServer(app).emit('request', input, output);
    input.push(null);
  });
}

test('draft routes return summaries and details, require ownership and refuse cross-origin requests', async () => {
  const initial = await request('/api/drafts');
  assert.equal(initial.status, 200);
  const cookie = initial.headers.get('Set-Cookie')!.split(';')[0]!;
  const profile = `browser:${cookie.split('=')[1]}`;
  const draft = await saveDraft(profile, { doc: { invalid: true }, errors: ['Invented issue'], reason: 'Failed', name: 'Test draft' });
  const headers = { cookie, 'x-blocks-request': '1', origin: 'http://blocks.test' };
  const list = await request('/api/drafts', 'GET', headers);
  assert.equal(list.headers.get('Cache-Control'), 'no-store');
  assert.deepEqual(await list.json(), { drafts: [{ id: draft.id, name: draft.name, reason: draft.reason, createdAt: draft.createdAt }] });
  const detail = await request(`/api/drafts/${draft.id}`, 'GET', headers);
  const { profile: _private, ...publicDraft } = draft;
  assert.deepEqual(await detail.json(), { draft: publicDraft });
  for (const method of ['GET', 'DELETE']) {
    assert.equal((await request(`/api/drafts/${draft.id}`, method, { ...headers, origin: 'https://other.test' })).status, 403);
    assert.equal((await request(`/api/drafts/${draft.id}`, method, { ...headers, cookie: `blocks_profile=${randomUUID()}` })).status, 404);
  }
  assert.equal((await request('/api/drafts', 'GET', { origin: 'https://other.test' })).status, 403);
  assert.equal((await request(`/api/drafts/${draft.id}`, 'DELETE', { cookie })).status, 403);
  assert.equal((await request(`/api/drafts/${draft.id}`, 'DELETE', { 'x-blocks-request': '1' })).status, 403);
  assert.equal((await request(`/api/drafts/${draft.id}`, 'DELETE', headers)).status, 200);
  assert.equal((await request(`/api/drafts/${draft.id}`, 'GET', headers)).status, 404);
});

test('version 1 and 2 databases migrate without losing existing app records', async () => {
  const { saveApp, getApp } = await import('../src/platform/index.ts');
  const { AppDocument } = await import('../src/app-schema/index.ts');
  const doc = AppDocument.parse({ meta: { name: 'Invented migration app', description: 'Test only', spec_version: '1.0' }, params: [], data: [], compute: [], triggers: [{ kind: 'manual' }], ui: { root: 'root', elements: { root: { type: 'Section', children: [] } } } });
  for (const version of [1, 2]) {
    closeStorage();
    const path = join(directory, `version-${version}.sqlite`);
    process.env.BLOCKS_DB_PATH = path;
    const saved = await saveApp(doc, 'migration');
    closeStorage();
    const old = new DatabaseSync(path);
    old.exec('DROP TABLE drafts');
    if (version === 1) old.exec('DROP TABLE executions; DROP TABLE scheduled_tasks');
    old.exec(`PRAGMA user_version = ${version}`);
    old.close();
    assert.deepEqual(await getApp(saved.id), saved);
    const draft = await saveDraft('migration', { doc: null, errors: [], reason: 'Failed' });
    assert.deepEqual(await getDraft(draft.id, 'migration'), draft);
    closeStorage();
    const migrated = new DatabaseSync(path);
    assert.equal(migrated.prepare('PRAGMA user_version').get()!.user_version, 3);
    migrated.close();
  }
});
