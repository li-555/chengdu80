import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import express from 'express';
import type { AddressInfo } from 'node:net';
import { AppDocument } from '../src/app-schema/index.ts';
import { saveApp } from '../src/platform/storage.ts';
import { closeStorage } from '../src/platform/database.ts';
import { monitorRouter } from '../src/api/routes-monitor.ts';
const directory = mkdtempSync(join(tmpdir(), 'blocks-monitor-http-')); const old = process.env.BLOCKS_DB_PATH;
before(() => { process.env.BLOCKS_DB_PATH = join(directory, 'state.sqlite'); });
after(() => { closeStorage(); if (old === undefined) delete process.env.BLOCKS_DB_PATH; else process.env.BLOCKS_DB_PATH = old; rmSync(directory, { recursive: true, force: true }); });
test('monitor API rejects foreign, stale, invalid, malformed and oversized acknowledgements', async () => {
 const doc = AppDocument.parse({ meta: { name: 'Invented HTTP fixture', description: 'Invented monitor HTTP fixture', spec_version: '1.0' }, params: [], data: [], compute: [], triggers: [{ kind: 'manual' }], ui: { root: 'root', elements: { root: { type: 'Section', children: [] } } } });
 const app = await saveApp(doc, 'fake-owner'); const server = express().use((_q, r, next) => { r.locals.profile = 'fake-owner'; next(); }).use('/api/apps/:id/monitor', monitorRouter).listen(0, '127.0.0.1'); await new Promise<void>((resolve) => server.once('listening', resolve));
 const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}/api/apps/${app.id}/monitor`;
 try {
 assert.equal((await fetch(base)).status, 200); assert.equal((await fetch(base.replace(app.id, 'foreign'))).status, 404);
 const post = (body: string) => fetch(`${base}/ack`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body });
 assert.equal((await post(JSON.stringify({ alertId: 'a'.repeat(64), acknowledged: true }))).status, 409);
 assert.equal((await post(JSON.stringify({ alertId: 'a'.repeat(64), acknowledged: true, extra: true }))).status, 422);
 assert.equal((await post('{')).status, 400); assert.equal((await post(JSON.stringify({ padding: 'x'.repeat(5000) }))).status, 413);
 } finally { await new Promise<void>((resolve, reject) => server.close((e) => e ? reject(e) : resolve())); }
});
