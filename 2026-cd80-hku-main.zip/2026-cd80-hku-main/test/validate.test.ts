import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { validateApplication, ERROR_CODES, cronProblem, DOCUMENT_LIMITS } from '../src/validate/index.ts';

const EXAMPLE = new URL('../examples/ex-01-daily-movers.fin.json', import.meta.url);
const raw = () => JSON.parse(readFileSync(EXAMPLE, 'utf8'));

/** Validate a bent copy of the example and return the report. */
function bend(mutate: (d: any) => void) {
  const d = raw();
  mutate(d);
  return validateApplication(d);
}

const codesOf = (r: ReturnType<typeof validateApplication>) => r.report.errors.map((e) => e.code);
const pointersOf = (r: ReturnType<typeof validateApplication>) => r.report.errors.map((e) => e.pointer);

test('the shipped example is valid and has no warnings', () => {
  const r = validateApplication(raw());
  if (!r.ok) assert.fail(`the example must be valid:\n${JSON.stringify(r.report.errors, null, 2)}`);
  assert.deepEqual(r.report.warnings, [], 'our own example should not warn');
  assert.equal(r.report.summary, 'This application is ready to run.');
});

test('every issue carries a code, a pointer, a readable path and a message', () => {
  const r = bend((d) => { d.compute[2].params.limitt = 5; });
  assert.equal(r.ok, false);
  assert.ok(r.report.errors.length > 0);
  for (const e of r.report.errors) {
    assert.ok(e.code.length > 0, 'code');
    assert.ok(typeof e.pointer === 'string', 'pointer');
    assert.ok(e.path.length > 0, 'path');
    assert.ok(e.message.length > 0, 'message');
    assert.ok(e.docs?.includes(e.code), 'docs link names the code');
    assert.ok(e.code in ERROR_CODES, `${e.code} must be in the published set`);
  }
});

test('the published code list is well formed', () => {
  for (const [code, text] of Object.entries(ERROR_CODES)) {
    assert.match(code, /^[EW]_[A-Z0-9_]+$/, `${code} is malformed`);
    assert.ok(text.length > 10, `${code} needs a real explanation`);
    assert.ok(text.endsWith('.'), `${code} explanation should be a sentence`);
  }
});

test('a formula that cannot be read is reported at its own location', () => {
  const r = bend((d) => { d.compute[1].params.where = '1 + ('; });
  assert.deepEqual(codesOf(r), ['E_BAD_EXPRESSION']);
  assert.deepEqual(pointersOf(r), ['/compute/1/params/where']);
  assert.equal(r.report.stopped_in, 'semantics');
});

test('a formula cannot reach a property, a list, this, or an unknown function', () => {
  const cases: [string, string][] = [
    ['close.constructor > 1', 'property'],
    ['[1,2,3]', 'list'],
    ['this', 'this'],
    ['frobnicate(pct_move)', 'function'],
    ['abs(pct_move, 1) > 1', 'values'],
  ];
  for (const [expr, expectInMessage] of cases) {
    const r = bend((d) => { d.compute[1].params.where = expr; });
    assert.equal(r.ok, false, `must refuse: ${expr}`);
    assert.ok(codesOf(r).includes('E_BAD_EXPRESSION'), `${expr}: ${JSON.stringify(codesOf(r))}`);
    assert.ok(
      r.report.errors.some((e) => e.message.toLowerCase().includes(expectInMessage)),
      `${expr}: the message should mention "${expectInMessage}", got ${JSON.stringify(r.report.errors.map((e) => e.message))}`,
    );
  }
});

test('a derived column formula is checked too', () => {
  const r = bend((d) => { d.compute[0].params.columns.pct_move = 'close.length'; });
  assert.ok(codesOf(r).includes('E_BAD_EXPRESSION'));
  assert.deepEqual(pointersOf(r), ['/compute/0/params/columns/pct_move']);
});

test('an alert condition formula is checked too', () => {
  const r = bend((d) => { d.triggers.push({ kind: 'alert', cron: '0 8 * * *', condition: 'this' }); });
  assert.ok(codesOf(r).includes('E_BAD_EXPRESSION'));
  assert.deepEqual(pointersOf(r), ['/triggers/2/condition']);
});

test('the one code this module still cannot emit is named, so the gap is not mistaken for coverage', () => {
  // E_BAD_SQL belongs to the SQL gate, which is a separate module. It is published
  // because it will be emitted. Until then this input passes, and this test exists so
  // that fact is visible rather than discovered later.
  assert.ok('E_BAD_SQL' in ERROR_CODES, 'E_BAD_SQL must stay published');
  const withSql = bend((d) => { d.compute[2] = { id: 'movers', kind: 'sql', sql: 'DROP TABLE prices' }; });
  assert.equal(withSql.ok, true, 'TODO: the SQL gate will make this invalid');
});

// --- phase 1: parse -------------------------------------------------------

test('parse: not JSON, empty, and not an object', () => {
  assert.deepEqual(codesOf(validateApplication('{ not json')), ['E_PARSE_JSON']);
  assert.deepEqual(codesOf(validateApplication('   ')), ['E_PARSE_EMPTY']);
  assert.deepEqual(codesOf(validateApplication('[1,2,3]')), ['E_PARSE_NOT_OBJECT']);
  assert.deepEqual(codesOf(validateApplication(42)), ['E_PARSE_NOT_OBJECT']);
  assert.deepEqual(codesOf(validateApplication(null)), ['E_PARSE_NOT_OBJECT']);
});

test('parse: an application pasted out of a chat window still validates', () => {
  const text = `Sure, here you go:\n\n\`\`\`json\n${JSON.stringify(raw())}\n\`\`\`\n\nLet me know!`;
  const r = validateApplication(text);
  assert.equal(r.ok, true, JSON.stringify(r.report.errors));
  assert.deepEqual(r.report.warnings.map((w) => w.code), ['W_SURROUNDING_TEXT']);
});

test('parse: the $schema envelope field our own export writes is accepted', () => {
  const d = raw();
  assert.ok('$schema' in d, 'the example must carry the envelope field');
  assert.equal(validateApplication(d).ok, true);
});

// --- phase 2: schema ------------------------------------------------------

test('schema: a wrong specification version returns one error, not forty', () => {
  const r = bend((d) => { d.meta.spec_version = '0.1'; d.compute = 'nonsense'; d.ui = 5; });
  assert.deepEqual(codesOf(r), ['E_SCHEMA_SPEC_VERSION']);
  assert.equal(r.report.stopped_in, 'schema');
});

test('schema: an unknown key is named at its own pointer, not at its parent', () => {
  const r = bend((d) => { d.compute[2].params.limitt = 5; });
  assert.ok(pointersOf(r).includes('/compute/2/params/limitt'), pointersOf(r).join(' '));
  assert.ok(r.report.errors.some((e) => e.message.includes('limitt')));
});

test('schema: a step with a valid kind is not told it should have been SQL', () => {
  const r = bend((d) => { d.compute[2].params.by = 'not-a-list'; });
  assert.equal(r.ok, false);
  const text = JSON.stringify(r.report.errors);
  assert.ok(!text.includes('"sql"'), `the report must not mention other branches:\n${text}`);
  assert.ok(pointersOf(r).every((p) => p.startsWith('/compute/2/params')), pointersOf(r).join(' '));
});

test('schema: op "ai" under kind "operation" is refused with the right instruction', () => {
  const r = bend((d) => { d.compute.push({ id: 'summary', kind: 'operation', op: 'ai', input: 'movers', params: {} }); });
  assert.deepEqual(codesOf(r), ['E_SCHEMA_ENUM']);
  assert.match(r.report.errors[0]!.hint!, /kind "ai"/);
});

test('schema: an unknown element type and an unknown step kind are located precisely', () => {
  const r1 = bend((d) => { d.ui.elements.table.type = 'DataGrid'; });
  assert.deepEqual(pointersOf(r1), ['/ui/elements/table/type']);
  const r2 = bend((d) => { d.compute[0].kind = 'magic'; });
  assert.deepEqual(pointersOf(r2), ['/compute/0/kind']);
});

test('schema: a missing section is reported as missing, not as a type error', () => {
  const r = bend((d) => { delete d.triggers; });
  assert.deepEqual(codesOf(r), ['E_SCHEMA_REQUIRED']);
  assert.deepEqual(pointersOf(r), ['/triggers']);
});

test('schema: an unknown icon is a warning and never blocks', () => {
  const r = bend((d) => { d.meta.icon = 'rocket'; });
  assert.equal(r.ok, true);
  assert.deepEqual(r.report.warnings.map((w) => w.code), ['W_UNKNOWN_ICON']);
});

// --- phase 3: references --------------------------------------------------

test('references: a step reading a table nothing produces, with a suggestion', () => {
  const r = bend((d) => { d.compute[1].input = 'with_chang'; });
  assert.deepEqual(codesOf(r), ['E_REF_UNKNOWN_RELATION']);
  assert.deepEqual(pointersOf(r), ['/compute/1/input']);
  assert.match(r.report.errors[0]!.hint!, /with_change/);
});

test('references: a control naming an undeclared parameter', () => {
  const r = bend((d) => { d.ui.elements.t.param = 'move_threshhold'; });
  assert.ok(codesOf(r).includes('E_REF_UNKNOWN_PARAM'));
  assert.ok(pointersOf(r).includes('/ui/elements/t/param'));
  assert.match(r.report.errors[0]!.hint!, /move_threshold/);
});

test('references: a filter naming an undeclared parameter', () => {
  const r = bend((d) => { d.data[0].filters[0].param = 'watchlistt'; });
  assert.ok(codesOf(r).includes('E_REF_UNKNOWN_PARAM'));
  assert.ok(pointersOf(r).includes('/data/0/filters/0/param'));
});

test('references: a formula using an undeclared setting', () => {
  const r = bend((d) => { d.compute[1].params.where = 'abs(pct_move) >= $params.nope'; });
  assert.ok(codesOf(r).includes('E_REF_UNKNOWN_PARAM'));
  assert.ok(pointersOf(r).includes('/compute/1/params/where'));
});

test('references: a numeric field naming an undeclared setting', () => {
  const r = bend((d) => { d.compute[2].params.limit = { param: 'top_nn' }; });
  assert.ok(codesOf(r).includes('E_REF_UNKNOWN_PARAM'));
  assert.ok(pointersOf(r).some((p) => p.startsWith('/compute/2/params/limit')), pointersOf(r).join(' '));
});

test('references: a duplicate name across the one flat namespace', () => {
  const r = bend((d) => { d.compute[0].id = 'prices'; });
  assert.ok(codesOf(r).includes('E_REF_DUPLICATE_NAME'));
  assert.ok(r.report.errors[0]!.message.includes('prices'));
});

test('references: a step reading its own output', () => {
  const r = bend((d) => { d.compute[0].input = 'with_change'; });
  assert.ok(codesOf(r).includes('E_SELF_REFERENCE'));
});

test('references: a screen root and a child that do not exist', () => {
  assert.deepEqual(codesOf(bend((d) => { d.ui.root = 'nope'; })), ['E_REF_UNKNOWN_ROOT']);
  const r = bend((d) => { d.ui.elements.page.children.push('ghost'); });
  assert.deepEqual(codesOf(r), ['E_REF_UNKNOWN_ELEMENT']);
  assert.deepEqual(pointersOf(r), ['/ui/elements/page/children/3']);
});

test('references: sections that contain each other are caught, not followed forever', () => {
  const r = bend((d) => { d.ui.elements.controls.children.push('page'); });
  assert.ok(codesOf(r).includes('E_ELEMENT_CYCLE'));
});

test('references: an element nothing shows is only a warning', () => {
  const r = bend((d) => { d.ui.elements.stray = { type: 'Text', text: 'nobody sees me' }; });
  assert.equal(r.ok, true);
  assert.deepEqual(r.report.warnings.map((w) => w.code), ['W_ORPHAN_ELEMENT']);
});

test('references: a forward reference is legal, because steps are sorted by dependency', () => {
  const r = bend((d) => {
    const [a, b, c, e] = d.compute;
    d.compute = [c, b, a, e];                   // reverse the order; dependencies unchanged
  });
  assert.equal(r.ok, true, JSON.stringify(r.report.errors));
});

test('references: a control that changes nothing is flagged', () => {
  const r = bend((d) => { d.compute[2].params.limit = 10; });   // unwire top_n
  assert.equal(r.ok, true);
  assert.deepEqual(r.report.warnings.map((w) => w.code), ['W_DEAD_CONTROL']);
  assert.match(r.report.warnings[0]!.message, /changes nothing/);
});

test('references: declared but unread data and steps are warnings', () => {
  const r1 = bend((d) => { d.data.push({ key: 'spare', fields: [{ name: 'a', type: 'text', required: true }] }); });
  assert.equal(r1.ok, true);
  assert.ok(r1.report.warnings.some((w) => w.code === 'W_UNUSED_DATA'));
  const r2 = bend((d) => { d.compute.push({ id: 'spare_step', kind: 'operation', op: 'describe', input: 'movers', params: {} }); });
  assert.equal(r2.ok, true);
  assert.ok(r2.report.warnings.some((w) => w.code === 'W_UNUSED_STEP'));
});

// --- phase 4: semantics ---------------------------------------------------

test('semantics: a cycle among steps names the loop', () => {
  const r = bend((d) => {
    d.compute[0].input = 'movers';              // with_change <- movers <- unusual <- with_change
  });
  assert.ok(codesOf(r).includes('E_CYCLE'), JSON.stringify(codesOf(r)));
  assert.match(r.report.errors[0]!.message, /->/);
});

test('semantics: one cycle is reported once, not once per member', () => {
  const r = bend((d) => { d.compute[0].input = 'movers'; });
  assert.equal(r.report.errors.filter((e) => e.code === 'E_CYCLE').length, 1);
});

test('semantics: cron is checked field by field', () => {
  assert.equal(cronProblem('0 8 * * 1-5'), undefined);
  assert.equal(cronProblem('*/15 9-15 * * 1-5'), undefined);
  assert.match(cronProblem('0 8 * *')!, /five fields/);
  assert.match(cronProblem('0 25 * * *')!, /hour/);
  assert.match(cronProblem('0 8 32 * *')!, /day of the month/);
  assert.match(cronProblem('0 8 * * 5-1')!, /backwards/);
  const r = bend((d) => { d.triggers.push({ kind: 'schedule', cron: '0 99 * * *' }); });
  assert.deepEqual(codesOf(r), ['E_BAD_CRON']);
  assert.deepEqual(pointersOf(r), ['/triggers/2/cron']);
});

test('semantics: no manual trigger is a warning, not a refusal', () => {
  const r = bend((d) => { d.triggers = [{ kind: 'market', at: 'close' }]; });
  assert.equal(r.ok, true);
  assert.ok(r.report.warnings.some((w) => w.code === 'W_NO_MANUAL_TRIGGER'));
});

test('semantics: an empty trigger list is refused', () => {
  assert.ok(codesOf(bend((d) => { d.triggers = []; })).includes('E_NO_TRIGGER'));
});

// --- phase 5: limits ------------------------------------------------------

test('limits: two custom-code steps are refused', () => {
  const codeStep = (id: string) => ({
    id, kind: 'code', input: ['movers'],
    output: { columns: [{ name: 'x', type: 'number' }] },
    body: 'return { rows: [] };',
  });
  const r = bend((d) => { d.compute.push(codeStep('c1'), codeStep('c2')); d.ui.elements.table.from = 'c2'; });
  assert.ok(codesOf(r).includes('E_LIMIT_CODE_STEPS'), JSON.stringify(codesOf(r)));
});

test('limits: a fifth AI step is refused', () => {
  const aiStep = (id: string) => ({
    id, kind: 'ai', input: 'movers',
    params: { mode: 'whole', instructions: 'summarise', output: { kind: 'text' } },
  });
  const r = bend((d) => {
    for (let i = 0; i < 5; i++) d.compute.push(aiStep(`ai${i}`));
    d.ui.elements.table.from = 'ai4';
  });
  assert.ok(codesOf(r).includes('E_LIMIT_AI_STEPS'), JSON.stringify(codesOf(r)));
});

test('limits: the document limits are the numbers the specification states', () => {
  assert.equal(DOCUMENT_LIMITS.codeSteps, 1);
  assert.equal(DOCUMENT_LIMITS.aiSteps, 4);
});

// --- phase order ----------------------------------------------------------

test('the phases stop at the first one that fails', () => {
  // a schema error AND a reference error at once: only the schema one is reported
  const r = bend((d) => { d.compute[2].params.limitt = 5; d.ui.root = 'nope'; });
  assert.equal(r.report.stopped_in, 'schema');
  assert.ok(!codesOf(r).includes('E_REF_UNKNOWN_ROOT'));
});

test('warnings from earlier phases survive into a later phase failure', () => {
  const r = bend((d) => { d.meta.icon = 'rocket'; d.ui.root = 'nope'; });
  assert.equal(r.report.stopped_in, 'references');
  assert.ok(r.report.warnings.some((w) => w.code === 'W_UNKNOWN_ICON'), 'the icon warning must survive');
});

test('the report wrapper is complete and the summary is plain language', () => {
  const r = validateApplication(raw());
  assert.equal(r.report.valid, true);
  assert.equal(r.report.spec_version, '1.0');
  assert.ok(r.report.validator_version.length > 0);
  assert.match(r.report.checked_at, /^\d{4}-\d{2}-\d{2}T/);
  for (const bad of ['schema', 'JSON', 'Zod', 'pointer', 'null', 'enum']) {
    assert.ok(!r.report.summary.includes(bad), `the summary must not say "${bad}"`);
  }
});

test('ok and report.valid can never disagree, whatever the input', () => {
  const inputs: unknown[] = [
    raw(),
    '{ broken',
    '',
    '[1]',
    null,
    42,
    `\`\`\`json\n${JSON.stringify(raw())}\n\`\`\``,
    { meta: { name: 'a', description: 'b', spec_version: '1.0' }, params: [], data: [], compute: [], triggers: [{ kind: 'manual' }], ui: { root: 'p', elements: { p: { type: 'Section', children: [] } } } },
  ];
  for (const [i, input] of inputs.entries()) {
    const r = validateApplication(input);
    assert.equal(r.ok, r.report.valid, `input ${i}: ok=${r.ok} but report.valid=${r.report.valid}`);
    assert.equal(r.report.valid, r.report.errors.length === 0, `input ${i}: valid must mean no errors`);
    if (!r.ok) assert.deepEqual(r.errors, r.report.errors, `input ${i}: the two error lists must match`);
  }
});

test('a warning alone never makes a document invalid', () => {
  const r = validateApplication(`\`\`\`json\n${JSON.stringify(raw())}\n\`\`\``);
  assert.equal(r.ok, true);
  assert.ok(r.report.warnings.length > 0);
});


// ---------------------------------------------------------------------------
// Regressions for the review of 2026-10-13. Fourteen findings were accepted.
// ---------------------------------------------------------------------------

test('review 1: an inherited property name as a discriminator is reported, not thrown', () => {
  // `'toString' in STEP_SCHEMA` is true, so a membership test with `in` used to hand
  // Object.prototype.toString to safeParse and crash the whole check.
  for (const word of ['toString', 'constructor', 'valueOf', '__proto__', 'hasOwnProperty']) {
    const r1 = bend((d) => { d.compute[0].kind = word; });
    assert.equal(r1.ok, false, `kind "${word}" must be refused`);
    assert.ok(r1.report.errors.length > 0, `kind "${word}" must produce an issue`);

    const r2 = bend((d) => { d.compute[0].op = word; });
    assert.equal(r2.ok, false, `op "${word}" must be refused`);
    assert.ok(r2.report.errors.length > 0);

    const r3 = bend((d) => { d.ui.elements.table.type = word; });
    assert.equal(r3.ok, false, `element type "${word}" must be refused`);
    assert.ok(r3.report.errors.length > 0);
  }
});

test('review 2: deep nesting is answered immediately, not exponentially', () => {
  const elements: Record<string, unknown> = {};
  for (let i = 0; i < 31; i++) {
    elements[`p${i}`] = { type: 'Section', children: i < 30 ? [`p${i + 1}`, `p${i + 1}`] : [] };
  }
  const started = Date.now();
  const r = bend((d) => { d.ui = { root: 'p0', elements }; });
  const took = Date.now() - started;
  assert.equal(r.ok, false);
  assert.ok(codesOf(r).includes('E_LIMIT_NESTING'), JSON.stringify(codesOf(r)));
  assert.ok(took < 500, `must not take exponential time, took ${took} ms`);
});

test('review 5: a code fence inside a field does not replace the document', () => {
  const d = raw();
  d.meta.description = 'See the example in ```json {} ``` for details.';
  const r = validateApplication(JSON.stringify(d));
  assert.equal(r.ok, true, JSON.stringify(r.report.errors));
  assert.deepEqual(r.report.warnings, []);
});

test('review 6: a JSON list is refused as not an object, not read as prose', () => {
  const r = validateApplication(JSON.stringify([raw()]));
  assert.deepEqual(codesOf(r), ['E_PARSE_NOT_OBJECT']);
});

test('review 8: a wrong type says wrong type, a missing field says missing', () => {
  const wrongType = bend((d) => { d.meta.name = 5; });
  assert.deepEqual(codesOf(wrongType), ['E_SCHEMA_TYPE']);
  assert.equal(wrongType.report.errors[0]!.received, 'number');
  assert.match(wrongType.report.errors[0]!.hint!, /Change this value/);

  const missing = bend((d) => { delete d.meta.name; });
  assert.deepEqual(codesOf(missing), ['E_SCHEMA_REQUIRED']);
  assert.equal(missing.report.errors[0]!.received, 'nothing');
  assert.match(missing.report.errors[0]!.hint!, /Add this field/);
});

test('review 9: a numeric parameter reference points at the param key itself', () => {
  const r = bend((d) => { d.compute[2].params.limit = { param: 'top_nn' }; });
  assert.deepEqual(pointersOf(r), ['/compute/2/params/limit/param']);
  assert.match(r.report.errors[0]!.hint!, /top_n/);
});

test('review 11: $params inside a quoted string is not a reference', () => {
  const r = bend((d) => { d.compute[1].params.where = 'contains(code, "$params.nope") or abs(pct_move) >= $params.move_threshold'; });
  assert.equal(r.ok, true, JSON.stringify(r.report.errors));
});

test('review 7: an alert condition is checked for undeclared settings', () => {
  const bad = bend((d) => { d.triggers.push({ kind: 'alert', cron: '0 8 * * *', condition: '$params.nope > 0' }); });
  assert.ok(codesOf(bad).includes('E_REF_UNKNOWN_PARAM'));
  assert.deepEqual(pointersOf(bad), ['/triggers/2/condition']);

  const good = bend((d) => { d.triggers.push({ kind: 'alert', cron: '0 8 * * *', condition: '$params.move_threshold > 0' }); });
  assert.equal(good.ok, true, JSON.stringify(good.report.errors));
});

test('review 12: a Section nothing shows still has its children checked', () => {
  const r = bend((d) => { d.ui.elements.orphan = { type: 'Section', children: ['missing'] }; });
  assert.equal(r.ok, false);
  assert.deepEqual(codesOf(r), ['E_REF_UNKNOWN_ELEMENT']);
  assert.deepEqual(pointersOf(r), ['/ui/elements/orphan/children/0']);
});

test('review 12b: a containment loop outside the reachable tree is still caught, once', () => {
  const r = bend((d) => {
    d.ui.elements.a = { type: 'Section', children: ['b'] };
    d.ui.elements.b = { type: 'Section', children: ['a'] };
  });
  assert.equal(r.ok, false);
  assert.equal(codesOf(r).filter((c) => c === 'E_ELEMENT_CYCLE').length, 1, JSON.stringify(codesOf(r)));
});

test('review 13: a leaf element does not consume a nesting level', () => {
  const elements: Record<string, unknown> = {
    p0: { type: 'Section', children: ['p1'] },
    p1: { type: 'Section', children: ['p2'] },
    p2: { type: 'Section', children: ['p3'] },
    p3: { type: 'Section', children: ['leaf'] },
    leaf: { type: 'Text', text: 'four sections deep, which is allowed' },
  };
  const r = bend((d) => { d.ui = { root: 'p0', elements }; });
  assert.ok(!codesOf(r).includes('E_LIMIT_NESTING'), `four Sections is the limit, not five: ${JSON.stringify(codesOf(r))}`);
});

test('review 14: a cron field with two step values is refused', () => {
  assert.match(cronProblem('*/2/garbage 8 * * *')!, /step value/);
  const r = bend((d) => { d.triggers.push({ kind: 'schedule', cron: '*/2/3 8 * * *' }); });
  assert.deepEqual(codesOf(r), ['E_BAD_CRON']);
});

test('review 4: a relation a SQL step reads is not reported as unread', () => {
  const r = bend((d) => {
    d.compute.push({ id: 'from_sql', kind: 'sql', sql: 'SELECT code, pct_move FROM movers WHERE pct_move > 0' });
    d.ui.elements.table.from = 'from_sql';
  });
  assert.equal(r.ok, true, JSON.stringify(r.report.errors));
  assert.ok(!r.report.warnings.some((w) => w.code === 'W_UNUSED_STEP' && w.message.includes('movers')),
    `movers is read by the SQL step: ${JSON.stringify(r.report.warnings)}`);
});

test('review 16: every error carries a fix hint', () => {
  const inputs: unknown[] = ['', '{ broken', '[1]', {}, bend(() => {}) && raw()];
  for (const input of [...inputs]) {
    const r = validateApplication(input);
    for (const e of r.report.errors) {
      assert.ok(e.hint && e.hint.length > 0, `${e.code} at ${e.pointer} has no hint`);
    }
  }
  // and over a spread of bent documents
  const bends: ((d: any) => void)[] = [
    (d) => { d.meta.name = 5; },
    (d) => { delete d.meta.name; },
    (d) => { d.compute[0].kind = 'magic'; },
    (d) => { d.compute[2].params.limitt = 1; },
    (d) => { d.ui.root = 'nope'; },
    (d) => { d.triggers = []; },
    (d) => { d.compute[0].input = 'movers'; },
  ];
  for (const b of bends) {
    for (const e of bend(b).report.errors) {
      assert.ok(e.hint && e.hint.length > 0, `${e.code} at ${e.pointer} has no hint`);
    }
  }
});

for (const [field, step] of [
  ['kind', { kind: { toString: null } }],
  ['op', { kind: 'operation', op: { toString: null } }],
] as const) {
  test(`an object with toString null in compute ${field} returns a schema report`, () => {
    const result = validateApplication({ meta: { spec_version: '1.0' }, compute: [step] });
    assert.equal(result.ok, false);
    assert.ok(result.report.errors.some((error) => error.code === 'E_SCHEMA_ENUM' && error.pointer === `/compute/0/${field}`));
    assert.ok(!codesOf(result).includes('E_INTERNAL'));
  });
}

test('unexpected checker failures return one internal error with a fix hint', () => {
  const result = validateApplication({ get meta() { throw new Error('unexpected failure'); } });
  assert.equal(result.ok, false);
  assert.deepEqual(codesOf(result), ['E_INTERNAL']);
  assert.deepEqual(pointersOf(result), ['']);
  assert.match(result.report.errors[0]!.hint!, /fault in the checker, not in your application/);
  assert.deepEqual(result.report.warnings, []);
});

test('300 hostile documents always return a report with a fixed seed', () => {
  let seed = 0x593b7a12;
  const next = (limit: number) => {
    seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
    return seed % limit;
  };
  const hostile = (index: number): unknown => {
    switch (index % 8) {
      case 0: return { toString: null, valueOf: null };
      case 1: return { toString: next(100), valueOf: 'invalid' };
      case 2: return JSON.parse('{"__proto__":{"toString":null},"constructor":{"valueOf":null}}');
      case 3: {
        let value: unknown = { toString: null };
        for (let depth = 0; depth < 60; depth++) value = depth % 2 ? [value] : { nested: value };
        return value;
      }
      case 4: return [[{ toString: null }], [null, { valueOf: false }]];
      case 5: return next(1000);
      case 6: return 'x'.repeat(100_000);
      default: return null;
    }
  };
  const sections = ['meta', 'params', 'data', 'compute', 'triggers', 'ui'] as const;
  for (let i = 0; i < 300; i++) {
    const doc = raw();
    const section = sections[i % sections.length]!;
    const value = hostile(Math.floor(i / sections.length));
    if (i < 96 || next(3) === 0) doc[section] = value;
    else if (section === 'meta') doc.meta.name = value;
    else if (section === 'ui') doc.ui.elements.page = { type: value };
    else if (section === 'compute') doc.compute = [{ kind: value }, { kind: 'operation', op: value }];
    else if (section === 'triggers') doc.triggers = [{ kind: value }];
    else doc[section] = [{ key: value, type: value }];
    const input = JSON.parse(JSON.stringify(doc));
    for (const candidate of [input, JSON.stringify(input)]) {
      const result = validateApplication(candidate);
      assert.equal(typeof result.report.valid, 'boolean', `document ${i}`);
      assert.equal(result.ok, result.report.valid, `document ${i}`);
      assert.ok(Array.isArray(result.report.errors), `document ${i}`);
      assert.ok(!codesOf(result).includes('E_INTERNAL'), `document ${i} should be handled by normal validation`);
    }
  }
});
