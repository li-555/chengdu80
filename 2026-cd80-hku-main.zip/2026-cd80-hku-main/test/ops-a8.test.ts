import test from 'node:test';
import assert from 'node:assert/strict';
import { compileWindow } from '../src/compute/ops/window.ts';
import { compileLagChange } from '../src/compute/ops/lag_change.ts';
import { compileRank } from '../src/compute/ops/rank.ts';
import { compileZscore } from '../src/compute/ops/zscore.ts';
import { compileResample } from '../src/compute/ops/resample.ts';
import { compilePivot } from '../src/compute/ops/pivot.ts';
import { compileDescribe } from '../src/compute/ops/describe.ts';
import { compileCorrelate } from '../src/compute/ops/correlate.ts';
import { compileRegress } from '../src/compute/ops/regress.ts';
import { IMPLEMENTED_OPERATIONS } from '../src/compute/ops/index.ts';
import { OpCompileError, type OpCompileInput } from '../src/compute/ops/contract.ts';

function fixture(inputs: string[] = ['orchard']): OpCompileInput {
  return {
    inputs,
    columns: new Map([['orchard', [
      { name: 'code', type: 'VARCHAR' }, { name: 'd', type: 'DATE' },
      { name: 'stamp', type: 'TIMESTAMP' }, { name: 'weight', type: 'DOUBLE' },
      { name: 'tick', type: 'INTEGER' }, { name: 'odd"key', type: 'DECIMAL(10,2)' },
    ]]]),
    params: new Map<string, unknown>([['back', 7], ['ahead', 3], ['periods', 2], ['window', 5]]),
    scalars: new Map(),
  };
}

const order = [{ col: 'd', dir: 'asc' as const }];
const frame = { kind: 'rows' as const, preceding: { param: 'back' }, following: { param: 'ahead' } };
const windowParams = { fn: 'mean' as const, of: 'weight', partition_by: ['code'], order_by: order, frame, as: 'rolling' };
const lagParams = { of: 'weight', periods: { param: 'periods' }, mode: 'pct' as const, partition_by: ['code'], order_by: order, as: 'change' };
const rankParams = { by: 'weight', direction: 'desc' as const, within: ['code'], method: 'rank' as const, as: 'position' };
const zscoreParams = { of: 'weight', within: ['code'], window: { param: 'window' }, order_by: order, as: 'z' };
const resampleParams = { date_col: 'd', by: ['code'], to: 'month' as const, metrics: [{ fn: 'quantile' as const, of: 'weight', as: 'q', p: 0.37 }] };
const pivotParams = { index: ['code'], on: 'd', values: 'weight', agg: 'sum' as const };
const regressParams = { y: 'weight', x: ['tick'], by: ['code'] };

test('window preserves clauses and binds resolved frame bounds', () => {
  const result = compileWindow(windowParams, fixture());
  assert.equal(result.sql, 'SELECT * , avg ( "weight" ) OVER ( PARTITION BY "code" ORDER BY "d" ASC ROWS BETWEEN ? PRECEDING AND ? FOLLOWING ) AS "rolling" FROM "orchard"');
  assert.deepEqual(result.bindings, [7, 3]);
});

test('window maps every function and quotes hostile names', () => {
  const functions = { sum: 'sum', mean: 'avg', min: 'min', max: 'max', count: 'count', stddev: 'stddev_samp', first: 'first_value', last: 'last_value' } as const;
  for (const fn of Object.keys(functions) as (keyof typeof functions)[]) {
    const result = compileWindow({ ...windowParams, fn, of: 'odd"key', as: 'odd"out' }, fixture());
    assert.ok(result.sql.includes(functions[fn] + ' ( "odd""key" )'));
    assert.ok(result.sql.includes('AS "odd""out"'));
    assert.deepEqual(result.bindings, [7, 3]);
  }
});

test('range uses bound day intervals for dates and timestamps and plain bounds for numbers', () => {
  for (const col of ['d', 'stamp', 'tick', 'odd"key']) {
    const result = compileWindow({ ...windowParams, order_by: [{ col, dir: 'asc' }], frame: { ...frame, kind: 'range' } }, fixture());
    assert.ok(result.sql.includes(col === 'd' || col === 'stamp'
      ? 'RANGE BETWEEN INTERVAL ( ? ) DAY PRECEDING AND INTERVAL ( ? ) DAY FOLLOWING'
      : 'RANGE BETWEEN ? PRECEDING AND ? FOLLOWING'));
    assert.deepEqual(result.bindings, [7, 3]);
  }
  for (const order_by of [[], [{ col: 'd', dir: 'asc' as const }, { col: 'tick', dir: 'asc' as const }], [{ col: 'code', dir: 'asc' as const }]]) {
    assert.throws(() => compileWindow({ ...windowParams, order_by, frame: { ...frame, kind: 'range' } }, fixture()), OpCompileError);
  }
});

test('lag_change binds offsets and constants in expression order and casts both operands', () => {
  const result = compileLagChange(lagParams, fixture());
  assert.equal(result.sql, 'SELECT * , CAST ( "weight" AS DOUBLE ) / NULLIF ( LAG ( CAST ( "weight" AS DOUBLE ) , ? ) OVER ( PARTITION BY "code" ORDER BY "d" ASC ) , ? ) - ? AS "change" FROM "orchard"');
  assert.deepEqual(result.bindings, [2, 0, 1]);
  const diff = compileLagChange({ ...lagParams, mode: 'diff' }, fixture());
  assert.ok(diff.sql.includes('AS DOUBLE ) - LAG'));
  assert.deepEqual(diff.bindings, [2]);
  const log = compileLagChange({ ...lagParams, mode: 'log' }, fixture());
  assert.ok(log.sql.includes('CASE WHEN'));
  assert.ok(log.sql.includes('THEN ln ('));
  assert.deepEqual(log.bindings, [0, 2, 0, 2]);
});

test('rank maps all methods and checks ordering and partitions', () => {
  const functions = { rank: 'rank', dense: 'dense_rank', row_number: 'row_number', percentile: 'percent_rank' } as const;
  for (const method of Object.keys(functions) as (keyof typeof functions)[]) {
    assert.deepEqual(compileRank({ ...rankParams, method }, fixture()), {
      sql: 'SELECT * , ' + functions[method] + ' () OVER ( PARTITION BY "code" ORDER BY "weight" DESC ) AS "position" FROM "orchard"', bindings: [],
    });
  }
});

test('zscore binds repeated frame bounds with a full-frame guard', () => {
  const result = compileZscore(zscoreParams, fixture());
  assert.equal(result.sql, 'SELECT * , CASE WHEN count ( "weight" ) OVER ( PARTITION BY "code" ORDER BY "d" ASC ROWS BETWEEN ? PRECEDING AND CURRENT ROW ) >= ? THEN ( CAST ( "weight" AS DOUBLE ) - avg ( "weight" ) OVER ( PARTITION BY "code" ORDER BY "d" ASC ROWS BETWEEN ? PRECEDING AND CURRENT ROW ) ) / NULLIF ( stddev_samp ( "weight" ) OVER ( PARTITION BY "code" ORDER BY "d" ASC ROWS BETWEEN ? PRECEDING AND CURRENT ROW ) , ? ) END AS "z" FROM "orchard"');
  assert.deepEqual(result.bindings, [4, 5, 4, 4, 0]);
  const whole = compileZscore({ of: 'weight', within: ['code'], as: 'z' }, fixture());
  assert.ok(!whole.sql.includes('CASE'));
  assert.ok(!whole.sql.includes('ORDER BY'));
  assert.deepEqual(whole.bindings, [0]);
  assert.throws(() => compileZscore({ ...zscoreParams, order_by: undefined }, fixture()), OpCompileError);
});

test('resample shares metric expressions and binds bucket and quantile in order', () => {
  const result = compileResample(resampleParams, fixture());
  assert.equal(result.sql, 'SELECT "code" , date_trunc ( ? , "d" )::DATE AS "d" , quantile_cont ( "weight" , ? ) AS "q" FROM "orchard" GROUP BY ALL ORDER BY "code" , "d"');
  assert.deepEqual(result.bindings, ['month', 0.37]);
  assert.throws(() => compileResample({ ...resampleParams, metrics: [] }, fixture()), OpCompileError);
  assert.throws(() => compileResample({ ...resampleParams, metrics: [{ fn: 'quantile', of: 'weight', as: 'q' }] }, fixture()), OpCompileError);
});

test('pivot is wrapped in a SELECT and supports shared aggregate functions', () => {
  assert.deepEqual(compilePivot(pivotParams, fixture()), {
    sql: 'SELECT * FROM ( PIVOT "orchard" ON "d" USING sum ( "weight" ) GROUP BY "code" )', bindings: [],
  });
  const distinct = compilePivot({ ...pivotParams, agg: 'count_distinct' }, fixture());
  assert.ok(distinct.sql.includes('USING count ( DISTINCT "weight" )'));
  assert.throws(() => compilePivot({ ...pivotParams, agg: 'quantile' }, fixture()), OpCompileError);
});

test('describe binds column names and quantiles and chooses numeric columns by default', () => {
  const result = compileDescribe({ columns: ['WEIGHT', 'odd"key'] }, fixture());
  assert.deepEqual(result.bindings, ['weight', 0.25, 0.75, 'odd"key', 0.25, 0.75]);
  assert.ok(result.sql.startsWith('SELECT ? ::VARCHAR AS "column" , count ( "weight" )::BIGINT AS "count"'));
  assert.ok(result.sql.includes('UNION ALL SELECT ? ::VARCHAR'));
  assert.ok(!result.sql.includes("'weight'"));
  assert.deepEqual(compileDescribe({}, fixture()).bindings, ['weight', 0.25, 0.75, 'tick', 0.25, 0.75, 'odd"key', 0.25, 0.75]);
  for (const columns of [[], ['code'], ['d'], ['missing']]) {
    assert.throws(() => compileDescribe({ columns }, fixture()), OpCompileError);
  }
  for (const type of ['VARCHAR', 'INTEGER[]', 'STRUCT(value INTEGER)']) {
    assert.throws(() => compileDescribe({}, { ...fixture(), columns: new Map([['orchard', [{ name: 'value', type }]]]) }), OpCompileError);
  }
});

test('correlate binds pair names in declared order with no repeated pairs', () => {
  const result = compileCorrelate({ columns: ['weight', 'tick', 'odd"key'], method: 'pearson', min_periods: 17 }, fixture());
  assert.deepEqual(result.bindings, ['weight', 'tick', 17, 'weight', 'odd"key', 17, 'tick', 'odd"key', 17]);
  assert.ok(result.sql.includes('CASE WHEN count (*) >= ? THEN corr ( "weight" , "tick" )::DOUBLE END AS corr'));
  assert.equal(result.sql.split('UNION ALL').length, 3);
  assert.ok(result.sql.includes('WHERE "weight" IS NOT NULL AND "tick" IS NOT NULL'));
  assert.throws(() => compileCorrelate({ columns: ['weight', 'WEIGHT'], method: 'pearson' }, fixture()), OpCompileError);
  assert.throws(() => compileCorrelate({ columns: ['weight'], method: 'pearson' }, fixture()), OpCompileError);
});

test('spearman builds average ranks after pairwise null filtering', () => {
  const result = compileCorrelate({ columns: ['weight', 'tick'], method: 'spearman' }, fixture());
  assert.deepEqual(result.bindings, ['weight', 'tick', 1, 2, 1, 2]);
  assert.ok(result.sql.includes('corr ( "rank_a" , "rank_b" )::DOUBLE'));
  assert.ok(result.sql.includes('rank () OVER ( ORDER BY "weight" ) + ( count (*) OVER ( PARTITION BY "weight" ) - ? ) / ? AS "rank_a"'));
  assert.ok(result.sql.endsWith('FROM "orchard" WHERE "weight" IS NOT NULL AND "tick" IS NOT NULL )'));
});

test('regress binds term names and emits grouped coefficients with explicit types', () => {
  const result = compileRegress(regressParams, fixture());
  assert.deepEqual(result.bindings, ['intercept', 'tick']);
  assert.ok(result.sql.startsWith('SELECT "code" , ? ::VARCHAR AS term , regr_intercept ( "weight" , "tick" )::DOUBLE AS "coefficient"'));
  assert.ok(result.sql.includes('regr_count ( "weight" , "tick" )::BIGINT AS "n"'));
  assert.ok(result.sql.includes('GROUP BY "code" UNION ALL SELECT "code" , ? ::VARCHAR AS term , regr_slope'));
  assert.throws(() => compileRegress({ ...regressParams, x: ['tick', 'weight'] }, fixture()), /regression on more than one column is not implemented yet/);
  assert.throws(() => compileRegress({ ...regressParams, x: [] }, fixture()), OpCompileError);
});

test('new output names refuse case-insensitive collisions and include a hint', () => {
  const checks = [
    () => compileWindow({ ...windowParams, as: 'WEIGHT' }, fixture()),
    () => compileLagChange({ ...lagParams, as: 'CODE' }, fixture()),
    () => compileRank({ ...rankParams, as: 'TICK' }, fixture()),
    () => compileZscore({ ...zscoreParams, as: 'D' }, fixture()),
    () => compileResample({ ...resampleParams, metrics: [{ fn: 'count', as: 'CODE' }] }, fixture()),
    () => compileResample({ ...resampleParams, metrics: [{ fn: 'count', as: 'D' }] }, fixture()),
    () => compileResample({ ...resampleParams, metrics: [{ fn: 'count', as: 'q' }, { fn: 'count', as: 'Q' }] }, fixture()),
  ];
  for (const compile of checks) {
    assert.throws(compile, (error: unknown) => error instanceof OpCompileError && !!error.hint);
  }
});

test('every parameter column is checked against input metadata', () => {
  const checks = [
    () => compileWindow({ ...windowParams, of: 'missing' }, fixture()),
    () => compileWindow({ ...windowParams, partition_by: ['missing'] }, fixture()),
    () => compileWindow({ ...windowParams, order_by: [{ col: 'missing', dir: 'asc' }] }, fixture()),
    () => compileLagChange({ ...lagParams, of: 'missing' }, fixture()),
    () => compileLagChange({ ...lagParams, partition_by: ['missing'] }, fixture()),
    () => compileLagChange({ ...lagParams, order_by: [{ col: 'missing', dir: 'asc' }] }, fixture()),
    () => compileRank({ ...rankParams, by: 'missing' }, fixture()),
    () => compileRank({ ...rankParams, within: ['missing'] }, fixture()),
    () => compileZscore({ ...zscoreParams, of: 'missing' }, fixture()),
    () => compileZscore({ ...zscoreParams, within: ['missing'] }, fixture()),
    () => compileZscore({ ...zscoreParams, order_by: [{ col: 'missing', dir: 'asc' }] }, fixture()),
    () => compileResample({ ...resampleParams, date_col: 'missing' }, fixture()),
    () => compileResample({ ...resampleParams, by: ['missing'] }, fixture()),
    () => compileResample({ ...resampleParams, metrics: [{ fn: 'sum', of: 'missing', as: 'q' }] }, fixture()),
    () => compilePivot({ ...pivotParams, index: ['missing'] }, fixture()),
    () => compilePivot({ ...pivotParams, on: 'missing' }, fixture()),
    () => compilePivot({ ...pivotParams, values: 'missing' }, fixture()),
    () => compileCorrelate({ columns: ['weight', 'missing'], method: 'pearson' }, fixture()),
    () => compileRegress({ ...regressParams, y: 'missing' }, fixture()),
    () => compileRegress({ ...regressParams, x: ['missing'] }, fixture()),
    () => compileRegress({ ...regressParams, by: ['missing'] }, fixture()),
  ];
  for (const compile of checks) assert.throws(compile, OpCompileError);
});

test('counts refuse invalid literals and unresolved or invalid settings', () => {
  for (const count of [-1, 100001, 1.5, NaN, Infinity, { param: 'missing' }]) {
    assert.throws(() => compileWindow({ ...windowParams, frame: { ...frame, preceding: count } }, fixture()), OpCompileError);
    assert.throws(() => compileWindow({ ...windowParams, frame: { ...frame, following: count } }, fixture()), OpCompileError);
  }
  for (const count of [0, 10001, 1.5, { param: 'missing' }]) {
    assert.throws(() => compileLagChange({ ...lagParams, periods: count }, fixture()), OpCompileError);
  }
  for (const count of [1, 100001, 1.5, { param: 'missing' }]) {
    assert.throws(() => compileZscore({ ...zscoreParams, window: count }, fixture()), OpCompileError);
  }
  for (const min_periods of [1, 100001, 1.5, NaN]) {
    assert.throws(() => compileCorrelate({ columns: ['weight', 'tick'], method: 'pearson', min_periods }, fixture()), OpCompileError);
  }
  const invalid = { ...fixture(), params: new Map<string, unknown>([['back', '7']]) };
  assert.throws(() => compileWindow(windowParams, invalid), OpCompileError);
});

test('all nine operations require one available input and are registered', () => {
  for (const input of [fixture([]), fixture(['orchard', 'basket']), { ...fixture(), columns: new Map() }]) {
    assert.throws(() => compileWindow(windowParams, input), OpCompileError);
    assert.throws(() => compileLagChange(lagParams, input), OpCompileError);
    assert.throws(() => compileRank(rankParams, input), OpCompileError);
    assert.throws(() => compileZscore(zscoreParams, input), OpCompileError);
    assert.throws(() => compileResample(resampleParams, input), OpCompileError);
    assert.throws(() => compilePivot(pivotParams, input), OpCompileError);
    assert.throws(() => compileDescribe({}, input), OpCompileError);
    assert.throws(() => compileCorrelate({ columns: ['weight', 'tick'], method: 'pearson' }, input), OpCompileError);
    assert.throws(() => compileRegress(regressParams, input), OpCompileError);
  }
  for (const name of ['window', 'lag_change', 'rank', 'zscore', 'resample', 'pivot', 'describe', 'correlate', 'regress']) {
    assert.ok(IMPLEMENTED_OPERATIONS.includes(name), `${name} must be registered`);
  }
});
