import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readUploadPacket, rememberUploadPreview, chatRequestBody, metadataChatState, uploadCard, type UploadMetadata } from '../web/src/upload-preview.ts';
import { setLanguage } from '../web/src/i18n.ts';

const canary = 'INVENTED-PREVIEW-CANARY-7Q3';
const metadata: UploadMetadata = { id: 'user:invented', name: 'Invented holdings', rowCount: 6, fields: [{ name: 'company', type: 'text' }, { name: 'amount', type: 'number' }] };
const packet = { dataset: metadata, blankCounts: [0, 2], preview: { columns: ['company', 'amount'], rows: [[canary, '0'], ['Fictional Birch', ''], ['Fictional Cedar', '12'], ['Fictional Pine', '7'], ['Fictional Elm', '3'], ['INVENTED-SIXTH-ROW', '9']] } };

test('preview remains local while request and saved-state whitelists retain metadata only', () => {
  const parsed = readUploadPacket(packet);
  assert.equal(parsed.preview?.rows.length, 5);
  assert.equal(parsed.upload.fields[1]?.blankCount, 2);
  assert.equal(JSON.stringify(parsed.upload).includes(canary), false);
  // Unknown preview properties are stripped even if an older or malformed saved file contains them.
  const polluted = { ...parsed.upload, preview: packet.preview, rows: packet.preview.rows,
    fields: parsed.upload.fields.map((field) => ({ ...field, rows: [canary] })) };
  const state = { input: 'Build a table', messages: [{ role: 'user' as const, files: [polluted] }], attachments: [polluted], preview: packet.preview };
  const saved = JSON.stringify(metadataChatState(state));
  assert.equal(saved.includes(canary), false);
  assert.equal(saved.includes('preview'), false);
  assert.equal(saved.includes('"rows"'), false);
  assert.equal(saved.includes('"blankCount":2'), true);
  const body = chatRequestBody('Build a table', [polluted], 'invented-conversation');
  assert.deepEqual(JSON.parse(body), { message: 'Build a table', conversationId: 'invented-conversation', uploads: ['user:invented'] });
  assert.equal(body.includes(canary), false);
});

test('local preview cache evicts older values while leaving upload metadata intact', () => {
  const parsed = readUploadPacket(packet); const cache = new Map();
  for (let index = 0; index < 40; index++) rememberUploadPreview(cache, `user:invented-${index}`, parsed.preview!);
  assert.equal(cache.size, 20); assert.equal(cache.has('user:invented-0'), false); assert.equal(cache.has('user:invented-39'), true);
  assert.equal(parsed.upload.rowCount, 6);
});

test('untrusted previews are bounded and non-primitive values are not expanded', () => {
  const result = readUploadPacket({ dataset: metadata, preview: { columns: Array.from({ length: 100 }, (_, i) => `invented_${i}`), rows: Array.from({ length: 10 }, () => ['x'.repeat(5000), { secret: canary }, 0, false]) } });
  assert.equal(result.preview?.columns.length, 50);
  assert.equal(result.preview?.rows.length, 5);
  assert.equal(result.preview?.rows[0]?.[0]?.length, 2001);
  assert.deepEqual(result.preview?.rows[0]?.slice(1, 4), ['', '0', 'false']);
  assert.equal(result.preview?.shortened, true);
});

class FakeElement {
  tagName: string; children: FakeElement[] = []; attributes = new Map<string, string>(); text = ''; className = ''; tabIndex = -1; scope = ''; open = false; dataset = {}; style = {}; lang = '';
  constructor(tag: string) { this.tagName = tag.toUpperCase(); }
  set textContent(value: string) { this.text = value; }
  get textContent(): string { return this.text + this.children.map((child) => child.textContent).join(''); }
  set innerHTML(_value: string) { throw new Error('HTML insertion is forbidden for upload values'); }
  append(...items: FakeElement[]): void { this.children.push(...items); }
  setAttribute(name: string, value: string): void { this.attributes.set(name, value); }
}
function walk(element: FakeElement): FakeElement[] { return [element, ...element.children.flatMap(walk)]; }

test('preview cards render hostile names as text, accessible five-row tables and translated counts', () => {
  const globals = globalThis as unknown as { document?: unknown };
  const previous = globals.document;
  globals.document = { createElement: (tag: string) => new FakeElement(tag), documentElement: new FakeElement('html'), querySelectorAll: () => [] };
  try {
    const hostile = '<img src=x onerror=alert(1)>';
    const parsed = readUploadPacket({ ...packet, dataset: { ...metadata, name: '<script>invented()</script>' }, preview: { columns: [hostile, 'amount'], rows: [[hostile, '0'], ...packet.preview.rows] } });
    const card = uploadCard(parsed.upload, parsed.preview) as unknown as FakeElement;
    const elements = walk(card);
    assert.equal(card.open, true);
    assert.equal(elements.some((element) => ['IMG', 'SCRIPT'].includes(element.tagName)), false);
    assert.equal(elements.filter((element) => element.tagName === 'TD').length, 10);
    assert.equal(elements.some((element) => element.tagName === 'TD' && element.textContent === hostile), true);
    assert.equal(card.textContent.includes('INVENTED-SIXTH-ROW'), false);
    assert.equal(card.textContent.includes('2 blanks'), true);
    assert.equal(elements.filter((element) => element.tagName === 'TH').every((element) => element.scope === 'col'), true);
    const region = elements.find((element) => element.attributes.get('role') === 'region');
    assert.equal(region?.tabIndex, 0);
    assert.equal(region?.attributes.get('aria-label'), 'Uploaded file preview');
    setLanguage('zh');
    assert.equal((uploadCard(parsed.upload, parsed.preview) as unknown as FakeElement).textContent.includes('前 5 行'), true);
  } finally { setLanguage('en'); globals.document = previous; }
});
