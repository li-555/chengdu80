import { after, before, test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import express from 'express';
import type { AddressInfo } from 'node:net';
import { AppDocument } from '../src/app-schema/index.ts';
import { saveApp, getState, setState } from '../src/platform/storage.ts';
import { closeStorage } from '../src/platform/database.ts';
import { getListActions, saveListAction } from '../src/platform/list-actions.ts';
import { appRoutes } from '../src/api/routes-apps.ts';
const directory = mkdtempSync(join(tmpdir(), 'blocks-list-actions-')); const previousPath = process.env.BLOCKS_DB_PATH;
before(() => { process.env.BLOCKS_DB_PATH = join(directory, 'state.sqlite'); });
after(() => { closeStorage(); if (previousPath === undefined) delete process.env.BLOCKS_DB_PATH; else process.env.BLOCKS_DB_PATH = previousPath; rmSync(directory, { recursive: true, force: true }); });
function document() { return AppDocument.parse({ meta: { name: 'Invented list actions', description: 'Invented local workflow setting fixture', spec_version: '1.0' }, params: [
  { key: 'completed', label: 'Invented completed IDs', type: 'text', list: true, default: ['FAKE-DEFAULT'] },
  { key: 'empty', label: 'Invented empty IDs', type: 'text', list: true }, { key: 'other', label: 'Other setting', type: 'number', default: 7 },
], data: [], compute: [], triggers: [{ kind: 'manual' }], ui: { root: 'root', elements: { root: { type: 'Section', children: [] } } } }); }
const request = (revision: string, requestId = 'fake-action') => ({ param: 'completed', recordId: 'FAKE-TASK', action: 'add' as const, note: 'Invented completion note', requestId, revision });
test('atomic actions preserve unrelated settings, latest carry and bindings, and survive restart', async () => {
  const app = await saveApp(document(), 'fake-owner');
  await setState(app.id, app.profile, { params: { other: 9 }, carry: { n: 1 }, bindings: { fake: 'FAKE-DATASET' }, mappings: { fake: { field: 'FAKE-COLUMN' } }, unrelated: { keep: true } });
  const initial = await getListActions(app.id, app.profile); assert.equal(initial.params.length, 2); assert.deepEqual(initial.params[0]!.values, ['FAKE-DEFAULT']);
  const state = await getState(app.id, app.profile); await setState(app.id, app.profile, { ...state, carry: { n: 2 } });
  const result = await saveListAction(app.id, app.profile, request(initial.revision)); assert.equal(result.kind, 'saved');
  closeStorage();
  const saved = await getState(app.id, app.profile);
  assert.deepEqual(saved.carry, { n: 2 }); assert.deepEqual(saved.bindings, state.bindings); assert.deepEqual(saved.mappings, state.mappings); assert.deepEqual(saved.unrelated, { keep: true });
  assert.deepEqual(saved.params, { other: 9, completed: ['FAKE-DEFAULT', 'FAKE-TASK'] });
  const reopened = await getListActions(app.id, app.profile); const event = reopened.history[0]!;
  assert.equal(event.actor, app.profile); assert.equal(event.appVersion, app.version); assert.deepEqual(event.before, ['FAKE-DEFAULT']); assert.deepEqual(event.after, ['FAKE-DEFAULT', 'FAKE-TASK']); assert.ok(Number.isFinite(Date.parse(event.time)));
  await assert.rejects(getListActions(app.id, 'another-owner'), /Application not found for this profile/);
  await assert.rejects(saveListAction(app.id, 'another-owner', request(reopened.revision, 'foreign')), /Application not found for this profile/);
});
test('retry is idempotent after later edits; payload mismatch and stale writes leave values/history unchanged', async () => {
  const app = await saveApp(document(), 'fake-retry'); const initial = await getListActions(app.id, app.profile);
  const input = request(initial.revision); assert.equal((await saveListAction(app.id, app.profile, input)).kind, 'saved');
  const after = await getListActions(app.id, app.profile);
  assert.equal((await saveListAction(app.id, app.profile, { ...request(after.revision, 'remove-task'), action: 'remove' })).kind, 'saved');
  const current = await getListActions(app.id, app.profile);
  assert.equal((await saveListAction(app.id, app.profile, input)).kind, 'reused');
  assert.equal((await saveListAction(app.id, app.profile, { ...input, note: 'Changed payload' })).kind, 'request_conflict');
  assert.equal((await saveListAction(app.id, app.profile, request(initial.revision, 'stale-request'))).kind, 'conflict');
  assert.deepEqual(await getListActions(app.id, app.profile), current);
  assert.deepEqual(current.params[0]!.values, ['FAKE-DEFAULT']);
});
test('only declared text-list parameters and bounded finite actions are accepted', async () => {
  const app = await saveApp(document(), 'fake-validation'); const current = await getListActions(app.id, app.profile); const input = request(current.revision);
  for (const bad of [{ ...input, param: 'other' }, { ...input, param: 'unknown' }, { ...input, recordId: ' ' }, { ...input, recordId: 'x'.repeat(201) }, { ...input, note: 'x'.repeat(1001) }, { ...input, action: 'complete' }, { ...input, extra: 'unexpected' }]) assert.equal((await saveListAction(app.id, app.profile, bad)).kind, 'invalid');
  assert.deepEqual(await getListActions(app.id, app.profile), current);
  const changedState = await getState(app.id, app.profile); await setState(app.id, app.profile, { ...changedState, params: { other: 11 } });
  assert.equal((await saveListAction(app.id, app.profile, input)).kind, 'conflict', 'CAS covers unrelated editable parameters too');
});
test('history is bounded and an evicted old request cannot overwrite current settings with its stale revision', async () => {
  const app = await saveApp(document(), 'fake-bounded'); const first = await getListActions(app.id, app.profile); const old = request(first.revision, 'bounded-0');
  await saveListAction(app.id, app.profile, old);
  for (let i = 1; i <= 100; i++) { const current = await getListActions(app.id, app.profile); await saveListAction(app.id, app.profile, { ...request(current.revision, `bounded-${i}`), recordId: `FAKE-${i}`, action: 'remove' }); }
  const current = await getListActions(app.id, app.profile); assert.equal(current.history.length, 100); assert.equal(current.history[0]!.requestId, 'bounded-1');
  assert.equal((await saveListAction(app.id, app.profile, old)).kind, 'conflict');
});
test('HTTP inherits browser/origin guards, returns scoped lists and distinguishes retry/stale/invalid requests', async () => {
  const server = express().use(...appRoutes).listen(0, '127.0.0.1'); await new Promise<void>((resolve) => server.once('listening', resolve));
  const base = `http://127.0.0.1:${(server.address() as AddressInfo).port}`;
  try {
    const initial = await fetch(`${base}/api/apps`); const cookie = initial.headers.get('set-cookie')!.split(';')[0]!;
    const app = await saveApp(document(), `browser:${cookie.split('=')[1]}`); const path = `${base}/api/apps/${app.id}/list-actions`;
    const currentResponse = await fetch(path, { headers: { cookie } }); assert.equal(currentResponse.status, 200); assert.equal(currentResponse.headers.get('cache-control'), 'no-store');
    const snapshot = await currentResponse.json(); const input = request(snapshot.revision);
    const post = (body: unknown, headers: Record<string, string> = {}) => fetch(path, { method: 'POST', headers: { cookie, 'Content-Type': 'application/json', 'X-Blocks-Request': '1', ...headers }, body: JSON.stringify(body) });
    assert.equal((await post(input, { origin: 'https://elsewhere.example' })).status, 403);
    assert.equal((await post(input, { 'X-Blocks-Request': '0' })).status, 403);
    assert.equal((await fetch(path)).status, 404);
    const saved = await post(input); assert.equal(saved.status, 200); assert.equal((await saved.json()).kind, 'saved');
    const reused = await post(input); assert.equal(reused.status, 200); assert.equal((await reused.json()).kind, 'reused');
    assert.equal((await post({ ...input, recordId: 'FAKE-OTHER' })).status, 409);
    assert.equal((await post({ ...input, requestId: 'fake-stale' })).status, 409);
    assert.equal((await post({ ...input, recordId: 'x'.repeat(201) })).status, 422);
    const current = await (await fetch(path, { headers: { cookie } })).json();
    assert.equal((await post({ ...request(current.revision, 'wrong-type'), param: 'other' })).status, 422);
    assert.equal((await post({ ...input, note: 'x'.repeat(20000) })).status, 413);
    const badJSON = await fetch(path, { method: 'POST', headers: { cookie, 'Content-Type': 'application/json', 'X-Blocks-Request': '1' }, body: '{bad' }); assert.equal(badJSON.status, 400);
    assert.equal((await (await fetch(path, { headers: { cookie } })).json()).history.length, 1);
  } finally { await new Promise<void>((resolve) => server.close(() => resolve())); }
});
