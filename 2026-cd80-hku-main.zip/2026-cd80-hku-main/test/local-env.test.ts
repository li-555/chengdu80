import { test, type TestContext } from 'node:test';
import assert from 'node:assert/strict';
import { cpSync, mkdirSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { resolveNode } from '../scripts/runtime.mjs';

// All keys here are invented strings; no real service is contacted.
function fixture(t: TestContext) {
  const directory = mkdtempSync(join(tmpdir(), 'blocks-local-env-'));
  t.after(() => rmSync(directory, { recursive: true, force: true }));
  const project = join(directory, 'project');
  mkdirSync(join(project, 'scripts'), { recursive: true });
  mkdirSync(join(project, 'src/platform'), { recursive: true });
  for (const name of ['runtime.mjs', 'start.mjs', 'go.mjs', 'check.mjs']) {
    cpSync(new URL(`../scripts/${name}`, import.meta.url), join(project, 'scripts', name));
  }
  writeFileSync(join(project, 'package.json'), '{"type":"module"}');
  writeFileSync(join(project, 'src/platform/dependencies.ts'), 'export function checkRuntimeDependencies() { return { ok: true }; }');
  const probe = `console.log(JSON.stringify({
    fromFile: process.env.GITEE_AI_API_KEY === 'INVENTED_ONLY_#_KEY',
    fromTerminal: process.env.GITEE_AI_API_KEY === 'INVENTED_TERMINAL_KEY',
    emptyKey: process.env.GITEE_AI_API_KEY === '',
    model: process.env.CD80_LLM_MODEL ?? null,
    port: process.env.CD80_PORT ?? null,
  }));`;
  writeFileSync(join(project, 'src/server.ts'), probe);
  writeFileSync(join(project, 'src/platform/check.ts'), probe);
  const runtime = resolveNode();
  function invoke(script: string, overrides: NodeJS.ProcessEnv = {}) {
    const env: NodeJS.ProcessEnv = { ...process.env, BLOCKS_NODE_PATH: runtime.executable };
    for (const key of ['GITEE_AI_API_KEY', 'CD80_LLM_MODEL', 'CD80_LLM_BASE_URL', 'CD80_PORT', 'BLOCKS_PORT', 'TUSHARE_TOKEN']) delete env[key];
    const result = spawnSync(runtime.executable, [join(project, 'scripts', script)], {
      // The launchers must find their own repository, regardless of caller cwd.
      cwd: directory, env: { ...env, ...overrides }, encoding: 'utf8', timeout: 10000,
    });
    assert.equal(result.status, 0, result.stderr);
    return JSON.parse(result.stdout.trim().split('\n').at(-1)!);
  }
  const save = (content: string) => writeFileSync(join(project, '.env'), content, { mode: 0o600 });
  return { invoke, save };
}
for (const script of ['start.mjs', 'go.mjs', 'check.mjs']) {
  test(`${script} loads its repository's optional .env with quoted keys and comments`, (t) => {
    const f = fixture(t);
    f.save('# Invented values only\nGITEE_AI_API_KEY="INVENTED_ONLY_#_KEY"\nCD80_LLM_MODEL=Invented-model\nCD80_PORT=3007 # comment\n');
    assert.deepEqual(f.invoke(script), { fromFile: true, fromTerminal: false, emptyKey: false, model: 'Invented-model', port: '3007' });
  });
}
test('terminal variables, including explicit empty keys, take precedence over .env', (t) => {
  const f = fixture(t);
  f.save('GITEE_AI_API_KEY=INVENTED_ONLY_#_KEY\nCD80_PORT=3007\n');
  const inherited = f.invoke('start.mjs', { GITEE_AI_API_KEY: 'INVENTED_TERMINAL_KEY', CD80_PORT: '0' });
  assert.equal(inherited.fromTerminal, true); assert.equal(inherited.port, '0');
  assert.equal(f.invoke('start.mjs', { GITEE_AI_API_KEY: '' }).emptyKey, true);
});
test('missing .env retains startup behavior; a restart loads edited configuration', (t) => {
  const f = fixture(t);
  assert.deepEqual(f.invoke('start.mjs'), { fromFile: false, fromTerminal: false, emptyKey: false, model: null, port: null });
  f.save('CD80_LLM_MODEL=Invented-first\n');
  assert.equal(f.invoke('start.mjs').model, 'Invented-first');
  f.save('CD80_LLM_MODEL=Invented-second\n');
  assert.equal(f.invoke('start.mjs').model, 'Invented-second');
});
