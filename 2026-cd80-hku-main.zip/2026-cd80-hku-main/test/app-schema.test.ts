import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { AppDocument, ExportEnvelope, appVersion, canonicalJson, OPERATION_COUNT, ELEMENT_TYPES } from '../src/app-schema/index.ts';

const raw = JSON.parse(readFileSync(new URL('../examples/ex-01-daily-movers.fin.json', import.meta.url), 'utf8'));

test('the catalogue sizes are what the submission committed to', () => {
  assert.equal(OPERATION_COUNT, 18);
  assert.equal(ELEMENT_TYPES.length, 12);
});

test('the example application parses', () => {
  const { $schema: _s, ...doc } = raw;
  const r = AppDocument.safeParse(doc);
  if (!r.success) assert.fail(`did not parse:\n${JSON.stringify(r.error.issues, null, 2)}`);
});

test('an unknown key at the root is an error, never ignored', () => {
  const { $schema: _s, ...doc } = raw;
  const r = AppDocument.safeParse({ ...doc, nonsense: 1 });
  assert.equal(r.success, false);
});

test('a typo inside a step is an error, never ignored', () => {
  const { $schema: _s, ...doc } = raw;
  const bent = structuredClone(doc);
  bent.compute[2].params.limitt = 5;
  assert.equal(AppDocument.safeParse(bent).success, false);
});

test('the version fingerprint is stable and survives export and re-import', () => {
  const { $schema: _s, ...doc } = raw;
  const d = AppDocument.parse(doc);
  const v1 = appVersion(d);
  assert.match(v1, /^[0-9a-f]{12}$/);
  // export, then re-import
  const exported = JSON.stringify(ExportEnvelope.parse({ ...d, $schema: '/api/spec/schema' }));
  const { $schema: _again, ...back } = JSON.parse(exported);
  assert.equal(appVersion(AppDocument.parse(back)), v1, 'a round trip must give the same fingerprint');
});

test('key order does not change the fingerprint', () => {
  const { $schema: _s, ...doc } = raw;
  const d = AppDocument.parse(doc);
  const shuffled = AppDocument.parse(JSON.parse(JSON.stringify({ ui: d.ui, triggers: d.triggers, compute: d.compute, data: d.data, params: d.params, meta: d.meta })));
  assert.equal(appVersion(shuffled), appVersion(d));
});

test('updated_at does not change the fingerprint, but a parameter default does', () => {
  const { $schema: _s, ...doc } = raw;
  const d = AppDocument.parse(doc);
  const v = appVersion(d);
  assert.equal(appVersion({ ...d, meta: { ...d.meta, updated_at: '2026-10-13T18:00:00Z' } }), v);
  const changed = structuredClone(d);
  changed.params[1]!.default = 5;
  assert.notEqual(appVersion(changed), v, 'changing a parameter default must change the version');
});

test('canonical JSON drops undefined and sorts keys', () => {
  assert.equal(canonicalJson({ b: 1, a: undefined, c: [3, { z: 1, y: 2 }] }), '{"b":1,"c":[3,{"y":2,"z":1}]}');
});

test('a filter names a parameter and cannot also carry a literal value', () => {
  const { $schema: _s, ...doc } = raw;
  // A well-formed filter, plus a literal value. The `value` key alone must be the reason
  // it is refused, which the earlier version of this test did not establish.
  const bent = structuredClone(doc);
  bent.data[0].filters = [{ field: 'code', op: 'in', param: 'watchlist', value: ['600000.SH'] }];
  const r = AppDocument.safeParse(bent);
  assert.equal(r.success, false, 'a filter must not be able to hold a value');
  assert.ok(
    JSON.stringify(r.error.issues).includes('value'),
    `the refusal must name the offending key, got: ${JSON.stringify(r.error.issues)}`,
  );
  // and the same filter without the literal is accepted
  const clean = structuredClone(doc);
  clean.data[0].filters = [{ field: 'code', op: 'in', param: 'watchlist' }];
  assert.equal(AppDocument.safeParse(clean).success, true);
});

test('a new key cannot be added to carry a URL or a credential', () => {
  const { $schema: _s, ...doc } = raw;
  const bent = structuredClone(doc);
  bent.data[0].url = 'https://example.invalid/data.csv';
  assert.equal(AppDocument.safeParse(bent).success, false);
  const bent2 = structuredClone(doc);
  bent2.meta.token = 'abc';
  assert.equal(AppDocument.safeParse(bent2).success, false);
});


// ---------------------------------------------------------------------------
// Regressions for the seven defects found in review on 2026-10-13.
// Each test names the defect it locks shut.
// ---------------------------------------------------------------------------

const baseDoc = (): any => { const { $schema: _s, ...d } = structuredClone(raw); return d; };

test('defect 1: a parameter default cannot smuggle data, a path or a token', () => {
  for (const value of [
    { rows: [{ price: 1 }] },
    { dataset_id: 'private', path: '/tmp/private.csv' },
    { token: 'secret' },
    [{ code: '600000.SH', px: 1 }],
    [1, 2, 3],
  ]) {
    const d = baseDoc();
    d.params[0].default = value;
    assert.equal(
      AppDocument.safeParse(d).success, false,
      `a default must not accept ${JSON.stringify(value)}`,
    );
  }
});

test('defect 2: a data requirement cannot hold a URL, a scheme or a file path', () => {
  const cases: [string, string][] = [
    ['datasetHint', 'https://example.invalid/data.csv'],
    ['datasetHint', 'file:///etc/passwd'],
    ['purpose', 'read from https://example.invalid'],
    ['datasetHint', '/Users/someone/private.csv'],
    ['datasetHint', 'C:\\data\\private.csv'],
  ];
  for (const [field, value] of cases) {
    const d = baseDoc();
    d.data[0][field] = value;
    assert.equal(AppDocument.safeParse(d).success, false, `${field} must refuse ${value}`);
  }
  // a column name cannot be an address either
  const d = baseDoc();
  d.data[0].fields[0].name = 'https://example.invalid';
  assert.equal(AppDocument.safeParse(d).success, false);
});

test('defect 3: the fingerprint refuses values it cannot represent faithfully', () => {
  assert.throws(() => canonicalJson(NaN), /cannot fingerprint the number NaN/);
  assert.throws(() => canonicalJson(Infinity), /cannot fingerprint the number Infinity/);
  assert.throws(() => canonicalJson(1n), /type bigint/);
  assert.throws(() => canonicalJson(() => 1), /type function/);
  assert.throws(() => canonicalJson(new Date('nonsense')), /invalid Date/);
  // two different Dates must not collide
  const a = canonicalJson({ d: new Date('2026-01-01T00:00:00Z') });
  const b = canonicalJson({ d: new Date('2026-02-01T00:00:00Z') });
  assert.notEqual(a, b, 'two different dates must not produce the same fingerprint input');
});

test('defect 4: canonical JSON of a sparse array is still valid JSON', () => {
  const out = canonicalJson(Array(2));
  assert.equal(out, '[null,null]');
  JSON.parse(out);                                  // must not throw
  JSON.parse(canonicalJson([1, undefined, 3]));
  assert.equal(canonicalJson([1, undefined, 3]), '[1,null,3]');
});

test('defect 5: the maps that used to be unbounded now have caps', () => {
  // derived columns: 64 allowed, 65 refused
  const ok = baseDoc();
  ok.compute[0].params.columns = Object.fromEntries(Array.from({ length: 64 }, (_, i) => [`c${i}`, '1 + 1']));
  assert.equal(AppDocument.safeParse(ok).success, true);
  const tooMany = baseDoc();
  tooMany.compute[0].params.columns = Object.fromEntries(Array.from({ length: 65 }, (_, i) => [`c${i}`, '1 + 1']));
  assert.equal(AppDocument.safeParse(tooMany).success, false);
  // an empty map is also refused
  const empty = baseDoc();
  empty.compute[0].params.columns = {};
  assert.equal(AppDocument.safeParse(empty).success, false);
  // screen elements: 61 refused
  const manyEls = baseDoc();
  for (let i = 0; i < 61; i++) manyEls.ui.elements[`extra${i}`] = { type: 'Text', text: 'x' };
  assert.equal(AppDocument.safeParse(manyEls).success, false);
});

test('defect 7: a default must match its parameter type, range and options', () => {
  const cases: [string, (d: any) => void][] = [
    ['a number parameter with a text default', (d) => { d.params[1].default = 'oops'; }],
    ['a number default above max',            (d) => { d.params[1].default = 100; }],
    ['a number default below min',            (d) => { d.params[1].default = -1; }],
    ['a list default on a non-list parameter',(d) => { d.params[1].default = ['a']; }],
    ['a scalar default on a list parameter',  (d) => { d.params[0].default = 'just-one'; }],
    ['a date default that is not YYYY-MM-DD', (d) => { d.params.push({ key: 'from_day', label: 'From', type: 'date', default: '13/10/2026' }); }],
    ['a default outside the options',         (d) => { d.params.push({ key: 'mode', label: 'Mode', type: 'text', options: [{ value: 'a', label: 'A' }], default: 'z' }); }],
    ['min above max',                         (d) => { d.params[1].min = 90; d.params[1].max = 10; }],
    ['options on a number parameter',         (d) => { d.params[1].options = [{ value: 'a', label: 'A' }]; }],
    ['list on a number parameter',            (d) => { d.params[1].list = true; }],
    ['duplicate option values',               (d) => { d.params.push({ key: 'pick', label: 'Pick', type: 'text', options: [{ value: 'a', label: 'A' }, { value: 'a', label: 'Again' }] }); }],
  ];
  for (const [name, bend] of cases) {
    const d = baseDoc();
    bend(d);
    assert.equal(AppDocument.safeParse(d).success, false, `must refuse: ${name}`);
  }
  // and a correct date parameter is accepted
  const good = baseDoc();
  good.params.push({ key: 'from_day', label: 'From', type: 'date', default: '2026-10-13' });
  assert.equal(AppDocument.safeParse(good).success, true);
});

test('the fingerprint is unaffected by the review fixes', () => {
  const d = AppDocument.parse(baseDoc());
  assert.match(appVersion(d), /^[0-9a-f]{12}$/);
});
