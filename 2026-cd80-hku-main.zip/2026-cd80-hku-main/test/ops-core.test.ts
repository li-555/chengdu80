import test from 'node:test';
import assert from 'node:assert/strict';
import { compileFilter } from '../src/compute/ops/filter.ts';
import { compileDerive } from '../src/compute/ops/derive.ts';
import { compileJoin } from '../src/compute/ops/join.ts';
import { compileAggregate } from '../src/compute/ops/aggregate.ts';
import { compileSortLimit } from '../src/compute/ops/sort_limit.ts';
import { OpCompileError, type OpCompileInput } from '../src/compute/ops/contract.ts';

function fixture(inputs: string[] = ['orchard']): OpCompileInput {
  return {
    inputs,
    columns: new Map([
      ['orchard', ['batch', 'weight', 'tick', 'odd"key'].map((name) => ({ name, type: 'DOUBLE' }))],
      ['basket', ['code', 'mass', 'stamp', 'odd"key'].map((name) => ({ name, type: 'DOUBLE' }))],
    ]),
    params: new Map<string, unknown>([['n', 173], ['cutoff', 731]]),
    scalars: new Map<string, unknown>([['baseline', 941]]),
  };
}

test('filter binds literals, settings and scalars in expression order', () => {
  const result = compileFilter({ where: 'weight > 613 and weight < $params.cutoff and weight != baseline' }, fixture());
  assert.equal(result.sql, 'SELECT * FROM "orchard" WHERE ((("weight" > ?) AND ("weight" < ?)) AND ("weight" <> ?))');
  assert.deepEqual(result.bindings, [613, 731, 941]);
  for (const value of result.bindings) assert.ok(!result.sql.includes(String(value)));
});

test('filter rejects unknown columns and invalid formulas', () => {
  assert.throws(() => compileFilter({ where: 'missing > 613' }, fixture()), OpCompileError);
  assert.throws(() => compileFilter({ where: 'weight +' }, fixture()), OpCompileError);
});

test('derive preserves column declaration order and each expression binding order', () => {
  const result = compileDerive({ columns: {
    zeta: 'weight + 827',
    alpha: '$params.cutoff - baseline + 419',
    beta: '$params.cutoff + baseline',
  } }, fixture());
  assert.equal(result.sql, 'SELECT * , ("weight" + ?) AS "zeta" , ((? - ?) + ?) AS "alpha" , (? + ?) AS "beta" FROM "orchard"');
  assert.deepEqual(result.bindings, [827, 731, 941, 419, 731, 941]);
  for (const value of result.bindings) assert.ok(!result.sql.includes(String(value)));
});

test('derive rejects unknown columns and does not expose sibling output aliases', () => {
  assert.throws(() => compileDerive({ columns: { added: 'missing + 827' } }, fixture()), OpCompileError);
  assert.throws(() => compileDerive({ columns: { added: 'weight + 827', next: 'added + 419' } }, fixture()), OpCompileError);
});

test('derive safely quotes newly declared output columns', () => {
  assert.equal(compileDerive({ columns: { 'odd"output': 'weight' } }, fixture()).sql,
    'SELECT * , "weight" AS "odd""output" FROM "orchard"');
});

test('join emits its key pairs in declaration order for inner and left joins', () => {
  for (const how of ['inner', 'left'] as const) {
    const result = compileJoin(
      { right: 'basket', on: [['batch', 'code'], ['weight', 'mass']], how },
      fixture(['orchard', 'basket']),
    );
    assert.ok(result.sql.includes(how === 'inner' ? 'INNER JOIN' : 'LEFT JOIN'));
    assert.ok(
      result.sql.includes('ON l. "batch" = r. "code" AND l. "weight" = r. "mass"'),
      `key pairs must keep declaration order: ${result.sql}`,
    );
    assert.deepEqual(result.bindings, [], 'a join binds nothing');
    assert.ok(!result.sql.includes('731'), 'no setting value may appear in the text');
  }
});

test('join projects named columns, dropping the right key and suffixing a collision', () => {
  const result = compileJoin(
    { right: 'basket', on: [['batch', 'code'], ['weight', 'mass']], how: 'inner' },
    fixture(['orchard', 'basket']),
  );
  assert.ok(!result.sql.startsWith('SELECT * '), 'the columns must be named, not starred');

  /**
   * Only the projection is examined. A dropped key still appears in the ON clause,
   * which is where it belongs -- the first version of this test searched the whole
   * statement and failed for that reason.
   */
  const projection = result.sql.slice('SELECT'.length, result.sql.indexOf(' FROM '));

  // The right-hand key columns equal the left's by definition, so they are not projected.
  for (const dropped of ['r. "code"', 'r. "mass"']) {
    assert.ok(!projection.includes(dropped), `${dropped} must not be projected: ${projection}`);
  }
  // Every left column survives under its own name.
  for (const kept of ['l. "batch"', 'l. "weight"', 'l. "tick"']) {
    assert.ok(projection.includes(kept), `${kept} must be projected: ${projection}`);
  }
  // A non-key column present on both sides is renamed rather than emitted twice.
  assert.ok(
    projection.includes('AS "odd""key_basket"'),
    `the colliding right-hand column must be suffixed: ${projection}`,
  );
  assert.ok(projection.includes('r. "stamp"'), 'a right column with no collision keeps its name');
});

test('join quotes a hostile identifier and still binds nothing', () => {
  const result = compileJoin(
    { right: 'basket', on: [['odd"key', 'odd"key']], how: 'inner' },
    fixture(['orchard', 'basket']),
  );
  assert.ok(
    result.sql.includes('ON l. "odd""key" = r. "odd""key"'),
    `a double quote in a name must be doubled, not escaped away: ${result.sql}`,
  );
  assert.deepEqual(result.bindings, []);
});

test('join rejects unknown columns on either relation', () => {
  for (const on of [[['missing', 'code']], [['batch', 'missing']]] as [string, string][][]) {
    assert.throws(() => compileJoin({ right: 'basket', on, how: 'inner' }, fixture(['orchard', 'basket'])), OpCompileError);
  }
});

test('ASOF joins use the default backward or explicit forward inequality', () => {
  for (const direction of [undefined, 'backward', 'forward'] as const) {
    const result = compileJoin({ right: 'basket', on: [['batch', 'code']], how: 'asof',
      asof_on: ['tick', 'stamp'], direction }, fixture(['orchard', 'basket']));
    assert.ok(result.sql.includes('ASOF LEFT JOIN'));
    assert.ok(
      result.sql.includes(
        'ON l. "batch" = r. "code" AND l. "tick" ' +
          (direction === 'forward' ? '<=' : '>=') +
          ' r. "stamp"',
      ),
      `backward matching is l >= r, forward is l <= r: ${result.sql}`,
    );
    assert.ok(!result.sql.includes('r. "stamp" AS'), 'the asof key is a key, so it is dropped');
    assert.deepEqual(result.bindings, []);
  }
});

test('ASOF rejects absent, unknown or unsupported matching conditions', () => {
  const input = fixture(['orchard', 'basket']);
  const base = { right: 'basket', on: [['batch', 'code']] as [string, string][], how: 'asof' as const };
  assert.throws(() => compileJoin(base, input), OpCompileError);
  assert.throws(() => compileJoin({ ...base, asof_on: ['missing', 'stamp'] }, input), OpCompileError);
  assert.throws(() => compileJoin({ ...base, asof_on: ['tick', 'stamp'], direction: 'nearest' }, input), OpCompileError);
});

test('aggregate preserves group and metric order and binds quantiles', () => {
  const result = compileAggregate({ by: ['batch', 'tick'], metrics: [
    { fn: 'quantile', of: 'weight', as: 'upper', p: 0.83 },
    { fn: 'mean', of: 'weight', as: 'average' },
    { fn: 'quantile', of: 'weight', as: 'lower', p: 0.17 },
  ] }, fixture());
  assert.equal(result.sql, 'SELECT "batch" , "tick" , quantile_cont ( "weight" , ? ) AS "upper" , avg ( "weight" ) AS "average" , quantile_cont ( "weight" , ? ) AS "lower" FROM "orchard" GROUP BY "batch" , "tick"');
  assert.deepEqual(result.bindings, [0.83, 0.17]);
  assert.ok(!result.sql.includes('0.83'));
  assert.ok(!result.sql.includes('0.17'));
});

test('aggregate implements every function and count without a column', () => {
  const functions = {
    sum: 'sum', mean: 'avg', median: 'median', min: 'min', max: 'max', count: 'count',
    count_distinct: 'count', stddev: 'stddev_samp', var: 'var_samp', quantile: 'quantile_cont',
  } as const;
  for (const fn of Object.keys(functions) as (keyof typeof functions)[]) {
    const result = compileAggregate({ by: [], metrics: [{ fn, of: 'weight', as: 'result', p: 0.37 }] }, fixture());
    assert.equal(result.sql, 'SELECT ' + functions[fn] + ' ( ' + (fn === 'count_distinct' ? 'DISTINCT ' : '') +
      '"weight"' + (fn === 'quantile' ? ' , ?' : '') + ' ) AS "result" FROM "orchard"');
    assert.deepEqual(result.bindings, fn === 'quantile' ? [0.37] : []);
  }
  assert.deepEqual(compileAggregate({ by: [], metrics: [{ fn: 'count', as: 'rows' }] }, fixture()), {
    sql: 'SELECT count ( * ) AS "rows" FROM "orchard"', bindings: [],
  });
});

test('aggregate rejects unknown group and metric columns', () => {
  assert.throws(() => compileAggregate({ by: ['missing'], metrics: [{ fn: 'count', as: 'rows' }] }, fixture()), OpCompileError);
  assert.throws(() => compileAggregate({ by: [], metrics: [{ fn: 'sum', of: 'missing', as: 'total' }] }, fixture()), OpCompileError);
});

test('aggregate rejects missing columns and invalid quantiles', () => {
  assert.throws(() => compileAggregate({ by: [], metrics: [{ fn: 'sum', as: 'total' }] }, fixture()), OpCompileError);
  for (const p of [undefined, -0.1, 1.1, NaN, Infinity]) {
    assert.throws(() => compileAggregate({ by: [], metrics: [{ fn: 'quantile', of: 'weight', as: 'q', p }] }, fixture()), OpCompileError);
  }
});

test('sort_limit preserves sort order and binds limit then offset', () => {
  const result = compileSortLimit({ by: [{ col: 'weight', dir: 'desc' }, { col: 'batch', dir: 'asc' }], limit: 157, offset: 29 }, fixture());
  assert.equal(result.sql, 'SELECT * FROM "orchard" ORDER BY "weight" DESC , "batch" ASC LIMIT ? OFFSET ?');
  assert.deepEqual(result.bindings, [157, 29]);
  assert.ok(!result.sql.includes('157'));
  assert.ok(!result.sql.includes('29'));
});

test('sort_limit resolves named settings for limit and offset', () => {
  const result = compileSortLimit({ by: [{ col: 'weight', dir: 'asc' }], limit: { param: 'n' }, offset: { param: 'cutoff' } }, fixture());
  assert.equal(result.sql, 'SELECT * FROM "orchard" ORDER BY "weight" ASC LIMIT ? OFFSET ?');
  assert.deepEqual(result.bindings, [173, 731]);
  assert.ok(!result.sql.includes('173'));
  assert.ok(!result.sql.includes('731'));
});

test('sort_limit supports absent counts and offset without limit', () => {
  const by = [{ col: 'WEIGHT', dir: 'asc' as const }];
  assert.deepEqual(compileSortLimit({ by }, fixture()), {
    sql: 'SELECT * FROM "orchard" ORDER BY "weight" ASC', bindings: [],
  });
  assert.deepEqual(compileSortLimit({ by, offset: 0 }, fixture()), {
    sql: 'SELECT * FROM "orchard" ORDER BY "weight" ASC OFFSET ?', bindings: [0],
  });
});

test('sort_limit rejects unknown columns and invalid counts', () => {
  const by = [{ col: 'weight', dir: 'asc' as const }];
  assert.throws(() => compileSortLimit({ by: [{ col: 'missing', dir: 'asc' }] }, fixture()), OpCompileError);
  for (const limit of [0, 200001, 1.5, NaN, { param: 'missing' }]) {
    assert.throws(() => compileSortLimit({ by, limit }, fixture()), OpCompileError);
  }
  for (const offset of [-1, 200001, 0.5]) {
    assert.throws(() => compileSortLimit({ by, offset }, fixture()), OpCompileError);
  }
});

test('single input operations reject missing or extra inputs and missing column metadata', () => {
  for (const input of [fixture([]), fixture(['orchard', 'basket']), { ...fixture(), columns: new Map() }]) {
    assert.throws(() => compileFilter({ where: 'weight > 1' }, input), OpCompileError);
    assert.throws(() => compileDerive({ columns: { added: 'weight + 1' } }, input), OpCompileError);
    assert.throws(() => compileAggregate({ by: [], metrics: [{ fn: 'count', as: 'rows' }] }, input), OpCompileError);
    assert.throws(() => compileSortLimit({ by: [{ col: 'weight', dir: 'asc' }] }, input), OpCompileError);
  }
});
