import { test } from 'node:test';
import assert from 'node:assert/strict';
import { ColumnName, Identifier, IsoDate } from '../src/app-schema/fields.ts';
import { ElementId } from '../src/app-schema/ui.ts';
import { TriggerSpec } from '../src/app-schema/triggers.ts';
import { validateApplication, cronProblem } from '../src/validate/index.ts';
import { nearest, paramsUsedIn, relationsInSql } from '../src/validate/references.ts';

const long = 'a'.repeat(200_000);
const document = {
  meta: { spec_version: '1.0', name: 'a', description: 'a' },
  params: [],
  data: [{ key: 'a', fields: [{ name: 'a', type: 'number', required: true }] }],
  compute: [],
  triggers: [{ kind: 'manual' }],
  ui: { root: 'page', elements: { page: { type: 'Section', children: [] } } },
};

const cases = [
  ['data field name', '/data/0/fields/0/name', { ...document, data: [{ key: 'a', fields: [{ name: long, type: 'number', required: true }] }] }],
  ['param key', '/params/0/key', { ...document, params: [{ key: long, type: 'number', default: 0, label: 'a' }] }],
  ['step id', '/compute/0/id', { ...document, compute: [{ id: long, kind: 'expression', expr: '1' }] }],
  ['formula', '/compute/0/expr', { ...document, compute: [{ id: 'b', kind: 'expression', expr: long }] }],
  ['SQL text', '/compute/0/sql', { ...document, compute: [{ id: 'b', kind: 'sql', sql: long }] }],
  ['element title', '/ui/elements/page/title', { ...document, ui: { root: 'page', elements: { page: { type: 'Section', title: long, children: [] } } } }],
  ['meta name', '/meta/name', { ...document, meta: { ...document.meta, name: long } }],
  ['trigger cron', '/triggers/0/cron', { ...document, triggers: [{ kind: 'schedule', cron: long }] }],
] as const;

for (const [name, pointer, doc] of cases) {
  test(`a 200,000-character ${name} validates within 500 ms with a small report`, () => {
    for (const input of [doc, JSON.stringify(doc)]) {
      const start = performance.now();
      const { report } = validateApplication(input);
      assert.ok(performance.now() - start < 500);
      assert.equal(report.valid, false);
      assert.equal(report.stopped_in, 'schema');
      const entry = report.errors.find((e) => e.pointer === pointer);
      assert.equal(entry?.code, 'E_SCHEMA_RANGE');
      assert.equal(entry?.received, 'a string of 200000 characters');
      const output = JSON.stringify(report);
      assert.ok(Buffer.byteLength(output) < 200_000);
      assert.ok(!output.includes('a'.repeat(100)));
    }
  });
}

test('address checks reject short addresses and skip strings over their schema maximum', () => {
  assert.equal(ColumnName.safeParse('a'.repeat(128)).success, true);
  for (const value of ['https://example.test', '/tmp/table', ' data:rows']) {
    assert.equal(ColumnName.safeParse(value).success, false);
  }
  const start = performance.now();
  const result = ColumnName.safeParse(long + '://');
  assert.ok(performance.now() - start < 500);
  assert.equal(result.success, false);
  if (!result.success) assert.deepEqual(result.error.issues.map((i) => i.code), ['too_big']);
});

test('pattern schemas check length before matching oversized strings', () => {
  for (const schema of [Identifier, ElementId, IsoDate]) {
    const result = schema.safeParse(long);
    assert.equal(result.success, false);
    if (!result.success) assert.deepEqual(result.error.issues.map((i) => i.code), ['too_big']);
  }
  const start = performance.now();
  const result = TriggerSpec.safeParse({ kind: 'schedule', cron: ' '.repeat(200_000) + '!' });
  assert.ok(performance.now() - start < 500);
  assert.equal(result.success, false);
  if (!result.success) assert.deepEqual(result.error.issues.map((i) => i.code), ['too_big']);
  assert.match(cronProblem(long)!, /200000 characters/);
});

test('suggestions only compare names of at most 64 characters', () => {
  assert.equal(nearest('move_threshhold', ['move_threshold']), 'move_threshold');
  assert.equal(nearest('A'.repeat(64), ['a'.repeat(64)]), 'a'.repeat(64));
  assert.equal(nearest('a'.repeat(64), ['a'.repeat(65)]), undefined);
  assert.equal(nearest('a'.repeat(65), ['a'.repeat(64)]), undefined);
  const start = performance.now();
  assert.equal(nearest(long, [long]), undefined);
  assert.equal(nearest('short', [long]), undefined);
  assert.ok(performance.now() - start < 500);
});

test('reference scanners skip text over its schema maximum', () => {
  assert.deepEqual(paramsUsedIn('$params.a' + long), []);
  assert.deepEqual(relationsInSql('select * from a ' + long), []);
  assert.deepEqual(paramsUsedIn('$params.a'), ['a']);
  assert.deepEqual(relationsInSql('select * from a'), ['a']);
});

test('oversized keys and unchecked values are described by length', () => {
  for (const doc of [
    { ...document, [long]: true },
    { ...document, meta: { ...document.meta, [long]: true } },
    { ...document, meta: { ...document.meta, spec_version: long } },
    { ...document, compute: [{ kind: long }] },
    { ...document, ui: { root: 'page', elements: { [long]: { type: long } } } },
  ]) {
    const start = performance.now();
    const { report } = validateApplication(doc);
    assert.ok(performance.now() - start < 500);
    assert.equal(report.valid, false);
    const output = JSON.stringify(report);
    assert.ok(Buffer.byteLength(output) < 200_000);
    assert.ok(output.includes('200000 characters'));
    assert.ok(!output.includes('a'.repeat(100)));
  }
});
