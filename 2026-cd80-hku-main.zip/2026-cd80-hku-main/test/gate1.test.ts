import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';

import { validateApplication } from '../src/validate/index.ts';
import { runApplication, resolveParams, type Slice } from '../src/compute/run.ts';
import { orderSteps, OrderError } from '../src/compute/order.ts';

/**
 * Gate 1: a document is validated, run, and produces a table.
 *
 * This is the whole vertical slice in one test. It uses the committed example document
 * and an invented slice, so it needs no network and no token.
 *
 * All rows below are invented.
 */

const doc = JSON.parse(
  readFileSync(new URL('../examples/ex-01-daily-movers.fin.json', import.meta.url), 'utf8'),
);

/** An invented price slice. `pct_move` works out to +25, -10, +2 and -40 per cent. */
const prices: Slice = {
  columns: [
    { name: 'code', type: 'string' },
    { name: 'd', type: 'date' },
    { name: 'px', type: 'number' },
    { name: 'prev_px', type: 'number' },
  ],
  rows: [
    { code: 'AAA', d: '2026-01-06', px: 12.5, prev_px: 10 },
    { code: 'BBB', d: '2026-01-06', px: 45, prev_px: 50 },
    { code: 'CCC', d: '2026-01-06', px: 10.2, prev_px: 10 },
    { code: 'DDD', d: '2026-01-06', px: 6, prev_px: 10 },
  ],
};

test('the example document is valid against our own published check', () => {
  const result = validateApplication(doc);
  assert.equal(
    result.ok,
    true,
    `errors: ${JSON.stringify(result.report.errors?.map((e) => `${e.pointer}: ${e.message}`))}`,
  );
});

test('Gate 1: validate, run, and get a table on the other side', async () => {
  assert.equal(validateApplication(doc).ok, true);

  const outcome = await runApplication(doc, { slices: { prices } });

  assert.equal(outcome.failure, undefined, `the run failed: ${outcome.failure}`);
  assert.equal(outcome.status, 'ok');

  // Every step ran, in dependency order.
  assert.deepEqual(
    outcome.steps.map((s) => s.id),
    ['with_change', 'unusual', 'movers', 'mover_count'],
  );
  for (const s of outcome.steps) assert.equal(s.failed, undefined, `${s.id}: ${s.failed}`);

  // The threshold is 3 per cent by default, so CCC's 2 per cent move drops out.
  const movers = outcome.results.get('movers');
  assert.ok(movers, 'the movers table must come back');
  assert.equal(movers.rows.length, 3);
  assert.deepEqual(
    movers.rows.map((r) => r.code),
    ['AAA', 'BBB', 'DDD'],
    'biggest move first, and CCC is excluded',
  );
  assert.equal(Math.round(Number(movers.rows[0]?.pct_move)), 25);

  // The derived column really is on the table, and the count agrees with it.
  assert.ok(movers.columns.some((c) => c.name === 'pct_move'));
  const count = outcome.results.get('unusual');
  assert.equal(count?.rows.length, 3);
});

test('changing a setting changes the result without touching the document', async () => {
  const strict = await runApplication(doc, {
    slices: { prices },
    params: { move_threshold: 20 },
  });
  assert.equal(strict.status, 'ok');
  assert.deepEqual(
    strict.results.get('movers')?.rows.map((r) => r.code),
    ['AAA', 'DDD'],
    'at 20 per cent only AAA and DDD remain',
  );

  const loose = await runApplication(doc, {
    slices: { prices },
    params: { move_threshold: 1 },
  });
  assert.equal(loose.results.get('movers')?.rows.length, 4, 'at 1 per cent everything qualifies');
});

test('a row limit supplied by a setting really limits the rows', async () => {
  const outcome = await runApplication(doc, {
    slices: { prices },
    params: { move_threshold: 1, top_n: 2 },
  });
  assert.equal(outcome.results.get('movers')?.rows.length, 2);
});

test('settings resolve from the given value, then the default', () => {
  const resolved = resolveParams(doc, { top_n: 5 });
  assert.equal(resolved.get('top_n'), 5, 'a given value wins');
  assert.equal(resolved.get('move_threshold'), 3, 'otherwise the default');
});

test('a missing data binding fails the run with a plain reason', async () => {
  const outcome = await runApplication(doc, { slices: {} });
  assert.equal(outcome.status, 'failed');
  assert.match(outcome.failure ?? '', /no data was bound to 'prices'/);
});

// ------------------------------------------------------------------ ordering

test('steps with nothing left to wait for keep their declaration order', () => {
  const ordered = orderSteps(
    [
      { id: 'c', deps: ['a'] },
      { id: 'b', deps: [] },
      { id: 'a', deps: [] },
    ],
    [],
  );
  assert.deepEqual(ordered.map((s) => s.id), ['b', 'a', 'c'],
    'b and a are both ready, so the document order between them is kept');
});

test('a step comes after everything it reads', () => {
  const ordered = orderSteps(
    [
      { id: 'third', deps: ['second'] },
      { id: 'second', deps: ['first'] },
      { id: 'first', deps: ['prices'] },
    ],
    ['prices'],
  );
  assert.deepEqual(ordered.map((s) => s.id), ['first', 'second', 'third']);
});

test('a circle is reported before anything runs, naming the steps', () => {
  assert.throws(
    () => orderSteps([{ id: 'a', deps: ['b'] }, { id: 'b', deps: ['a'] }], []),
    (e: unknown) => e instanceof OrderError && /circle/.test(e.message) && e.ids.includes('a'),
  );
});

test('a step that reads itself, a duplicate id, and a dangling name are all refused', () => {
  assert.throws(() => orderSteps([{ id: 'a', deps: ['a'] }], []), /reads itself/);
  assert.throws(() => orderSteps([{ id: 'a', deps: [] }, { id: 'a', deps: [] }], []), /both called/);
  assert.throws(() => orderSteps([{ id: 'a', deps: ['nope'] }], []), /nothing provides/);
  assert.throws(() => orderSteps([{ id: 'prices', deps: [] }], ['prices']), /same name as a data requirement/);
});

// ------------------------------------------------- defects found in review, 2026-10-14

test('a SQL step cannot read a relation it did not declare', async () => {
  /**
   * It used to be checked against the run's own connection, which holds everything
   * loaded so far, so declaring one requirement gave access to all of them.
   */
  const outcome = await runApplication(
    {
      data: [{ key: 'public' }, { key: 'secret' }],
      compute: [{ id: 'leak', kind: 'sql', input: 'public', sql: 'SELECT * FROM secret', key: true }],
    },
    {
      slices: {
        public: { columns: [{ name: 'x', type: 'integer' }], rows: [{ x: 1 }] },
        secret: { columns: [{ name: 'x', type: 'integer' }], rows: [{ x: 999 }] },
      },
    },
  );
  assert.equal(outcome.status, 'failed');
  assert.match(outcome.failure ?? '', /cannot use/);
  assert.equal(outcome.results.get('leak'), undefined);
});

test('a SQL step reading only what it declared still works', async () => {
  const outcome = await runApplication(
    {
      data: [{ key: 'public' }],
      compute: [{ id: 'kept', kind: 'sql', input: 'public', sql: 'SELECT x * 2 AS doubled FROM public', key: true }],
    },
    { slices: { public: { columns: [{ name: 'x', type: 'integer' }], rows: [{ x: 21 }] } } },
  );
  assert.equal(outcome.status, 'ok', outcome.failure);
  assert.equal(Number(outcome.results.get('kept')?.rows[0]?.doubled), 42);
});

test('the first ready step in declaration order is always the next one taken', () => {
  assert.deepEqual(
    orderSteps([{ id: 'a', deps: ['b'] }, { id: 'b', deps: [] }, { id: 'c', deps: [] }], []).map((s) => s.id),
    ['b', 'a', 'c'],
    'once b is done, a is declared before c and must run first',
  );
});
