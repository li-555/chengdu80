import { test } from 'node:test';
import assert from 'node:assert/strict';
import { runApplication, type Slice } from '../src/compute/run.ts';

// All rows are invented.
const items: Slice = { columns: [{ name: 'amount', type: 'number' }], rows: [{ amount: 3 }, { amount: 9 }] };
const expression = { id: 'threshold', kind: 'expression', expr: '$params.base * 2', key: true };
const reader = { id: 'kept', kind: 'operation', op: 'filter', input: 'items', params: { where: 'amount > threshold' }, key: true };

for (const [name, compute] of [
  ['settings supply a value used by a later filter', [expression, reader]],
  ['a reader declared first waits for its expression', [reader, expression]],
] as const) {
  test(name, async () => {
    const out = await runApplication({ params: [{ key: 'base', type: 'number', default: 2 }], data: [{ key: 'items' }], compute: [...compute] }, { slices: { items } });
    assert.equal(out.status, 'ok', out.failure);
    assert.deepEqual(out.results.get('threshold')?.rows, [{ value: 4 }]);
    assert.deepEqual(out.results.get('kept')?.rows, [{ amount: 9 }]);
    assert.deepEqual(out.steps.map((s) => s.id), ['threshold', 'kept']);
  });
}

test('a column reference in an expression is refused at expr', async () => {
  const out = await runApplication({ data: [{ key: 'items' }], compute: [{ ...expression, input: 'items', expr: 'amount * 2' }] }, { slices: { items } });
  assert.equal(out.status, 'failed');
  assert.match(out.failure ?? '', /threshold.*\.expr:.*settings and single values only.*amount/);
});

test('expression scalar edges catch cycles and self references before steps run', async () => {
  for (const compute of [
    [{ ...expression, expr: 'threshold + 1' }],
    [{ ...expression, expr: 'other + 1' }, { id: 'other', kind: 'expression', expr: 'threshold + 1' }],
  ]) {
    const out = await runApplication({ compute }, { slices: {} });
    assert.equal(out.status, 'failed');
    assert.equal(out.steps.length, 0);
  }
});
