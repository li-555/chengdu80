import { test } from 'node:test';
import assert from 'node:assert/strict';
import { detachedDOM, type TestElement } from './dom-fixture.ts';
import { describeUpload } from '../src/platform/upload-preview.ts';
import { parseMarkdownDocument } from '../src/data/markdown-tables.ts';

const settle = () => new Promise<void>((resolve) => setImmediate(resolve));
async function finish(input: TestElement): Promise<void> {
  for (let index = 0; index < 100 && input.disabled; index++) await settle();
  assert.equal(input.disabled, false, 'the operation must finish');
}
test('Markdown picker flow previews prose, saves all tables, sends selected IDs and restores a rejected message', async () => {
  const dom = detachedDOM('/chat'); const original = globalThis.fetch;
  const uploads: string[] = [], requests: { message: string; uploads?: string[] }[] = [];
  let rejectChat = true;
  globalThis.fetch = async (url, options) => {
    if (String(url) === '/api/apps') return Response.json({ apps: [] });
    if (String(url).startsWith('/api/uploads?')) {
      const markdown = await (options!.body as File).text(); uploads.push(markdown);
      const sheets = parseMarkdownDocument(markdown).tables.map((table, index) => ({ sheetName: table.name,
        ...describeUpload({ id: `user:invented-md-${index}`, name: table.name, source: 'upload', rowCount: table.rows.length,
          fields: table.headers.map((name) => ({ name, label: name, type: 'text' as const, nullable: true })) }, table.rows) }));
      return Response.json({ ...sheets[0], sheets, skippedSheets: [] }, { status: 201 });
    }
    if (String(url) === '/api/chat') {
      requests.push(JSON.parse(String(options?.body)));
      if (rejectChat) return Response.json({ error: { message: 'Invented rejection' } }, { status: 400 });
      return new Response('data: {"kind":"conversation","conversationId":"invented-md"}\n\ndata: {"kind":"question","questions":["Invented follow-up"],"acceptsFile":true}\n\n', { headers: { 'Content-Type': 'text/event-stream' } });
    }
    throw new Error(`Unexpected request: ${url}`);
  };
  try {
    const { showChatScreen } = await import('../web/src/chat-screen.ts');
    showChatScreen(dom.view as unknown as HTMLElement, () => {});
    const input = dom.view.querySelector('#chat-message')!;
    input.value = 'Keep my draft.'; input.dispatchEvent(new Event('input'));
    const picker = dom.view.querySelectorAll('input').find((node) => node.type === 'file')!;
    assert.match((picker as unknown as HTMLInputElement).accept, /\.md/);
    const choose = async (file: File) => { Object.assign(picker, { files: [file] }); picker.dispatchEvent(new Event('change')); await finish(input); };
    await choose(new File(['Add an invented chart.'], 'prose.md'));
    assert.equal(uploads.length, 0, 'prose-only Markdown must not call the dataset upload API');
    assert.equal(input.value, 'Keep my draft.\n\nAdd an invented chart.');
    const mixed = 'Use two sources.\n\ncode | amount\n--- | ---\nPRIVATE-ROW-CANARY | 987654321\n\n| name | note |\n| --- | --- |\n| PRIVATE-SECOND-CANARY | note |';
    await choose(new File([mixed], 'mixed.md'));
    assert.equal(uploads.length, 1);
    assert.equal(requests.length, 0, 'uploading must not send a chat message automatically');
    const choices = dom.view.querySelectorAll('input[data-upload-id]');
    assert.equal(choices.length, 2); assert(choices.every((choice) => !choice.checked));
    choices[1]!.checked = true; choices[1]!.dispatchEvent(new Event('change'));
    const message = input.value;
    assert.equal(message, 'Keep my draft.\n\nAdd an invented chart.\n\nUse two sources.');
    assert.doesNotMatch(sessionStorage.getItem('blocks:chat:v1')!, /PRIVATE-ROW|PRIVATE-SECOND|987654321|preview|analysis/);
    dom.view.querySelector('form')!.requestSubmit(); await finish(input);
    assert.deepEqual(requests[0], { message, uploads: ['user:invented-md-1'] });
    assert.equal(input.value, message, 'a rejected request must restore the complete editable description');
    assert.equal(choices[1]!.checked, true);
    rejectChat = false;
    dom.view.querySelector('form')!.requestSubmit(); await finish(input);
    assert.deepEqual(requests[1], requests[0]);
    assert.equal(input.value, '');
    assert.equal(uploads.length, 1, 'an explicit chat retry must not upload tables again');
    const count = uploads.length;
    await choose(new File(['x'.repeat(4001)], 'too-long.md'));
    assert.equal(uploads.length, count);
    assert.match(dom.view.querySelector('.chat-feedback')!.textContent, /4,000/);
  } finally { globalThis.fetch = original; dom.restore(); }
});
