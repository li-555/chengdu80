import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { runInNewContext } from 'node:vm';
import ts from 'typescript';
import { renderScreen } from '../web/src/screen-elements.ts';
import { setLanguage } from '../web/src/i18n.ts';
import type { UiSpec } from '../web/src/app-types.ts';

const compile = (name: string, module: ts.ModuleKind) => ts.transpileModule(
  readFileSync(new URL(`../web/src/${name}.ts`, import.meta.url), 'utf8'),
  { compilerOptions: { target: ts.ScriptTarget.ES2023, module } },
).outputText;
const bootstrap = compile('theme-init', ts.ModuleKind.None);
const preferences = compile('i18n', ts.ModuleKind.CommonJS);

function browser(saved: string | null, dark: boolean, blocked = false) {
  const values = new Map<string, string>([['blocks:language', 'zh']]);
  if (saved !== null) values.set('blocks:theme', saved);
  let writes = 0;
  const root = { dataset: {} as Record<string, string>, style: { colorScheme: '' }, lang: 'en' };
  const exports: Record<string, (...args: unknown[]) => unknown> = {};
  const context = {
    exports, Event,
    window: {
      matchMedia: () => ({ matches: dark }), dispatchEvent: () => true,
      localStorage: {
        getItem: (key: string) => { if (blocked) throw new Error('Storage unavailable'); return values.get(key) ?? null; },
        setItem: (key: string, value: string) => { if (blocked) throw new Error('Storage unavailable'); writes++; values.set(key, value); },
      },
    },
    document: { documentElement: root, querySelectorAll: () => [] },
  };
  return { context, root, values, exports, writes: () => writes };
}

test('first paint and module initialization agree on stored, legacy and system appearance', () => {
  const cases = [['light', 'light'], ['dark', 'dark'], ['daylight', 'light'], ['paper', 'light'], ['desk', 'light'], ['night', 'dark']] as const;
  for (const dark of [false, true]) {
    for (const [saved, expected] of [...cases, [null, dark ? 'dark' : 'light'], ['unknown', dark ? 'dark' : 'light']] as const) {
      const b = browser(saved, dark);
      runInNewContext(bootstrap, b.context);
      assert.equal(b.root.dataset.theme, expected, `first paint: ${saved}`);
      assert.equal(b.root.style.colorScheme, expected);
      assert.equal(b.root.lang, 'zh-CN');
      runInNewContext(preferences, b.context);
      assert.equal(b.exports.getTheme!(), expected, `module: ${saved}`);
      assert.equal(b.root.dataset.theme, expected);
      if (saved !== null) assert.equal(b.values.get('blocks:theme'), expected);
      else assert.equal(b.values.has('blocks:theme'), false, 'first visit does not invent an explicit choice');
    }
  }
});

test('blocked storage preserves system appearance and usable in-memory selection', () => {
  const b = browser(null, true, true);
  runInNewContext(bootstrap, b.context);
  assert.equal(b.root.dataset.theme, 'dark');
  runInNewContext(preferences, b.context);
  assert.equal(b.exports.getTheme!(), 'dark');
  b.exports.setTheme!('light');
  assert.equal(b.root.dataset.theme, 'light');
  b.exports.setLanguage!('zh');
  assert.equal(b.exports.t!('Light'), '浅色');
});

test('cross-tab changes and deletion apply without storage write-back; selectable themes are only light/dark', () => {
  const b = browser('dark', true);
  runInNewContext(preferences, b.context);
  const before = b.writes();
  b.exports.syncThemePreference!('paper');
  assert.equal(b.root.dataset.theme, 'light');
  b.exports.syncThemePreference!(null);
  assert.equal(b.root.dataset.theme, 'dark');
  assert.equal(b.writes(), before);
  for (const value of ['daylight', 'night', 'paper', 'desk', null, {}, 'unknown']) assert.equal(b.exports.isTheme!(value), false);
  for (const value of ['light', 'dark']) assert.equal(b.exports.isTheme!(value), true);
});

// Detached rendering needs only element creation; charts are not mounted here.
class Element {
  tag: string;
  className = '';
  textContent = '';
  dataset: Record<string, string> = {};
  children: Element[] = [];
  attributes: Record<string, string> = {};
  constructor(tag: string) { this.tag = tag; }
  append(...children: Element[]) { this.children.push(...children); }
  setAttribute(name: string, value: string) { this.attributes[name] = value; }
}

test('Text and Chart dispatch remains valid in both languages and preserves document content', () => {
  const prior = Object.getOwnPropertyDescriptor(globalThis, 'document');
  Object.defineProperty(globalThis, 'document', { configurable: true, value: {
    documentElement: { dataset: {}, style: {}, lang: 'en' },
    querySelectorAll: () => [], createElement: (tag: string) => new Element(tag),
  } });
  const ui: UiSpec = { root: 'root', elements: {
    root: { type: 'Section', children: ['text', 'chart'], columns: 1 },
    text: { type: 'Text', text: 'Invented document text stays unchanged.', emphasis: 'body' },
    chart: { type: 'Chart', title: 'Invented chart', chart: 'bar', from: 'values', x: 'label', y: ['amount'] },
  } };
  try {
    for (const language of ['en', 'zh'] as const) {
      setLanguage(language);
      const root = renderScreen(ui, new Map([['values', {
        columns: [{ name: 'label', type: 'text' }, { name: 'amount', type: 'number' }],
        rows: [{ label: 'Invented category', amount: 7 }],
      }]])) as unknown as Element;
      const parts = root.children[0]!.children[0]!.children;
      assert.equal(parts[0]!.textContent, 'Invented document text stays unchanged.');
      assert.equal(parts[1]!.dataset.chart, 'bar');
      assert.equal(parts[1]!.children[0]!.textContent, 'Invented chart');
    }
  } finally {
    setLanguage('en');
    if (prior) Object.defineProperty(globalThis, 'document', prior);
    else Reflect.deleteProperty(globalThis, 'document');
  }
});
