# Blocks — application development and user guide

Blocks turns a financial idea written in plain language into a working application. The application
runs on the platform's own data, calculation and screen building blocks. It can be changed without
rebuilding, run on a schedule tied to the trading calendar, and shared as a single file.

This guide is a sequence of actions. Section 1 is the fastest path; sections 2–8 follow an application
from idea to sharing; section 9 is for developers who write applications outside the chat; section 10
lists every interface.

Installation is in [INSTALL.md](INSTALL.md). Everything below assumes Blocks is running at
`http://127.0.0.1:3000`.

---

## 1. The fastest path (5 minutes)

1. Open `http://127.0.0.1:3000` and choose **Start building**.
2. In **Create app**, describe what you need in one or two sentences, for example:
   > Show me which stocks on my watchlist moved more than 3% today, biggest first, with a chart of their closing prices over the last month.
3. Answer the questions the builder asks, if any. "Use sensible defaults" is always an acceptable answer.
4. When the card **Open app** appears, open it. The app is already saved in **My Apps**.
5. Choose **Run application**. Change a setting, for example the watchlist or the threshold, and run again.
6. To share it, choose **Export app**. Send the file. The other person chooses **Import app**.

To use a flagship, open **Flagship applications** and choose **Connect my data**. Configure the
server Tushare token and connect your own business records. Missing data requires a connection;
no invented demonstration inputs are installed.

---

## 2. From idea to request

A good request names three things:

| Name this | Example |
|---|---|
| **What to look at** | stocks on my watchlist; the bonds in my file; my clients |
| **What to calculate** | daily change; 20-day volatility; rank by return; flag when debt rises faster than sales |
| **What to see** | a table of the top 10; a line chart per company; one headline number |

Optional but useful: **when** it should run ("every trading day 30 minutes after the close") and
**which settings** you want to change later ("let me change the threshold").

You may write in English or Chinese. The builder answers in the language you use.

**Your own data.** Use **Attach files** (or drag files into the chat) to add CSV, TSV, Excel or
Markdown tables, up to five files of 20 MB each. You see the first five rows and column statistics.
The AI sees only the file name, the column names and their types, never the rows. Do not paste rows
into the message; the chat refuses pasted tables and asks for a file instead.

**Live market data.** With a Tushare token configured, the builder can choose from 37 catalogued
datasets (daily prices, financial statements, trading calendar and more). Browse them in **Data space**.

---

## 3. Building in the chat ("vibe coding")

What happens after you send a request:

1. **Understand.** The builder reads your request and may ask up to a few questions.
2. **Pick data.** It searches the data catalogue and your uploads, and reads the exact fields.
3. **Write.** It writes one application document using only published building blocks
   (section 9.2). It never writes free program code into your platform.
4. **Check.** The platform validates the document. If something is wrong, the builder receives the
   exact errors and repairs them, up to four attempts.
5. **Save.** A valid application is saved to **My Apps** and the card **Open app** appears.

Progress lines show each stage. A build usually takes one to four minutes, depending on the model
service.

**Change an app by talking.** In the same conversation, ask for a change ("add a column for volume",
"make the threshold 5%"). The same app is updated, keeping its id, its saved settings and its run
history; the previous ten versions are kept. **New conversation** starts a different app.

**If a build fails**, the chat says so plainly. When a draft exists it is kept in **My Apps** marked
**Needs attention**; **Download details** gives the draft and the exact errors. Rephrase the request,
or give the draft to a developer (section 9).

---

## 4. Platform integration: validation and data connection

Every application, however it was made, passes the same checks before it can run:

- **Validation.** The document must match the published format: known operations, known screen
  elements, correct types, no cycles, settings within limits. Errors name the exact place and suggest
  the fix. The same validator is behind the chat, import, the command line and `POST /api/validate`.
- **Data connection.** An application says what data it *needs* (fields and types), never where the
  data is. When the platform cannot match a requirement automatically, the app shows
  **Connect your data**: choose a dataset, match its columns to the required fields, then
  **Save and run**. Your choices are saved with the app, on this computer only.
- **Safety.** Applications cannot read files, open network connections or run arbitrary code. Every
  calculation runs inside a locked-down engine with time and memory limits.

---

## 5. Deployment

There is no separate deployment step. An application is live as soon as it is in **My Apps**, which
happens when:

- the chat builds it (section 3),
- you choose **Connect my data** on a flagship application, or
- you choose **Import app** with an application file (section 8).

Apps are stored in the platform's database and survive restarts. Each browser has its own local
library.

---

## 6. Operation

Open an app from **My Apps**.

| To do this | Use |
|---|---|
| Run it now | **Run application** |
| Change a setting and re-run, without rebuilding | the inputs at the top of the app (numbers, lists, dates, choices), then run |
| See where every number came from | **Inspect**: the data sources and filters used, each calculation step, its formula or operation, its settings and its intermediate result |
| See past runs | **Run history**: time, settings, status, failure reason, app version and data date of each run |
| Compare two runs | **Compare two runs**: choose **Run A** and **Run B**; changed settings and changed results are shown side by side |
| Run it automatically | **Scheduled tasks**: enable a trigger the app declares |
| Fix missing data | **Connect your data** |

**Triggers** an application can declare:

| Trigger | Meaning |
|---|---|
| manual | runs when you choose **Run application** (always available) |
| schedule | a clock, as a cron expression with a time zone, e.g. every weekday at 08:00 |
| market | on real trading days only, at a set number of minutes before or after the open or close, using the platform's trading calendar; holidays are skipped |
| alert | evaluates a condition on a schedule (declared in the format; see limitations) |

Scheduled tasks run while the server is running. After a restart, Blocks recovers: an interrupted run
is recorded as interrupted, and at most one missed occurrence from the last 24 hours runs once. A task
whose data is missing pauses with the reason shown, instead of failing silently.

**Settings and appearance.** Use the **Theme** and **Language** controls in the header (English or
中文). App names and results keep their own language.

---

## 7. The flagship applications

Open **Flagship applications** in the side bar.

| Application | What it does |
|---|---|
| **AlphaVista** | Watchlist research, company comparisons and historical portfolio risk |
| **RiskRift** | Explainable financial checks, disclosure evidence and recorded review |
| **WealthWeave** | Client constraints, product suitability, pipeline and follow-up work |

- **Connect my data** installs a portable definition with Tushare hints and asks for your authorised records.
- AlphaVista uses Tushare prices, adjustment factors, company metadata, valuations and annual statements, plus your holdings and disclosure evidence.
- RiskRift aligns Tushare income, cash-flow and balance-sheet periods; disclosure excerpts and regulatory snapshots must come from you.
- WealthWeave uses your clients, approved products and activities. Its Tushare fund NAV panel is a separate public reference and does not establish product approval or suitability.
- All required inputs must be connected before running. Tushare errors and missing data never trigger invented fallback values. Old saved demo copies are retired; install a new copy from this page.

They are ordinary Blocks applications: they open, run, export and import like any other app, and
their documents are in [`examples/`](examples/).

---

## 8. Sharing with other users

1. Open the app and choose **Export app**. You get one `.fin.json` file.
   It contains the application only: **no data, no uploaded files, no column matches, no keys.**
2. Send the file by any means.
3. The other person opens **My Apps → Import app**, then chooses the file or pastes its content
   (up to 1 MB). Blocks validates it before saving; an invalid file is refused with the reasons.
4. On first run, the other person connects their own data if needed (**Connect your data**) and runs it.

The same file can be checked from the command line (section 9.3) and is what external developers
produce.

---

## 9. Developing applications outside the chat

Applications are JSON documents. You can write one by hand, with any AI coding assistant, or with
your own tools, and the platform treats it exactly like a chat-built app.

### 9.1 The document

One JSON object with six sections:

| Section | Holds |
|---|---|
| `meta` | name, one-sentence description, `spec_version` (exactly `"1.0"`), icon |
| `params` | settings a person can change without rebuilding: watchlists, thresholds, dates |
| `data` | data requirements: named fields with types and filters that refer to settings. **Never data.** |
| `compute` | calculation steps, each producing a named result used by later steps or the screen |
| `triggers` | manual, schedule, market, alert (section 6) |
| `ui` | the screen: a tree of elements under `root` |

A complete working example: [`examples/ex-01-daily-movers.fin.json`](examples/ex-01-daily-movers.fin.json).
The three flagship applications in [`examples/`](examples/) are larger examples.

### 9.2 The building blocks

**Calculation steps** (`compute`), five kinds:

| Kind | Use for |
|---|---|
| `operation` | one of 18 published operations (below) |
| `sql` | a single read-only SELECT over earlier results, checked by the SQL gate |
| `expression` | a single value from a formula, e.g. a ratio of two earlier single values |
| `code` | a small calculation in a sandbox with no file, network or clock access |
| `ai` | the platform's model writes a short interpretation of rows; numbers are never produced by AI |

**Operations:** `filter`, `derive`, `join`, `aggregate`, `sort_limit`, `window`, `lag_change`, `rank`,
`zscore`, `resample`, `pivot`, `describe`, `correlate`, `regress`, `adjust_price`, `irr`, `factor`, `ai`.

**Screen elements:** `Section`, `Text`, `Metric`, `Table`, `Chart` (line, bar and more; one line per
company with `series`), `Callout`, `List`, `NumberInput`, `TextInput`, `SelectInput`, `DateRangeInput`,
`RunButton`.

Every property of every block, with its type, limits and an example, is in the specification
(section 9.4). There is nothing outside it.

### 9.3 Write, check, import

1. **Read** the instructions in [`skill/SKILL.md`](skill/SKILL.md) and the reference file for each block
   family you need in [`skill/references/`](skill/references/) (data, operations by family, screen
   elements by family, errors). These files are written to be given directly to an AI assistant.
2. **Write** the document, starting from an example.
3. **Check** it:
   ```sh
   npm run validate -- my-app.fin.json          # human-readable report
   npm run validate -- my-app.fin.json --json   # full report as JSON
   ```
   Exit code 0 means valid, 1 invalid. Or send it to the running server:
   ```sh
   curl -s -X POST http://127.0.0.1:3000/api/validate -H 'content-type: application/json' --data @my-app.fin.json
   ```
   Every error has a code, the exact path in the document, a message and, where possible, a
   suggested fix. All 42 error codes are listed in [`spec/errors.json`](spec/errors.json).
4. **Fix** exactly what each error names and check again.
5. **Import** it: **My Apps → Import app**, or `POST /api/apps/import` (section 10).

**Using an AI coding assistant.** Give it the `skill/` folder and your request. The folder is a
self-contained instruction set: what to produce, the rules, the reference files and the validator
loop above.

### 9.4 Specifications

| File | Content |
|---|---|
| [`spec/SPEC.md`](spec/SPEC.md) | The full human-readable specification |
| [`spec/application.schema.json`](spec/application.schema.json) | JSON Schema of the whole document |
| [`spec/operations.json`](spec/operations.json) | Every operation: parameters, types, output columns |
| [`spec/components.json`](spec/components.json) | Every screen element and its properties |
| [`spec/blocks.json`](spec/blocks.json) | Step kinds and triggers |
| [`spec/errors.json`](spec/errors.json) | Every validation error code |
| [`skill/`](skill/) | The same, arranged as instructions for an AI assistant |
| [`docs/DATA-SHAPES.md`](docs/DATA-SHAPES.md) | Data types, datasets and units |
| [`docs/CONTRACTS.md`](docs/CONTRACTS.md) | Internal module and HTTP contracts |

The specification is generated from the platform's own schema (`npm run spec:build`), so it cannot
drift from what the validator accepts.

---

## 10. Interfaces (HTTP)

All endpoints are on the same server. Requests that change something must come from the same origin
(the browser page) or carry no `Origin` header (command-line tools). Errors are
`{ "error": { "code", "message" } }`.

The `/api/apps`, `/api/drafts` and `/api/examples` endpoints belong to a library. A `GET /api/apps`
sets the library cookie `blocks_profile`; send that cookie back, and for any request that changes
something also send the header `X-Blocks-Request: 1`. For example:

```sh
curl -s -c jar -b jar http://127.0.0.1:3000/api/apps > /dev/null
curl -s -c jar -b jar -H 'X-Blocks-Request: 1' -H 'content-type: application/json' \
  --data @my-app.fin.json http://127.0.0.1:3000/api/apps/import
```

| Method and path | Purpose |
|---|---|
| `GET /health` | server status |
| `GET /api/spec` | the specification (Markdown) |
| `GET /api/spec/{schema,operations,components,errors,blocks}` | one specification file (JSON) |
| `GET /api/spec/bundle` | every specification file in one response |
| `GET /api/skill`, `GET /api/skill/files/{path}` | the AI-assistant instruction files |
| `POST /api/validate` | validate a document; returns the report |
| `POST /api/chat` | build or change an app from a message; answers as server-sent events (progress, question, built, failed) |
| `POST /api/uploads?filename=…&name=…` | upload a CSV/TSV/Excel/Markdown file as a dataset; returns columns and a five-row preview |
| `GET /api/uploads` | your uploaded datasets (metadata only) |
| `GET /api/data/datasets`, `GET /api/data/datasets/:id` | the data catalogue |
| `GET /api/apps`, `GET /api/apps/:id` | your apps |
| `POST /api/apps/import` | import an application document |
| `GET /api/apps/:id/export` | export an application file (no data, no keys) |
| `POST /api/apps/:id/run` | run an app, optionally with changed settings |
| `GET /api/apps/:id/runs` | run history |
| `GET/POST /api/apps/:id/connection` | read or change the app's data connection |
| `GET /api/apps/:id/schedules` | scheduled tasks |
| `GET /api/drafts`, `GET /api/drafts/:id` | failed-build drafts and their details |
| `GET /api/examples`, `POST /api/examples/:id/import` | the flagship applications |

Full request and response shapes: [`docs/CONTRACTS.md`](docs/CONTRACTS.md).

---

## 11. Limits worth knowing

- **Build time** depends on the model service: usually one to four minutes, stopped after ten.
- **Alerts** are part of the document format, but the automatic scheduler runs clock and market
  triggers only; an alert condition is shown in results, not delivered as a notification.
- **Profiles** are local libraries per browser, not user accounts.
- **Live data** requires a Tushare token and covers the catalogued datasets; the AI never sees data
  rows, only names and types.
- **The AI never calculates numbers.** It chooses building blocks; the platform computes every result.
