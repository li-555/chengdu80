---
name: building-blocks-applications
description: Builds financial applications for the Blocks platform. Use when someone asks for a financial tool, screen, report, alert, monitor or dashboard that should run on Blocks, for example "find today's biggest movers", "watch my bonds for redemption risk" or "summarise overnight announcements for my watchlist". Produces one JSON document that Blocks validates and runs.
---

# Building Blocks applications

## 1. What you produce

A Blocks application is **one JSON document**, not a program. It has six sections:

| Section | Holds |
|---|---|
| `meta` | name, a plain-language description, `spec_version`, an icon |
| `params` | the settings a person can change without rebuilding (a watchlist, a threshold) |
| `data` | what data the application needs: fields and filters only, **never data itself** |
| `compute` | calculation steps, each producing a named result |
| `triggers` | when it runs: by hand, on a schedule, around the market open or close, or as an alert |
| `ui` | what the screen shows, built from a fixed set of screen elements |

The platform reads the document and carries it out. Nothing is compiled or deployed. Set `meta.spec_version` to exactly `"{{SPEC_VERSION}}"`.

## 2. How to work

1. Decide what data the request needs. Read `references/data.md` for the available datasets and their exact field names.
2. Pick the calculation steps. Read the operation family files listed in section 9, **only the families you need**.
3. Pick the screen elements. Read the screen family files you need.
4. Write the whole document.
5. Check it with the validator (section 7). Fix exactly what each error names, and check again. Repeat until it passes.

Read a reference file instead of guessing. A guessed parameter name costs a whole check-and-fix round.

## 3. Rules

These rules are checked by the validator. Breaking one makes the document invalid.

- **Use only names that exist.** Every operation, screen element and property is listed in the reference files. There is nothing else. Do not invent one.
- **Data requirements describe data; they never contain it.** A requirement lists the fields it needs with their types. It does not name a dataset: `datasetHint` is only a suggestion, and the person connects the real data when the application is imported.
- **Name fields as the dataset names them** (copy them from `references/data.md`) and give each a `semantic` tag (for example `security_code`, `trade_date`). Matching names connect automatically. A field with a name of your own (as in the example in section 6) still works, but the person must match it by hand when connecting data, so prefer the dataset's names.
- **Filters name settings, never values.** A list of companies is a `params` entry with `"list": true`, and the filter points at it with `"param"`. A literal value in a filter cannot be written: the schema has no place for it.
- **Every step reads results that exist.** A step's `input` is a data requirement `key` or an earlier step `id`. There are no cycles.
- **Every screen element reads a step that exists**, through `from`. Every control names a declared setting through `param`.
- **Prefer, in this order:** a named operation → a formula (`derive`, `filter`) → a SQL step → a custom-code step. A named operation is checked, explained to the person and shown step by step. A SQL or code step that repeats a named operation produces a warning.
- **Keep it small.** Three to eight steps and four to ten screen elements make a good application. A bigger one is not a better one.
- **Include a manual trigger**, so the person can always run it by hand.
- **When the data does not exist, say so.** Do not invent a dataset or a field to make the request fit.

## 4. Writing for the person

The person using the application is not a programmer. `meta.description`, setting labels, element titles and empty-table hints are read by them.

- Short sentences. One idea per sentence. Ordinary words.
- Do not use these words in anything the person reads: {{BANNED_WORDS}}.
  Say "spreadsheet" not "dataset", "column" not "field", "setting" not "parameter", "check" not "validate".
- Explain a finance term the first time it appears, in the same sentence.
- `meta.description` is two or three sentences: what the application does, where its numbers come from, and when it runs.

## 5. The document skeleton

{{SKELETON}}

## 6. A complete example

{{EXAMPLE}}

## 7. Checking your work

The validator is the authority. Run it on your document:

```
npm run validate -- app.json
```

or send the document to `POST /api/validate` on a running Blocks server. It answers with a report: `valid`, and a list of `errors` and `warnings`. Each error has a `pointer` (where in the document), a `code`, a `message`, and a `hint` saying how to fix it. **Follow the hint.**

The validator checks in stages: first the shape of the document, then the names it refers to, then formulas and limits. It stops at the first stage that fails. So fixing every reported error can reveal new ones from the next stage. Expect more than one round; that is normal.

`application.schema.json` (JSON Schema, draft 2020-12) checks structure and types only. The validator also checks references, formulas, SQL and limits. A document that passes the schema can still fail the validator.

### A repair, start to finish

{{REPAIR_EXAMPLE}}

## 8. Importing and running

Save the document as `app.json`. In Blocks, open **My Apps → Import an application** and choose the file. Blocks checks it, then asks the person to connect any data it needs (a dataset from the catalogue, or a spreadsheet they upload). A requirement waiting to be connected is normal, not an error. Then press **Run**.

## 9. Where to read more

Read only the file that answers your question. Each file starts with its own contents list.

{{ROUTING_TABLE}}

## 10. The five things that most often go wrong

1. **A field name that is not in the dataset.** Copy names from `references/data.md`.
2. **A parameter name guessed instead of read.** Open the family file for that operation.
3. **A screen element reading a step that does not exist,** often after a step was renamed. Check every `from`.
4. **A control whose setting is never used.** The validator warns: the control would do nothing.
5. **A literal value where a setting is expected.** Put the value in `params` and point at it.
