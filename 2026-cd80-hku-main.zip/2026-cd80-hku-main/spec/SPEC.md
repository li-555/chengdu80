# Blocks application specification

## Contents

- [Document](#document)
- [Sections](#sections)
- [Step kinds](#step-kinds)
- [Trigger kinds](#trigger-kinds)
- [Shaping operations](#shaping-operations)
- [Time series operations](#time-series-operations)
- [Statistics operations](#statistics-operations)
- [Finance operations](#finance-operations)
- [Display components](#display-components)
- [Chart components](#chart-components)
- [Control components](#control-components)
- [Layout components](#layout-components)
- [Errors](#errors)

## Document

Specification version: 1.0.

An application has six sections: meta, params, data, compute, triggers and ui. The optional $schema field identifies the export format. Unknown object keys are refused.

application.schema.json publishes the document structure as JSON Schema draft 2020-12. The parameter and property schemas below describe inputs, including fields with defaults. Cross-field refinements, expression and SQL rules, reference checks and runtime limits are also enforced by the platform validator; JSON Schema alone does not express every rule.

The public endpoints are /api/spec for this document, /api/spec/schema, /api/spec/blocks, /api/spec/operations, /api/spec/components and /api/spec/errors. /api/spec/bundle returns all six files together, keyed by filename.

## Sections

### compute

Declare calculation steps whose ids name results available to later steps and the screen.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| [].choice 1.choice 1.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 1.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 1.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 1.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 1.op | "filter" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 1.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 1.params.where | string; minLength: 1; maxLength: 2000 | yes | Boolean expression that keeps only input rows for which it is true. |
| [].choice 1.choice 1.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 2.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 2.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 2.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 2.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 2.op | "derive" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 2.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 2.params.columns | object | yes | Map from each new output column name to the expression calculated for every input row. |
| [].choice 1.choice 2.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 3.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 3.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 3.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 3.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 3.op | "join" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 3.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 3.params.asof_on | [string, string]; minItems: 2; maxItems: 2 | no | Ordered matching columns as [column in the input table, column in the right table], required for asof and adding no ordered match when omitted for other join kinds. |
| [].choice 1.choice 3.params.direction | "backward" / "forward" / "nearest" | no | As-of matching direction, defaulting to backward for the latest right row at or before the input row, with forward choosing the earliest at or after it and nearest currently unsupported. |
| [].choice 1.choice 3.params.how | "inner" / "left" / "asof" | yes | Join kind, retaining matching rows for inner or all input rows for left and asof. |
| [].choice 1.choice 3.params.on | array of [string, string]; minItems: 1; maxItems: 8 | yes | Pairs of equality keys in the order [column in the input table, column in the right table]. |
| [].choice 1.choice 3.params.right | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the second table, while the step input names the first table. |
| [].choice 1.choice 3.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 4.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 4.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 4.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 4.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 4.op | "aggregate" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 4.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 4.params.by | array of string; maxItems: 8 | yes | Grouping columns, with an empty array producing one summary across the whole input. |
| [].choice 1.choice 4.params.metrics | array of object; minItems: 1; maxItems: 32 | yes | Summary definitions producing one output column each per group. |
| [].choice 1.choice 4.params.metrics[].as | string; minLength: 1; maxLength: 128 | yes | Name of the output column holding this summary. |
| [].choice 1.choice 4.params.metrics[].fn | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function to apply, with stddev and var using sample statistics. |
| [].choice 1.choice 4.params.metrics[].of | string; minLength: 1; maxLength: 128 | no | Input column to summarise, required except for count, which counts all rows when omitted. |
| [].choice 1.choice 4.params.metrics[].p | number; minimum: 0; maximum: 1 | no | Quantile fraction from 0 to 1, required for quantile and unused by other summary functions. |
| [].choice 1.choice 4.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 5.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 5.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 5.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 5.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 5.op | "sort_limit" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 5.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 5.params.by | array of object; minItems: 1; maxItems: 8 | yes | Sort columns and directions in priority order. |
| [].choice 1.choice 5.params.by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| [].choice 1.choice 5.params.by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| [].choice 1.choice 5.params.limit | integer or object | no | Maximum number of output rows, supplied as an integer or parameter reference, with no row limit when omitted. |
| [].choice 1.choice 5.params.limit.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| [].choice 1.choice 5.params.offset | integer or object | no | Number of sorted rows to skip, supplied as an integer or parameter reference, defaulting to zero when omitted. |
| [].choice 1.choice 5.params.offset.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| [].choice 1.choice 5.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 6.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 6.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 6.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 6.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 6.op | "window" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 6.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 6.params.as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the window calculation. |
| [].choice 1.choice 6.params.fn | "sum" / "mean" / "min" / "max" / "count" / "stddev" / "first" / "last" | yes | Calculation applied within each frame, with stddev using sample standard deviation and count counting non-null values. |
| [].choice 1.choice 6.params.frame | object | yes | Inclusive frame around the current row using row counts or ordered-value distances. |
| [].choice 1.choice 6.params.frame.following | integer or object | yes | Distance after the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps. |
| [].choice 1.choice 6.params.frame.following.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| [].choice 1.choice 6.params.frame.kind | "rows" / "range" | yes | Frame measure, using row counts for rows or ordered-value distances for range, measured in days for date or timestamp order columns. |
| [].choice 1.choice 6.params.frame.preceding | integer or object | yes | Distance before the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps. |
| [].choice 1.choice 6.params.frame.preceding.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| [].choice 1.choice 6.params.of | string; minLength: 1; maxLength: 128 | yes | Input column whose values are calculated within each frame. |
| [].choice 1.choice 6.params.order_by | array of object; minItems: 1; maxItems: 8 | yes | Columns and directions defining row order within each partition. |
| [].choice 1.choice 6.params.order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| [].choice 1.choice 6.params.order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| [].choice 1.choice 6.params.partition_by | array of string; maxItems: 4 | no | Columns separating independent row groups, with all rows in one group when omitted. |
| [].choice 1.choice 6.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 7.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 7.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 7.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 7.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 7.op | "lag_change" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 7.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 7.params.as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the change. |
| [].choice 1.choice 7.params.mode | "diff" / "pct" / "log" | yes | Change calculation, using current minus earlier for diff, current divided by earlier minus one for pct as a fraction, or the natural logarithm of their positive ratio for log. |
| [].choice 1.choice 7.params.of | string; minLength: 1; maxLength: 128 | yes | Input column compared with its earlier value. |
| [].choice 1.choice 7.params.order_by | array of object; minItems: 1; maxItems: 8 | yes | Columns and directions determining which rows are earlier. |
| [].choice 1.choice 7.params.order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| [].choice 1.choice 7.params.order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| [].choice 1.choice 7.params.partition_by | array of string; maxItems: 4 | no | Columns separating independent histories, with all rows in one history when omitted. |
| [].choice 1.choice 7.params.periods | integer or object | yes | Number of ordered rows to look back within the partition, supplied as an integer or parameter reference. |
| [].choice 1.choice 7.params.periods.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| [].choice 1.choice 7.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 8.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 8.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 8.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 8.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 8.op | "rank" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 8.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 8.params.as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the rank. |
| [].choice 1.choice 8.params.by | string; minLength: 1; maxLength: 128 | yes | Input column whose values determine the rank. |
| [].choice 1.choice 8.params.direction | "asc" / "desc" | yes | Ascending or descending order used to assign ranks. |
| [].choice 1.choice 8.params.method | "rank" / "dense" / "row_number" / "percentile" | yes | Ranking rule, using gaps for rank, no gaps for dense, distinct row numbers for row_number, or a fraction from 0 to 1 for percentile. |
| [].choice 1.choice 8.params.within | array of string; maxItems: 4 | no | Columns separating independent ranking groups, with all rows ranked together when omitted. |
| [].choice 1.choice 8.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 9.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 9.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 9.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 9.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 9.op | "zscore" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 9.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 9.params.as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the dimensionless standard score. |
| [].choice 1.choice 9.params.of | string; minLength: 1; maxLength: 128 | yes | Input column standardised as its value minus the mean divided by sample standard deviation. |
| [].choice 1.choice 9.params.order_by | array of object; minItems: 1; maxItems: 8 | no | Columns and directions defining rolling row order, required when window is set and ignored otherwise. |
| [].choice 1.choice 9.params.order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| [].choice 1.choice 9.params.order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| [].choice 1.choice 9.params.window | integer or object | no | Rolling frame size in rows including the current row, supplied as an integer or parameter reference, requiring that many non-null values and using the entire group when omitted. |
| [].choice 1.choice 9.params.window.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| [].choice 1.choice 9.params.within | array of string; maxItems: 4 | no | Columns separating independent standardisation groups, with all rows in one group when omitted. |
| [].choice 1.choice 9.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 10.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 10.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 10.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 10.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 10.op | "resample" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 10.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 10.params.by | array of string; maxItems: 4 | no | Additional grouping columns kept separate within each period, with no additional grouping when omitted. |
| [].choice 1.choice 10.params.date_col | string; minLength: 1; maxLength: 128 | yes | Input date column whose name is preserved in the output and whose value becomes the first day of each period. |
| [].choice 1.choice 10.params.metrics | array of object; minItems: 1; maxItems: 32 | yes | Summary definitions calculated for each period and additional group. |
| [].choice 1.choice 10.params.metrics[].as | string; minLength: 1; maxLength: 128 | yes | Name of the output column holding this summary. |
| [].choice 1.choice 10.params.metrics[].fn | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function to apply, with stddev and var using sample statistics. |
| [].choice 1.choice 10.params.metrics[].of | string; minLength: 1; maxLength: 128 | no | Input column to summarise, required except for count, which counts all rows when omitted. |
| [].choice 1.choice 10.params.metrics[].p | number; minimum: 0; maximum: 1 | no | Quantile fraction from 0 to 1, required for quantile and unused by other summary functions. |
| [].choice 1.choice 10.params.to | "week" / "month" / "quarter" / "year" | yes | Calendar period to aggregate into, with weeks starting on Monday. |
| [].choice 1.choice 10.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 11.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 11.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 11.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 11.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 11.op | "pivot" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 11.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 11.params.agg | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function for each pivot cell, with quantile currently unsupported. |
| [].choice 1.choice 11.params.index | array of string; minItems: 1; maxItems: 4 | yes | Columns identifying each output row and grouping the pivoted values. |
| [].choice 1.choice 11.params.on | string; minLength: 1; maxLength: 128 | yes | Input category column whose distinct values become output columns. |
| [].choice 1.choice 11.params.values | string; minLength: 1; maxLength: 128 | yes | Input column whose values are summarised in each pivot cell. |
| [].choice 1.choice 11.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 12.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 12.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 12.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 12.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 12.op | "describe" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 12.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 12.params.columns | array of string; maxItems: 64 | no | Numeric input columns to summarise, defaulting to all numeric input columns when omitted. |
| [].choice 1.choice 12.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 13.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 13.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 13.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 13.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 13.op | "correlate" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 13.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 13.params.columns | array of string; minItems: 2; maxItems: 32 | yes | Input columns for which each distinct pair receives a correlation result. |
| [].choice 1.choice 13.params.method | "pearson" / "spearman" | yes | Correlation method, using raw values for pearson or average ranks for spearman. |
| [].choice 1.choice 13.params.min_periods | integer; minimum: 2; maximum: 100000 | no | Minimum count of rows with both values present before returning a correlation, with no additional count threshold when omitted. |
| [].choice 1.choice 13.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 14.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 14.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 14.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 14.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 14.op | "regress" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 14.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 14.params.by | array of string; maxItems: 4 | no | Columns separating independent regression groups, with one fit across the input when omitted. |
| [].choice 1.choice 14.params.x | array of string; minItems: 1; maxItems: 16 | yes | Predictor input columns for the regression, allowing 1 to 16 names in the schema. |
| [].choice 1.choice 14.params.y | string; minLength: 1; maxLength: 128 | yes | Dependent input column to fit. |
| [].choice 1.choice 14.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 15.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 15.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 15.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 15.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 15.op | "adjust_price" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 15.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 15.params.base_date | string; maxLength: 10; pattern: "^\\d{4}-\\d{2}-\\d{2}$" | no | Forward adjustment cutoff in YYYY-MM-DD form, using the latest factor on or before this date or the latest available factor date per security when omitted and disallowed for backward adjustment. |
| [].choice 1.choice 15.params.date | [string, string]; minItems: 2; maxItems: 2 | yes | Trading date columns in the order [column in the input table, column in the factor table], matching the latest factor on or before each input date. |
| [].choice 1.choice 15.params.factor_col | string; minLength: 1; maxLength: 128 | yes | Column in the factor table containing the cumulative multiplicative adjustment factor. |
| [].choice 1.choice 15.params.factor_table | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the cumulative adjustment factor table, distinct from the input price table. |
| [].choice 1.choice 15.params.key | [string, string]; minItems: 2; maxItems: 2 | yes | Security key columns in the order [column in the input table, column in the factor table]. |
| [].choice 1.choice 15.params.mode | "forward" / "backward" | yes | Adjustment direction, with backward multiplying prices by their dated factor and forward dividing that product by the base factor, using the latest factor date for each security when base_date is omitted. |
| [].choice 1.choice 15.params.price_cols | array of string; minItems: 1; maxItems: 8 | yes | Input price columns replaced by adjusted values under the same names and in the same price units. |
| [].choice 1.choice 15.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 16.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 16.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 16.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 16.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 16.op | "irr" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 16.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 16.params.amount_col | string; minLength: 1; maxLength: 128 | yes | Cash flow amount column in a consistent monetary unit, with payments out negative and receipts positive. |
| [].choice 1.choice 16.params.date_col | string; minLength: 1; maxLength: 128 | yes | Cash flow date column used to count elapsed days over a 365-day year. |
| [].choice 1.choice 16.params.guess | number | no | Initial annual rate as a fraction for the iterative solver, defaulting to 0.1 when omitted. |
| [].choice 1.choice 16.params.max_iter | integer; minimum: 1; maximum: 100; default: 100 | no | Maximum number of Newton iterations before the fallback solver, defaulting to 100 when omitted. |
| [].choice 1.choice 16.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 1.choice 17.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 1.choice 17.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| [].choice 1.choice 17.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 1.choice 17.kind | "operation" | yes | Step discriminator identifying a named operation. |
| [].choice 1.choice 17.op | "factor" | yes | Named operation selected by this schema branch. |
| [].choice 1.choice 17.params | object | yes | Parameters for the selected operation. |
| [].choice 1.choice 17.params.as_of | string; maxLength: 10; pattern: "^\\d{4}-\\d{2}-\\d{2}$" | no | Latest eligible trading date in YYYY-MM-DD form, returning each security latest row on or before it or its latest available row when omitted. |
| [].choice 1.choice 17.params.factor | string; minLength: 1; maxLength: 60 | yes | Name of a supported market measure to calculate from the input daily rows. |
| [].choice 1.choice 17.params.universe | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | no | Data requirement key or step id whose ts_code column restricts the securities, with no universe restriction when omitted. |
| [].choice 1.choice 17.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 2.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 2.input | array of string; maxItems: 8 | no | Declared relation names available to the SQL query, with no relations declared when omitted. |
| [].choice 2.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 2.kind | "sql" | yes | Step discriminator identifying a SQL calculation. |
| [].choice 2.sql | string; minLength: 1; maxLength: 20000 | yes | Read-only SQL query checked by the SQL validator against declared inputs. |
| [].choice 2.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 3.expr | string; minLength: 1; maxLength: 2000 | yes | Formula intended to produce a single value addressable by this step id. |
| [].choice 3.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 3.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | no | Optional data requirement key or step id declared as input, with no input declared when omitted. |
| [].choice 3.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 3.kind | "expression" | yes | Step discriminator identifying a scalar expression. |
| [].choice 3.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 4.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 4.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the input rows. |
| [].choice 4.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 4.kind | "ai" | yes | Step discriminator identifying a row interpretation step. |
| [].choice 4.params | object | yes | Processing limits, instructions, output shape, and error policy for this step. |
| [].choice 4.params.instructions | string; minLength: 1; maxLength: 4000 | yes | Instructions for interpreting the input rows, containing 1 to 4000 characters. |
| [].choice 4.params.max_input_chars | integer; minimum: 100; maximum: 60000; default: 20000 | no | Maximum input text length in characters, defaulting to 20000 when omitted. |
| [].choice 4.params.max_rows | integer or object; default: 50 | no | Maximum input row count as an integer or parameter reference, defaulting to 50 when omitted. |
| [].choice 4.params.max_rows.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| [].choice 4.params.mode | "whole" / "per_row" | yes | Requested processing scope, either the whole input or each row separately. |
| [].choice 4.params.on_error | "null" / "fail"; default: "null" | no | Declared error policy, either null or fail, defaulting to null when omitted. |
| [].choice 4.params.output | object or object or object | yes | Declared result shape, either text, an enumerated string, or an object of typed fields. |
| [].choice 4.params.output.choice 1.kind | "text" | yes | Result shape discriminator selecting text, enum, or object. |
| [].choice 4.params.output.choice 2.kind | "enum" | yes | Result shape discriminator selecting text, enum, or object. |
| [].choice 4.params.output.choice 2.values | array of string; minItems: 2; maxItems: 32 | yes | Allowed non-empty string result values for an enum output, containing 2 to 32 entries. |
| [].choice 4.params.output.choice 3.fields | object | yes | Map of output column names to string, number, or boolean types, containing 1 to 32 fields. |
| [].choice 4.params.output.choice 3.kind | "object" | yes | Result shape discriminator selecting text, enum, or object. |
| [].choice 4.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| [].choice 5.body | string; minLength: 1; maxLength: 40000 | yes | Sandboxed JavaScript body containing 1 to 40000 characters. |
| [].choice 5.carry_state | boolean; default: false | no | Whether state from the previous successful run is available, capped at 64 KB and defaulting to false when omitted. |
| [].choice 5.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| [].choice 5.input | array of string; minItems: 1; maxItems: 3 | yes | One to three declared input relation names. |
| [].choice 5.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| [].choice 5.kind | "code" | yes | Step discriminator identifying a sandboxed code calculation. |
| [].choice 5.output | object | yes | Declared columns and types for the result table. |
| [].choice 5.output.columns | array of object; minItems: 1; maxItems: 64 | yes | One to 64 column declarations for the result table. |
| [].choice 5.output.columns[].name | string; minLength: 1; maxLength: 128 | yes | Output table column name. |
| [].choice 5.output.columns[].type | "text" / "number" / "date" / "boolean" | yes | Output table column data type. |
| [].choice 5.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
[
  {
    "id": "harbor_positive",
    "input": "harbor_prices",
    "kind": "operation",
    "op": "filter",
    "params": {
      "where": "harbor_price > 0"
    }
  }
]
```

### data

Declare required fields and optional windows or parameter filters without embedding data rows.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| [].datasetHint | string; minLength: 1; maxLength: 100 | no | Optional dataset suggestion for the person or resolver, with no suggestion when omitted and no binding established by this field. |
| [].fields | array of object; minItems: 1; maxItems: 100 | yes | Columns requested from the bound dataset with their types and mapping requirements. |
| [].fields[].name | string; minLength: 1; maxLength: 128 | yes | Column name exposed to calculations after mapping the bound dataset. |
| [].fields[].required | boolean | yes | Whether this column is required for the data requirement. |
| [].fields[].semantic | string; minLength: 1; maxLength: 40 | no | Optional shared meaning such as security_code or trade_date used to help column mapping, with no semantic hint when omitted. |
| [].fields[].type | "text" / "number" / "date" / "boolean" | yes | Required data type for the mapped column. |
| [].filters | array of object; maxItems: 20 | no | Parameter-based filter requests, with no filters requested when omitted. |
| [].filters[].field | string; minLength: 1; maxLength: 128 | yes | Requirement column on which the filter operates. |
| [].filters[].op | "eq" / "neq" / "gt" / "gte" / "lt" / "lte" / "in" / "not_in" / "contains" | yes | Comparison applied between the field and the named parameter value. |
| [].filters[].param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the filter value rather than a literal in the document. |
| [].grain | "daily" / "weekly" / "monthly" / "quarterly" / "yearly" / "snapshot" | no | Optional declared time granularity of the requested rows, with none specified when omitted. |
| [].key | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique relation name used to reference this data requirement from calculations. |
| [].purpose | string; minLength: 1; maxLength: 200 | no | Optional explanation of why this data is needed, with no explanation when omitted. |
| [].window | object | no | Optional trading-calendar lookback request, with no lookback request when omitted. |
| [].window.field | string; minLength: 1; maxLength: 128 | yes | Requirement date column to which the requested lookback applies. |
| [].window.lookbackDays | integer; maximum: 3650; exclusiveMinimum: 0 | yes | Requested number of trading-calendar days rather than wall-clock days, from 1 to 3650, with 1 requesting a single trading day and no date-boundary resolution enforced by the schema. |

Example:

```json
[
  {
    "fields": [
      {
        "name": "harbor_price",
        "required": true,
        "type": "number"
      }
    ],
    "grain": "daily",
    "key": "harbor_prices"
  }
]
```

### meta

Name and describe the application and declare its specification version.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| description | string; minLength: 1; maxLength: 400 | yes | Plain-language application description shown on the card and in the header. |
| icon | string; minLength: 1; maxLength: 40 | no | Optional icon name checked against the supported icon list, with no icon specified when omitted. |
| name | string; minLength: 1; maxLength: 80 | yes | Application name shown to the person. |
| provenance | object | no | Optional audit metadata, with no provenance recorded when omitted. |
| provenance.created_by | "platform" / "external" | yes | Audit origin category, either platform or external, which does not change document installation behaviour. |
| provenance.imported_at | string; minLength: 1; maxLength: 40 | no | Optional audit timestamp text of 1 to 40 characters, with no timestamp recorded when omitted. |
| provenance.model | string; minLength: 1; maxLength: 120 | no | Optional audit label of 1 to 120 characters, absent when omitted. |
| provenance.tool | string; minLength: 1; maxLength: 120 | no | Optional audit label of 1 to 120 characters, absent when omitted. |
| spec_version | string; minLength: 1; maxLength: 16 | yes | Specification version string, required to match the supported version by the validator. |
| theme | "daylight" / "night" / "paper" / "desk" | no | Optional theme choice, with no application theme specified when omitted. |
| updated_at | string; minLength: 1; maxLength: 40 | no | Optional update timestamp text of 1 to 40 characters, with no timestamp recorded when omitted. |

Example:

```json
{
  "description": "Review invented daily price changes.",
  "name": "Harbor Prices",
  "spec_version": "1.0"
}
```

### params

Declare settings that controls and calculations can read when the application runs.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| [].default | string or number or boolean or array of string | no | Initial value used when no run value is supplied, leaving the value undefined when omitted. |
| [].key | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique parameter name used by controls, filters, and parameter references. |
| [].label | string; minLength: 1; maxLength: 80 | yes | Display label for this setting. |
| [].list | boolean | no | Whether a text setting holds a list of strings, treating it as a scalar when omitted. |
| [].max | number | no | Optional maximum numeric value in the parameter units, with no declared upper bound when omitted. |
| [].min | number | no | Optional minimum numeric value in the parameter units, with no declared lower bound when omitted. |
| [].options | array of object; minItems: 1; maxItems: 100 | no | Allowed text choices shown as a dropdown, with no fixed choices when omitted and disallowed for list settings. |
| [].options[].label | string; minLength: 1; maxLength: 200 | yes | Display label for this choice. |
| [].options[].value | string; minLength: 1; maxLength: 200 | yes | Stored non-empty text value for this choice, unique within the setting. |
| [].step | number; exclusiveMinimum: 0 | no | Optional positive numeric increment in the parameter units, with no increment declared when omitted. |
| [].type | "text" / "number" / "date" / "boolean" | yes | Value type of the setting, either text, number, date, or boolean. |
| [].unit | string; minLength: 1; maxLength: 16 | no | Optional unit label of 1 to 16 characters, with no unit label when omitted. |

Example:

```json
[
  {
    "default": 10,
    "key": "harbor_limit",
    "label": "Rows to show",
    "max": 50,
    "min": 1,
    "type": "number"
  }
]
```

### triggers

Declare when the application runs, by hand, by schedule or around trading hours.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| [].choice 1.kind | "manual" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| [].choice 2.cron | string; maxLength: 256; pattern: "^\\s*\\S+(\\s+\\S+){4}\\s*$" | yes | Five-field schedule in minute, hour, day-of-month, month, and weekday order. |
| [].choice 2.kind | "schedule" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| [].choice 2.tz | string; minLength: 1; maxLength: 64; default: "Asia/Shanghai" | no | Schedule time zone, defaulting to Asia/Shanghai when omitted. |
| [].choice 3.at | "open" / "close" | yes | Market event to run near, either opening or closing. |
| [].choice 3.calendar | "SSE"; default: "SSE" | no | Trading calendar used for market events, restricted to SSE and defaulting to SSE when omitted. |
| [].choice 3.kind | "market" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| [].choice 3.offsetMinutes | integer; minimum: -240; maximum: 240; default: 0 | no | Signed offset in minutes from the market event, with negative values before it and zero when omitted. |
| [].choice 4.condition | string; minLength: 1; maxLength: 2000 | yes | Expression that must hold for a scheduled alert to raise a notification. |
| [].choice 4.cron | string; maxLength: 256; pattern: "^\\s*\\S+(\\s+\\S+){4}\\s*$" | yes | Five-field schedule in minute, hour, day-of-month, month, and weekday order. |
| [].choice 4.kind | "alert" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| [].choice 4.tz | string; minLength: 1; maxLength: 64; default: "Asia/Shanghai" | no | Schedule time zone, defaulting to Asia/Shanghai when omitted. |

Example:

```json
[
  {
    "kind": "manual"
  }
]
```

### ui

Declare a flat map of screen elements and the root section whose children form the screen.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| elements | object | yes | Map from element ids to their screen definitions, with section children linking the tree. |
| elements.*.choice 1.children | array of string; maxItems: 32 | yes | Ordered element ids contained by this section. |
| elements.*.choice 1.columns | 1 or 2 or 3; default: 1 | no | Number of section layout columns, defaulting to 1 when omitted. |
| elements.*.choice 1.title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| elements.*.choice 1.tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| elements.*.choice 1.type | "Section" | yes | Element type discriminator selecting the declared screen component. |
| elements.*.choice 2.emphasis | "heading" / "body" / "caption"; default: "body" | no | Text presentation role, defaulting to body when omitted. |
| elements.*.choice 2.text | string; minLength: 1; maxLength: 4000 | yes | Text content displayed by the element. |
| elements.*.choice 2.tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| elements.*.choice 2.type | "Text" | yes | Element type discriminator selecting the declared screen component. |
| elements.*.choice 3.change | string; minLength: 1; maxLength: 128 | no | Optional result column providing the metric change, with no change column when omitted. |
| elements.*.choice 3.format | "number" / "money" / "percent" / "integer"; default: "number" | no | Metric display format, defaulting to number when omitted. |
| elements.*.choice 3.from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| elements.*.choice 3.label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| elements.*.choice 3.tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| elements.*.choice 3.type | "Metric" | yes | Element type discriminator selecting the declared screen component. |
| elements.*.choice 3.unit | string; minLength: 1; maxLength: 16 | no | Optional displayed unit label, with no unit label when omitted. |
| elements.*.choice 3.value | string; minLength: 1; maxLength: 128 | yes | Result column providing the metric value. |
| elements.*.choice 4.columns | array of object; minItems: 1; maxItems: 40 | yes | Ordered declarations of the result columns displayed in the table. |
| elements.*.choice 4.columns[].col | string; minLength: 1; maxLength: 128 | yes | Result column to display in this table column. |
| elements.*.choice 4.columns[].format | "text" / "number" / "money" / "percent" / "date" / "integer" | no | Optional display format for this column, with no format specified when omitted. |
| elements.*.choice 4.columns[].label | string; minLength: 1; maxLength: 60 | no | Optional display label for the column, with no label specified when omitted. |
| elements.*.choice 4.emptyHint | string; minLength: 1; maxLength: 200 | no | Optional message for an empty result, with no custom message when omitted. |
| elements.*.choice 4.from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| elements.*.choice 4.pageSize | integer; minimum: 5; maximum: 200; default: 25 | no | Number of table rows per page, defaulting to 25 when omitted. |
| elements.*.choice 4.title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| elements.*.choice 4.tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| elements.*.choice 4.type | "Table" | yes | Element type discriminator selecting the declared screen component. |
| elements.*.choice 5.chart | "line" / "bar" / "candlestick" / "heatmap" | yes | Chart kind, either line, bar, candlestick, or heatmap. |
| elements.*.choice 5.from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| elements.*.choice 5.heat | object | no | Second-axis and value result columns, required for heatmaps and otherwise optional. |
| elements.*.choice 5.heat.value | string; minLength: 1; maxLength: 128 | yes | Result column supplying the heatmap cell value. |
| elements.*.choice 5.heat.y | string; minLength: 1; maxLength: 128 | yes | Result column supplying the heatmap second axis. |
| elements.*.choice 5.ohlc | object | no | Open, high, low, and close result columns, required for candlestick charts and otherwise optional. |
| elements.*.choice 5.ohlc.close | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle closing price. |
| elements.*.choice 5.ohlc.high | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle highest price. |
| elements.*.choice 5.ohlc.low | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle lowest price. |
| elements.*.choice 5.ohlc.open | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle opening price. |
| elements.*.choice 5.series | string; minLength: 1; maxLength: 128 | no | Text result column whose distinct values each become their own line or bar group, for example one line per company; only for line and bar charts with exactly one y column; at most 20 groups are drawn, the rest are listed as hidden. |
| elements.*.choice 5.stacked | boolean | no | Optional request to stack chart series, with no stacking request when omitted. |
| elements.*.choice 5.title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| elements.*.choice 5.tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| elements.*.choice 5.type | "Chart" | yes | Element type discriminator selecting the declared screen component. |
| elements.*.choice 5.x | string; minLength: 1; maxLength: 128 | yes | Result column supplying the horizontal axis. |
| elements.*.choice 5.y | array of string; maxItems: 8 | no | Result columns supplying line or bar series, required and non-empty for those chart kinds and otherwise optional. |
| elements.*.choice 6.text | string; minLength: 1; maxLength: 2000 | yes | Text content displayed by the element. |
| elements.*.choice 6.title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| elements.*.choice 6.tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| elements.*.choice 6.type | "Callout" | yes | Element type discriminator selecting the declared screen component. |
| elements.*.choice 7.emptyHint | string; minLength: 1; maxLength: 200 | no | Optional message for an empty result, with no custom message when omitted. |
| elements.*.choice 7.from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| elements.*.choice 7.groupBy | string; minLength: 1; maxLength: 128 | no | Optional result column used to group list items, with no grouping column when omitted. |
| elements.*.choice 7.itemBody | string; minLength: 1; maxLength: 128 | no | Optional result column supplying each list item body, with no body column when omitted. |
| elements.*.choice 7.itemLink | string; minLength: 1; maxLength: 128 | no | Optional result column supplying each list item link, with no link column when omitted. |
| elements.*.choice 7.itemTitle | string; minLength: 1; maxLength: 128 | yes | Result column supplying each list item title. |
| elements.*.choice 7.itemTone | string; minLength: 1; maxLength: 128 | no | Optional result column supplying each list item tone, with no per-item tone column when omitted. |
| elements.*.choice 7.title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| elements.*.choice 7.tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| elements.*.choice 7.type | "List" | yes | Element type discriminator selecting the declared screen component. |
| elements.*.choice 8.label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| elements.*.choice 8.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited by this control. |
| elements.*.choice 8.tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| elements.*.choice 8.type | "NumberInput" | yes | Element type discriminator selecting the declared screen component. |
| elements.*.choice 9.label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| elements.*.choice 9.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited by this control. |
| elements.*.choice 9.tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| elements.*.choice 9.type | "SelectInput" | yes | Element type discriminator selecting the declared screen component. |
| elements.*.choice 10.label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| elements.*.choice 10.list | boolean; default: false | no | Whether text input displays a string list as chips, defaulting to false when omitted. |
| elements.*.choice 10.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited by this control. |
| elements.*.choice 10.placeholder | string; minLength: 1; maxLength: 80 | no | Optional text input hint, with no placeholder specified when omitted. |
| elements.*.choice 10.tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| elements.*.choice 10.type | "TextInput" | yes | Element type discriminator selecting the declared screen component. |
| elements.*.choice 11.fromParam | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited as the start date of the range. |
| elements.*.choice 11.label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| elements.*.choice 11.toParam | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited as the end date of the range. |
| elements.*.choice 11.tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| elements.*.choice 11.type | "DateRangeInput" | yes | Element type discriminator selecting the declared screen component. |
| elements.*.choice 12.label | string; minLength: 1; maxLength: 40; default: "Run" | no | Button label, defaulting to Run when omitted. |
| elements.*.choice 12.tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| elements.*.choice 12.type | "RunButton" | yes | Element type discriminator selecting the declared screen component. |
| root | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Element id of the outermost section in the screen tree. |

Example:

```json
{
  "elements": {
    "harbor_intro": {
      "text": "Invented price overview.",
      "type": "Text"
    },
    "harbor_page": {
      "children": [
        "harbor_intro"
      ],
      "type": "Section"
    }
  },
  "root": "harbor_page"
}
```

## Step kinds

### ai

Ask the configured model about input rows and declare the shape of its response.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the input rows. |
| key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| kind | "ai" | yes | Step discriminator identifying a row interpretation step. |
| params | object | yes | Processing limits, instructions, output shape, and error policy for this step. |
| params.instructions | string; minLength: 1; maxLength: 4000 | yes | Instructions for interpreting the input rows, containing 1 to 4000 characters. |
| params.max_input_chars | integer; minimum: 100; maximum: 60000; default: 20000 | no | Maximum input text length in characters, defaulting to 20000 when omitted. |
| params.max_rows | integer or object; default: 50 | no | Maximum input row count as an integer or parameter reference, defaulting to 50 when omitted. |
| params.max_rows.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| params.mode | "whole" / "per_row" | yes | Requested processing scope, either the whole input or each row separately. |
| params.on_error | "null" / "fail"; default: "null" | no | Declared error policy, either null or fail, defaulting to null when omitted. |
| params.output | object or object or object | yes | Declared result shape, either text, an enumerated string, or an object of typed fields. |
| params.output.choice 1.kind | "text" | yes | Result shape discriminator selecting text, enum, or object. |
| params.output.choice 2.kind | "enum" | yes | Result shape discriminator selecting text, enum, or object. |
| params.output.choice 2.values | array of string; minItems: 2; maxItems: 32 | yes | Allowed non-empty string result values for an enum output, containing 2 to 32 entries. |
| params.output.choice 3.fields | object | yes | Map of output column names to string, number, or boolean types, containing 1 to 32 fields. |
| params.output.choice 3.kind | "object" | yes | Result shape discriminator selecting text, enum, or object. |
| title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "id": "harbor_summary",
  "input": "harbor_prices",
  "kind": "ai",
  "params": {
    "instructions": "Summarize harbor_price.",
    "max_input_chars": 2000,
    "max_rows": 10,
    "mode": "whole",
    "on_error": "null",
    "output": {
      "kind": "text"
    }
  }
}
```

### code

Run sandboxed JavaScript with declared inputs and output columns, optionally carrying state across successful runs.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| body | string; minLength: 1; maxLength: 40000 | yes | Sandboxed JavaScript body containing 1 to 40000 characters. |
| carry_state | boolean; default: false | no | Whether state from the previous successful run is available, capped at 64 KB and defaulting to false when omitted. |
| id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| input | array of string; minItems: 1; maxItems: 3 | yes | One to three declared input relation names. |
| key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| kind | "code" | yes | Step discriminator identifying a sandboxed code calculation. |
| output | object | yes | Declared columns and types for the result table. |
| output.columns | array of object; minItems: 1; maxItems: 64 | yes | One to 64 column declarations for the result table. |
| output.columns[].name | string; minLength: 1; maxLength: 128 | yes | Output table column name. |
| output.columns[].type | "text" / "number" / "date" / "boolean" | yes | Output table column data type. |
| title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "body": "return [{ harbor_value: 1 }];",
  "carry_state": false,
  "id": "harbor_constant",
  "input": [
    "harbor_prices"
  ],
  "kind": "code",
  "output": {
    "columns": [
      {
        "name": "harbor_value",
        "type": "number"
      }
    ]
  }
}
```

### expression

Evaluate a one-line formula to produce a single value for later calculations.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| expr | string; minLength: 1; maxLength: 2000 | yes | Formula intended to produce a single value addressable by this step id. |
| id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | no | Optional data requirement key or step id declared as input, with no input declared when omitted. |
| key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| kind | "expression" | yes | Step discriminator identifying a scalar expression. |
| title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "expr": "2 * 3",
  "id": "harbor_assumption",
  "kind": "expression"
}
```

### operation

Run a named operation with its own parameter shape over an input relation.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| choice 1.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 1.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 1.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 1.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 1.op | "filter" | yes | Named operation selected by this schema branch. |
| choice 1.params | object | yes | Parameters for the selected operation. |
| choice 1.params.where | string; minLength: 1; maxLength: 2000 | yes | Boolean expression that keeps only input rows for which it is true. |
| choice 1.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 2.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 2.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 2.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 2.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 2.op | "derive" | yes | Named operation selected by this schema branch. |
| choice 2.params | object | yes | Parameters for the selected operation. |
| choice 2.params.columns | object | yes | Map from each new output column name to the expression calculated for every input row. |
| choice 2.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 3.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 3.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 3.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 3.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 3.op | "join" | yes | Named operation selected by this schema branch. |
| choice 3.params | object | yes | Parameters for the selected operation. |
| choice 3.params.asof_on | [string, string]; minItems: 2; maxItems: 2 | no | Ordered matching columns as [column in the input table, column in the right table], required for asof and adding no ordered match when omitted for other join kinds. |
| choice 3.params.direction | "backward" / "forward" / "nearest" | no | As-of matching direction, defaulting to backward for the latest right row at or before the input row, with forward choosing the earliest at or after it and nearest currently unsupported. |
| choice 3.params.how | "inner" / "left" / "asof" | yes | Join kind, retaining matching rows for inner or all input rows for left and asof. |
| choice 3.params.on | array of [string, string]; minItems: 1; maxItems: 8 | yes | Pairs of equality keys in the order [column in the input table, column in the right table]. |
| choice 3.params.right | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the second table, while the step input names the first table. |
| choice 3.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 4.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 4.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 4.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 4.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 4.op | "aggregate" | yes | Named operation selected by this schema branch. |
| choice 4.params | object | yes | Parameters for the selected operation. |
| choice 4.params.by | array of string; maxItems: 8 | yes | Grouping columns, with an empty array producing one summary across the whole input. |
| choice 4.params.metrics | array of object; minItems: 1; maxItems: 32 | yes | Summary definitions producing one output column each per group. |
| choice 4.params.metrics[].as | string; minLength: 1; maxLength: 128 | yes | Name of the output column holding this summary. |
| choice 4.params.metrics[].fn | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function to apply, with stddev and var using sample statistics. |
| choice 4.params.metrics[].of | string; minLength: 1; maxLength: 128 | no | Input column to summarise, required except for count, which counts all rows when omitted. |
| choice 4.params.metrics[].p | number; minimum: 0; maximum: 1 | no | Quantile fraction from 0 to 1, required for quantile and unused by other summary functions. |
| choice 4.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 5.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 5.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 5.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 5.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 5.op | "sort_limit" | yes | Named operation selected by this schema branch. |
| choice 5.params | object | yes | Parameters for the selected operation. |
| choice 5.params.by | array of object; minItems: 1; maxItems: 8 | yes | Sort columns and directions in priority order. |
| choice 5.params.by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| choice 5.params.by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| choice 5.params.limit | integer or object | no | Maximum number of output rows, supplied as an integer or parameter reference, with no row limit when omitted. |
| choice 5.params.limit.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| choice 5.params.offset | integer or object | no | Number of sorted rows to skip, supplied as an integer or parameter reference, defaulting to zero when omitted. |
| choice 5.params.offset.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| choice 5.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 6.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 6.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 6.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 6.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 6.op | "window" | yes | Named operation selected by this schema branch. |
| choice 6.params | object | yes | Parameters for the selected operation. |
| choice 6.params.as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the window calculation. |
| choice 6.params.fn | "sum" / "mean" / "min" / "max" / "count" / "stddev" / "first" / "last" | yes | Calculation applied within each frame, with stddev using sample standard deviation and count counting non-null values. |
| choice 6.params.frame | object | yes | Inclusive frame around the current row using row counts or ordered-value distances. |
| choice 6.params.frame.following | integer or object | yes | Distance after the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps. |
| choice 6.params.frame.following.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| choice 6.params.frame.kind | "rows" / "range" | yes | Frame measure, using row counts for rows or ordered-value distances for range, measured in days for date or timestamp order columns. |
| choice 6.params.frame.preceding | integer or object | yes | Distance before the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps. |
| choice 6.params.frame.preceding.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| choice 6.params.of | string; minLength: 1; maxLength: 128 | yes | Input column whose values are calculated within each frame. |
| choice 6.params.order_by | array of object; minItems: 1; maxItems: 8 | yes | Columns and directions defining row order within each partition. |
| choice 6.params.order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| choice 6.params.order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| choice 6.params.partition_by | array of string; maxItems: 4 | no | Columns separating independent row groups, with all rows in one group when omitted. |
| choice 6.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 7.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 7.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 7.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 7.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 7.op | "lag_change" | yes | Named operation selected by this schema branch. |
| choice 7.params | object | yes | Parameters for the selected operation. |
| choice 7.params.as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the change. |
| choice 7.params.mode | "diff" / "pct" / "log" | yes | Change calculation, using current minus earlier for diff, current divided by earlier minus one for pct as a fraction, or the natural logarithm of their positive ratio for log. |
| choice 7.params.of | string; minLength: 1; maxLength: 128 | yes | Input column compared with its earlier value. |
| choice 7.params.order_by | array of object; minItems: 1; maxItems: 8 | yes | Columns and directions determining which rows are earlier. |
| choice 7.params.order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| choice 7.params.order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| choice 7.params.partition_by | array of string; maxItems: 4 | no | Columns separating independent histories, with all rows in one history when omitted. |
| choice 7.params.periods | integer or object | yes | Number of ordered rows to look back within the partition, supplied as an integer or parameter reference. |
| choice 7.params.periods.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| choice 7.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 8.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 8.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 8.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 8.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 8.op | "rank" | yes | Named operation selected by this schema branch. |
| choice 8.params | object | yes | Parameters for the selected operation. |
| choice 8.params.as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the rank. |
| choice 8.params.by | string; minLength: 1; maxLength: 128 | yes | Input column whose values determine the rank. |
| choice 8.params.direction | "asc" / "desc" | yes | Ascending or descending order used to assign ranks. |
| choice 8.params.method | "rank" / "dense" / "row_number" / "percentile" | yes | Ranking rule, using gaps for rank, no gaps for dense, distinct row numbers for row_number, or a fraction from 0 to 1 for percentile. |
| choice 8.params.within | array of string; maxItems: 4 | no | Columns separating independent ranking groups, with all rows ranked together when omitted. |
| choice 8.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 9.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 9.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 9.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 9.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 9.op | "zscore" | yes | Named operation selected by this schema branch. |
| choice 9.params | object | yes | Parameters for the selected operation. |
| choice 9.params.as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the dimensionless standard score. |
| choice 9.params.of | string; minLength: 1; maxLength: 128 | yes | Input column standardised as its value minus the mean divided by sample standard deviation. |
| choice 9.params.order_by | array of object; minItems: 1; maxItems: 8 | no | Columns and directions defining rolling row order, required when window is set and ignored otherwise. |
| choice 9.params.order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| choice 9.params.order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| choice 9.params.window | integer or object | no | Rolling frame size in rows including the current row, supplied as an integer or parameter reference, requiring that many non-null values and using the entire group when omitted. |
| choice 9.params.window.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| choice 9.params.within | array of string; maxItems: 4 | no | Columns separating independent standardisation groups, with all rows in one group when omitted. |
| choice 9.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 10.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 10.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 10.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 10.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 10.op | "resample" | yes | Named operation selected by this schema branch. |
| choice 10.params | object | yes | Parameters for the selected operation. |
| choice 10.params.by | array of string; maxItems: 4 | no | Additional grouping columns kept separate within each period, with no additional grouping when omitted. |
| choice 10.params.date_col | string; minLength: 1; maxLength: 128 | yes | Input date column whose name is preserved in the output and whose value becomes the first day of each period. |
| choice 10.params.metrics | array of object; minItems: 1; maxItems: 32 | yes | Summary definitions calculated for each period and additional group. |
| choice 10.params.metrics[].as | string; minLength: 1; maxLength: 128 | yes | Name of the output column holding this summary. |
| choice 10.params.metrics[].fn | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function to apply, with stddev and var using sample statistics. |
| choice 10.params.metrics[].of | string; minLength: 1; maxLength: 128 | no | Input column to summarise, required except for count, which counts all rows when omitted. |
| choice 10.params.metrics[].p | number; minimum: 0; maximum: 1 | no | Quantile fraction from 0 to 1, required for quantile and unused by other summary functions. |
| choice 10.params.to | "week" / "month" / "quarter" / "year" | yes | Calendar period to aggregate into, with weeks starting on Monday. |
| choice 10.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 11.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 11.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 11.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 11.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 11.op | "pivot" | yes | Named operation selected by this schema branch. |
| choice 11.params | object | yes | Parameters for the selected operation. |
| choice 11.params.agg | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function for each pivot cell, with quantile currently unsupported. |
| choice 11.params.index | array of string; minItems: 1; maxItems: 4 | yes | Columns identifying each output row and grouping the pivoted values. |
| choice 11.params.on | string; minLength: 1; maxLength: 128 | yes | Input category column whose distinct values become output columns. |
| choice 11.params.values | string; minLength: 1; maxLength: 128 | yes | Input column whose values are summarised in each pivot cell. |
| choice 11.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 12.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 12.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 12.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 12.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 12.op | "describe" | yes | Named operation selected by this schema branch. |
| choice 12.params | object | yes | Parameters for the selected operation. |
| choice 12.params.columns | array of string; maxItems: 64 | no | Numeric input columns to summarise, defaulting to all numeric input columns when omitted. |
| choice 12.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 13.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 13.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 13.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 13.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 13.op | "correlate" | yes | Named operation selected by this schema branch. |
| choice 13.params | object | yes | Parameters for the selected operation. |
| choice 13.params.columns | array of string; minItems: 2; maxItems: 32 | yes | Input columns for which each distinct pair receives a correlation result. |
| choice 13.params.method | "pearson" / "spearman" | yes | Correlation method, using raw values for pearson or average ranks for spearman. |
| choice 13.params.min_periods | integer; minimum: 2; maximum: 100000 | no | Minimum count of rows with both values present before returning a correlation, with no additional count threshold when omitted. |
| choice 13.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 14.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 14.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 14.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 14.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 14.op | "regress" | yes | Named operation selected by this schema branch. |
| choice 14.params | object | yes | Parameters for the selected operation. |
| choice 14.params.by | array of string; maxItems: 4 | no | Columns separating independent regression groups, with one fit across the input when omitted. |
| choice 14.params.x | array of string; minItems: 1; maxItems: 16 | yes | Predictor input columns for the regression, allowing 1 to 16 names in the schema. |
| choice 14.params.y | string; minLength: 1; maxLength: 128 | yes | Dependent input column to fit. |
| choice 14.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 15.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 15.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 15.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 15.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 15.op | "adjust_price" | yes | Named operation selected by this schema branch. |
| choice 15.params | object | yes | Parameters for the selected operation. |
| choice 15.params.base_date | string; maxLength: 10; pattern: "^\\d{4}-\\d{2}-\\d{2}$" | no | Forward adjustment cutoff in YYYY-MM-DD form, using the latest factor on or before this date or the latest available factor date per security when omitted and disallowed for backward adjustment. |
| choice 15.params.date | [string, string]; minItems: 2; maxItems: 2 | yes | Trading date columns in the order [column in the input table, column in the factor table], matching the latest factor on or before each input date. |
| choice 15.params.factor_col | string; minLength: 1; maxLength: 128 | yes | Column in the factor table containing the cumulative multiplicative adjustment factor. |
| choice 15.params.factor_table | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the cumulative adjustment factor table, distinct from the input price table. |
| choice 15.params.key | [string, string]; minItems: 2; maxItems: 2 | yes | Security key columns in the order [column in the input table, column in the factor table]. |
| choice 15.params.mode | "forward" / "backward" | yes | Adjustment direction, with backward multiplying prices by their dated factor and forward dividing that product by the base factor, using the latest factor date for each security when base_date is omitted. |
| choice 15.params.price_cols | array of string; minItems: 1; maxItems: 8 | yes | Input price columns replaced by adjusted values under the same names and in the same price units. |
| choice 15.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 16.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 16.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 16.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 16.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 16.op | "irr" | yes | Named operation selected by this schema branch. |
| choice 16.params | object | yes | Parameters for the selected operation. |
| choice 16.params.amount_col | string; minLength: 1; maxLength: 128 | yes | Cash flow amount column in a consistent monetary unit, with payments out negative and receipts positive. |
| choice 16.params.date_col | string; minLength: 1; maxLength: 128 | yes | Cash flow date column used to count elapsed days over a 365-day year. |
| choice 16.params.guess | number | no | Initial annual rate as a fraction for the iterative solver, defaulting to 0.1 when omitted. |
| choice 16.params.max_iter | integer; minimum: 1; maximum: 100; default: 100 | no | Maximum number of Newton iterations before the fallback solver, defaulting to 100 when omitted. |
| choice 16.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |
| choice 17.id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| choice 17.input | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the primary input table, which is the first table for join. |
| choice 17.key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| choice 17.kind | "operation" | yes | Step discriminator identifying a named operation. |
| choice 17.op | "factor" | yes | Named operation selected by this schema branch. |
| choice 17.params | object | yes | Parameters for the selected operation. |
| choice 17.params.as_of | string; maxLength: 10; pattern: "^\\d{4}-\\d{2}-\\d{2}$" | no | Latest eligible trading date in YYYY-MM-DD form, returning each security latest row on or before it or its latest available row when omitted. |
| choice 17.params.factor | string; minLength: 1; maxLength: 60 | yes | Name of a supported market measure to calculate from the input daily rows. |
| choice 17.params.universe | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | no | Data requirement key or step id whose ts_code column restricts the securities, with no universe restriction when omitted. |
| choice 17.title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "id": "harbor_positive",
  "input": "harbor_prices",
  "kind": "operation",
  "op": "filter",
  "params": {
    "where": "harbor_price > 0"
  }
}
```

### sql

Run a single allowed SELECT or WITH query over declared input relations.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| id | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Unique step name that also names its output in the namespace shared with data requirement keys. |
| input | array of string; maxItems: 8 | no | Declared relation names available to the SQL query, with no relations declared when omitted. |
| key | boolean | no | Whether to mark the step for the Inspect panel, with no explicit marking when omitted and screen-read steps included independently. |
| kind | "sql" | yes | Step discriminator identifying a SQL calculation. |
| sql | string; minLength: 1; maxLength: 20000 | yes | Read-only SQL query checked by the SQL validator against declared inputs. |
| title | string; minLength: 1; maxLength: 120 | no | Optional display title for the calculation, with no title specified when omitted. |

Example:

```json
{
  "id": "harbor_total",
  "input": [
    "harbor_prices"
  ],
  "kind": "sql",
  "sql": "SELECT sum(harbor_price) AS harbor_total FROM harbor_prices"
}
```

## Trigger kinds

### alert

Run on a schedule and raise a notification only when the result condition holds.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| condition | string; minLength: 1; maxLength: 2000 | yes | Expression that must hold for a scheduled alert to raise a notification. |
| cron | string; maxLength: 256; pattern: "^\\s*\\S+(\\s+\\S+){4}\\s*$" | yes | Five-field schedule in minute, hour, day-of-month, month, and weekday order. |
| kind | "alert" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| tz | string; minLength: 1; maxLength: 64; default: "Asia/Shanghai" | no | Schedule time zone, defaulting to Asia/Shanghai when omitted. |

Example:

```json
{
  "condition": "harbor_assumption > 5",
  "cron": "0 16 * * 1-5",
  "kind": "alert",
  "tz": "Asia/Shanghai"
}
```

### manual

Allow a person to run the application with its current settings.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| kind | "manual" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |

Example:

```json
{
  "kind": "manual"
}
```

### market

Run before or after market opening or closing on actual trading days in the SSE calendar.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| at | "open" / "close" | yes | Market event to run near, either opening or closing. |
| calendar | "SSE"; default: "SSE" | no | Trading calendar used for market events, restricted to SSE and defaulting to SSE when omitted. |
| kind | "market" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| offsetMinutes | integer; minimum: -240; maximum: 240; default: 0 | no | Signed offset in minutes from the market event, with negative values before it and zero when omitted. |

Example:

```json
{
  "at": "close",
  "calendar": "SSE",
  "kind": "market",
  "offsetMinutes": 15
}
```

### schedule

Run on a five-field cron schedule in the named time zone.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| cron | string; maxLength: 256; pattern: "^\\s*\\S+(\\s+\\S+){4}\\s*$" | yes | Five-field schedule in minute, hour, day-of-month, month, and weekday order. |
| kind | "schedule" | yes | Trigger discriminator selecting manual, schedule, market, or alert. |
| tz | string; minLength: 1; maxLength: 64; default: "Asia/Shanghai" | no | Schedule time zone, defaulting to Asia/Shanghai when omitted. |

Example:

```json
{
  "cron": "0 8 * * 1-5",
  "kind": "schedule",
  "tz": "Asia/Shanghai"
}
```

## Shaping operations

### aggregate

Return one row per group with the grouping columns and named summary columns.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| by | array of string; maxItems: 8 | yes | Grouping columns, with an empty array producing one summary across the whole input. |
| metrics | array of object; minItems: 1; maxItems: 32 | yes | Summary definitions producing one output column each per group. |
| metrics[].as | string; minLength: 1; maxLength: 128 | yes | Name of the output column holding this summary. |
| metrics[].fn | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function to apply, with stddev and var using sample statistics. |
| metrics[].of | string; minLength: 1; maxLength: 128 | no | Input column to summarise, required except for count, which counts all rows when omitted. |
| metrics[].p | number; minimum: 0; maximum: 1 | no | Quantile fraction from 0 to 1, required for quantile and unused by other summary functions. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "by": {
      "description": "Grouping columns, with an empty array producing one summary across the whole input.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 8,
      "type": "array"
    },
    "metrics": {
      "description": "Summary definitions producing one output column each per group.",
      "items": {
        "additionalProperties": false,
        "properties": {
          "as": {
            "description": "Name of the output column holding this summary.",
            "maxLength": 128,
            "minLength": 1,
            "type": "string"
          },
          "fn": {
            "description": "Summary function to apply, with stddev and var using sample statistics.",
            "enum": [
              "sum",
              "mean",
              "median",
              "min",
              "max",
              "count",
              "count_distinct",
              "stddev",
              "var",
              "quantile"
            ],
            "type": "string"
          },
          "of": {
            "description": "Input column to summarise, required except for count, which counts all rows when omitted.",
            "maxLength": 128,
            "minLength": 1,
            "type": "string"
          },
          "p": {
            "description": "Quantile fraction from 0 to 1, required for quantile and unused by other summary functions.",
            "maximum": 1,
            "minimum": 0,
            "type": "number"
          }
        },
        "required": [
          "fn",
          "as"
        ],
        "type": "object"
      },
      "maxItems": 32,
      "minItems": 1,
      "type": "array"
    }
  },
  "required": [
    "by",
    "metrics"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "by": [
    "harbor_sector"
  ],
  "metrics": [
    {
      "as": "harbor_average",
      "fn": "mean",
      "of": "harbor_price"
    }
  ]
}
```

### derive

Keep input columns and append the named calculated columns.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| columns | object | yes | Map from each new output column name to the expression calculated for every input row. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "columns": {
      "additionalProperties": {
        "maxLength": 2000,
        "minLength": 1,
        "type": "string"
      },
      "description": "Map from each new output column name to the expression calculated for every input row.",
      "propertyNames": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "type": "object"
    }
  },
  "required": [
    "columns"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "columns": {
    "harbor_gain": "harbor_price - harbor_cost"
  }
}
```

### filter

Keep matching rows with all input columns unchanged.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| where | string; minLength: 1; maxLength: 2000 | yes | Boolean expression that keeps only input rows for which it is true. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "where": {
      "description": "Boolean expression that keeps only input rows for which it is true.",
      "maxLength": 2000,
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "where"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "where": "harbor_price > 20"
}
```

### join

Combine matching rows, retaining left columns and non-key right columns, with right relation suffixes and numbered suffixes for name collisions.

Inputs: 2. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| asof_on | [string, string]; minItems: 2; maxItems: 2 | no | Ordered matching columns as [column in the input table, column in the right table], required for asof and adding no ordered match when omitted for other join kinds. |
| direction | "backward" / "forward" / "nearest" | no | As-of matching direction, defaulting to backward for the latest right row at or before the input row, with forward choosing the earliest at or after it and nearest currently unsupported. |
| how | "inner" / "left" / "asof" | yes | Join kind, retaining matching rows for inner or all input rows for left and asof. |
| on | array of [string, string]; minItems: 1; maxItems: 8 | yes | Pairs of equality keys in the order [column in the input table, column in the right table]. |
| right | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the second table, while the step input names the first table. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "asof_on": {
      "description": "Ordered matching columns as [column in the input table, column in the right table], required for asof and adding no ordered match when omitted for other join kinds.",
      "items": false,
      "maxItems": 2,
      "minItems": 2,
      "prefixItems": [
        {
          "maxLength": 128,
          "minLength": 1,
          "type": "string"
        },
        {
          "maxLength": 128,
          "minLength": 1,
          "type": "string"
        }
      ],
      "type": "array"
    },
    "direction": {
      "description": "As-of matching direction, defaulting to backward for the latest right row at or before the input row, with forward choosing the earliest at or after it and nearest currently unsupported.",
      "enum": [
        "backward",
        "forward",
        "nearest"
      ],
      "type": "string"
    },
    "how": {
      "description": "Join kind, retaining matching rows for inner or all input rows for left and asof.",
      "enum": [
        "inner",
        "left",
        "asof"
      ],
      "type": "string"
    },
    "on": {
      "description": "Pairs of equality keys in the order [column in the input table, column in the right table].",
      "items": {
        "items": false,
        "maxItems": 2,
        "minItems": 2,
        "prefixItems": [
          {
            "maxLength": 128,
            "minLength": 1,
            "type": "string"
          },
          {
            "maxLength": 128,
            "minLength": 1,
            "type": "string"
          }
        ],
        "type": "array"
      },
      "maxItems": 8,
      "minItems": 1,
      "type": "array"
    },
    "right": {
      "description": "Data requirement key or step id of the second table, while the step input names the first table.",
      "maxLength": 40,
      "pattern": "^[a-z][a-z0-9_]{0,39}$",
      "type": "string"
    }
  },
  "required": [
    "right",
    "on",
    "how"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "how": "left",
  "on": [
    [
      "harbor_code",
      "harbor_code"
    ]
  ],
  "right": "harbor_sectors"
}
```

### pivot

Return index columns and one summary column per category in the pivot column.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| agg | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function for each pivot cell, with quantile currently unsupported. |
| index | array of string; minItems: 1; maxItems: 4 | yes | Columns identifying each output row and grouping the pivoted values. |
| on | string; minLength: 1; maxLength: 128 | yes | Input category column whose distinct values become output columns. |
| values | string; minLength: 1; maxLength: 128 | yes | Input column whose values are summarised in each pivot cell. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "agg": {
      "description": "Summary function for each pivot cell, with quantile currently unsupported.",
      "enum": [
        "sum",
        "mean",
        "median",
        "min",
        "max",
        "count",
        "count_distinct",
        "stddev",
        "var",
        "quantile"
      ],
      "type": "string"
    },
    "index": {
      "description": "Columns identifying each output row and grouping the pivoted values.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 4,
      "minItems": 1,
      "type": "array"
    },
    "on": {
      "description": "Input category column whose distinct values become output columns.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "values": {
      "description": "Input column whose values are summarised in each pivot cell.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "index",
    "on",
    "values",
    "agg"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "agg": "mean",
  "index": [
    "harbor_day"
  ],
  "on": "harbor_sector",
  "values": "harbor_price"
}
```

### sort_limit

Sort rows and optionally skip or limit them while retaining all input columns.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| by | array of object; minItems: 1; maxItems: 8 | yes | Sort columns and directions in priority order. |
| by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| limit | integer or object | no | Maximum number of output rows, supplied as an integer or parameter reference, with no row limit when omitted. |
| limit.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| offset | integer or object | no | Number of sorted rows to skip, supplied as an integer or parameter reference, defaulting to zero when omitted. |
| offset.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "by": {
      "description": "Sort columns and directions in priority order.",
      "items": {
        "additionalProperties": false,
        "properties": {
          "col": {
            "description": "Input column used to order rows.",
            "maxLength": 128,
            "minLength": 1,
            "type": "string"
          },
          "dir": {
            "description": "Sort direction, ascending for asc or descending for desc.",
            "enum": [
              "asc",
              "desc"
            ],
            "type": "string"
          }
        },
        "required": [
          "col",
          "dir"
        ],
        "type": "object"
      },
      "maxItems": 8,
      "minItems": 1,
      "type": "array"
    },
    "limit": {
      "anyOf": [
        {
          "maximum": 200000,
          "minimum": 1,
          "type": "integer"
        },
        {
          "additionalProperties": false,
          "properties": {
            "param": {
              "description": "Declared parameter key supplying the integer value at run time.",
              "maxLength": 40,
              "pattern": "^[a-z][a-z0-9_]{0,39}$",
              "type": "string"
            }
          },
          "required": [
            "param"
          ],
          "type": "object"
        }
      ],
      "description": "Maximum number of output rows, supplied as an integer or parameter reference, with no row limit when omitted."
    },
    "offset": {
      "anyOf": [
        {
          "maximum": 200000,
          "minimum": 0,
          "type": "integer"
        },
        {
          "additionalProperties": false,
          "properties": {
            "param": {
              "description": "Declared parameter key supplying the integer value at run time.",
              "maxLength": 40,
              "pattern": "^[a-z][a-z0-9_]{0,39}$",
              "type": "string"
            }
          },
          "required": [
            "param"
          ],
          "type": "object"
        }
      ],
      "description": "Number of sorted rows to skip, supplied as an integer or parameter reference, defaulting to zero when omitted."
    }
  },
  "required": [
    "by"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "by": [
    {
      "col": "harbor_price",
      "dir": "desc"
    }
  ],
  "limit": 10,
  "offset": 0
}
```

## Time series operations

### adjust_price

Keep input columns and replace selected prices under their original names using cumulative split and dividend adjustment factors.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| base_date | string; maxLength: 10; pattern: "^\\d{4}-\\d{2}-\\d{2}$" | no | Forward adjustment cutoff in YYYY-MM-DD form, using the latest factor on or before this date or the latest available factor date per security when omitted and disallowed for backward adjustment. |
| date | [string, string]; minItems: 2; maxItems: 2 | yes | Trading date columns in the order [column in the input table, column in the factor table], matching the latest factor on or before each input date. |
| factor_col | string; minLength: 1; maxLength: 128 | yes | Column in the factor table containing the cumulative multiplicative adjustment factor. |
| factor_table | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id of the cumulative adjustment factor table, distinct from the input price table. |
| key | [string, string]; minItems: 2; maxItems: 2 | yes | Security key columns in the order [column in the input table, column in the factor table]. |
| mode | "forward" / "backward" | yes | Adjustment direction, with backward multiplying prices by their dated factor and forward dividing that product by the base factor, using the latest factor date for each security when base_date is omitted. |
| price_cols | array of string; minItems: 1; maxItems: 8 | yes | Input price columns replaced by adjusted values under the same names and in the same price units. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "base_date": {
      "description": "Forward adjustment cutoff in YYYY-MM-DD form, using the latest factor on or before this date or the latest available factor date per security when omitted and disallowed for backward adjustment.",
      "maxLength": 10,
      "pattern": "^\\d{4}-\\d{2}-\\d{2}$",
      "type": "string"
    },
    "date": {
      "description": "Trading date columns in the order [column in the input table, column in the factor table], matching the latest factor on or before each input date.",
      "items": false,
      "maxItems": 2,
      "minItems": 2,
      "prefixItems": [
        {
          "maxLength": 128,
          "minLength": 1,
          "type": "string"
        },
        {
          "maxLength": 128,
          "minLength": 1,
          "type": "string"
        }
      ],
      "type": "array"
    },
    "factor_col": {
      "description": "Column in the factor table containing the cumulative multiplicative adjustment factor.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "factor_table": {
      "description": "Data requirement key or step id of the cumulative adjustment factor table, distinct from the input price table.",
      "maxLength": 40,
      "pattern": "^[a-z][a-z0-9_]{0,39}$",
      "type": "string"
    },
    "key": {
      "description": "Security key columns in the order [column in the input table, column in the factor table].",
      "items": false,
      "maxItems": 2,
      "minItems": 2,
      "prefixItems": [
        {
          "maxLength": 128,
          "minLength": 1,
          "type": "string"
        },
        {
          "maxLength": 128,
          "minLength": 1,
          "type": "string"
        }
      ],
      "type": "array"
    },
    "mode": {
      "description": "Adjustment direction, with backward multiplying prices by their dated factor and forward dividing that product by the base factor, using the latest factor date for each security when base_date is omitted.",
      "enum": [
        "forward",
        "backward"
      ],
      "type": "string"
    },
    "price_cols": {
      "description": "Input price columns replaced by adjusted values under the same names and in the same price units.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 8,
      "minItems": 1,
      "type": "array"
    }
  },
  "required": [
    "price_cols",
    "factor_table",
    "key",
    "date",
    "factor_col",
    "mode"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "base_date": "2026-01-30",
  "date": [
    "harbor_day",
    "harbor_date"
  ],
  "factor_col": "harbor_multiplier",
  "factor_table": "harbor_adjustments",
  "key": [
    "harbor_code",
    "harbor_security"
  ],
  "mode": "forward",
  "price_cols": [
    "harbor_price"
  ]
}
```

### lag_change

Keep input columns and append a named difference, fractional change or logarithmic change from an earlier row.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the change. |
| mode | "diff" / "pct" / "log" | yes | Change calculation, using current minus earlier for diff, current divided by earlier minus one for pct as a fraction, or the natural logarithm of their positive ratio for log. |
| of | string; minLength: 1; maxLength: 128 | yes | Input column compared with its earlier value. |
| order_by | array of object; minItems: 1; maxItems: 8 | yes | Columns and directions determining which rows are earlier. |
| order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| partition_by | array of string; maxItems: 4 | no | Columns separating independent histories, with all rows in one history when omitted. |
| periods | integer or object | yes | Number of ordered rows to look back within the partition, supplied as an integer or parameter reference. |
| periods.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "as": {
      "description": "Name of the new output column containing the change.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "mode": {
      "description": "Change calculation, using current minus earlier for diff, current divided by earlier minus one for pct as a fraction, or the natural logarithm of their positive ratio for log.",
      "enum": [
        "diff",
        "pct",
        "log"
      ],
      "type": "string"
    },
    "of": {
      "description": "Input column compared with its earlier value.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "order_by": {
      "description": "Columns and directions determining which rows are earlier.",
      "items": {
        "additionalProperties": false,
        "properties": {
          "col": {
            "description": "Input column used to order rows.",
            "maxLength": 128,
            "minLength": 1,
            "type": "string"
          },
          "dir": {
            "description": "Sort direction, ascending for asc or descending for desc.",
            "enum": [
              "asc",
              "desc"
            ],
            "type": "string"
          }
        },
        "required": [
          "col",
          "dir"
        ],
        "type": "object"
      },
      "maxItems": 8,
      "minItems": 1,
      "type": "array"
    },
    "partition_by": {
      "description": "Columns separating independent histories, with all rows in one history when omitted.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 4,
      "type": "array"
    },
    "periods": {
      "anyOf": [
        {
          "maximum": 10000,
          "minimum": 1,
          "type": "integer"
        },
        {
          "additionalProperties": false,
          "properties": {
            "param": {
              "description": "Declared parameter key supplying the integer value at run time.",
              "maxLength": 40,
              "pattern": "^[a-z][a-z0-9_]{0,39}$",
              "type": "string"
            }
          },
          "required": [
            "param"
          ],
          "type": "object"
        }
      ],
      "description": "Number of ordered rows to look back within the partition, supplied as an integer or parameter reference."
    }
  },
  "required": [
    "of",
    "periods",
    "mode",
    "order_by",
    "as"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "as": "harbor_change",
  "mode": "pct",
  "of": "harbor_price",
  "order_by": [
    {
      "col": "harbor_day",
      "dir": "asc"
    }
  ],
  "partition_by": [
    "harbor_code"
  ],
  "periods": 1
}
```

### resample

Return grouping columns, the original date column set to each period start, and named summary columns.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| by | array of string; maxItems: 4 | no | Additional grouping columns kept separate within each period, with no additional grouping when omitted. |
| date_col | string; minLength: 1; maxLength: 128 | yes | Input date column whose name is preserved in the output and whose value becomes the first day of each period. |
| metrics | array of object; minItems: 1; maxItems: 32 | yes | Summary definitions calculated for each period and additional group. |
| metrics[].as | string; minLength: 1; maxLength: 128 | yes | Name of the output column holding this summary. |
| metrics[].fn | "sum" / "mean" / "median" / "min" / "max" / "count" / "count_distinct" / "stddev" / "var" / "quantile" | yes | Summary function to apply, with stddev and var using sample statistics. |
| metrics[].of | string; minLength: 1; maxLength: 128 | no | Input column to summarise, required except for count, which counts all rows when omitted. |
| metrics[].p | number; minimum: 0; maximum: 1 | no | Quantile fraction from 0 to 1, required for quantile and unused by other summary functions. |
| to | "week" / "month" / "quarter" / "year" | yes | Calendar period to aggregate into, with weeks starting on Monday. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "by": {
      "description": "Additional grouping columns kept separate within each period, with no additional grouping when omitted.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 4,
      "type": "array"
    },
    "date_col": {
      "description": "Input date column whose name is preserved in the output and whose value becomes the first day of each period.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "metrics": {
      "description": "Summary definitions calculated for each period and additional group.",
      "items": {
        "additionalProperties": false,
        "properties": {
          "as": {
            "description": "Name of the output column holding this summary.",
            "maxLength": 128,
            "minLength": 1,
            "type": "string"
          },
          "fn": {
            "description": "Summary function to apply, with stddev and var using sample statistics.",
            "enum": [
              "sum",
              "mean",
              "median",
              "min",
              "max",
              "count",
              "count_distinct",
              "stddev",
              "var",
              "quantile"
            ],
            "type": "string"
          },
          "of": {
            "description": "Input column to summarise, required except for count, which counts all rows when omitted.",
            "maxLength": 128,
            "minLength": 1,
            "type": "string"
          },
          "p": {
            "description": "Quantile fraction from 0 to 1, required for quantile and unused by other summary functions.",
            "maximum": 1,
            "minimum": 0,
            "type": "number"
          }
        },
        "required": [
          "fn",
          "as"
        ],
        "type": "object"
      },
      "maxItems": 32,
      "minItems": 1,
      "type": "array"
    },
    "to": {
      "description": "Calendar period to aggregate into, with weeks starting on Monday.",
      "enum": [
        "week",
        "month",
        "quarter",
        "year"
      ],
      "type": "string"
    }
  },
  "required": [
    "date_col",
    "to",
    "metrics"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "by": [
    "harbor_code"
  ],
  "date_col": "harbor_day",
  "metrics": [
    {
      "as": "harbor_average",
      "fn": "mean",
      "of": "harbor_price"
    }
  ],
  "to": "month"
}
```

### window

Keep input columns and append a named running or rolling summary over the ordered frame.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the window calculation. |
| fn | "sum" / "mean" / "min" / "max" / "count" / "stddev" / "first" / "last" | yes | Calculation applied within each frame, with stddev using sample standard deviation and count counting non-null values. |
| frame | object | yes | Inclusive frame around the current row using row counts or ordered-value distances. |
| frame.following | integer or object | yes | Distance after the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps. |
| frame.following.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| frame.kind | "rows" / "range" | yes | Frame measure, using row counts for rows or ordered-value distances for range, measured in days for date or timestamp order columns. |
| frame.preceding | integer or object | yes | Distance before the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps. |
| frame.preceding.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| of | string; minLength: 1; maxLength: 128 | yes | Input column whose values are calculated within each frame. |
| order_by | array of object; minItems: 1; maxItems: 8 | yes | Columns and directions defining row order within each partition. |
| order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| partition_by | array of string; maxItems: 4 | no | Columns separating independent row groups, with all rows in one group when omitted. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "as": {
      "description": "Name of the new output column containing the window calculation.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "fn": {
      "description": "Calculation applied within each frame, with stddev using sample standard deviation and count counting non-null values.",
      "enum": [
        "sum",
        "mean",
        "min",
        "max",
        "count",
        "stddev",
        "first",
        "last"
      ],
      "type": "string"
    },
    "frame": {
      "additionalProperties": false,
      "description": "Inclusive frame around the current row using row counts or ordered-value distances.",
      "properties": {
        "following": {
          "anyOf": [
            {
              "maximum": 100000,
              "minimum": 0,
              "type": "integer"
            },
            {
              "additionalProperties": false,
              "properties": {
                "param": {
                  "description": "Declared parameter key supplying the integer value at run time.",
                  "maxLength": 40,
                  "pattern": "^[a-z][a-z0-9_]{0,39}$",
                  "type": "string"
                }
              },
              "required": [
                "param"
              ],
              "type": "object"
            }
          ],
          "description": "Distance after the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps."
        },
        "kind": {
          "description": "Frame measure, using row counts for rows or ordered-value distances for range, measured in days for date or timestamp order columns.",
          "enum": [
            "rows",
            "range"
          ],
          "type": "string"
        },
        "preceding": {
          "anyOf": [
            {
              "maximum": 100000,
              "minimum": 0,
              "type": "integer"
            },
            {
              "additionalProperties": false,
              "properties": {
                "param": {
                  "description": "Declared parameter key supplying the integer value at run time.",
                  "maxLength": 40,
                  "pattern": "^[a-z][a-z0-9_]{0,39}$",
                  "type": "string"
                }
              },
              "required": [
                "param"
              ],
              "type": "object"
            }
          ],
          "description": "Distance before the current row, as an integer or parameter reference, in rows for rows frames or order-column units for range frames, using days for dates and timestamps."
        }
      },
      "required": [
        "kind",
        "preceding",
        "following"
      ],
      "type": "object"
    },
    "of": {
      "description": "Input column whose values are calculated within each frame.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "order_by": {
      "description": "Columns and directions defining row order within each partition.",
      "items": {
        "additionalProperties": false,
        "properties": {
          "col": {
            "description": "Input column used to order rows.",
            "maxLength": 128,
            "minLength": 1,
            "type": "string"
          },
          "dir": {
            "description": "Sort direction, ascending for asc or descending for desc.",
            "enum": [
              "asc",
              "desc"
            ],
            "type": "string"
          }
        },
        "required": [
          "col",
          "dir"
        ],
        "type": "object"
      },
      "maxItems": 8,
      "minItems": 1,
      "type": "array"
    },
    "partition_by": {
      "description": "Columns separating independent row groups, with all rows in one group when omitted.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 4,
      "type": "array"
    }
  },
  "required": [
    "fn",
    "of",
    "order_by",
    "frame",
    "as"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "as": "harbor_rolling",
  "fn": "mean",
  "frame": {
    "following": 0,
    "kind": "rows",
    "preceding": 4
  },
  "of": "harbor_price",
  "order_by": [
    {
      "col": "harbor_day",
      "dir": "asc"
    }
  ],
  "partition_by": [
    "harbor_code"
  ]
}
```

## Statistics operations

### correlate

Return a long table with one row per distinct column pair and columns col_a, col_b, corr and n.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| columns | array of string; minItems: 2; maxItems: 32 | yes | Input columns for which each distinct pair receives a correlation result. |
| method | "pearson" / "spearman" | yes | Correlation method, using raw values for pearson or average ranks for spearman. |
| min_periods | integer; minimum: 2; maximum: 100000 | no | Minimum count of rows with both values present before returning a correlation, with no additional count threshold when omitted. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "columns": {
      "description": "Input columns for which each distinct pair receives a correlation result.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 32,
      "minItems": 2,
      "type": "array"
    },
    "method": {
      "description": "Correlation method, using raw values for pearson or average ranks for spearman.",
      "enum": [
        "pearson",
        "spearman"
      ],
      "type": "string"
    },
    "min_periods": {
      "description": "Minimum count of rows with both values present before returning a correlation, with no additional count threshold when omitted.",
      "maximum": 100000,
      "minimum": 2,
      "type": "integer"
    }
  },
  "required": [
    "columns",
    "method"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "columns": [
    "harbor_price",
    "harbor_volume"
  ],
  "method": "pearson",
  "min_periods": 5
}
```

### describe

Return a long table with one row per numeric column and columns column, count, mean, std, min, q25, median, q75 and max.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| columns | array of string; maxItems: 64 | no | Numeric input columns to summarise, defaulting to all numeric input columns when omitted. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "columns": {
      "description": "Numeric input columns to summarise, defaulting to all numeric input columns when omitted.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 64,
      "type": "array"
    }
  },
  "type": "object"
}
```

Example parameters:

```json
{
  "columns": [
    "harbor_price",
    "harbor_volume"
  ]
}
```

### rank

Keep input columns and append a named rank, dense rank, row number or percentile within each group.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the rank. |
| by | string; minLength: 1; maxLength: 128 | yes | Input column whose values determine the rank. |
| direction | "asc" / "desc" | yes | Ascending or descending order used to assign ranks. |
| method | "rank" / "dense" / "row_number" / "percentile" | yes | Ranking rule, using gaps for rank, no gaps for dense, distinct row numbers for row_number, or a fraction from 0 to 1 for percentile. |
| within | array of string; maxItems: 4 | no | Columns separating independent ranking groups, with all rows ranked together when omitted. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "as": {
      "description": "Name of the new output column containing the rank.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "by": {
      "description": "Input column whose values determine the rank.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "direction": {
      "description": "Ascending or descending order used to assign ranks.",
      "enum": [
        "asc",
        "desc"
      ],
      "type": "string"
    },
    "method": {
      "description": "Ranking rule, using gaps for rank, no gaps for dense, distinct row numbers for row_number, or a fraction from 0 to 1 for percentile.",
      "enum": [
        "rank",
        "dense",
        "row_number",
        "percentile"
      ],
      "type": "string"
    },
    "within": {
      "description": "Columns separating independent ranking groups, with all rows ranked together when omitted.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 4,
      "type": "array"
    }
  },
  "required": [
    "by",
    "direction",
    "method",
    "as"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "as": "harbor_rank",
  "by": "harbor_price",
  "direction": "desc",
  "method": "dense",
  "within": [
    "harbor_sector"
  ]
}
```

### regress

Return a long table of fitted intercept and predictor terms with grouping columns plus term, coefficient, r2 and n.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| by | array of string; maxItems: 4 | no | Columns separating independent regression groups, with one fit across the input when omitted. |
| x | array of string; minItems: 1; maxItems: 16 | yes | Predictor input columns for the regression, allowing 1 to 16 names in the schema. |
| y | string; minLength: 1; maxLength: 128 | yes | Dependent input column to fit. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "by": {
      "description": "Columns separating independent regression groups, with one fit across the input when omitted.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 4,
      "type": "array"
    },
    "x": {
      "description": "Predictor input columns for the regression, allowing 1 to 16 names in the schema.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 16,
      "minItems": 1,
      "type": "array"
    },
    "y": {
      "description": "Dependent input column to fit.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "y",
    "x"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "by": [
    "harbor_sector"
  ],
  "x": [
    "harbor_market",
    "harbor_size"
  ],
  "y": "harbor_return"
}
```

### zscore

Keep input columns and append a named distance from the mean in sample standard deviations, optionally over a full rolling window.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as | string; minLength: 1; maxLength: 128 | yes | Name of the new output column containing the dimensionless standard score. |
| of | string; minLength: 1; maxLength: 128 | yes | Input column standardised as its value minus the mean divided by sample standard deviation. |
| order_by | array of object; minItems: 1; maxItems: 8 | no | Columns and directions defining rolling row order, required when window is set and ignored otherwise. |
| order_by[].col | string; minLength: 1; maxLength: 128 | yes | Input column used to order rows. |
| order_by[].dir | "asc" / "desc" | yes | Sort direction, ascending for asc or descending for desc. |
| window | integer or object | no | Rolling frame size in rows including the current row, supplied as an integer or parameter reference, requiring that many non-null values and using the entire group when omitted. |
| window.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| within | array of string; maxItems: 4 | no | Columns separating independent standardisation groups, with all rows in one group when omitted. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "as": {
      "description": "Name of the new output column containing the dimensionless standard score.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "of": {
      "description": "Input column standardised as its value minus the mean divided by sample standard deviation.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "order_by": {
      "description": "Columns and directions defining rolling row order, required when window is set and ignored otherwise.",
      "items": {
        "additionalProperties": false,
        "properties": {
          "col": {
            "description": "Input column used to order rows.",
            "maxLength": 128,
            "minLength": 1,
            "type": "string"
          },
          "dir": {
            "description": "Sort direction, ascending for asc or descending for desc.",
            "enum": [
              "asc",
              "desc"
            ],
            "type": "string"
          }
        },
        "required": [
          "col",
          "dir"
        ],
        "type": "object"
      },
      "maxItems": 8,
      "minItems": 1,
      "type": "array"
    },
    "window": {
      "anyOf": [
        {
          "maximum": 100000,
          "minimum": 2,
          "type": "integer"
        },
        {
          "additionalProperties": false,
          "properties": {
            "param": {
              "description": "Declared parameter key supplying the integer value at run time.",
              "maxLength": 40,
              "pattern": "^[a-z][a-z0-9_]{0,39}$",
              "type": "string"
            }
          },
          "required": [
            "param"
          ],
          "type": "object"
        }
      ],
      "description": "Rolling frame size in rows including the current row, supplied as an integer or parameter reference, requiring that many non-null values and using the entire group when omitted."
    },
    "within": {
      "description": "Columns separating independent standardisation groups, with all rows in one group when omitted.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 4,
      "type": "array"
    }
  },
  "required": [
    "of",
    "as"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "as": "harbor_score",
  "of": "harbor_price",
  "order_by": [
    {
      "col": "harbor_day",
      "dir": "asc"
    }
  ],
  "window": 20,
  "within": [
    "harbor_code"
  ]
}
```

## Finance operations

### ai

Return model responses as a typed table for the whole input or individual rows using the declared text, enum or object output shape.

Inputs: 1. Output: table.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| instructions | string; minLength: 1; maxLength: 4000 | yes | Instructions for interpreting the input rows, containing 1 to 4000 characters. |
| max_input_chars | integer; minimum: 100; maximum: 60000; default: 20000 | no | Maximum input text length in characters, defaulting to 20000 when omitted. |
| max_rows | integer or object; default: 50 | no | Maximum input row count as an integer or parameter reference, defaulting to 50 when omitted. |
| max_rows.choice 2.param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key supplying the integer value at run time. |
| mode | "whole" / "per_row" | yes | Requested processing scope, either the whole input or each row separately. |
| on_error | "null" / "fail"; default: "null" | no | Declared error policy, either null or fail, defaulting to null when omitted. |
| output | object or object or object | yes | Declared result shape, either text, an enumerated string, or an object of typed fields. |
| output.choice 1.kind | "text" | yes | Result shape discriminator selecting text, enum, or object. |
| output.choice 2.kind | "enum" | yes | Result shape discriminator selecting text, enum, or object. |
| output.choice 2.values | array of string; minItems: 2; maxItems: 32 | yes | Allowed non-empty string result values for an enum output, containing 2 to 32 entries. |
| output.choice 3.fields | object | yes | Map of output column names to string, number, or boolean types, containing 1 to 32 fields. |
| output.choice 3.kind | "object" | yes | Result shape discriminator selecting text, enum, or object. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "instructions": {
      "description": "Instructions for interpreting the input rows, containing 1 to 4000 characters.",
      "maxLength": 4000,
      "minLength": 1,
      "type": "string"
    },
    "max_input_chars": {
      "default": 20000,
      "description": "Maximum input text length in characters, defaulting to 20000 when omitted.",
      "maximum": 60000,
      "minimum": 100,
      "type": "integer"
    },
    "max_rows": {
      "anyOf": [
        {
          "maximum": 200,
          "minimum": 1,
          "type": "integer"
        },
        {
          "additionalProperties": false,
          "properties": {
            "param": {
              "description": "Declared parameter key supplying the integer value at run time.",
              "maxLength": 40,
              "pattern": "^[a-z][a-z0-9_]{0,39}$",
              "type": "string"
            }
          },
          "required": [
            "param"
          ],
          "type": "object"
        }
      ],
      "default": 50,
      "description": "Maximum input row count as an integer or parameter reference, defaulting to 50 when omitted."
    },
    "mode": {
      "description": "Requested processing scope, either the whole input or each row separately.",
      "enum": [
        "whole",
        "per_row"
      ],
      "type": "string"
    },
    "on_error": {
      "default": "null",
      "description": "Declared error policy, either null or fail, defaulting to null when omitted.",
      "enum": [
        "null",
        "fail"
      ],
      "type": "string"
    },
    "output": {
      "description": "Declared result shape, either text, an enumerated string, or an object of typed fields.",
      "oneOf": [
        {
          "additionalProperties": false,
          "properties": {
            "kind": {
              "const": "text",
              "description": "Result shape discriminator selecting text, enum, or object.",
              "type": "string"
            }
          },
          "required": [
            "kind"
          ],
          "type": "object"
        },
        {
          "additionalProperties": false,
          "properties": {
            "kind": {
              "const": "enum",
              "description": "Result shape discriminator selecting text, enum, or object.",
              "type": "string"
            },
            "values": {
              "description": "Allowed non-empty string result values for an enum output, containing 2 to 32 entries.",
              "items": {
                "minLength": 1,
                "type": "string"
              },
              "maxItems": 32,
              "minItems": 2,
              "type": "array"
            }
          },
          "required": [
            "kind",
            "values"
          ],
          "type": "object"
        },
        {
          "additionalProperties": false,
          "properties": {
            "fields": {
              "additionalProperties": {
                "enum": [
                  "string",
                  "number",
                  "boolean"
                ],
                "type": "string"
              },
              "description": "Map of output column names to string, number, or boolean types, containing 1 to 32 fields.",
              "propertyNames": {
                "maxLength": 128,
                "minLength": 1,
                "type": "string"
              },
              "type": "object"
            },
            "kind": {
              "const": "object",
              "description": "Result shape discriminator selecting text, enum, or object.",
              "type": "string"
            }
          },
          "required": [
            "kind",
            "fields"
          ],
          "type": "object"
        }
      ]
    }
  },
  "required": [
    "mode",
    "instructions",
    "output"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "instructions": "Summarize the pattern in harbor_price and harbor_volume.",
  "max_input_chars": 20000,
  "max_rows": 50,
  "mode": "whole",
  "on_error": "null",
  "output": {
    "fields": {
      "harbor_summary": "string"
    },
    "kind": "object"
  }
}
```

### factor

Return one row per security on its latest eligible day with ts_code, trade_date and a column named after the chosen market factor.

Inputs: 1. Output: table.

The supported factor list, meanings and required columns are published in operations.json under factor.supported.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| as_of | string; maxLength: 10; pattern: "^\\d{4}-\\d{2}-\\d{2}$" | no | Latest eligible trading date in YYYY-MM-DD form, returning each security latest row on or before it or its latest available row when omitted. |
| factor | string; minLength: 1; maxLength: 60 | yes | Name of a supported market measure to calculate from the input daily rows. |
| universe | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | no | Data requirement key or step id whose ts_code column restricts the securities, with no universe restriction when omitted. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "as_of": {
      "description": "Latest eligible trading date in YYYY-MM-DD form, returning each security latest row on or before it or its latest available row when omitted.",
      "maxLength": 10,
      "pattern": "^\\d{4}-\\d{2}-\\d{2}$",
      "type": "string"
    },
    "factor": {
      "description": "Name of a supported market measure to calculate from the input daily rows.",
      "maxLength": 60,
      "minLength": 1,
      "type": "string"
    },
    "universe": {
      "description": "Data requirement key or step id whose ts_code column restricts the securities, with no universe restriction when omitted.",
      "maxLength": 40,
      "pattern": "^[a-z][a-z0-9_]{0,39}$",
      "type": "string"
    }
  },
  "required": [
    "factor"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "as_of": "2026-01-30",
  "factor": "momentum_20d",
  "universe": "harbor_universe"
}
```

Supported factors (ts_code and trade_date are required for every factor):

| Factor | Meaning | Additional columns |
| --- | --- | --- |
| avg_amount_20d | average daily traded value over the last 20 trading days | amount |
| avg_volume_20d | average daily volume over the last 20 trading days | vol |
| book_to_price | book value per unit of price (1 / P/B), blank when book value is negative | pb |
| dividend_yield | dividends of the last 12 months per unit of price, as a fraction | dv_ttm |
| earnings_yield | earnings per unit of price (1 / P/E), blank when earnings are negative | pe |
| high_gap_250d | how far the price sits below its highest close of the last 250 trading days | close |
| log_size | natural logarithm of total market value | total_mv |
| ma_gap_20d | how far the price sits above its 20-day average | close |
| ma_gap_60d | how far the price sits above its 60-day average | close |
| momentum_120d | price change over the last 120 trading days | close |
| momentum_20d | price change over the last 20 trading days | close |
| momentum_250d | price change over the last 250 trading days | close |
| momentum_5d | price change over the last 5 trading days | close |
| momentum_60d | price change over the last 60 trading days | close |
| turnover_20d | average daily turnover rate over the last 20 trading days | turnover_rate |
| volatility_20d | yearly-scaled spread of daily returns over the last 20 trading days | close |
| volatility_60d | yearly-scaled spread of daily returns over the last 60 trading days | close |
| volume_ratio_5_20d | average volume of the last 5 days divided by that of the last 20 | vol |

### irr

Return one annual break-even rate as a scalar value, read from the single irr column.

Inputs: 1. Output: scalar.

Parameters:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| amount_col | string; minLength: 1; maxLength: 128 | yes | Cash flow amount column in a consistent monetary unit, with payments out negative and receipts positive. |
| date_col | string; minLength: 1; maxLength: 128 | yes | Cash flow date column used to count elapsed days over a 365-day year. |
| guess | number | no | Initial annual rate as a fraction for the iterative solver, defaulting to 0.1 when omitted. |
| max_iter | integer; minimum: 1; maximum: 100; default: 100 | no | Maximum number of Newton iterations before the fallback solver, defaulting to 100 when omitted. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "amount_col": {
      "description": "Cash flow amount column in a consistent monetary unit, with payments out negative and receipts positive.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "date_col": {
      "description": "Cash flow date column used to count elapsed days over a 365-day year.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "guess": {
      "description": "Initial annual rate as a fraction for the iterative solver, defaulting to 0.1 when omitted.",
      "type": "number"
    },
    "max_iter": {
      "default": 100,
      "description": "Maximum number of Newton iterations before the fallback solver, defaulting to 100 when omitted.",
      "maximum": 100,
      "minimum": 1,
      "type": "integer"
    }
  },
  "required": [
    "amount_col",
    "date_col"
  ],
  "type": "object"
}
```

Example parameters:

```json
{
  "amount_col": "harbor_payment",
  "date_col": "harbor_day",
  "guess": 0.1,
  "max_iter": 100
}
```

## Display components

### Callout

Show a note with an optional title and semantic tone.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| text | string; minLength: 1; maxLength: 2000 | yes | Text content displayed by the element. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Callout" | yes | Element type discriminator selecting the declared screen component. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "text": {
      "description": "Text content displayed by the element.",
      "maxLength": 2000,
      "minLength": 1,
      "type": "string"
    },
    "title": {
      "description": "Optional heading text for this element, with no heading specified when omitted.",
      "maxLength": 120,
      "minLength": 1,
      "type": "string"
    },
    "tone": {
      "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
      "enum": [
        "default",
        "positive",
        "negative",
        "warning",
        "muted"
      ],
      "type": "string"
    },
    "type": {
      "const": "Callout",
      "description": "Element type discriminator selecting the declared screen component.",
      "type": "string"
    }
  },
  "required": [
    "type",
    "text"
  ],
  "type": "object"
}
```

### List

Show result rows as items with titles and optional bodies, links, tones and groups.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| emptyHint | string; minLength: 1; maxLength: 200 | no | Optional message for an empty result, with no custom message when omitted. |
| from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| groupBy | string; minLength: 1; maxLength: 128 | no | Optional result column used to group list items, with no grouping column when omitted. |
| itemBody | string; minLength: 1; maxLength: 128 | no | Optional result column supplying each list item body, with no body column when omitted. |
| itemLink | string; minLength: 1; maxLength: 128 | no | Optional result column supplying each list item link, with no link column when omitted. |
| itemTitle | string; minLength: 1; maxLength: 128 | yes | Result column supplying each list item title. |
| itemTone | string; minLength: 1; maxLength: 128 | no | Optional result column supplying each list item tone, with no per-item tone column when omitted. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "List" | yes | Element type discriminator selecting the declared screen component. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "emptyHint": {
      "description": "Optional message for an empty result, with no custom message when omitted.",
      "maxLength": 200,
      "minLength": 1,
      "type": "string"
    },
    "from": {
      "description": "Data requirement key or step id providing the displayed result.",
      "maxLength": 40,
      "pattern": "^[a-z][a-z0-9_]{0,39}$",
      "type": "string"
    },
    "groupBy": {
      "description": "Optional result column used to group list items, with no grouping column when omitted.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "itemBody": {
      "description": "Optional result column supplying each list item body, with no body column when omitted.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "itemLink": {
      "description": "Optional result column supplying each list item link, with no link column when omitted.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "itemTitle": {
      "description": "Result column supplying each list item title.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "itemTone": {
      "description": "Optional result column supplying each list item tone, with no per-item tone column when omitted.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "title": {
      "description": "Optional heading text for this element, with no heading specified when omitted.",
      "maxLength": 120,
      "minLength": 1,
      "type": "string"
    },
    "tone": {
      "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
      "enum": [
        "default",
        "positive",
        "negative",
        "warning",
        "muted"
      ],
      "type": "string"
    },
    "type": {
      "const": "List",
      "description": "Element type discriminator selecting the declared screen component.",
      "type": "string"
    }
  },
  "required": [
    "type",
    "from",
    "itemTitle"
  ],
  "type": "object"
}
```

### Metric

Show one formatted result value with an optional change and unit.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| change | string; minLength: 1; maxLength: 128 | no | Optional result column providing the metric change, with no change column when omitted. |
| format | "number" / "money" / "percent" / "integer"; default: "number" | no | Metric display format, defaulting to number when omitted. |
| from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Metric" | yes | Element type discriminator selecting the declared screen component. |
| unit | string; minLength: 1; maxLength: 16 | no | Optional displayed unit label, with no unit label when omitted. |
| value | string; minLength: 1; maxLength: 128 | yes | Result column providing the metric value. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "change": {
      "description": "Optional result column providing the metric change, with no change column when omitted.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "format": {
      "default": "number",
      "description": "Metric display format, defaulting to number when omitted.",
      "enum": [
        "number",
        "money",
        "percent",
        "integer"
      ],
      "type": "string"
    },
    "from": {
      "description": "Data requirement key or step id providing the displayed result.",
      "maxLength": 40,
      "pattern": "^[a-z][a-z0-9_]{0,39}$",
      "type": "string"
    },
    "label": {
      "description": "Display label for this element.",
      "maxLength": 60,
      "minLength": 1,
      "type": "string"
    },
    "tone": {
      "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
      "enum": [
        "default",
        "positive",
        "negative",
        "warning",
        "muted"
      ],
      "type": "string"
    },
    "type": {
      "const": "Metric",
      "description": "Element type discriminator selecting the declared screen component.",
      "type": "string"
    },
    "unit": {
      "description": "Optional displayed unit label, with no unit label when omitted.",
      "maxLength": 16,
      "minLength": 1,
      "type": "string"
    },
    "value": {
      "description": "Result column providing the metric value.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    }
  },
  "required": [
    "type",
    "label",
    "from",
    "value"
  ],
  "type": "object"
}
```

### Table

Show result rows in named, formatted columns with pagination.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| columns | array of object; minItems: 1; maxItems: 40 | yes | Ordered declarations of the result columns displayed in the table. |
| columns[].col | string; minLength: 1; maxLength: 128 | yes | Result column to display in this table column. |
| columns[].format | "text" / "number" / "money" / "percent" / "date" / "integer" | no | Optional display format for this column, with no format specified when omitted. |
| columns[].label | string; minLength: 1; maxLength: 60 | no | Optional display label for the column, with no label specified when omitted. |
| emptyHint | string; minLength: 1; maxLength: 200 | no | Optional message for an empty result, with no custom message when omitted. |
| from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| pageSize | integer; minimum: 5; maximum: 200; default: 25 | no | Number of table rows per page, defaulting to 25 when omitted. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Table" | yes | Element type discriminator selecting the declared screen component. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "columns": {
      "description": "Ordered declarations of the result columns displayed in the table.",
      "items": {
        "additionalProperties": false,
        "properties": {
          "col": {
            "description": "Result column to display in this table column.",
            "maxLength": 128,
            "minLength": 1,
            "type": "string"
          },
          "format": {
            "description": "Optional display format for this column, with no format specified when omitted.",
            "enum": [
              "text",
              "number",
              "money",
              "percent",
              "date",
              "integer"
            ],
            "type": "string"
          },
          "label": {
            "description": "Optional display label for the column, with no label specified when omitted.",
            "maxLength": 60,
            "minLength": 1,
            "type": "string"
          }
        },
        "required": [
          "col"
        ],
        "type": "object"
      },
      "maxItems": 40,
      "minItems": 1,
      "type": "array"
    },
    "emptyHint": {
      "description": "Optional message for an empty result, with no custom message when omitted.",
      "maxLength": 200,
      "minLength": 1,
      "type": "string"
    },
    "from": {
      "description": "Data requirement key or step id providing the displayed result.",
      "maxLength": 40,
      "pattern": "^[a-z][a-z0-9_]{0,39}$",
      "type": "string"
    },
    "pageSize": {
      "default": 25,
      "description": "Number of table rows per page, defaulting to 25 when omitted.",
      "maximum": 200,
      "minimum": 5,
      "type": "integer"
    },
    "title": {
      "description": "Optional heading text for this element, with no heading specified when omitted.",
      "maxLength": 120,
      "minLength": 1,
      "type": "string"
    },
    "tone": {
      "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
      "enum": [
        "default",
        "positive",
        "negative",
        "warning",
        "muted"
      ],
      "type": "string"
    },
    "type": {
      "const": "Table",
      "description": "Element type discriminator selecting the declared screen component.",
      "type": "string"
    }
  },
  "required": [
    "type",
    "from",
    "columns"
  ],
  "type": "object"
}
```

### Text

Show prose as a heading, body or caption.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| emphasis | "heading" / "body" / "caption"; default: "body" | no | Text presentation role, defaulting to body when omitted. |
| text | string; minLength: 1; maxLength: 4000 | yes | Text content displayed by the element. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Text" | yes | Element type discriminator selecting the declared screen component. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "emphasis": {
      "default": "body",
      "description": "Text presentation role, defaulting to body when omitted.",
      "enum": [
        "heading",
        "body",
        "caption"
      ],
      "type": "string"
    },
    "text": {
      "description": "Text content displayed by the element.",
      "maxLength": 4000,
      "minLength": 1,
      "type": "string"
    },
    "tone": {
      "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
      "enum": [
        "default",
        "positive",
        "negative",
        "warning",
        "muted"
      ],
      "type": "string"
    },
    "type": {
      "const": "Text",
      "description": "Element type discriminator selecting the declared screen component.",
      "type": "string"
    }
  },
  "required": [
    "type",
    "text"
  ],
  "type": "object"
}
```

## Chart components

### Chart

Plot daily results as a line, bar, candlestick or heatmap chart.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| chart | "line" / "bar" / "candlestick" / "heatmap" | yes | Chart kind, either line, bar, candlestick, or heatmap. |
| from | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Data requirement key or step id providing the displayed result. |
| heat | object | no | Second-axis and value result columns, required for heatmaps and otherwise optional. |
| heat.value | string; minLength: 1; maxLength: 128 | yes | Result column supplying the heatmap cell value. |
| heat.y | string; minLength: 1; maxLength: 128 | yes | Result column supplying the heatmap second axis. |
| ohlc | object | no | Open, high, low, and close result columns, required for candlestick charts and otherwise optional. |
| ohlc.close | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle closing price. |
| ohlc.high | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle highest price. |
| ohlc.low | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle lowest price. |
| ohlc.open | string; minLength: 1; maxLength: 128 | yes | Result column containing each candle opening price. |
| series | string; minLength: 1; maxLength: 128 | no | Text result column whose distinct values each become their own line or bar group, for example one line per company; only for line and bar charts with exactly one y column; at most 20 groups are drawn, the rest are listed as hidden. |
| stacked | boolean | no | Optional request to stack chart series, with no stacking request when omitted. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Chart" | yes | Element type discriminator selecting the declared screen component. |
| x | string; minLength: 1; maxLength: 128 | yes | Result column supplying the horizontal axis. |
| y | array of string; maxItems: 8 | no | Result columns supplying line or bar series, required and non-empty for those chart kinds and otherwise optional. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "chart": {
      "description": "Chart kind, either line, bar, candlestick, or heatmap.",
      "enum": [
        "line",
        "bar",
        "candlestick",
        "heatmap"
      ],
      "type": "string"
    },
    "from": {
      "description": "Data requirement key or step id providing the displayed result.",
      "maxLength": 40,
      "pattern": "^[a-z][a-z0-9_]{0,39}$",
      "type": "string"
    },
    "heat": {
      "additionalProperties": false,
      "description": "Second-axis and value result columns, required for heatmaps and otherwise optional.",
      "properties": {
        "value": {
          "description": "Result column supplying the heatmap cell value.",
          "maxLength": 128,
          "minLength": 1,
          "type": "string"
        },
        "y": {
          "description": "Result column supplying the heatmap second axis.",
          "maxLength": 128,
          "minLength": 1,
          "type": "string"
        }
      },
      "required": [
        "y",
        "value"
      ],
      "type": "object"
    },
    "ohlc": {
      "additionalProperties": false,
      "description": "Open, high, low, and close result columns, required for candlestick charts and otherwise optional.",
      "properties": {
        "close": {
          "description": "Result column containing each candle closing price.",
          "maxLength": 128,
          "minLength": 1,
          "type": "string"
        },
        "high": {
          "description": "Result column containing each candle highest price.",
          "maxLength": 128,
          "minLength": 1,
          "type": "string"
        },
        "low": {
          "description": "Result column containing each candle lowest price.",
          "maxLength": 128,
          "minLength": 1,
          "type": "string"
        },
        "open": {
          "description": "Result column containing each candle opening price.",
          "maxLength": 128,
          "minLength": 1,
          "type": "string"
        }
      },
      "required": [
        "open",
        "high",
        "low",
        "close"
      ],
      "type": "object"
    },
    "series": {
      "description": "Text result column whose distinct values each become their own line or bar group, for example one line per company; only for line and bar charts with exactly one y column; at most 20 groups are drawn, the rest are listed as hidden.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "stacked": {
      "description": "Optional request to stack chart series, with no stacking request when omitted.",
      "type": "boolean"
    },
    "title": {
      "description": "Optional heading text for this element, with no heading specified when omitted.",
      "maxLength": 120,
      "minLength": 1,
      "type": "string"
    },
    "tone": {
      "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
      "enum": [
        "default",
        "positive",
        "negative",
        "warning",
        "muted"
      ],
      "type": "string"
    },
    "type": {
      "const": "Chart",
      "description": "Element type discriminator selecting the declared screen component.",
      "type": "string"
    },
    "x": {
      "description": "Result column supplying the horizontal axis.",
      "maxLength": 128,
      "minLength": 1,
      "type": "string"
    },
    "y": {
      "description": "Result columns supplying line or bar series, required and non-empty for those chart kinds and otherwise optional.",
      "items": {
        "maxLength": 128,
        "minLength": 1,
        "type": "string"
      },
      "maxItems": 8,
      "type": "array"
    }
  },
  "required": [
    "type",
    "chart",
    "from",
    "x"
  ],
  "type": "object"
}
```

## Control components

### DateRangeInput

Edit the two named parameters that define a date range.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| fromParam | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited as the start date of the range. |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| toParam | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited as the end date of the range. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "DateRangeInput" | yes | Element type discriminator selecting the declared screen component. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "fromParam": {
      "description": "Declared parameter key edited as the start date of the range.",
      "maxLength": 40,
      "pattern": "^[a-z][a-z0-9_]{0,39}$",
      "type": "string"
    },
    "label": {
      "description": "Display label for this element.",
      "maxLength": 60,
      "minLength": 1,
      "type": "string"
    },
    "toParam": {
      "description": "Declared parameter key edited as the end date of the range.",
      "maxLength": 40,
      "pattern": "^[a-z][a-z0-9_]{0,39}$",
      "type": "string"
    },
    "tone": {
      "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
      "enum": [
        "default",
        "positive",
        "negative",
        "warning",
        "muted"
      ],
      "type": "string"
    },
    "type": {
      "const": "DateRangeInput",
      "description": "Element type discriminator selecting the declared screen component.",
      "type": "string"
    }
  },
  "required": [
    "type",
    "fromParam",
    "toParam",
    "label"
  ],
  "type": "object"
}
```

### NumberInput

Edit a named numeric parameter.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited by this control. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "NumberInput" | yes | Element type discriminator selecting the declared screen component. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "label": {
      "description": "Display label for this element.",
      "maxLength": 60,
      "minLength": 1,
      "type": "string"
    },
    "param": {
      "description": "Declared parameter key edited by this control.",
      "maxLength": 40,
      "pattern": "^[a-z][a-z0-9_]{0,39}$",
      "type": "string"
    },
    "tone": {
      "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
      "enum": [
        "default",
        "positive",
        "negative",
        "warning",
        "muted"
      ],
      "type": "string"
    },
    "type": {
      "const": "NumberInput",
      "description": "Element type discriminator selecting the declared screen component.",
      "type": "string"
    }
  },
  "required": [
    "type",
    "param",
    "label"
  ],
  "type": "object"
}
```

### RunButton

Run the application with its current settings.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| label | string; minLength: 1; maxLength: 40; default: "Run" | no | Button label, defaulting to Run when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "RunButton" | yes | Element type discriminator selecting the declared screen component. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "label": {
      "default": "Run",
      "description": "Button label, defaulting to Run when omitted.",
      "maxLength": 40,
      "minLength": 1,
      "type": "string"
    },
    "tone": {
      "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
      "enum": [
        "default",
        "positive",
        "negative",
        "warning",
        "muted"
      ],
      "type": "string"
    },
    "type": {
      "const": "RunButton",
      "description": "Element type discriminator selecting the declared screen component.",
      "type": "string"
    }
  },
  "required": [
    "type"
  ],
  "type": "object"
}
```

### SelectInput

Choose among the declared options of a named text parameter.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited by this control. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "SelectInput" | yes | Element type discriminator selecting the declared screen component. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "label": {
      "description": "Display label for this element.",
      "maxLength": 60,
      "minLength": 1,
      "type": "string"
    },
    "param": {
      "description": "Declared parameter key edited by this control.",
      "maxLength": 40,
      "pattern": "^[a-z][a-z0-9_]{0,39}$",
      "type": "string"
    },
    "tone": {
      "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
      "enum": [
        "default",
        "positive",
        "negative",
        "warning",
        "muted"
      ],
      "type": "string"
    },
    "type": {
      "const": "SelectInput",
      "description": "Element type discriminator selecting the declared screen component.",
      "type": "string"
    }
  },
  "required": [
    "type",
    "param",
    "label"
  ],
  "type": "object"
}
```

### TextInput

Edit a named text parameter or list of text values.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| label | string; minLength: 1; maxLength: 60 | yes | Display label for this element. |
| list | boolean; default: false | no | Whether text input displays a string list as chips, defaulting to false when omitted. |
| param | string; maxLength: 40; pattern: "^[a-z][a-z0-9_]{0,39}$" | yes | Declared parameter key edited by this control. |
| placeholder | string; minLength: 1; maxLength: 80 | no | Optional text input hint, with no placeholder specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "TextInput" | yes | Element type discriminator selecting the declared screen component. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "label": {
      "description": "Display label for this element.",
      "maxLength": 60,
      "minLength": 1,
      "type": "string"
    },
    "list": {
      "default": false,
      "description": "Whether text input displays a string list as chips, defaulting to false when omitted.",
      "type": "boolean"
    },
    "param": {
      "description": "Declared parameter key edited by this control.",
      "maxLength": 40,
      "pattern": "^[a-z][a-z0-9_]{0,39}$",
      "type": "string"
    },
    "placeholder": {
      "description": "Optional text input hint, with no placeholder specified when omitted.",
      "maxLength": 80,
      "minLength": 1,
      "type": "string"
    },
    "tone": {
      "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
      "enum": [
        "default",
        "positive",
        "negative",
        "warning",
        "muted"
      ],
      "type": "string"
    },
    "type": {
      "const": "TextInput",
      "description": "Element type discriminator selecting the declared screen component.",
      "type": "string"
    }
  },
  "required": [
    "type",
    "param",
    "label"
  ],
  "type": "object"
}
```

## Layout components

### Section

Arrange child elements in one, two or three columns with an optional title.

Properties:

| Name | Type | Required | Meaning |
| --- | --- | --- | --- |
| children | array of string; maxItems: 32 | yes | Ordered element ids contained by this section. |
| columns | 1 or 2 or 3; default: 1 | no | Number of section layout columns, defaulting to 1 when omitted. |
| title | string; minLength: 1; maxLength: 120 | no | Optional heading text for this element, with no heading specified when omitted. |
| tone | "default" / "positive" / "negative" / "warning" / "muted" | no | Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted. |
| type | "Section" | yes | Element type discriminator selecting the declared screen component. |

```json
{
  "$schema": "https://json-schema.org/draft/2020-12/schema",
  "additionalProperties": false,
  "properties": {
    "children": {
      "description": "Ordered element ids contained by this section.",
      "items": {
        "maxLength": 40,
        "pattern": "^[a-z][a-z0-9_]{0,39}$",
        "type": "string"
      },
      "maxItems": 32,
      "type": "array"
    },
    "columns": {
      "anyOf": [
        {
          "const": 1,
          "type": "number"
        },
        {
          "const": 2,
          "type": "number"
        },
        {
          "const": 3,
          "type": "number"
        }
      ],
      "default": 1,
      "description": "Number of section layout columns, defaulting to 1 when omitted."
    },
    "title": {
      "description": "Optional heading text for this element, with no heading specified when omitted.",
      "maxLength": 120,
      "minLength": 1,
      "type": "string"
    },
    "tone": {
      "description": "Optional semantic tone mapped to colours by the active theme, with no tone specified when omitted.",
      "enum": [
        "default",
        "positive",
        "negative",
        "warning",
        "muted"
      ],
      "type": "string"
    },
    "type": {
      "const": "Section",
      "description": "Element type discriminator selecting the declared screen component.",
      "type": "string"
    }
  },
  "required": [
    "type",
    "children"
  ],
  "type": "object"
}
```

## Errors

Codes beginning with E_ block validation; codes beginning with W_ are warnings.

### E_BAD_CRON

A schedule is not a valid five-field cron expression.

### E_BAD_EXPRESSION

A formula could not be understood.

### E_BAD_SQL

A SQL step is not a single SELECT or WITH, or uses something not allowed.

### E_CYCLE

Two or more steps depend on each other, so no order can run them.

### E_ELEMENT_CYCLE

Sections contain each other in a loop.

### E_INTERNAL

The checker could not finish checking this application.

### E_LIMIT_AI_STEPS

More than four AI steps in one application.

### E_LIMIT_CODE_STEPS

More than one custom-code step in one application.

### E_LIMIT_ELEMENTS

Too many screen elements.

### E_LIMIT_NESTING

Sections are nested too deeply.

### E_LIMIT_STEPS

Too many calculation steps.

### E_NO_TRIGGER

An application needs at least one trigger.

### E_PARSE_EMPTY

The file is empty.

### E_PARSE_JSON

The file is not valid JSON.

### E_PARSE_NOT_OBJECT

The top level of an application must be a JSON object.

### E_REF_DUPLICATE_NAME

Two things claim the same name. Data keys and step ids share one namespace.

### E_REF_UNKNOWN_ELEMENT

A section lists a child element that does not exist.

### E_REF_UNKNOWN_PARAM

Something names a parameter that was never declared.

### E_REF_UNKNOWN_RELATION

A step reads a table that no data requirement or earlier step produces.

### E_REF_UNKNOWN_ROOT

The screen names a root element that does not exist.

### E_SCHEMA_CUSTOM

A value broke a rule specific to this field.

### E_SCHEMA_ENUM

A value is not one of the allowed choices.

### E_SCHEMA_PATTERN

A value does not match the required form.

### E_SCHEMA_RANGE

A number or a length is outside the allowed range.

### E_SCHEMA_REQUIRED

A required field is missing.

### E_SCHEMA_SPEC_VERSION

The specification version is missing or unsupported.

### E_SCHEMA_TYPE

A value is the wrong type.

### E_SCHEMA_UNION

A value does not match any allowed shape.

### E_SCHEMA_UNKNOWN_KEY

A key is not part of the specification. Usually a typo.

### E_SELF_REFERENCE

A step reads its own output.

### E_TOO_MANY_ERRORS

More problems were found than one report can show.

### W_CODE_COULD_BE_OPERATION

A custom-code step does something a named operation already does.

### W_DEAD_CONTROL

A parameter has a control on screen but nothing in the calculation reads it, so the control does nothing.

### W_NO_MANUAL_TRIGGER

The application cannot be run by hand.

### W_ORPHAN_ELEMENT

An element is declared but nothing on the screen shows it.

### W_SHORT_HISTORY

The data does not go back as far as this application asks for.

### W_SQL_COULD_BE_OPERATION

A SQL step does something a named operation already does.

### W_SURROUNDING_TEXT

The application was wrapped in a code fence or surrounded by prose. It was read anyway.

### W_UNKNOWN_ICON

The icon name is not one we ship. A default will be used.

### W_UNUSED_DATA

A data requirement is declared but no step reads it.

### W_UNUSED_PARAM

A parameter is declared but nothing uses it.

### W_UNUSED_STEP

A step produces a table that nothing reads.
