// Runtime dependencies must not compile or run install scripts.
// Shipped prebuilt native binaries (.node files) are allowed: they need no compiler.
import { readFileSync, statSync, lstatSync, realpathSync } from 'node:fs';
import { resolve, join, sep } from 'node:path';

function exists(path) {
  try {
    statSync(path);
    return true;
  } catch (error) {
    if (error.code === 'ENOENT') return false;
    throw error;
  }
}

try {
  const args = process.argv.slice(2);
  const verbose = args.includes('--verbose');
  const directories = args.filter(arg => arg !== '--verbose');
  if (directories.length > 1 || directories.some(arg => arg.startsWith('--'))) {
    throw new Error('Usage: node scripts/check-deps.mjs [project-directory] [--verbose]');
  }
  const project = realpathSync(resolve(directories[0] ?? process.cwd()));
  const lock = JSON.parse(readFileSync(join(project, 'package-lock.json'), 'utf8'));
  if (lock.lockfileVersion !== 3 || !lock.packages || typeof lock.packages !== 'object' || Array.isArray(lock.packages)) {
    throw new Error('Expected package-lock.json with lockfileVersion 3 and a packages map');
  }

  for (const location of Object.keys(lock.packages)) {
    if (location.startsWith('/') || location.split('/').includes('..')) {
      throw new Error(`Malformed lock: package key "${location}" must not be absolute or contain ".." segments`);
    }
  }

  function existsInside(path) {
    let current = project;
    for (const segment of path.slice(project.length + 1).split(sep)) {
      current = join(current, segment);
      let stat;
      try {
        stat = lstatSync(current);
      } catch (error) {
        if (error.code === 'ENOENT') return false;
        throw error;
      }
      if (stat.isSymbolicLink() && !realpathSync(current).startsWith(join(project, 'node_modules') + sep)) {
        throw new Error(`Package path ${path} is a symbolic link outside node_modules; the judges' install cannot verify it`);
      }
    }
    return exists(path);
  }

  let count = 0;
  let missing = 0;
  let offenders = 0;
  for (const [location, entry] of Object.entries(lock.packages)) {
    if (!location.startsWith('node_modules/')) continue;
    if (entry.link === true) {
      const target = Object.hasOwn(lock.packages, entry.resolved) ? lock.packages[entry.resolved] : undefined;
      if (target?.dev === true) continue;
      const name = location.slice(location.lastIndexOf('node_modules/') + 'node_modules/'.length);
      throw new Error(`runtime dependency ${name} is a linked local package; the judges' install cannot verify it`);
    }
    if (entry.dev === true) continue;
    count++;
    const label = location || '(project root)';
    const reasons = [];
    if (entry.hasInstallScript === true) reasons.push('hasInstallScript: true in lock');

    const root = resolve(project, location);
    const present = existsInside(root);
    if (present) {
      const manifestPath = join(root, 'package.json');
      if (existsInside(manifestPath)) {
        const manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
        for (const hook of ['preinstall', 'install', 'postinstall']) {
          if (Object.hasOwn(manifest.scripts ?? {}, hook)) reasons.push(`package.json scripts.${hook}`);
        }
      }
      if (existsInside(join(root, 'binding.gyp'))) reasons.push('binding.gyp at package root');
    } else {
      missing++;
    }
    const note = present ? '' : ' (not present in node_modules; checked from lock alone)';
    if (reasons.length) {
      offenders++;
      console.error(`${label}: ${reasons.join('; ')}${note}`);
    }
    if (verbose) console.log(`Checked ${label}: ${reasons.length ? 'FAIL' : 'OK'}${note}`);
  }

  const note = missing ? ` ${missing} not present in node_modules; checked from lock alone.` : '';
  if (offenders) {
    console.error(`Dependency guard: ${count} runtime packages, ${offenders} offenders.${note}`);
    process.exitCode = 1;
  } else {
    console.log(`Dependency guard: ${count} runtime packages, none compiles or runs an install script.${note}`);
  }
} catch (error) {
  console.error(`Dependency guard: ${error.message}`);
  process.exitCode = 1;
}
