export type NodeRuntime = { executable: string; version: string };

export function isSupportedNodeVersion(version: string): boolean;
export function resolveNode(): NodeRuntime;
export function createRuntimeEnvironment(executable: string): NodeJS.ProcessEnv;
export function launchServer(runtime: NodeRuntime): void;
