/** Explicit live-data acceptance helper. Never run by startup or automated checks. */
import { resolve } from 'node:path';
import { validateApplication } from '../src/validate/index.ts';
import { saveApp, setState, getState, listRuns, runSavedApplication, realExecutionAdapter,
  createScheduledTask, configureScheduledTask, getScheduledTask } from '../src/platform/index.ts';

const [company, endDate] = process.argv.slice(2);
if (!company || !/^[0-9]{6}\.(SH|SZ|BJ)$/.test(company) || !endDate || !/^\d{4}-\d{2}-\d{2}$/.test(endDate)) {
  throw new Error('Usage: node scripts/c8-manual.ts <company code> <historical YYYY-MM-DD>');
}
if (!process.env.BLOCKS_DB_PATH || resolve(process.env.BLOCKS_DB_PATH) === resolve('data/blocks.sqlite')) {
  throw new Error('Set BLOCKS_DB_PATH to a separate acceptance database first.');
}
const profile = 'c8-manual';
const checked = validateApplication({
  meta: { name: 'C8 live daily acceptance', description: 'Explicit live daily data check with a separate local profile.', spec_version: '1.0', provenance: { created_by: 'platform' } },
  params: [{ key: 'company', label: 'Company code', type: 'text' }],
  data: [{ key: 'prices', fields: [
    { name: 'company', type: 'text', required: true },
    { name: 'day', type: 'date', required: true },
    { name: 'close', type: 'number', required: true },
  ], window: { field: 'day', lookbackDays: 3 }, filters: [{ field: 'company', op: 'eq', param: 'company' }] }],
  compute: [{ id: 'daily_rows', kind: 'operation', op: 'sort_limit', input: 'prices', params: { by: [{ col: 'day', dir: 'asc' }] } }],
  triggers: [{ kind: 'manual' }, { kind: 'schedule', cron: '0 8 * * 1-5', tz: 'Asia/Shanghai' }],
  ui: { root: 'chart', elements: { chart: { type: 'Chart', chart: 'line', from: 'daily_rows', x: 'day', y: ['close'], series: 'company' } } },
});
if (!checked.ok) throw new Error('The acceptance application failed document validation.');
const app = await saveApp(checked.document, profile);
await setState(app.id, profile, { params: { company }, bindings: { prices: 'tushare:daily' },
  mappings: { prices: { company: 'ts_code', day: 'trade_date' } }, carry: { acceptanceMarker: 'keep' } });
const adapter = realExecutionAdapter({ today: endDate });
const runId = `manual_${app.id}`;
const first = await runSavedApplication({ appId: app.id, profile, runId, adapter });
if (first.kind !== 'completed') {
  console.log(JSON.stringify(first));
  process.exit(1);
}
const output = first.record.result?.outputs.daily_rows;
console.log(JSON.stringify({ phase: 'manual', appId: app.id, runId, status: first.record.status,
  failure: first.record.failure, source: first.record.dataSource, asOfDate: first.record.asOfDate,
  versions: first.record.datasetVersions, sources: first.record.sources?.map(({ key, datasetId, rows, asOfDate, datasetVersion, warnings }) => ({ key, datasetId, rows, ...(asOfDate === undefined ? {} : { asOfDate }), datasetVersion, warnings })), rows: output?.rows.length, columns: output?.schema.map((field) => field.name) }));
if (first.record.status === 'failed') process.exitCode = 1;
else {
  const repeat = await runSavedApplication({ appId: app.id, profile, runId, adapter });
  console.log(JSON.stringify({ phase: 'retry', reused: repeat.kind === 'completed' && repeat.reused, savedRuns: (await listRuns(app.id)).length }));
  const task = await createScheduledTask(app.id, profile, 1);
  const scheduledFor = new Date().toISOString();
  await configureScheduledTask(task.id, profile, { enabled: true, nextRunAt: scheduledFor });
  const scheduled = await runSavedApplication({ appId: app.id, profile, adapter, scheduled: { taskId: task.id, scheduledFor } });
  console.log(JSON.stringify({ phase: 'scheduled', status: scheduled.kind === 'completed' ? scheduled.record.status : scheduled.kind,
    task: await getScheduledTask(task.id, profile) }));
  const before = await getState(app.id, profile);
  await setState(app.id, profile, { ...before, bindings: {} });
  const connectionRunId = `connection_${app.id}`;
  const blocked = await runSavedApplication({ appId: app.id, profile, runId: connectionRunId, adapter });
  const after = await getState(app.id, profile);
  console.log(JSON.stringify({ phase: 'missing_binding', kind: blocked.kind,
    issue: blocked.kind === 'needs_data' ? blocked.issue : undefined,
    carryPreserved: JSON.stringify(before.carry) === JSON.stringify(after.carry), savedRuns: (await listRuns(app.id)).length }));
  await setState(app.id, profile, before);
  const resumed = await runSavedApplication({ appId: app.id, profile, runId: connectionRunId, adapter });
  console.log(JSON.stringify({ phase: 'reconnected', kind: resumed.kind,
    status: resumed.kind === 'completed' ? resumed.record.status : undefined, savedRuns: (await listRuns(app.id)).length }));
}
