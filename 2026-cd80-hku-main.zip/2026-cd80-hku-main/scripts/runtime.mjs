import { delimiter, dirname, join } from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export function isSupportedNodeVersion(version) {
  const match = /^v?(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)$/.exec(version);
  if (!match) return false;
  const major = Number(match[1]);
  const minor = Number(match[2]);
  return major > 24 || (major === 24 && minor >= 11);
}

export function resolveNode() {
  const executableName = process.platform === 'win32' ? 'node.exe' : 'node';
  const candidates = process.env.BLOCKS_NODE_PATH !== undefined
    ? [process.env.BLOCKS_NODE_PATH]
    : [
        process.execPath,
        ...(process.env.PATH ?? '').split(delimiter).filter(Boolean)
          .map((directory) => join(directory, executableName)),
        '/usr/local/bin/node',
        '/opt/homebrew/opt/node@24/bin/node',
        '/usr/local/opt/node@24/bin/node',
      ];

  for (const executable of new Set(candidates)) {
    if (!executable || executable.includes('\0')) continue;
    const probe = spawnSync(executable, ['--version'], { encoding: 'utf8', timeout: 3000 });
    const version = probe.stdout?.trim() ?? '';
    if (probe.status === 0 && isSupportedNodeVersion(version)) {
      return { executable, version };
    }
  }

  throw new Error('Node.js 24.11.0 or later is required. Activate a supported Node version or set BLOCKS_NODE_PATH to its executable.');
}

export function launchServer(runtime) {
  console.log(`Starting Blocks with Node.js ${runtime.version}...`);
  const server = spawn(runtime.executable, ['--env-file-if-exists=.env', 'src/server.ts'], {
    cwd: fileURLToPath(new URL('../', import.meta.url)),
    env: createRuntimeEnvironment(runtime.executable),
    stdio: 'inherit',
  });

  process.once('SIGINT', () => server.kill('SIGINT'));
  process.once('SIGTERM', () => server.kill('SIGTERM'));
  server.once('error', (error) => {
    console.error(`Unable to start Blocks: ${error.message}`);
    process.exitCode = 1;
  });
  server.once('exit', (code, signal) => {
    process.exitCode = code ?? (signal === 'SIGINT' || signal === 'SIGTERM' ? 0 : 1);
  });
}

export function createRuntimeEnvironment(executable) {
  return {
    ...process.env,
    PATH: `${dirname(executable)}${delimiter}${process.env.PATH ?? ''}`,
  };
}
