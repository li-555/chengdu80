import { launchServer, resolveNode } from './runtime.mjs';

let runtime;
try {
  runtime = resolveNode();
} catch (error) {
  console.error(error instanceof Error ? error.message : 'Unable to locate a supported Node.js runtime.');
  process.exit(1);
}

launchServer(runtime);
