import { mkdirSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { json, schema, fenced, propertyTable, type Shape } from '../src/spec/render.ts';
import { AppDocument, CURRENT_SPEC_VERSION, ExportEnvelope } from '../src/app-schema/document.ts';
import { BLOCK_INFO, COMPONENT_INFO, OPERATION_INFO } from '../src/app-schema/describe.ts';
import { OperationParams, OPERATION_SHAPE, type OperationName } from '../src/app-schema/operations.ts';
import { ELEMENT_SCHEMA, ELEMENT_TYPES } from '../src/app-schema/ui.ts';
import { FACTORS, SUPPORTED_FACTORS } from '../src/compute/ops/factor.ts';
import { STEP_SCHEMA } from '../src/app-schema/compute.ts';
import { TriggerSpec } from '../src/app-schema/triggers.ts';
import { ERROR_CODES } from '../src/validate/errors.ts';

const application = schema(ExportEnvelope);
const blocks = BLOCK_INFO;
const operations = Object.fromEntries((Object.keys(OperationParams) as OperationName[]).sort().map((name) => [
  name,
  {
    ...OPERATION_INFO[name],
    inputs: OPERATION_SHAPE[name].inputs,
    params: schema(OperationParams[name]),
    ...(name === 'factor' ? {
      supported: Object.fromEntries(SUPPORTED_FACTORS.map((factor) => [factor, {
        meaning: FACTORS[factor]!.meaning,
        needs: FACTORS[factor]!.needs,
      }])),
    } : {}),
  },
]));
const components = Object.fromEntries([...ELEMENT_TYPES].sort().map((name) => [name, {
  ...COMPONENT_INFO[name], props: schema(ELEMENT_SCHEMA[name]!),
}]));
const errors = Object.fromEntries(Object.entries(ERROR_CODES).map(([code, meaning]) => [code, { meaning }]));

const operationFamilies = ['shaping', 'time_series', 'statistics', 'finance'] as const;
const componentFamilies = ['display', 'chart', 'control', 'layout'] as const;
const titles = {
  shaping: 'Shaping', time_series: 'Time series', statistics: 'Statistics', finance: 'Finance',
  display: 'Display', chart: 'Chart', control: 'Control', layout: 'Layout',
};
const lines = [
  '# Blocks application specification',
  '',
  '## Contents',
  '',
  '- [Document](#document)',
  '- [Sections](#sections)',
  '- [Step kinds](#step-kinds)',
  '- [Trigger kinds](#trigger-kinds)',
  ...operationFamilies.map((family) => `- [${titles[family]} operations](#${family.replaceAll('_', '-')}-operations)`),
  ...componentFamilies.map((family) => `- [${titles[family]} components](#${family}-components)`),
  '- [Errors](#errors)',
  '',
  '## Document',
  '',
  `Specification version: ${CURRENT_SPEC_VERSION}.`,
  '',
  'An application has six sections: meta, params, data, compute, triggers and ui. The optional $schema field identifies the export format. Unknown object keys are refused.',
  '',
  'application.schema.json publishes the document structure as JSON Schema draft 2020-12. The parameter and property schemas below describe inputs, including fields with defaults. Cross-field refinements, expression and SQL rules, reference checks and runtime limits are also enforced by the platform validator; JSON Schema alone does not express every rule.',
  '',
  'The public endpoints are /api/spec for this document, /api/spec/schema, /api/spec/blocks, /api/spec/operations, /api/spec/components and /api/spec/errors. /api/spec/bundle returns all six files together, keyed by filename.',
  '',
];

for (const [group, title] of [['sections', 'Sections'], ['steps', 'Step kinds'], ['triggers', 'Trigger kinds']] as const) {
  lines.push(`## ${title}`, '');
  for (const [name, info] of Object.entries(blocks[group]).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)) {
    const shape = schema(group === 'sections'
      ? AppDocument.shape[name as keyof typeof AppDocument.shape]
      : group === 'steps'
        ? STEP_SCHEMA[name as keyof typeof STEP_SCHEMA]
        : TriggerSpec.options.find((option) => option.shape.kind.value === name)!) as Shape;
    lines.push(`### ${name}`, '', info.en, '', 'Properties:', '', propertyTable(shape), 'Example:', '', fenced(info.example));
  }
}

for (const family of operationFamilies) {
  lines.push(`## ${titles[family]} operations`, '');
  for (const [name, info] of Object.entries(operations).filter(([, item]) => item.family === family)) {
    lines.push(`### ${name}`, '', info.summary, '', `Inputs: ${info.inputs}. Output: ${info.output}.`, '');
    if ('notes' in info) lines.push(String(info.notes), '');
    lines.push('Parameters:', '', propertyTable(info.params as Shape), fenced(info.params), 'Example parameters:', '', fenced(info.example));
    if (info.supported) {
      lines.push('Supported factors (ts_code and trade_date are required for every factor):', '', '| Factor | Meaning | Additional columns |', '| --- | --- | --- |');
      for (const [factor, def] of Object.entries(info.supported)) {
        lines.push(`| ${factor} | ${def.meaning} | ${def.needs.join(', ')} |`);
      }
      lines.push('');
    }
  }
}

for (const family of componentFamilies) {
  lines.push(`## ${titles[family]} components`, '');
  for (const [name, info] of Object.entries(components).filter(([, item]) => item.family === family)) {
    lines.push(`### ${name}`, '', info.summary, '', 'Properties:', '', propertyTable(info.props as Shape), fenced(info.props));
  }
}

lines.push('## Errors', '', 'Codes beginning with E_ block validation; codes beginning with W_ are warnings.', '');
for (const [code, info] of Object.entries(errors).sort(([a], [b]) => a < b ? -1 : a > b ? 1 : 0)) {
  lines.push(`### ${code}`, '', info.meaning, '');
}

const files = {
  'application.schema.json': json(application),
  'blocks.json': json(blocks),
  'operations.json': json(operations),
  'components.json': json(components),
  'errors.json': json(errors),
  'SPEC.md': lines.join('\n').trimEnd() + '\n',
};
const destination = process.argv[2]
  ? resolve(process.argv[2])
  : fileURLToPath(new URL('../spec/', import.meta.url));
mkdirSync(destination, { recursive: true });
for (const [name, content] of Object.entries(files)) writeFileSync(resolve(destination, name), content);
console.log(`Built ${Object.keys(files).length} specification files.`);
