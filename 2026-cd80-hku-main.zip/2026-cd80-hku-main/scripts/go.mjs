import { existsSync } from 'node:fs';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createRuntimeEnvironment, launchServer, resolveNode } from './runtime.mjs';

const projectRoot = fileURLToPath(new URL('../', import.meta.url));
let runtime;
try {
  runtime = resolveNode();
} catch (error) {
  console.error(error instanceof Error ? error.message : 'Unable to locate a supported Node.js runtime.');
  process.exit(1);
}
const runtimeEnvironment = createRuntimeEnvironment(runtime.executable);

const dependencyProbe = spawnSync(runtime.executable, [
  '--input-type=module',
  '-e',
  "import { checkRuntimeDependencies } from './src/platform/dependencies.ts'; if (!checkRuntimeDependencies().ok) process.exit(1);",
], { cwd: projectRoot, env: runtimeEnvironment, stdio: 'ignore', timeout: 10000 });

if (dependencyProbe.status !== 0) {
  const npmEntry = process.env.npm_execpath;
  if (!npmEntry || !existsSync(join(projectRoot, 'package-lock.json'))) {
    console.error('Dependencies are missing. Use npm run go with the committed package-lock.json.');
    process.exit(1);
  }

  console.log('Installing runtime dependencies from package-lock.json...');
  const installation = spawnSync(runtime.executable, [
    npmEntry, 'ci', '--omit=dev', '--no-audit', '--no-fund',
    '--cache', join(projectRoot, '.cache', 'npm'),
    '--fetch-retries=0', '--fetch-timeout=30000',
  ], { cwd: projectRoot, env: runtimeEnvironment, stdio: 'inherit' });

  if (installation.status !== 0) {
    console.error('Dependency installation failed. Check npm connectivity and try npm run go again.');
    process.exit(installation.status ?? 1);
  }
}

launchServer(runtime);
