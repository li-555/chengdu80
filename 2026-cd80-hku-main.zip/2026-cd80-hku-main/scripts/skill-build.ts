import { mkdirSync, writeFileSync } from 'node:fs';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { buildSkill } from '../src/skill/build.ts';

const destination = process.argv[2]
  ? resolve(process.argv[2])
  : fileURLToPath(new URL('../skill/', import.meta.url));
const files = buildSkill();
for (const [path, content] of files) {
  const target = resolve(destination, path);
  mkdirSync(dirname(target), { recursive: true });
  writeFileSync(target, content);
}
const bundle = [
  '# Blocks application skill', '',
  'Read only the sections you need for the current application.', '',
  '## Contents', '',
  ...[...files.keys()].map((path) => `- ${path}`), '',
  ...[...files].map(([path, content]) => `## ${path}\n\n${path.endsWith('.json') ? '```json\n' + content + '```\n' : content}`),
].join('\n').trimEnd() + '\n';
writeFileSync(resolve(destination, 'blocks-skill.md'), bundle);
console.log(`Built ${files.size + 1} skill files.`);
