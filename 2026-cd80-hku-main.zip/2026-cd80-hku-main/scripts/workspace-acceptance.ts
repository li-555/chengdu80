/** Offline workspace integration: fictional documents, uploads, model and isolated storage. */
import assert from 'node:assert/strict';
import { mkdtempSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { MockLanguageModelV4 } from 'ai/test';
import type { AppDocument } from '../src/app-schema/index.ts';
import { readChatStream, type ChatEvent } from '../web/src/chat-stream.ts';
import { chatPayload, uploadMetadata, prepareChatUploads } from '../web/src/chat-upload.ts';
import type { WorkbookUpload } from '../src/platform/upload-preview.ts';

const directory = mkdtempSync(join(tmpdir(), 'blocks-workspace-'));
process.env.BLOCKS_DB_PATH = join(directory, 'checks.sqlite');
delete process.env.GITEE_AI_API_KEY;
delete process.env.TUSHARE_TOKEN;
const { appRoutes } = await import('../src/api/routes-apps.ts');
const { createChatRouter } = await import('../src/api/routes-chat.ts');
const { uploadRouter } = await import('../src/api/routes-uploads.ts');
const { dataRoutes } = await import('../src/api/routes-data.ts');
const { closeStorage } = await import('../src/platform/database.ts');
const { getApp } = await import('../src/platform/storage.ts');
let modelPrompt = '';
let sequence = 0;
const document: AppDocument = {
  meta: { name: 'Fictional workspace app', description: 'Invented offline acceptance example.', spec_version: '1.0' },
  params: [], data: [], compute: [{ id: 'value', kind: 'sql', sql: 'SELECT 7 AS total' }], triggers: [{ kind: 'manual' }],
  ui: { root: 'root', elements: { root: { type: 'Metric', label: 'Fictional total', from: 'value', value: 'total' } } },
};
const model = new MockLanguageModelV4({ doGenerate: async (options) => {
  modelPrompt = JSON.stringify(options.prompt);
  const messages = options.prompt.filter((message) => message.role === 'user');
  const last = JSON.stringify(messages.at(-1));
  if (last.includes('slow fixture')) await new Promise((resolve) => setTimeout(resolve, 3000));
  const question = last.includes('ask fixture');
  const doc = structuredClone(document);
  if (last.includes('rename fixture')) doc.meta.name = 'Renamed fictional app';
  if (last.includes('fail fixture')) (doc.compute[0] as { sql: string }).sql = 'select * from missing_fixture';
  return {
    content: [{ type: 'tool-call', toolCallId: `fixture-${++sequence}`, toolName: question ? 'ask_user' : 'submit_application',
      input: JSON.stringify(question ? { questions: ['Which fictional value should I show?'], accepts_file: true } : { application: doc }) }],
    finishReason: { unified: 'tool-calls', raw: 'tool_calls' },
    usage: { inputTokens: { total: 1, noCache: 1, cacheRead: 0, cacheWrite: 0 }, outputTokens: { total: 1, text: 1, reasoning: 0 } }, warnings: [],
  };
} });
const app = express();
const root = fileURLToPath(new URL('../', import.meta.url));
app.get(['/', '/apps', '/apps/:id', '/chat', '/data', '/charts', '/screen-elements'], (_req, res) => res.sendFile(join(root, 'web/index.html')));
app.get('/api/chart-example', async (_req, res) => { const { buildChartExample } = await import('../src/platform/chart-example.ts'); res.json(await buildChartExample()); });
app.get('/api/screen-example', async (_req, res) => { const { buildScreenExample } = await import('../src/platform/screen-example.ts'); res.json(await buildScreenExample()); });
app.use('/assets', express.static(join(root, 'web/assets')), express.static(join(root, 'web/src')));
app.use(...appRoutes, uploadRouter, ...dataRoutes, createChatRouter({ model: () => model }));
const server = app.listen(0, '127.0.0.1');
await new Promise<void>((resolve) => server.once('listening', resolve));
const address = server.address(); if (!address || typeof address === 'string') throw new Error('No loopback address.');
const base = `http://127.0.0.1:${address.port}`;
let external = 0;
const fetchLocal = globalThis.fetch;
globalThis.fetch = (input, options) => {
  const url = String(input instanceof Request ? input.url : input);
  if (!url.startsWith(`${base}/`)) { external++; throw new Error('External requests are forbidden.'); }
  return fetchLocal(input, options);
};
const request = (path: string, cookie: string, body?: unknown) => fetch(`${base}${path}`, { headers: {
  cookie, ...(body ? { 'Content-Type': 'application/json', 'X-Blocks-Request': '1' } : {}),
}, ...(body ? { method: 'POST', body: JSON.stringify(body) } : {}) });
async function chat(cookie: string, body: unknown): Promise<ChatEvent[]> {
  const response = await request('/api/chat', cookie, body); assert.equal(response.status, 200);
  const events: ChatEvent[] = []; await readChatStream(response.body!, (event) => events.push(event)); return events;
}
if (process.argv.includes('--serve')) {
  console.log(`Offline fictional workspace: ${base}`);
  console.log(`Temporary evidence: ${directory}`);
  process.once('SIGTERM', () => server.close(() => { closeStorage(); }));
} else {
try {
  const cookie = (await request('/api/apps', '')).headers.get('set-cookie')!.split(';')[0]!;
  const other = (await request('/api/apps', '')).headers.get('set-cookie')!.split(';')[0]!;
  const upload = async (owner: string, name: string, row: string) => {
    const response = await fetch(`${base}/api/uploads?filename=${name}.csv&profile=forged`, { method: 'POST', headers: { cookie: owner, 'Content-Type': 'text/csv' }, body: `company,value\n${row},987654321.125\nANOTHER-INVENTED-ROW,123456789.625\n` });
    assert.equal(response.status, 201); return (await response.json()).dataset;
  };
  const own = await upload(cookie, 'Fictional own upload', 'PRIVATE-ROW-CANARY');
  const foreign = await upload(other, 'FOREIGN-METADATA-CANARY', 'OTHER-ROW');
  assert.deepEqual((await (await request('/api/uploads?profile=forged', cookie)).json()).datasets.map((d: { id: string }) => d.id), [own.id]);
  assert.equal((await request(`/api/data/datasets/${foreign.id}`, cookie)).status, 404);
  const refused = await request('/api/chat', cookie, { message: 'build', uploads: [foreign.id] });
  assert.equal(refused.status, 400);
  const events = await chat(cookie, { message: 'build an invented app', uploads: [own.id], profile: 'forged' });
  const built = events.at(-1)!; assert.equal(built.kind, 'built'); if (built.kind !== 'built') throw new Error('Not built');
  assert.doesNotMatch(modelPrompt, /PRIVATE-ROW-CANARY|FOREIGN-METADATA-CANARY|987654321\.125|123456789\.625|1111111110\.75|555555555\.375/);
  assert.match(modelPrompt, /Fictional own upload/);
  const id = built.appId;
  assert.equal((await request(`/api/apps/${id}`, cookie)).status, 200);
  assert.equal((await request(`/api/apps/${id}`, other)).status, 404);
  assert.equal((await getApp(id))!.profile, `browser:${cookie.split('=')[1]}`);
  const connection = await (await request(`/api/apps/${id}/connection`, cookie)).json();
  assert.ok(connection.datasets.some((d: { id: string }) => d.id === own.id));
  assert.ok(!connection.datasets.some((d: { id: string }) => d.id === foreign.id));
  const conversation = events[0]!; if (conversation.kind !== 'conversation') throw new Error('Missing conversation');
  const updated = (await chat(cookie, { message: 'rename fixture', conversationId: conversation.conversationId })).at(-1)!;
  assert.equal(updated.kind, 'built'); if (updated.kind === 'built') { assert.equal(updated.updated, true); assert.equal(updated.appId, id); }
  const separate = (await chat(other, { message: 'build', conversationId: conversation.conversationId })).at(-1)!;
  assert.equal(separate.kind, 'built'); if (separate.kind === 'built') assert.notEqual(separate.appId, id);
  const question = (await chat(cookie, { message: 'ask fixture' })).at(-1)!; assert.equal(question.kind, 'question');
  const run = await (await request(`/api/apps/${id}/run`, cookie, { runId: 'fictional-workspace-run' })).json();
  assert.equal(run.record.status, 'ok'); assert.deepEqual(run.record.result.outputs.value.rows, [[7]]);
  console.log('PASS browser chat -> saved app -> run, follow-up revision, uploads, metadata-only model prompt, foreign-profile isolation');

  const workbookReply = await fetch(`${base}/api/uploads?filename=Invented.xlsx`, { method: 'POST', headers: { cookie, 'Content-Type': 'application/octet-stream' },
    body: readFileSync(new URL('../test/fixtures/invented-upload-review.xlsx', import.meta.url)) });
  assert.equal(workbookReply.status, 201);
  const workbook = await workbookReply.json() as WorkbookUpload;
  assert.equal(workbook.sheets.length, 6);
  const previewReply = await request(`/api/uploads/${encodeURIComponent(workbook.dataset.id)}/preview`, cookie);
  assert.equal(previewReply.status, 200);
  assert.deepEqual((await previewReply.json()).analysis, workbook.analysis);
  assert.equal((await request(`/api/uploads/${encodeURIComponent(workbook.dataset.id)}/preview`, other)).status, 404);
  assert.equal((await request('/api/chat', cookie, { message: 'build', uploads: workbook.sheets.map((sheet) => sheet.dataset.id) })).status, 400);
  const selected = workbook.sheets.slice(0, 5).map((sheet) => uploadMetadata(sheet.dataset));
  const payload = chatPayload('build from the selected tables', undefined, selected);
  assert.deepEqual(Object.keys(payload).sort(), ['message', 'uploads']);
  assert.equal((await chat(cookie, payload)).at(-1)!.kind, 'built');
  assert.doesNotMatch(modelPrompt, /INVENTED_PRIVATE_NOTE|INVENTED_01|987654321\.125|123456789\.625|1111111110\.75|555555555\.375/);
  console.log('PASS multi-sheet preview ownership, five-table chat limit and model request excludes rows/statistics');

  const mdFile = new File(['Summarise the invented Markdown sources.\n\ncode | amount\n--- | ---\nPRIVATE-MD-ROW-CANARY | 876543210.25\n\n| label | value |\n| --- | --- |\n| PRIVATE-MD-SECOND-CANARY | 765432109.5 |'], 'invented.md');
  const prepared = (await prepareChatUploads([mdFile], ''))[0]!;
  const mdReply = await fetch(`${base}/api/uploads?filename=invented.md`, { method: 'POST', headers: { cookie, 'Content-Type': 'application/octet-stream' }, body: mdFile });
  assert.equal(mdReply.status, 201);
  const mdUpload = await mdReply.json() as WorkbookUpload;
  assert.equal(mdUpload.sheets.length, 2);
  const mdPayload = chatPayload(prepared.description, undefined, mdUpload.sheets.map((sheet) => uploadMetadata(sheet.dataset)));
  assert.equal((await chat(cookie, mdPayload)).at(-1)!.kind, 'built');
  assert.match(modelPrompt, /Summarise the invented Markdown sources/);
  assert.doesNotMatch(modelPrompt, /PRIVATE-MD-ROW-CANARY|PRIVATE-MD-SECOND-CANARY|876543210|765432109/);
  console.log('PASS Markdown prose reaches chat; every table persists; model prompt excludes Markdown rows');

  const encoder = new TextEncoder();
  const bytes = encoder.encode('data: {"kind":"conversation","conversationId":"fictional"}\r\n\r\ndata: {"kind":"question","questions":["中文问题"],"acceptsFile":true}\r\n\r\n');
  const chunks = new ReadableStream<Uint8Array>({ start(controller) { for (const byte of bytes) controller.enqueue(new Uint8Array([byte])); controller.close(); } });
  const parsed: ChatEvent[] = []; await readChatStream(chunks, (e) => parsed.push(e));
  assert.deepEqual(parsed.at(-1), { kind: 'question', questions: ['中文问题'], acceptsFile: true });
  await assert.rejects(readChatStream(new ReadableStream({ start(c) { c.enqueue(encoder.encode('data: {"kind":"conversation","conversationId":"x"}\n\n')); c.close(); } }), () => {}), /final event/);
  console.log('PASS streaming: split UTF-8, CRLF, terminal event and interrupted-stream detection');
  const { setLanguage, setTheme, getTheme, t } = await import('../web/src/i18n.ts');
  setLanguage('zh'); assert.equal(t('My Apps'), '我的应用'); assert.equal(t('Run {status}{reused}.', { status: '成功', reused: '' }), '运行成功。');
  assert.equal(t('Choose a dataset for: prices'), '请为以下需求选择数据集：prices');
  assert.equal(t('Match required fields: {details}', { details: 'date' }), '请映射必需字段：date');
  assert.equal(t('CUSTOM-DATA-NAME'), 'CUSTOM-DATA-NAME'); setLanguage('en'); assert.equal(t('My Apps'), 'My Apps');
  for (const theme of ['light', 'dark'] as const) { setTheme(theme); assert.equal(getTheme(), theme); }
  console.log('PASS translation lookup and theme choices; visual acceptance is manual');
  assert.equal(external, 0); console.log('PASS external requests: 0');
} finally { await new Promise<void>((resolve) => server.close(() => resolve())); closeStorage(); }
}
