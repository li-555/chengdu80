import { mkdtempSync, readFileSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const temporary = mkdtempSync(join(tmpdir(), 'blocks-spec-'));

try {
  const build = spawnSync(process.execPath, ['scripts/spec-build.ts', temporary], { cwd: root, encoding: 'utf8' });
  if (build.error || build.status !== 0) {
    console.error(build.error?.message ?? build.stderr ?? 'Specification build failed.');
    process.exitCode = 1;
  } else {
    const published = join(root, 'spec');
    const generated = readdirSync(temporary);
    let existing = [];
    try {
      existing = readdirSync(published);
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
    const names = [...new Set([...generated, ...existing])].sort();
    const differences = [];
    for (const name of names) {
      if (!generated.includes(name)) {
        differences.push(`${name}: unexpected file`);
      } else if (!existing.includes(name)) {
        differences.push(`${name}: missing file`);
      } else if (!readFileSync(join(temporary, name)).equals(readFileSync(join(published, name)))) {
        differences.push(`${name}: differs`);
      }
    }
    if (differences.length > 0) {
      for (const difference of differences) console.error(difference);
      console.error('Specification is out of date. Run npm run spec:build.');
      process.exitCode = 1;
    } else {
      console.log(`Specification matches (${generated.length} files).`);
    }
  }
} finally {
  rmSync(temporary, { recursive: true, force: true });
}
