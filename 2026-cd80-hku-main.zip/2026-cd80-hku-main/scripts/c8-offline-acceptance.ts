/** Offline C8 acceptance: invented rows only, isolated SQLite, no live data requests. */
import assert from 'node:assert/strict';
import { mock } from 'node:test';
import { mkdtempSync, readFileSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';

let networkCalls = 0;
globalThis.fetch = async () => { networkCalls++; throw new Error('Network is forbidden during offline acceptance.'); };
let dataCalls = 0;
const schema = [
  { name: 'value', label: 'Invented value', type: 'text', nullable: false },
  { name: 'company', label: 'Invented company', type: 'text', nullable: false },
];
mock.module('../src/data/index.ts', { namedExports: {
  getDataset: async (id: string) => id === 'invented:values' || id === 'invented:upload'
    ? { id, name: 'Invented acceptance dataset', source: id === 'invented:upload' ? 'upload' : 'tushare', fields: schema } : null,
  isTradingDay: async () => { throw new Error('This fixture must not need a calendar.'); },
  resolveSlice: async () => {
    dataCalls++;
    return { schema, rows: [['12', 'Fictional Amber'], ['8', 'Fictional Birch'], ['unreadable', 'Fictional Cedar']],
      asOfDate: '2026-01-05', datasetVersion: 'invented-offline-v1' };
  },
} });

const inspect = process.argv[2] === '--inspect';
const directory = inspect ? process.argv[3]! : mkdtempSync(join(tmpdir(), 'blocks-c8-offline-'));
// Set before any storage import or operation; never use the caller's configured database.
process.env.BLOCKS_DB_PATH = join(directory, 'acceptance.sqlite');
const platform = await import('../src/platform/index.ts');
const { closeStorage } = await import('../src/platform/database.ts');
const { inventedScheduledDocument } = await import('../src/platform/invented-execution.ts');
const profile = 'invented-offline-acceptance';

try {
  if (inspect) {
    const expected = JSON.parse(readFileSync(join(directory, 'expected.json'), 'utf8'));
    for (const item of expected) {
      assert.deepEqual(await platform.listRuns(item.appId), item.runs);
      assert.deepEqual(await platform.getState(item.appId, profile), item.state);
      if (item.task) assert.deepEqual(await platform.getScheduledTask(item.task.id, profile), item.task);
    }
    assert.equal(dataCalls, 0);
    assert.equal(networkCalls, 0);
    console.log('PASS fresh-process persistence: full sources, results, state and task markers');
  } else {
    const snapshots = [];
    for (const scheduled of [false, true]) {
      for (const code of ['NeedsBindingError', 'NeedsMappingError']) {
        const app = await platform.saveApp(inventedScheduledDocument(), profile);
        const fixed = {
          params: { scale: 1 }, bindings: { invented_values: 'invented:values' },
          mappings: { invented_values: { amount: 'value' } }, carry: { marker: 'untouched' },
        };
        const broken = structuredClone(fixed);
        if (code === 'NeedsBindingError') broken.bindings.invented_values = 'invented:missing';
        if (code === 'NeedsMappingError') broken.mappings.invented_values.amount = 'missing_column';
        await platform.setState(app.id, profile, broken);
        const task = scheduled ? await platform.createScheduledTask(app.id, profile, 1) : undefined;
        const due = new Date(Date.now() - 1000).toISOString();
        if (task) await platform.configureScheduledTask(task.id, profile, { enabled: true, nextRunAt: due });
        const beforeTask = task ? await platform.getScheduledTask(task.id, profile) : undefined;
        const options = { appId: app.id, profile, runId: `offline_${app.id}`,
          ...(task ? { scheduled: { taskId: task.id, scheduledFor: due } } : {}) };
        const beforeCalls = dataCalls;
        const blocked = await platform.runSavedApplication(options);
        assert.equal(blocked.kind, 'needs_data', JSON.stringify(blocked));
        if (blocked.kind !== 'needs_data') throw new Error('Expected connection state.');
        assert.equal(blocked.issue.code, code);
        if (blocked.issue.code === 'NeedsBindingError') assert.deepEqual(blocked.issue.problems, [{ key: 'invented_values', datasetId: 'invented:missing' }]);
        if (blocked.issue.code === 'NeedsMappingError') assert.deepEqual(blocked.issue.problems, [{ key: 'invented_values', field: 'amount', suggestions: ['value', 'company'] }]);
        assert.equal(dataCalls, beforeCalls, 'No rows may be fetched before connection is ready.');
        assert.deepEqual(await platform.listRuns(app.id), []);
        assert.deepEqual(await platform.getState(app.id, profile), broken);
        assert.equal((await platform.listExecutionAttempts(profile)).filter((attempt) => attempt.appId === app.id).length, 0);
        if (task) assert.deepEqual(await platform.getScheduledTask(task.id, profile), beforeTask);

        await platform.setState(app.id, profile, fixed);
        const completed = await platform.runSavedApplication(options);
        assert.equal(completed.kind, 'completed', JSON.stringify(completed));
        if (completed.kind !== 'completed') throw new Error('Expected completed run.');
        assert.equal(completed.record.status, 'ok', JSON.stringify(completed.record.failure));
        assert.equal(completed.reused, false);
        assert.deepEqual(completed.record.result?.outputs.total?.rows, [[20]]);
        assert.equal(dataCalls, beforeCalls + 1);
        const sources = completed.record.sources;
        assert.ok(sources && sources.length === 1);
        assert.equal(sources[0]!.datasetId, 'invented:values');
        assert.equal(sources[0]!.datasetVersion, 'invented-offline-v1');
        assert.equal(sources[0]!.asOfDate, '2026-01-05');
        assert.deepEqual(sources[0]!.fields, [{ app: 'company', dataset: 'company' }, { app: 'amount', dataset: 'value' }]);
        assert.equal(sources[0]!.rows, 3);
        assert.equal(sources[0]!.warnings.length, 1, 'Conversion warnings must survive persistence.');
        assert.deepEqual((await platform.listRuns(app.id))[0]!.sources, sources);
        assert.deepEqual(await platform.getState(app.id, profile), fixed);
        const repeated = await platform.runSavedApplication(options);
        assert.equal(repeated.kind, 'completed');
        if (repeated.kind === 'completed') assert.equal(repeated.reused, true);
        assert.equal(dataCalls, beforeCalls + 1, 'Completed retry must not fetch again.');
        const runs = await platform.listRuns(app.id);
        assert.equal(runs.length, 1);
        const attempts = (await platform.listExecutionAttempts(profile)).filter((attempt) => attempt.appId === app.id);
        assert.equal(attempts.length, 1);
        assert.equal(attempts[0]!.status, 'finished');
        const finalTask = task ? await platform.getScheduledTask(task.id, profile) : undefined;
        if (finalTask) {
          assert.equal(finalTask.nextRunAt, null);
          assert.equal(finalTask.lastScheduledFor, due);
          assert.equal(finalTask.lastRunId, options.runId);
        }
        snapshots.push({ appId: app.id, runs, state: fixed, ...(finalTask ? { task: finalTask } : {}) });
        console.log(`PASS ${scheduled ? 'scheduled' : 'manual'} ${code}: no failed run, released claim, same-id recovery, sources, idempotent retry`);
      }
    }
    const paramApp = await platform.saveApp(inventedScheduledDocument(), profile);
    const paramState = { bindings: { invented_values: 'invented:values' }, mappings: { invented_values: { amount: 'value' } }, carry: { marker: 'keep' } };
    await platform.setState(paramApp.id, profile, paramState);
    const defaults = await platform.runSavedApplication({ appId: paramApp.id, profile });
    assert.equal(defaults.kind, 'completed');
    if (defaults.kind === 'completed') { assert.equal(defaults.record.params.scale, 1); assert.deepEqual(defaults.record.result?.outputs.total?.rows, [[20]]); }
    await platform.setState(paramApp.id, profile, { ...paramState, params: { scale: 2 } });
    const savedSettings = await platform.runSavedApplication({ appId: paramApp.id, profile });
    assert.equal(savedSettings.kind, 'completed');
    if (savedSettings.kind === 'completed') { assert.equal(savedSettings.record.params.scale, 2); assert.deepEqual(savedSettings.record.result?.outputs.total?.rows, [[40]]); }
    const overridden = await platform.runSavedApplication({ appId: paramApp.id, profile, params: { scale: 3 } });
    assert.equal(overridden.kind, 'completed');
    if (overridden.kind === 'completed') { assert.equal(overridden.record.params.scale, 3); assert.deepEqual(overridden.record.result?.outputs.total?.rows, [[60]]); }
    assert.deepEqual(await platform.getState(paramApp.id, profile), { ...paramState, params: { scale: 2 } });
    console.log('PASS settings precedence: override > saved > default; overrides do not overwrite saved settings');
    for (const expectedStatus of ['ok', 'partial', 'failed'] as const) {
      const doc = inventedScheduledDocument();
      doc.compute = [{ id: 'total', kind: 'code', input: ['invented_values'], carry_state: true,
        output: { columns: [{ name: 'value', type: 'number' }] },
        body: expectedStatus === 'failed' ? 'throw new Error("Invented failure");'
          : `const n = (state.n || 0) + 1; return { rows: [${expectedStatus === 'partial' ? '{}' : '{ value: n }'}], state: { n } };`,
      }];
      const app = await platform.saveApp(doc, profile);
      const state = { ...paramState, carry: { n: 4, marker: 'keep-on-failure' } };
      await platform.setState(app.id, profile, state);
      const reply = await platform.runSavedApplication({ appId: app.id, profile });
      assert.equal(reply.kind, 'completed', JSON.stringify(reply));
      if (reply.kind !== 'completed') throw new Error('Expected completed carry check.');
      assert.equal(reply.record.status, expectedStatus, JSON.stringify(reply.record));
      assert.ok(reply.record.sources?.length);
      const expectedState = { ...state, carry: expectedStatus === 'failed' ? state.carry : { n: 5 } };
      assert.deepEqual(await platform.getState(app.id, profile), expectedState);
      snapshots.push({ appId: app.id, runs: await platform.listRuns(app.id), state: expectedState });
    }
    console.log('PASS carry: ok/partial advance state; failed leaves state intact; sources survive all three');
    assert.equal(networkCalls, 0);
    assert.equal(dataCalls, 10);
    closeStorage();
    writeFileSync(join(directory, 'expected.json'), JSON.stringify(snapshots));
    const child = spawnSync(process.execPath, ['--experimental-test-module-mocks', 'scripts/c8-offline-acceptance.ts', '--inspect', directory], {
      cwd: process.cwd(), encoding: 'utf8', timeout: 30000,
      env: { ...process.env, TUSHARE_TOKEN: '', GITEE_AI_API_KEY: '' },
    });
    assert.equal(child.status, 0, child.stderr + child.stdout);
    process.stdout.write(child.stdout);
    console.log('PASS network calls: 0; invented slice fetches: 10');
    console.log(`Evidence retained: ${directory}`);
  }
} finally {
  closeStorage();
  mock.restoreAll();
}
