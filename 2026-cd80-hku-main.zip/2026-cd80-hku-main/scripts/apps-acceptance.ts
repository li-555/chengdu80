import { spawn } from 'node:child_process';
import type { ChildProcess } from 'node:child_process';
import { appendFileSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import { gzipSync } from 'node:zlib';
import { appVersion } from '../src/app-schema/index.ts';
import type { AppDocument } from '../src/app-schema/index.ts';
import type { ValidationIssue } from '../src/validate/index.ts';

const projectRoot = fileURLToPath(new URL('../', import.meta.url));
const activeServers = new Set<ChildProcess>();

class AcceptanceError extends Error {}

function check(condition: unknown, message: string): asserts condition {
  if (!condition) throw new AcceptanceError(message);
}

function equal(actual: unknown, expected: unknown, message: string): void {
  check(isDeepStrictEqual(actual, expected), message);
}

function inventedDocument(): AppDocument {
  return {
    meta: {
      name: 'Invented App Import Fixture',
      description: 'Invented application used only for acceptance checks.',
      spec_version: '1.0',
      icon: 'table',
    },
    params: [{ key: 'watchlist', label: 'Invented companies', type: 'text', list: true,
      default: ['INVENTED-CO-001'] }],
    data: [{
      key: 'invented_rows',
      purpose: 'Invented acceptance data',
      fields: [
        { name: 'company_code', type: 'text', required: true },
        { name: 'trade_date', type: 'date', required: true },
      ],
      window: { field: 'trade_date', lookbackDays: 30 },
      filters: [{ field: 'company_code', op: 'in', param: 'watchlist' }],
    }],
    compute: [],
    triggers: [{ kind: 'manual' }],
    ui: { root: 'page', elements: {
      page: { type: 'Section', columns: 1, children: ['note'] },
      note: { type: 'Text', text: 'Invented acceptance fixture.', emphasis: 'body' },
    } },
  };
}

type AppView = {
  id: string;
  doc: AppDocument;
  version: string;
  createdAt: string;
  updatedAt: string;
};

type AppCard = { id: string; name: string; description: string; icon?: string; createdAt: string; updatedAt: string };
type ImportResult = { app: AppView; warnings: ValidationIssue[] };
type ErrorBody = { error: { code: string; message: string; issues?: ValidationIssue[] } };
type RunningServer = { child: ChildProcess; url: string };

function environment(databasePath: string): NodeJS.ProcessEnv {
  const result: NodeJS.ProcessEnv = { ...process.env, BLOCKS_DB_PATH: databasePath, CD80_PORT: '0' };
  delete result.TUSHARE_TOKEN;
  delete result.GITEE_AI_API_KEY;
  return result;
}

async function startServer(databasePath: string, evidenceDir: string): Promise<RunningServer> {
  const child = spawn(process.execPath, ['--no-warnings', 'src/server.ts'], {
    cwd: projectRoot,
    env: environment(databasePath),
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  activeServers.add(child);
  child.once('exit', () => activeServers.delete(child));
  const log = (chunk: Buffer): void => { appendFileSync(join(evidenceDir, 'server.log'), chunk); };
  child.stdout?.on('data', log);
  child.stderr?.on('data', log);
  const url = await new Promise<string>((resolve, reject) => {
    let output = '';
    const finish = (error?: Error, value?: string): void => {
      clearTimeout(timeout);
      child.stdout?.off('data', onData);
      child.off('error', onError);
      child.off('exit', onExit);
      if (error) reject(error);
      else resolve(value!);
    };
    const onData = (chunk: Buffer): void => {
      output += chunk.toString();
      const match = /Blocks is running at (http:\/\/127\.0\.0\.1:\d+)/.exec(output);
      if (match) finish(undefined, match[1]);
    };
    const onError = (): void => finish(new AcceptanceError('Server could not start.'));
    const onExit = (): void => finish(new AcceptanceError('Server exited before startup.'));
    const timeout = setTimeout(() => finish(new AcceptanceError('Server startup timed out.')), 10000);
    child.stdout?.on('data', onData);
    child.once('error', onError);
    child.once('exit', onExit);
  });
  return { child, url };
}

async function stopServer(server: RunningServer): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const timeout = setTimeout(() => {
      server.child.kill('SIGKILL');
      reject(new AcceptanceError('Server shutdown timed out.'));
    }, 5000);
    server.child.once('exit', (code) => {
      clearTimeout(timeout);
      if (code === 0) resolve();
      else reject(new AcceptanceError('Server did not shut down successfully.'));
    });
    server.child.kill('SIGTERM');
  });
}

async function request(server: RunningServer, path: string, init: RequestInit = {}): Promise<Response> {
  const response = await fetch(`${server.url}${path}`, { ...init, signal: AbortSignal.timeout(5000) });
  if (path.startsWith('/api/apps')) {
    check(response.headers.get('cache-control')?.split(',').map((part) => part.trim()).includes('no-store'),
      'Application responses must not be cached.');
  }
  return response;
}

function importRequest(body: string, cookie?: string, extraHeaders: Record<string, string> = {}): RequestInit {
  return {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json; charset=utf-8',
      'X-Blocks-Request': '1',
      ...(cookie ? { Cookie: cookie } : {}),
      ...extraHeaders,
    },
    body,
  };
}

async function errorResponse(response: Response, expected: number, message: string, evidenceDir: string): Promise<ErrorBody> {
  check(response.status === expected, `${message}: expected HTTP ${expected}, received ${response.status}.`);
  const text = await response.text();
  check(!text.includes(evidenceDir) && !text.includes(projectRoot), `${message}: errors must not expose storage or source paths.`);
  const body = JSON.parse(text) as ErrorBody;
  check(body.error && typeof body.error.code === 'string' && typeof body.error.message === 'string',
    `${message}: errors must have a code and message.`);
  check(/[A-Za-z]/.test(body.error.message) && !/[\u3400-\u9fff]/.test(body.error.message),
    `${message}: error messages must be in English.`);
  return body;
}

function cookieFrom(response: Response): string {
  const header = response.headers.get('set-cookie');
  check(header, 'A new browser must receive a profile cookie.');
  check(/(?:^|;\s*)HttpOnly(?:;|$)/i.test(header), 'The profile cookie must be HttpOnly.');
  check(/(?:^|;\s*)SameSite=Strict(?:;|$)/i.test(header), 'The profile cookie must use SameSite=Strict.');
  check(/(?:^|;\s*)Path=\/(?:;|$)/i.test(header), 'The profile cookie must cover the application.');
  check(/(?:^|;\s*)Max-Age=31536000(?:;|$)/i.test(header), 'The profile cookie must persist for one year.');
  const cookie = header.split(';')[0]!;
  check(/^blocks_profile=[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(cookie),
    'The browser profile must be a generated UUID.');
  return cookie;
}

async function listApps(server: RunningServer, cookie: string, suffix = ''): Promise<AppCard[]> {
  const response = await request(server, `/api/apps${suffix}`, { headers: { Cookie: cookie } });
  check(response.status === 200, 'An application list must be available.');
  const body = await response.json() as { apps: AppCard[] };
  check(Array.isArray(body.apps), 'An application list must contain an apps array.');
  check(!JSON.stringify(body).includes('"profile"'), 'Application lists must not disclose profile fields.');
  return body.apps;
}

async function getApp(server: RunningServer, cookie: string, id: string): Promise<AppView> {
  const response = await request(server, `/api/apps/${id}`, { headers: { Cookie: cookie } });
  check(response.status === 200, 'A saved application must open.');
  const body = await response.json() as { app: AppView };
  check(!Object.hasOwn(body.app, 'profile'), 'Application details must not disclose the profile.');
  return body.app;
}

async function importApp(server: RunningServer, cookie: string, text: string, contentType = 'application/json'): Promise<ImportResult> {
  const response = await request(server, '/api/apps/import', importRequest(text, cookie, { 'Content-Type': contentType }));
  check(response.status === 201, `A valid application must import: expected HTTP 201, received ${response.status}.`);
  const body = await response.json() as ImportResult;
  check(body.app && typeof body.app.id === 'string', 'An import must return the saved application.');
  check(!Object.hasOwn(body.app, 'profile'), 'Imports must not disclose the profile.');
  check(Array.isArray(body.warnings) && body.warnings.every((warning) => warning.severity === 'warning'),
    'Imports must preserve structured validation warnings.');
  return body;
}

async function checkCore(server: RunningServer): Promise<void> {
  const home = await request(server, '/');
  check(home.status === 200 && (await home.text()).includes('<title>Blocks</title>'), 'The home page must remain available.');
  const health = await request(server, '/health');
  check(health.status === 200, 'The health endpoint must remain available.');
  const body = await health.json() as { status?: string; node?: string };
  check(body.status === 'ok' && body.node === process.version, 'Health must report the selected Node runtime.');
}

async function main(): Promise<void> {
  const evidenceDir = mkdtempSync(join(tmpdir(), 'blocks-apps-acceptance-'));
  const databasePath = join(evidenceDir, 'blocks.sqlite');
  let succeeded = false;
  try {
    const firstServer = await startServer(databasePath, evidenceDir);
    await checkCore(firstServer);
    for (const path of ['/', '/apps', '/apps/invented-missing', '/chat', '/chat/', '/data', '/charts', '/screen-elements']) {
      const response = await request(firstServer, path);
      check(response.status === 200 && (await response.text()).includes('<title>Blocks</title>'),
        'Application navigation and refresh must serve the browser shell.');
    }
    for (const path of ['/assets/app.js', '/assets/theme-init.js', '/assets/workspace-ui.js', '/assets/chat.css', '/assets/theme.css', '/assets/platform.css',
      '/assets/markdown-tables.js', '/assets/screen-controls.js', '/assets/upload-preview.js', '/assets/ui-icon.js', '/assets/desktop.css', '/assets/appearance.js', '/assets/pointer-motion.js', '/assets/SplitText.min.js', '/assets/gsap.min.js', '/assets/motion-runtime.js', '/assets/motion-elements.js', '/assets/workspace-motion.js', '/assets/workspace-motion.css', '/assets/theme-transition.js', '/assets/theme-transition.css',
      '/assets/i18n.js', '/assets/preferences.js', '/assets/chat-stream.js', '/assets/chat-screen.js', '/assets/chat-upload.js']) {
      const response = await request(firstServer, path);
      check(response.status === 200 && (await response.text()).trim().length > 0, 'The browser shell must have its local assets.');
    }
    console.log('PASS application shell, refresh routes and browser assets');

    const firstList = await request(firstServer, '/api/apps');
    check(firstList.status === 200, 'A new browser must open My Apps.');
    const firstCookie = cookieFrom(firstList);
    equal(await firstList.json(), { apps: [] }, 'A new browser must have an empty application list.');
    const document = inventedDocument();
    const envelope = { $schema: 'https://invented.example/app.schema.json', ...document };
    const imported = await importApp(firstServer, firstCookie, JSON.stringify(envelope));
    equal(imported.app.doc, document, 'An import must save the validated document without its export envelope.');
    equal(imported.app.version, appVersion(document), 'An import must use the shared document version function.');
    equal(imported.app.doc.data[0]!.window, document.data[0]!.window, 'An import must preserve the declared data window.');
    equal(imported.app.doc.data[0]!.filters, document.data[0]!.filters, 'An import must preserve parameter-named filters.');
    check(imported.app.createdAt === imported.app.updatedAt && !Number.isNaN(Date.parse(imported.app.createdAt)),
      'A new application must have valid persistence timestamps.');
    equal(await getApp(firstServer, firstCookie, imported.app.id), imported.app, 'Opening an application must return the saved document.');
    const fenced = await importApp(firstServer, firstCookie, `\`\`\`json\n${JSON.stringify(document)}\n\`\`\``, 'text/plain; charset=utf-8');
    check(fenced.warnings.some((warning) => warning.code === 'W_SURROUNDING_TEXT'), 'Fenced imports must retain the shared validator warning.');
    const cards = await listApps(firstServer, firstCookie);
    check(cards.length === 2 && cards.some((card) => card.id === imported.app.id), 'Imported applications must appear in My Apps.');
    const card = cards.find((candidate) => candidate.id === imported.app.id)!;
    equal(card, { id: imported.app.id, name: document.meta.name, description: document.meta.description,
      icon: document.meta.icon, createdAt: imported.app.createdAt, updatedAt: imported.app.updatedAt },
    'Application cards must provide display metadata without the full document.');
    console.log('PASS validated imports, shared versions, windows, filters and warnings');

    const unknown = { ...document, invented_unknown: true };
    const brokenReference = structuredClone(document);
    brokenReference.ui.root = 'invented_missing_root';
    const wrongVersion = structuredClone(document);
    wrongVersion.meta.spec_version = 'invented-999';
    for (const [invalid, expectedCode] of [
      [unknown, 'E_SCHEMA_UNKNOWN_KEY'],
      [brokenReference, 'E_REF_UNKNOWN_ROOT'],
      [wrongVersion, 'E_SCHEMA_SPEC_VERSION'],
    ] as const) {
      const response = await request(firstServer, '/api/apps/import', importRequest(JSON.stringify(invalid), firstCookie));
      const error = await errorResponse(response, 422, 'Invalid documents must be rejected', evidenceDir);
      check(error.error.issues?.some((issue) => issue.code === expectedCode), 'Invalid imports must return the shared structured issues.');
    }
    equal(await listApps(firstServer, firstCookie), cards, 'Rejected documents must not create saved applications.');
    console.log('PASS schema, reference and specification failures without saved records');

    const secondList = await request(firstServer, '/api/apps');
    check(secondList.status === 200, 'A separate browser must open My Apps.');
    const secondCookie = cookieFrom(secondList);
    check(secondCookie !== firstCookie, 'Separate browsers must receive independent profiles.');
    equal(await secondList.json(), { apps: [] }, 'A separate browser must not see existing applications.');
    for (const id of [imported.app.id, 'invented-missing']) {
      await errorResponse(await request(firstServer, `/api/apps/${id}`, { headers: { Cookie: secondCookie } }),
        404, 'Missing and other-profile applications must be unavailable', evidenceDir);
    }
    equal(await listApps(firstServer, secondCookie, `?profile=${encodeURIComponent(firstCookie.split('=')[1]!)}`), [],
      'A query parameter must not select another browser profile.');
    await errorResponse(await request(firstServer, '/api/apps/import', importRequest(JSON.stringify({
      ...document, profile: firstCookie.split('=')[1],
    }), secondCookie)), 422, 'A document field must not select another profile', evidenceDir);
    const secondImport = await importApp(firstServer, secondCookie, JSON.stringify(document));
    equal((await listApps(firstServer, secondCookie)).map((entry) => entry.id), [secondImport.app.id],
      'Separate browser imports must remain isolated.');
    equal(await listApps(firstServer, firstCookie), cards, 'Another profile must not change the original list.');
    console.log('PASS browser-profile isolation and inaccessible application responses');

    const text = JSON.stringify(document);
    await errorResponse(await request(firstServer, '/api/apps/import', importRequest(text)), 403,
      'Imports must require an existing browser profile', evidenceDir);
    await errorResponse(await request(firstServer, '/api/apps/import', {
      method: 'POST', headers: { Cookie: firstCookie, 'Content-Type': 'application/json' }, body: text,
    }), 403, 'Imports must require the request marker', evidenceDir);
    await errorResponse(await request(firstServer, '/api/apps/import', importRequest(text, firstCookie, {
      Origin: 'https://invented-other.example',
    })), 403, 'Cross-origin imports must be rejected', evidenceDir);
    await errorResponse(await request(firstServer, '/api/apps/import', importRequest(text, firstCookie, {
      'Content-Type': 'text/html',
    })), 415, 'Unsupported import types must be rejected', evidenceDir);
    await errorResponse(await request(firstServer, '/api/apps/import', importRequest(text, firstCookie, {
      'Content-Type': 'text/plain; charset=utf-16',
    })), 415, 'Unsupported text encodings must be rejected', evidenceDir);
    await errorResponse(await request(firstServer, '/api/apps/import', importRequest(' \n\t ', firstCookie)),
      400, 'Empty imports must be rejected', evidenceDir);
    await errorResponse(await request(firstServer, '/api/apps/import', importRequest('x'.repeat(1024 * 1024 + 1), firstCookie)),
      413, 'Imports larger than one MiB must be rejected', evidenceDir);
    const compressed = importRequest('', firstCookie, { 'Content-Encoding': 'gzip' });
    compressed.body = new Uint8Array(gzipSync(text));
    await errorResponse(await request(firstServer, '/api/apps/import', compressed), 415,
      'Compressed import bodies must not bypass the byte limit', evidenceDir);
    equal(await listApps(firstServer, firstCookie), cards, 'Rejected HTTP requests must not change the saved application list.');
    const sameOrigin = await request(firstServer, '/api/apps/import', importRequest(text, firstCookie, { Origin: firstServer.url }));
    check(sameOrigin.status === 201, 'Same-origin browser imports must work.');
    await sameOrigin.arrayBuffer();
    const persistedCards = await listApps(firstServer, firstCookie);
    console.log('PASS import request, origin, content-type and body-size boundaries');

    await stopServer(firstServer);
    const restarted = await startServer(databasePath, evidenceDir);
    await checkCore(restarted);
    equal(await listApps(restarted, firstCookie), persistedCards, 'The same browser profile must retain its list after a server restart.');
    equal(await getApp(restarted, firstCookie, imported.app.id), imported.app, 'The saved document must survive a server restart.');
    equal((await listApps(restarted, secondCookie)).map((entry) => entry.id), [secondImport.app.id],
      'Profile isolation must survive a server restart.');
    await stopServer(restarted);
    console.log('PASS real-server restart persistence and profile continuity');

    const corruptPath = join(evidenceDir, 'invented-corrupt.sqlite');
    const corruptContents = Buffer.from('Invented invalid SQLite fixture.');
    writeFileSync(corruptPath, corruptContents);
    const broken = await startServer(corruptPath, evidenceDir);
    await errorResponse(await request(broken, '/api/apps', { headers: { Cookie: firstCookie } }),
      503, 'Unavailable storage must return a clear API failure', evidenceDir);
    await errorResponse(await request(broken, '/api/apps/import', importRequest(text, firstCookie)),
      503, 'Unavailable storage must not report a successful import', evidenceDir);
    await checkCore(broken);
    await stopServer(broken);
    equal(readFileSync(corruptPath), corruptContents, 'Storage failures must not replace the original database contents.');
    console.log('PASS storage failure responses and independent core-server availability');
    succeeded = true;
  } catch (error) {
    console.error(`FAIL ${error instanceof AcceptanceError ? error.message : 'Unexpected application acceptance error.'}`);
    if (error instanceof Error) writeFileSync(join(evidenceDir, 'failure-details.txt'), error.stack ?? error.message);
    console.error(`Acceptance evidence retained at ${evidenceDir}`);
    process.exitCode = 1;
  } finally {
    for (const child of activeServers) child.kill('SIGKILL');
    if (succeeded) rmSync(evidenceDir, { recursive: true, force: true });
  }
}

await main();
