import { spawn, spawnSync } from 'node:child_process';
import type { ChildProcess } from 'node:child_process';
import { mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { DatabaseSync } from 'node:sqlite';
import { fileURLToPath } from 'node:url';
import { isDeepStrictEqual } from 'node:util';
import { AppDocument as DocumentSchema, appVersion } from '../src/app-schema/index.ts';
import type { AppDocument } from '../src/app-schema/index.ts';
import type { RunRecord, StoredApp } from '../src/platform/types.ts';

const projectRoot = fileURLToPath(new URL('../', import.meta.url));
const scriptPath = fileURLToPath(import.meta.url);
const profiles = { first: 'invented-alpha', second: 'invented-beta' };
const timestamp = '2026-01-15T09:00:00.000Z';

class AcceptanceError extends Error {}

function check(condition: unknown, message: string): asserts condition {
  if (!condition) throw new AcceptanceError(message);
}

function equal(actual: unknown, expected: unknown, message: string): void {
  check(isDeepStrictEqual(actual, expected), message);
}

async function rejects(operation: () => Promise<unknown>, message: string): Promise<void> {
  try {
    await operation();
  } catch (error) {
    check(error instanceof Error && /[A-Za-z]/.test(error.message)
      && !/[\u3400-\u9fff]/.test(error.message), `${message}: an English error is required.`);
    return;
  }
  throw new AcceptanceError(message);
}

function inventedDocument(): AppDocument {
  return DocumentSchema.parse({
    meta: {
      name: 'Invented Storage Fixture',
      description: 'Invented data used only for storage acceptance checks.',
      spec_version: '1.0',
    },
    params: [{ key: 'watchlist', label: 'Invented companies', type: 'text', list: true,
      default: ['INVENTED-CO-001'] }],
    data: [{
      key: 'invented_rows',
      purpose: 'Invented acceptance data',
      fields: [
        { name: 'company_code', type: 'text', required: true },
        { name: 'trade_date', type: 'date', required: true },
      ],
      window: { field: 'trade_date', lookbackDays: 30 },
      filters: [{ field: 'company_code', op: 'in', param: 'watchlist' }],
    }],
    compute: [],
    triggers: [{ kind: 'manual' }],
    ui: { root: 'page', elements: {
      page: { type: 'Section', columns: 1, children: ['note'] },
      note: { type: 'Text', text: 'Invented acceptance fixture.', emphasis: 'body' },
    } },
  });
}

function inventedRun(app: StoredApp, id: string, startedAt = timestamp): RunRecord {
  return {
    id,
    appId: app.id,
    appVersion: app.version,
    startedAt,
    status: 'ok',
    params: { watchlist: ['INVENTED-CO-001'], nested: { allowed: [null, true, 12.5] } },
    result: {
      status: 'ok',
      outputs: { invented_rows: {
        schema: [{ name: 'invented_label', label: 'Invented label', type: 'text', nullable: false }],
        rows: [['INVENTED-ROW-001']],
      } },
      asOfDate: '2026-01-14',
      startedAt,
      durationMs: 4,
    },
    asOfDate: '2026-01-14',
  };
}

function inventedState(): Record<string, unknown> {
  return { watchlist: ['INVENTED-CO-001'], carry: { count: 1 }, choices: [null, true, 12.5, 'invented'] };
}

type Manifest = {
  appId: string;
  secondAppId: string;
  appMetadata: Omit<StoredApp, 'doc'>;
  runIds: string[];
};

function readManifest(evidenceDir: string): Manifest {
  return JSON.parse(readFileSync(join(evidenceDir, 'manifest.json'), 'utf8')) as Manifest;
}

async function writeAndCheck(evidenceDir: string): Promise<void> {
  const storage = await import('../src/platform/index.ts');
  const { closeStorage } = await import('../src/platform/database.ts');
  try {
    check(storage.STUB === false, 'Storage must no longer be a stub.');
    equal(await storage.listApps(profiles.first), [], 'A new database must have no applications.');
    equal(await storage.getApp('invented-missing'), null, 'Missing applications must return null.');
    equal(await storage.getState('invented-missing', profiles.first), {}, 'Missing state must return an empty object.');
    equal(await storage.listRuns('invented-missing'), [], 'Missing run history must be empty.');

    const input = inventedDocument();
    const expectedDocument = structuredClone(input);
    const first = await storage.saveApp(input, profiles.first);
    const duplicate = await storage.saveApp(expectedDocument, profiles.first);
    const second = await storage.saveApp(expectedDocument, profiles.second);
    check(new Set([first.id, duplicate.id, second.id]).size === 3, 'Every saveApp must create a new application ID.');
    equal(first.version, appVersion(expectedDocument), 'Stored version must use the shared appVersion function.');
    equal(duplicate.version, first.version, 'Identical documents must have identical versions.');
    equal(first.createdAt, first.updatedAt, 'New applications must share creation and update timestamps.');
    check(!Number.isNaN(Date.parse(first.createdAt)), 'Application timestamps must be valid.');
    const changedDocument = inventedDocument();
    changedDocument.params[0]!.default = ['INVENTED-CO-002'];
    const changed = await storage.saveApp(changedDocument, profiles.second);
    check(changed.version !== first.version, 'Changing a parameter default must change the version.');
    await storage.deleteApp(changed.id);

    input.meta.name = 'Invented input mutation';
    first.doc.meta.description = 'Invented return mutation';
    const loaded = await storage.getApp(first.id);
    check(loaded !== null, 'Saved application must be found.');
    equal(loaded.doc, expectedDocument, 'Application input and returned values must be independent copies.');
    equal(loaded.doc.data[0]!.window, expectedDocument.data[0]!.window, 'Data windows must be preserved.');
    equal(loaded.doc.data[0]!.filters, expectedDocument.data[0]!.filters, 'Parameter-named filters must be preserved.');
    equal((await storage.listApps(profiles.first)).map((app) => app.id), [first.id, duplicate.id],
      'Profile lists must keep insertion order, including equal timestamps.');
    equal((await storage.listApps(profiles.second)).map((app) => app.id), [second.id], 'Applications must be isolated by profile.');
    loaded.doc.meta.name = 'Invented getApp mutation';
    const listed = await storage.listApps(profiles.first);
    listed[0]!.doc.meta.name = 'Invented listApps mutation';
    equal((await storage.getApp(first.id))!.doc, expectedDocument, 'Application reads must return copies.');

    const surrogateProfile = 'invented-profile-\ud800';
    const replacementProfile = 'invented-profile-\ufffd';
    const surrogateApp = await storage.saveApp(inventedDocument(), surrogateProfile);
    const replacementApp = await storage.saveApp(inventedDocument(), replacementProfile);
    equal((await storage.listApps(surrogateProfile)).map((app) => app.id), [surrogateApp.id],
      'A lone-surrogate profile must remain distinct from a replacement-character profile.');
    equal((await storage.listApps(replacementProfile)).map((app) => app.id), [replacementApp.id],
      'Replacement-character profiles must retain their exact keys.');
    const nullPrototype = Object.create(null) as Record<string, unknown>;
    nullPrototype.invented = true;
    const shared = { invented: true };
    const positiveJson = { negativeZero: -0, nullPrototype, sharedFirst: shared, sharedSecond: shared };
    await storage.setState(surrogateApp.id, surrogateProfile, positiveJson);
    const positiveState = await storage.getState(surrogateApp.id, surrogateProfile);
    check(Object.is(positiveState.negativeZero, -0), 'State must preserve negative zero.');
    equal(positiveState.nullPrototype, { invented: true }, 'Null-prototype objects must preserve their JSON properties.');
    equal(positiveState.sharedFirst, { invented: true }, 'Repeated references must be accepted as JSON values.');
    equal(positiveState.sharedSecond, { invented: true }, 'Every repeated reference must preserve its value.');
    const surrogateRun = { ...inventedRun(surrogateApp, 'invented-run-\ud800'), params: positiveJson };
    const replacementRun = inventedRun(surrogateApp, 'invented-run-\ufffd');
    await storage.saveRun(surrogateRun);
    await storage.saveRun(replacementRun);
    const exactRuns = await storage.listRuns(surrogateApp.id);
    equal(exactRuns.map((run) => run.id), ['invented-run-\ud800', 'invented-run-\ufffd'],
      'Lone-surrogate and replacement-character run IDs must remain distinct.');
    check(Object.is(exactRuns[0]!.params.negativeZero, -0), 'Run parameters must preserve negative zero.');
    equal(exactRuns[0]!.params.nullPrototype, { invented: true }, 'Run parameters must accept null-prototype objects.');
    equal(exactRuns[0]!.params.sharedSecond, { invented: true }, 'Run parameters must accept repeated references.');
    await storage.deleteApp(surrogateApp.id);
    await storage.deleteApp(replacementApp.id);

    const invalidDocument = { ...inventedDocument(), invented_unknown: true } as AppDocument;
    await rejects(() => storage.saveApp(invalidDocument, profiles.first), 'Unknown document fields must be rejected.');
    const undefinedDocument = inventedDocument();
    undefinedDocument.meta.icon = undefined;
    await rejects(() => storage.saveApp(undefinedDocument, profiles.first), 'Explicit undefined optional fields must be rejected.');
    equal((await storage.listApps(profiles.first)).length, 2, 'Rejected application writes must not create records.');

    const stateInput = inventedState();
    await storage.setState(first.id, profiles.first, stateInput);
    (stateInput.carry as Record<string, unknown>).count = 999;
    const stateRead = await storage.getState(first.id, profiles.first);
    equal(stateRead, inventedState(), 'State input must be copied.');
    (stateRead.carry as Record<string, unknown>).count = 999;
    equal(await storage.getState(first.id, profiles.first), inventedState(), 'State reads must return copies.');
    equal(await storage.getState(first.id, profiles.second), {}, 'State must be isolated by profile.');
    await rejects(() => storage.setState(first.id, profiles.second, {}), 'Wrong-profile state writes must be rejected.');
    await rejects(() => storage.setState('invented-missing', profiles.first, {}), 'Missing-application state writes must be rejected.');
    await storage.setState(first.id, profiles.first, { replacement: true });
    equal(await storage.getState(first.id, profiles.first), { replacement: true }, 'State writes must replace existing state.');
    await storage.setState(first.id, profiles.first, inventedState());

    const tiedFirst = inventedRun(first, 'invented-tie-first');
    const tiedSecond = inventedRun(first, 'invented-tie-second');
    const newest = inventedRun(first, 'invented-newest', '2026-01-16T09:00:00.000Z');
    const oldest = inventedRun(first, 'invented-oldest', '2026-01-14T09:00:00.000Z');
    await storage.saveRun(tiedFirst);
    await storage.saveRun(tiedSecond);
    await storage.saveRun(newest);
    await storage.saveRun(oldest);
    tiedFirst.params.watchlist = ['INVENTED-MUTATION'];
    const expectedIds = ['invented-newest', 'invented-tie-first', 'invented-tie-second', 'invented-oldest'];
    equal((await storage.listRuns(first.id)).map((run) => run.id), expectedIds,
      'Run history must sort newest first and retain insertion order for tied timestamps.');
    equal((await storage.listRuns(first.id))[1]!.params.watchlist, ['INVENTED-CO-001'], 'Run input must be copied.');
    const runRead = await storage.listRuns(first.id);
    runRead[0]!.params.watchlist = ['INVENTED-MUTATION'];
    runRead[0]!.result!.outputs.invented_rows!.rows[0]![0] = 'INVENTED-MUTATION';
    equal((await storage.listRuns(first.id))[0], newest, 'Run reads must return deep copies.');
    equal(await storage.listRuns(first.id, 0), [], 'A zero run limit must return no records.');
    equal((await storage.listRuns(first.id, 1)).map((run) => run.id), ['invented-newest'], 'A positive run limit must cap history.');
    equal((await storage.listRuns(first.id, Number.MAX_SAFE_INTEGER)).length, 4, 'Large integer limits must work.');
    equal((await storage.listRuns(first.id, 1e100)).length, 4, 'Very large integer limits must preserve existing slice behavior.');
    for (const limit of [-1, 0.5, NaN, Infinity]) {
      await rejects(() => storage.listRuns(first.id, limit), 'Invalid run limits must be rejected.');
    }
    await rejects(() => storage.saveRun({ ...newest, id: 'invented-missing-run', appId: 'invented-missing' }),
      'Runs for missing applications must be rejected.');

    const replaced = { ...inventedRun(first, 'invented-tie-first'), status: 'failed' as const,
      failure: { code: 'INVENTED_FAILURE', message: 'Invented acceptance failure.' } };
    await storage.saveRun(replaced);
    equal((await storage.listRuns(first.id)).map((run) => run.id), expectedIds,
      'Replacing a run must retain its first-inserted tie position.');
    equal((await storage.listRuns(first.id))[1], replaced, 'Existing run IDs must replace the complete record.');
    await storage.saveRun({ ...replaced, appId: second.id });
    equal((await storage.listRuns(second.id)).map((run) => run.id), ['invented-tie-first'],
      'An existing run ID may move to another existing application.');
    equal((await storage.listRuns(first.id)).length, 3, 'Moving a run must remove it from its old application history.');
    await storage.saveRun(replaced);
    equal((await storage.listRuns(first.id)).map((run) => run.id), expectedIds,
      'Moving a run back must preserve its original insertion order.');

    const cyclic: Record<string, unknown> = {};
    cyclic.self = cyclic;
    const sparse = new Array(2);
    sparse[1] = 'invented';
    const getter = Object.defineProperty({}, 'value', { enumerable: true, get: () => 'invented' });
    const hidden = Object.defineProperty({}, 'value', { value: 'invented' });
    const symbolKey = { [Symbol('invented')]: 'invented' };
    const extraArray = Object.assign(['invented'], { invented: true });
    const invalidValues: unknown[] = [undefined, new Date(timestamp), 1n, NaN, Infinity,
      () => 'invented', Symbol('invented'), new Map([['invented', true]]), cyclic, sparse,
      getter, hidden, symbolKey, extraArray];
    for (const [index, value] of invalidValues.entries()) {
      const invalidRun = { ...newest, id: `invented-invalid-${index}`, params: { value } };
      await rejects(() => storage.saveRun(invalidRun), `Unsupported JSON run value ${index} must be rejected.`);
      await rejects(() => storage.setState(first.id, profiles.first, { value }),
        `Unsupported JSON state value ${index} must be rejected.`);
      equal((await storage.listRuns(first.id)).map((run) => run.id), expectedIds, 'Rejected run writes must not create records.');
      equal(await storage.getState(first.id, profiles.first), inventedState(), 'Rejected state writes must preserve previous state.');
    }
    await rejects(() => storage.saveRun({ ...newest, params: { value: undefined } }),
      'An invalid run replacement must be rejected.');
    equal((await storage.listRuns(first.id))[0], newest, 'Rejected replacements must preserve previous run records.');

    await storage.saveRun(inventedRun(duplicate, 'invented-delete-run'));
    await storage.setState(duplicate.id, profiles.first, { invented: true });
    await storage.deleteApp(duplicate.id);
    equal(await storage.getApp(duplicate.id), null, 'Deleted applications must be absent.');
    equal(await storage.listRuns(duplicate.id), [], 'Application deletion must remove all its runs.');
    equal(await storage.getState(duplicate.id, profiles.first), {}, 'Application deletion must remove all its state.');
    await storage.deleteApp(duplicate.id);
    equal((await storage.listApps(profiles.first)).map((app) => app.id), [first.id], 'Repeated deletion must be harmless.');

    writeFileSync(join(evidenceDir, 'manifest.json'), JSON.stringify({
      appId: first.id,
      secondAppId: second.id,
      appMetadata: { id: first.id, version: first.version, createdAt: first.createdAt,
        updatedAt: first.updatedAt, profile: first.profile },
      runIds: expectedIds,
    } satisfies Manifest));
  } finally {
    closeStorage();
  }
}

async function readAndCheck(evidenceDir: string): Promise<void> {
  const manifest = readManifest(evidenceDir);
  const storage = await import('../src/platform/index.ts');
  const { closeStorage } = await import('../src/platform/database.ts');
  try {
    const app = await storage.getApp(manifest.appId);
    check(app !== null, 'Applications must survive a fresh process and server restart.');
    equal(app.doc, inventedDocument(), 'The complete application document must survive a restart.');
    equal({ id: app.id, version: app.version, createdAt: app.createdAt, updatedAt: app.updatedAt, profile: app.profile },
      manifest.appMetadata, 'All application metadata must survive a fresh process unchanged.');
    equal(app.version, appVersion(inventedDocument()), 'Application versions must survive a restart.');
    equal((await storage.listApps(profiles.first)).map((record) => record.id), [manifest.appId],
      'Profile isolation and deleted applications must persist.');
    equal((await storage.listApps(profiles.second)).map((record) => record.id), [manifest.secondAppId],
      'Other profiles must survive a restart.');
    equal((await storage.listRuns(manifest.appId)).map((run) => run.id), manifest.runIds,
      'Run history and insertion order must survive a restart.');
    const runs = await storage.listRuns(manifest.appId);
    equal(runs[0], inventedRun(app, 'invented-newest', '2026-01-16T09:00:00.000Z'),
      'Complete run records must survive a restart.');
    equal(runs[1]!.failure, { code: 'INVENTED_FAILURE', message: 'Invented acceptance failure.' },
      'Run replacements must survive a restart.');
    equal(await storage.getState(manifest.appId, profiles.first), inventedState(), 'User state must survive a restart.');
    equal(await storage.getState(manifest.appId, profiles.second), {}, 'State profile isolation must survive a restart.');
  } finally {
    closeStorage();
  }
}

async function failureAndCheck(): Promise<void> {
  const storage = await import('../src/platform/index.ts');
  const { closeStorage } = await import('../src/platform/database.ts');
  try {
    await rejects(() => storage.listApps(profiles.first), 'An unavailable database must reject reads.');
    await rejects(() => storage.saveApp(inventedDocument(), profiles.first), 'An unavailable database must reject writes.');
  } finally {
    closeStorage();
  }
}

async function busyAndCheck(): Promise<void> {
  const storage = await import('../src/platform/index.ts');
  const { closeStorage } = await import('../src/platform/database.ts');
  try {
    const started = performance.now();
    await rejects(() => storage.saveApp(inventedDocument(), profiles.first), 'A locked database must reject writes.');
    check(performance.now() - started < 1000, 'A locked database must fail immediately without a busy wait.');
  } finally {
    closeStorage();
  }
}

async function configurationAndCheck(): Promise<void> {
  const { loadStorageConfig } = await import('../src/platform/config.ts');
  const original = process.env.BLOCKS_DB_PATH;
  try {
    delete process.env.BLOCKS_DB_PATH;
    equal(loadStorageConfig().path, join(projectRoot, 'data', 'blocks.sqlite'), 'Default storage must be rooted in the repository.');
    process.env.BLOCKS_DB_PATH = 'data/invented-custom.sqlite';
    equal(loadStorageConfig().path, join(projectRoot, 'data', 'invented-custom.sqlite'),
      'Relative storage paths must be rooted in the repository.');
    for (const value of ['', ' ', ':memory:', '\0']) {
      process.env.BLOCKS_DB_PATH = value;
      await rejects(async () => loadStorageConfig(), 'Invalid persistent database paths must be rejected.');
    }
  } finally {
    if (original === undefined) delete process.env.BLOCKS_DB_PATH;
    else process.env.BLOCKS_DB_PATH = original;
  }
}

function environment(databasePath: string): NodeJS.ProcessEnv {
  const result: NodeJS.ProcessEnv = { ...process.env, BLOCKS_DB_PATH: databasePath, CD80_PORT: '0' };
  delete result.TUSHARE_TOKEN;
  delete result.GITEE_AI_API_KEY;
  return result;
}

function runWorker(mode: string, databasePath: string, evidenceDir: string): void {
  const child = spawnSync(process.execPath, ['--no-warnings', scriptPath, mode, evidenceDir], {
    cwd: projectRoot,
    env: environment(databasePath),
    stdio: 'ignore',
    timeout: 15000,
  });
  if (child.status !== 0) {
    let detail = 'Worker failed or timed out.';
    try { detail = readFileSync(join(evidenceDir, 'failure.txt'), 'utf8').trim(); } catch {}
    throw new AcceptanceError(`${mode}: ${detail}`);
  }
}

type RunningServer = { child: ChildProcess; url: string };
const activeServers = new Set<ChildProcess>();

async function startServer(databasePath: string, evidenceDir?: string): Promise<RunningServer> {
  const arguments_ = evidenceDir
    ? ['--no-warnings', scriptPath, 'server-open', evidenceDir]
    : ['--no-warnings', 'src/server.ts'];
  const child = spawn(process.execPath, arguments_, {
    cwd: projectRoot,
    env: environment(databasePath),
    stdio: ['ignore', 'pipe', 'ignore'],
  });
  activeServers.add(child);
  child.once('exit', () => activeServers.delete(child));
  const url = await new Promise<string>((resolve, reject) => {
    let output = '';
    const timeout = setTimeout(() => reject(new AcceptanceError('Server startup timed out.')), 10000);
    const finish = (error?: Error, value?: string): void => {
      clearTimeout(timeout);
      child.stdout?.off('data', onData);
      child.off('error', onError);
      child.off('exit', onExit);
      if (error) reject(error);
      else resolve(value!);
    };
    const onData = (chunk: Buffer): void => {
      output += chunk.toString();
      const match = /Blocks is running at (http:\/\/127\.0\.0\.1:\d+)/.exec(output);
      if (match) finish(undefined, match[1]);
    };
    const onError = (): void => finish(new AcceptanceError('Server could not start.'));
    const onExit = (): void => finish(new AcceptanceError('Server exited before startup.'));
    child.stdout?.on('data', onData);
    child.once('error', onError);
    child.once('exit', onExit);
  });
  return { child, url };
}

async function checkCore(server: RunningServer): Promise<void> {
  const home = await fetch(server.url, { signal: AbortSignal.timeout(5000) });
  check(home.status === 200 && (await home.text()).includes('<title>Blocks</title>'), 'Core home page must remain available.');
  const health = await fetch(`${server.url}/health`, { signal: AbortSignal.timeout(5000) });
  check(health.status === 200, 'Core health endpoint must remain available.');
  const body = await health.json() as { status?: string; node?: string };
  check(body.status === 'ok' && body.node === process.version, 'Health must report the selected Node runtime.');
}

async function stopServer(server: RunningServer): Promise<void> {
  await new Promise<void>((resolve, reject) => {
    const timeout = setTimeout(() => {
      server.child.kill('SIGKILL');
      reject(new AcceptanceError('Server shutdown timed out.'));
    }, 5000);
    server.child.once('exit', (code) => {
      clearTimeout(timeout);
      if (code === 0) resolve();
      else reject(new AcceptanceError('Server did not shut down successfully.'));
    });
    server.child.kill('SIGTERM');
  });
}

async function checkFault(databasePath: string, evidenceDir: string): Promise<void> {
  runWorker('failure', databasePath, evidenceDir);
  const server = await startServer(databasePath);
  await checkCore(server);
  await stopServer(server);
}

async function main(): Promise<void> {
  const evidenceDir = mkdtempSync(join(tmpdir(), 'blocks-storage-acceptance-'));
  const databasePath = join(evidenceDir, 'blocks.sqlite');
  let succeeded = false;
  try {
    runWorker('configuration', databasePath, evidenceDir);
    console.log('PASS storage path configuration');
    runWorker('write', databasePath, evidenceDir);
    console.log('PASS eight storage functions and JSON rejection');
    runWorker('read', databasePath, evidenceDir);
    console.log('PASS independent-process persistence');

    const firstServer = await startServer(databasePath, evidenceDir);
    await checkCore(firstServer);
    runWorker('read', databasePath, evidenceDir);
    await stopServer(firstServer);
    const secondServer = await startServer(databasePath, evidenceDir);
    await checkCore(secondServer);
    runWorker('read', databasePath, evidenceDir);
    await stopServer(secondServer);
    console.log('PASS stopped-and-restarted server persistence');

    const lock = new DatabaseSync(databasePath);
    try {
      lock.exec('BEGIN EXCLUSIVE');
      runWorker('busy', databasePath, evidenceDir);
      lock.exec('ROLLBACK');
    } finally {
      lock.close();
    }
    runWorker('read', databasePath, evidenceDir);
    console.log('PASS immediate database-lock rejection');

    const blockedParent = join(evidenceDir, 'invented-parent-file');
    writeFileSync(blockedParent, 'Invented non-directory fixture.');
    await checkFault(join(blockedParent, 'blocks.sqlite'), evidenceDir);
    equal(readFileSync(blockedParent, 'utf8'), 'Invented non-directory fixture.', 'Invalid-path failures must preserve existing files.');
    console.log('PASS inaccessible storage and core-server availability');

    const corruptPath = join(evidenceDir, 'invented-corrupt.sqlite');
    const corruptContents = Buffer.from('Invented invalid SQLite fixture.');
    writeFileSync(corruptPath, corruptContents);
    await checkFault(corruptPath, evidenceDir);
    equal(readFileSync(corruptPath), corruptContents, 'Corrupt databases must not be cleared or replaced.');
    console.log('PASS corrupt-database rejection without data replacement');

    const unknownPath = join(evidenceDir, 'invented-unknown-version.sqlite');
    const unknown = new DatabaseSync(unknownPath);
    unknown.exec('PRAGMA user_version = 999');
    unknown.close();
    const unknownContents = readFileSync(unknownPath);
    await checkFault(unknownPath, evidenceDir);
    equal(readFileSync(unknownPath), unknownContents, 'Unknown database versions must not be cleared or migrated silently.');
    console.log('PASS unknown-schema rejection without data replacement');

    const foreignVersionPath = join(evidenceDir, 'invented-foreign-version.sqlite');
    const foreignVersion = new DatabaseSync(foreignVersionPath);
    foreignVersion.exec('PRAGMA user_version = 1');
    foreignVersion.close();
    const foreignVersionContents = readFileSync(foreignVersionPath);
    await checkFault(foreignVersionPath, evidenceDir);
    equal(readFileSync(foreignVersionPath), foreignVersionContents,
      'Version one without the Blocks application ID must not be accepted or replaced.');
    console.log('PASS foreign-database identity rejection');

    const unrelatedPath = join(evidenceDir, 'invented-unrelated.sqlite');
    const unrelated = new DatabaseSync(unrelatedPath);
    unrelated.exec("CREATE TABLE sqliteXcustom (value TEXT); INSERT INTO sqliteXcustom VALUES ('invented');");
    unrelated.close();
    const unrelatedContents = readFileSync(unrelatedPath);
    await checkFault(unrelatedPath, evidenceDir);
    equal(readFileSync(unrelatedPath), unrelatedContents, 'Unrelated databases must not be repurposed.');
    console.log('PASS unrelated-database rejection without data replacement');
    succeeded = true;
  } catch (error) {
    console.error(`FAIL ${error instanceof AcceptanceError ? error.message : 'Unexpected storage acceptance error.'}`);
    if (error instanceof Error) writeFileSync(join(evidenceDir, 'failure-details.txt'), error.stack ?? error.message);
    console.error(`Acceptance evidence retained at ${evidenceDir}`);
    process.exitCode = 1;
  } finally {
    for (const child of activeServers) child.kill('SIGKILL');
    if (succeeded) rmSync(evidenceDir, { recursive: true, force: true });
  }
}

const mode = process.argv[2] ?? 'main';
if (mode === 'main') {
  await main();
} else {
  const evidenceDir = process.argv[3];
  check(evidenceDir, 'An acceptance evidence directory is required.');
  try {
    if (mode === 'write') await writeAndCheck(evidenceDir);
    else if (mode === 'read') await readAndCheck(evidenceDir);
    else if (mode === 'failure') await failureAndCheck();
    else if (mode === 'busy') await busyAndCheck();
    else if (mode === 'configuration') await configurationAndCheck();
    else if (mode === 'server-open') {
      const { getApp } = await import('../src/platform/index.ts');
      check(await getApp(readManifest(evidenceDir).appId), 'The server must open the persisted database before startup.');
      await import('../src/server.ts');
    }
    else throw new AcceptanceError('Unknown acceptance worker mode.');
  } catch (error) {
    writeFileSync(join(evidenceDir, 'failure.txt'), error instanceof AcceptanceError ? error.message : 'Unexpected storage error.');
    if (error instanceof Error) writeFileSync(join(evidenceDir, 'worker-failure-details.txt'), error.stack ?? error.message);
    process.exitCode = 1;
  }
}
