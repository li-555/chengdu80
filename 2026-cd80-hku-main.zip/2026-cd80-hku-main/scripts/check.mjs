import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createRuntimeEnvironment, resolveNode } from './runtime.mjs';

let runtime;
try {
  runtime = resolveNode();
} catch (error) {
  console.error(`[FAIL] Runtime: ${error instanceof Error ? error.message : 'Unable to locate a supported Node.js runtime.'}`);
  process.exit(1);
}

const checker = spawn(runtime.executable, ['--env-file-if-exists=.env', 'src/platform/check.ts'], {
  cwd: fileURLToPath(new URL('../', import.meta.url)),
  env: createRuntimeEnvironment(runtime.executable),
  stdio: 'inherit',
});

process.once('SIGINT', () => checker.kill('SIGINT'));
process.once('SIGTERM', () => checker.kill('SIGTERM'));
checker.once('error', () => {
  console.error('[FAIL] Configuration check: unable to start the checker.');
  process.exitCode = 1;
});
checker.once('exit', (code) => { process.exitCode = code ?? 1; });
