import { mkdir, readFile, writeFile } from 'node:fs/promises';
import ts from 'typescript';

const entries = ['markdown-tables', 'ui-icon', 'appearance', 'pointer-motion', 'workspace-ui', 'motion-runtime', 'motion-elements', 'workspace-motion', 'theme-transition', 'theme-init', 'app', 'screen-elements', 'screen-controls', 'upload-preview', 'screen-example', 'charts', 'compare', 'data-screen', 'i18n', 'preferences', 'chat-stream', 'chat-screen', 'chat-upload', 'templates', 'list-actions', 'record-tools', 'record-state', 'monitor-panel', 'flagship-i18n'];
const check = process.argv.includes('--check');

try {
  const outputs = [];
  for (const name of entries) {
    const sourceFile = new URL(name === 'markdown-tables' ? '../src/data/markdown-tables.ts' : `../web/src/${name}.ts`, import.meta.url);
    const outputFile = new URL(`../web/assets/${name}.js`, import.meta.url);
    const source = await readFile(sourceFile, 'utf8');
    const result = ts.transpileModule(source, {
      fileName: `${name}.ts`,
      compilerOptions: {
        target: ts.ScriptTarget.ES2023,
        module: ts.ModuleKind.ES2022,
        verbatimModuleSyntax: true,
        rewriteRelativeImportExtensions: true,
        newLine: ts.NewLineKind.LineFeed,
      },
      reportDiagnostics: true,
    });
    const errors = (result.diagnostics ?? []).filter((diagnostic) => diagnostic.category === ts.DiagnosticCategory.Error);
    if (errors.length > 0) {
      throw new Error(ts.formatDiagnosticsWithColorAndContext(errors, {
        getCurrentDirectory: () => process.cwd(),
        getCanonicalFileName: (fileName) => fileName,
        getNewLine: () => '\n',
      }));
    }
    outputs.push({ name, outputFile, content: result.outputText.replaceAll('../../src/data/markdown-tables.js', './markdown-tables.js') });
  }
  const vendorRoot = new URL('../node_modules/echarts/', import.meta.url);
  const vendorPackage = JSON.parse(await readFile(new URL('package.json', vendorRoot), 'utf8'));
  const manifest = JSON.parse(await readFile(new URL('../package.json', import.meta.url), 'utf8'));
  if (vendorPackage.version !== manifest.devDependencies.echarts) throw new Error('Install the declared ECharts version before preparing browser assets.');
  for (const [source, destination] of [
    ['dist/echarts.esm.min.js', 'echarts.esm.min.js'],
    ['LICENSE', 'echarts-LICENSE.txt'],
    ['NOTICE', 'echarts-NOTICE.txt'],
  ]) {
    outputs.push({ name: destination, outputFile: new URL(`../web/assets/${destination}`, import.meta.url),
      content: await readFile(new URL(source, vendorRoot), 'utf8') });
  }
  const gsapRoot = new URL('../node_modules/gsap/', import.meta.url);
  const gsapPackage = JSON.parse(await readFile(new URL('package.json', gsapRoot), 'utf8'));
  if (gsapPackage.version !== manifest.devDependencies.gsap) throw new Error('Install the declared GSAP version before preparing browser assets.');
  // Keep the distributed copyright/license text; normalize comment whitespace.
  for (const [source, destination] of [['dist/gsap.min.js', 'gsap.min.js'], ['dist/SplitText.min.js', 'SplitText.min.js']]) {
    outputs.push({ name: destination, outputFile: new URL(`../web/assets/${destination}`, import.meta.url),
      content: (await readFile(new URL(source, gsapRoot), 'utf8')).replace(/[\t ]+$/gm, '').trimEnd() + '\n' });
  }
  for (const { name, outputFile, content } of outputs) {
    if (check) {
      const current = await readFile(outputFile, 'utf8').catch((error) => {
        if (error.code === 'ENOENT') return '';
        throw error;
      });
      if (current !== content) throw new Error(`The browser asset ${outputFile.pathname.split('/').pop()} is out of date. Run npm run build:web before committing.`);
    } else {
      await mkdir(new URL('../web/assets/', import.meta.url), { recursive: true });
      await writeFile(outputFile, content, 'utf8');
      console.log(`Built web/assets/${outputFile.pathname.split('/').pop()}.`);
    }
  }
  if (check) console.log('The browser assets are up to date.');
} catch (error) {
  console.error(error instanceof Error ? error.message : 'Unable to build the browser asset.');
  process.exitCode = 1;
}
