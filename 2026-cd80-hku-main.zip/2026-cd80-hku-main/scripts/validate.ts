#!/usr/bin/env node
/**
 * Check an application file.
 *
 *   npm run validate -- app.json
 *   cat app.json | npm run validate -- --stdin
 *   npm run validate -- app.json --json
 *
 * Exit codes: 0 valid, 1 invalid, 2 the command itself was used wrongly.
 * Works with no data token and no model key set.
 */
import { readFileSync } from 'node:fs';
import { validateApplication } from '../src/validate/index.ts';

const USAGE = `Usage:
  validate <file.json>          check a file
  validate --stdin              read the application from standard input
Options:
  --json                        print the full report as JSON
  --quiet                       print nothing; rely on the exit code
Exit codes: 0 valid, 1 invalid, 2 wrong usage.`;

const argv = process.argv.slice(2);
const flags = new Set(argv.filter((a) => a.startsWith('--')));
const files = argv.filter((a) => !a.startsWith('--'));

for (const f of flags) {
  if (!['--stdin', '--json', '--quiet', '--help'].includes(f)) {
    process.stderr.write(`Unknown option ${f}\n\n${USAGE}\n`);
    process.exit(2);
  }
}
if (flags.has('--help')) { process.stdout.write(`${USAGE}\n`); process.exit(0); }

const useStdin = flags.has('--stdin');
if (useStdin && files.length > 0) {
  process.stderr.write(`Give a file or --stdin, not both.\n\n${USAGE}\n`);
  process.exit(2);
}
if (!useStdin && files.length !== 1) {
  process.stderr.write(`${files.length === 0 ? 'No file given.' : 'Give exactly one file.'}\n\n${USAGE}\n`);
  process.exit(2);
}

let text: string;
try {
  text = useStdin ? readFileSync(0, 'utf8') : readFileSync(files[0]!, 'utf8');
} catch (e) {
  process.stderr.write(`Could not read ${useStdin ? 'standard input' : files[0]}: ${(e as Error).message}\n`);
  process.exit(2);
}

const result = validateApplication(text);
const { report } = result;

if (flags.has('--json')) {
  process.stdout.write(`${JSON.stringify(report, null, 2)}\n`);
} else if (!flags.has('--quiet')) {
  const lines: string[] = [report.summary, ''];
  for (const e of report.errors) {
    lines.push(`error  ${e.pointer || '(root)'}`);
    lines.push(`       ${e.message}`);
    if (e.hint) lines.push(`       fix: ${e.hint}`);
    lines.push(`       ${e.code}`);
    lines.push('');
  }
  for (const w of report.warnings) {
    lines.push(`warning  ${w.pointer || '(root)'}`);
    lines.push(`         ${w.message}`);
    if (w.hint) lines.push(`         fix: ${w.hint}`);
    lines.push(`         ${w.code}`);
    lines.push('');
  }
  process.stdout.write(`${lines.join('\n')}\n`);
}

process.exit(report.valid ? 0 : 1);
