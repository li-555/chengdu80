import { mkdtempSync, readFileSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, resolve } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('../', import.meta.url));
const temporary = mkdtempSync(join(tmpdir(), 'blocks-skill-'));

try {
  const build = spawnSync(process.execPath, ['scripts/skill-build.ts', temporary], { cwd: root, encoding: 'utf8' });
  if (build.error || build.status !== 0) {
    console.error(build.error?.message ?? build.stderr ?? 'Skill build failed.');
    process.exitCode = 1;
  } else {
    const published = process.argv[2] ? resolve(process.argv[2]) : join(root, 'skill');
    const list = (directory, prefix = '') => readdirSync(directory, { withFileTypes: true }).flatMap((entry) => entry.isDirectory() ? list(join(directory, entry.name), prefix + entry.name + '/') : [prefix + entry.name]);
    const generated = list(temporary);
    let existing = [];
    try {
      existing = list(published);
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
    const names = [...new Set([...generated, ...existing])].sort();
    const differences = [];
    for (const name of names) {
      if (!generated.includes(name)) {
        differences.push(`${name}: unexpected file`);
      } else if (!existing.includes(name)) {
        differences.push(`${name}: missing file`);
      } else if (!readFileSync(join(temporary, name)).equals(readFileSync(join(published, name)))) {
        differences.push(`${name}: differs`);
      }
    }
    if (differences.length > 0) {
      for (const difference of differences) console.error(difference);
      console.error('Skill is out of date. Run npm run skill:build.');
      process.exitCode = 1;
    } else {
      console.log(`Skill matches (${generated.length} files).`);
    }
  }
} finally {
  rmSync(temporary, { recursive: true, force: true });
}
