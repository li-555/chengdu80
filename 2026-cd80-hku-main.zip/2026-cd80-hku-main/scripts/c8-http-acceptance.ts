/** Browser API checks on loopback only. Every dataset and row is invented. */
import assert from 'node:assert/strict';
import { mock } from 'node:test';
import { mkdtempSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { request as httpRequest } from 'node:http';
import express from 'express';
let externalCalls = 0;
globalThis.fetch = async () => { externalCalls++; throw new Error('External requests are forbidden.'); };
mock.module('../src/data/index.ts', { namedExports: {
  listDatasets: async () => [
    { id: 'invented:values', name: 'Invented values', source: 'tushare', fields: [{ name: 'company', label: 'Company', type: 'text', nullable: false }, { name: 'amount', label: 'Amount', type: 'number', nullable: false }] },
    { id: 'invented:upload', name: 'Private upload', source: 'upload', fields: [] },
  ],
  getDataset: async (id: string) => id === 'invented:upload' ? { id, name: 'Invented upload', source: 'upload', fields: [] } : id === 'invented:values' ? { id, name: 'Invented', source: 'tushare', fields: [
    { name: 'company', label: 'Company', type: 'text', nullable: false },
    { name: 'amount', label: 'Amount', type: 'number', nullable: false },
  ] } : null,
  isTradingDay: async () => true,
  resolveSlice: async () => ({ schema: [
    { name: 'company', label: 'Company', type: 'text', nullable: false },
    { name: 'amount', label: 'Amount', type: 'number', nullable: false },
  ], rows: [['Fictional Amber', 12], ['Fictional Birch', 8]], datasetVersion: 'invented-http-v1' }),
} });
process.env.BLOCKS_DB_PATH = join(mkdtempSync(join(tmpdir(), 'blocks-c8-http-')), 'acceptance.sqlite');
const { appRoutes } = await import('../src/api/routes-apps.ts');
const { inventedScheduledDocument } = await import('../src/platform/invented-execution.ts');
const { saveApp, setState, getState } = await import('../src/platform/index.ts');
const { closeStorage } = await import('../src/platform/database.ts');
const app = express(); app.use(...appRoutes);
const server = app.listen(0, '127.0.0.1');
await new Promise<void>((resolve, reject) => { server.once('listening', resolve); server.once('error', reject); });
const address = server.address();
if (!address || typeof address === 'string') throw new Error('Expected loopback address.');
const port = address.port;
async function request(path: string, method = 'GET', cookie?: string, body?: unknown, headers: Record<string, string> = {}) {
  return new Promise<{ status: number; body: any; cookie?: string }>((resolve, reject) => {
    const req = httpRequest({ host: '127.0.0.1', port, path, method, headers: {
      ...(cookie ? { Cookie: cookie } : {}), ...(body ? { 'Content-Type': 'application/json' } : {}), ...headers,
    } }, (response) => {
      let text = ''; response.setEncoding('utf8'); response.on('data', (chunk) => { text += chunk; });
      response.on('end', () => resolve({ status: response.statusCode!, body: JSON.parse(text), cookie: response.headers['set-cookie']?.[0]?.split(';')[0] }));
    });
    req.once('error', reject); req.setTimeout(10000, () => req.destroy(new Error('Loopback check timed out.')));
    req.end(body === undefined ? undefined : JSON.stringify(body));
  });
}
try {
  const first = await request('/api/apps'); const cookie = first.cookie!;
  assert.ok(cookie);
  const other = (await request('/api/apps')).cookie!;
  const profile = `browser:${cookie.split('=')[1]}`;
  const saved = await saveApp(inventedScheduledDocument(), profile);
  await setState(saved.id, profile, { params: { scale: 2 }, bindings: { invented_values: 'invented:values' }, carry: { secret: 'never-return-settings-carry' } });
  const path = `/api/apps/${saved.id}`;
  const body = { runId: 'invented_http_run', params: { scale: 3 } };
  const headers = { 'X-Blocks-Request': '1' };
  assert.equal((await request(`${path}/run`, 'POST', cookie, body)).status, 403);
  assert.equal((await request(`${path}/run`, 'POST', cookie, body, { ...headers, Origin: 'https://unrelated.invalid' })).status, 403);
  assert.equal((await request(`${path}/run`, 'POST', other, body, headers)).status, 404);
  assert.equal((await request(`${path}/runs`, 'GET', other)).status, 404);
  assert.equal((await request(`${path}/run`, 'POST', cookie, { ...body, adapter: 'invented' }, headers)).status, 400);
  const run = await request(`${path}/run`, 'POST', cookie, body, headers);
  assert.equal(run.status, 200); assert.equal(run.body.kind, 'completed'); assert.equal(run.body.record.status, 'ok', JSON.stringify(run.body));
  assert.deepEqual(run.body.record.result.outputs.total.rows, [[60]]);
  assert.equal(run.body.record.sources[0].datasetVersion, 'invented-http-v1');
  assert.equal((await request(`${path}/run`, 'POST', cookie, body, headers)).body.reused, true);
  const history = await request(`${path}/runs`, 'GET', cookie);
  assert.equal(history.status, 200); assert.equal(history.body.runs.length, 1); assert.deepEqual(history.body.params, { scale: 2 });
  assert.equal(Object.hasOwn(history.body, 'carry'), false);
  assert.deepEqual(history.body.runs[0].sources, run.body.record.sources);
  const state = await getState(saved.id, profile);
  await setState(saved.id, profile, { ...state, bindings: {} });
  const blocked = await request(`${path}/run`, 'POST', cookie, { runId: 'invented_http_blocked' }, headers);
  assert.equal(blocked.status, 200); assert.equal(blocked.body.kind, 'needs_data'); assert.equal(blocked.body.issue.code, 'NeedsBindingError');
  assert.equal((await request(`${path}/runs`, 'GET', cookie)).body.runs.length, 1);
  assert.equal((await request(`${path}/connection`, 'GET', other)).status, 404);
  const connection = await request(`${path}/connection`, 'GET', cookie);
  assert.equal(connection.status, 200);
  assert.deepEqual(connection.body.datasets.map((item: { id: string }) => item.id), ['invented:values']);
  assert.equal(Object.hasOwn(connection.body.settings, 'carry'), false);
  const changed = { revision: connection.body.revision, settings: { params: { scale: 4 }, bindings: { invented_values: 'invented:values' }, mappings: {} } };
  assert.equal((await request(`${path}/connection`, 'POST', other, changed, headers)).status, 404);
  assert.equal((await request(`${path}/connection`, 'POST', cookie, changed)).status, 403);
  assert.equal((await request(`${path}/connection`, 'POST', cookie, changed, { ...headers, Origin: 'https://unrelated.invalid' })).status, 403);
  assert.equal((await request(`${path}/connection`, 'POST', cookie, { ...changed, settings: { ...changed.settings, carry: {} } }, headers)).status, 400);
  assert.equal((await request(`${path}/connection`, 'POST', cookie, { ...changed, settings: { ...changed.settings, params: { scale: 999 } } }, headers)).status, 422);
  // Carry changes after the settings read must be retained without causing a settings conflict.
  const current = await getState(saved.id, profile);
  await setState(saved.id, profile, { ...current, carry: { n: 9 }, extra: 'keep' });
  assert.equal((await request(`${path}/connection`, 'POST', cookie, changed, headers)).status, 200);
  assert.deepEqual(await getState(saved.id, profile), { ...changed.settings, carry: { n: 9 }, extra: 'keep' });
  assert.equal((await request(`${path}/connection`, 'POST', cookie, changed, headers)).status, 409);
  const resumed = await request(`${path}/run`, 'POST', cookie, { runId: 'invented_http_blocked' }, headers);
  assert.equal(resumed.body.kind, 'completed'); assert.equal(resumed.body.record.status, 'ok');
  assert.deepEqual(resumed.body.record.result.outputs.total.rows, [[80]]);
  for (const code of ['NeedsMappingError']) {
    const read = await request(`${path}/connection`, 'GET', cookie);
    const settings = structuredClone(changed.settings) as { params: { scale: number }; bindings: Record<string, string>; mappings: Record<string, Record<string, string>> };
    if (code === 'NeedsMappingError') settings.mappings = { invented_values: { amount: 'missing' } };
    else settings.bindings.invented_values = 'invented:upload';
    assert.equal((await request(`${path}/connection`, 'POST', cookie, { revision: read.body.revision, settings }, headers)).status, 200);
    const count = (await request(`${path}/runs`, 'GET', cookie)).body.runs.length;
    const runId = `fix_${code}`;
    const needsData = await request(`${path}/run`, 'POST', cookie, { runId }, headers);
    assert.equal(needsData.body.kind, 'needs_data'); assert.equal(needsData.body.issue.code, code);
    assert.equal((await request(`${path}/runs`, 'GET', cookie)).body.runs.length, count);
    const beforeFix = await request(`${path}/connection`, 'GET', cookie);
    assert.deepEqual(beforeFix.body.settings, settings);
    assert.equal((await request(`${path}/connection`, 'POST', cookie, { revision: beforeFix.body.revision, settings: changed.settings }, headers)).status, 200);
    const fixed = await request(`${path}/run`, 'POST', cookie, { runId }, headers);
    assert.equal(fixed.body.kind, 'completed'); assert.equal(fixed.body.record.status, 'ok');
    assert.deepEqual((await getState(saved.id, profile)).carry, { n: 9 });
  }
  console.log('PASS connection HTTP: saved settings, carry-safe atomic update, conflicts, upload privacy, both correction/retry flows');
  const schedule = { triggerIndex: 1, action: 'enable', appVersion: saved.version };
  assert.equal((await request(`${path}/schedules`, 'GET', other)).status, 404);
  assert.equal((await request(`${path}/schedules`, 'POST', cookie, schedule)).status, 403);
  assert.equal((await request(`${path}/schedules`, 'POST', other, schedule, headers)).status, 404);
  assert.equal((await request(`${path}/schedules`, 'POST', cookie, { ...schedule, profile: 'other' }, headers)).status, 400);
  assert.equal((await request(`${path}/schedules`, 'POST', cookie, { ...schedule, triggerIndex: 0 }, headers)).status, 400);
  assert.equal((await request(`${path}/schedules`, 'POST', cookie, { ...schedule, appVersion: 'old' }, headers)).status, 409);
  const enabled = await request(`${path}/schedules`, 'POST', cookie, schedule, headers);
  assert.equal(enabled.status, 200); assert.equal(enabled.body.task.enabled, true);
  assert.ok(enabled.body.task.nextRunAt > new Date().toISOString());
  assert.equal((await request(`${path}/schedules`, 'GET', cookie)).body.tasks.length, 1);
  const paused = await request(`${path}/schedules`, 'POST', cookie, { ...schedule, action: 'pause' }, headers);
  assert.equal(paused.body.task.enabled, false);
  const resumedTask = await request(`${path}/schedules`, 'POST', cookie, { ...schedule, action: 'resume' }, headers);
  assert.equal(resumedTask.body.task.enabled, true);
  assert.equal((await request(`${path}/schedules`, 'GET', cookie)).body.tasks.length, 1);
  console.log('PASS task HTTP: enable/pause/resume, owner isolation, strict actions, stale version rejection');
  assert.equal(externalCalls, 0);
  console.log('PASS run/history HTTP: owner isolation, same-origin/header checks, strict request shape, parameter overrides, retry, sources and needs_data');
  console.log('PASS external requests: 0; loopback HTTP and invented rows only');
} finally {
  await new Promise<void>((resolve) => server.close(() => resolve()));
  closeStorage(); mock.restoreAll();
}
