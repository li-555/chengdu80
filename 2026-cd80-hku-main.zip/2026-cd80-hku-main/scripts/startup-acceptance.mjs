import assert from 'node:assert/strict';
import { spawn, spawnSync } from 'node:child_process';
import { cpSync, existsSync, mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { isSupportedNodeVersion, resolveNode } from './runtime.mjs';

const projectRoot = fileURLToPath(new URL('../', import.meta.url));
const evidenceDir = mkdtempSync(join(tmpdir(), 'blocks-startup-acceptance-'));
const installationMarker = join(evidenceDir, 'installation-request.json');
const fakeNpm = join(evidenceDir, 'invented-npm.cjs');
const activeChildren = new Set();

async function check(name, action) {
  await action();
  console.log(`PASS ${name}`);
}

function environment(runtime) {
  const env = {
    ...process.env,
    BLOCKS_NODE_PATH: runtime.executable,
    BLOCKS_DB_PATH: join(evidenceDir, 'unused.sqlite'),
    CD80_PORT: '0',
    npm_execpath: fakeNpm,
  };
  // Explicit empty values override personal .env credentials in startup checks.
  env.TUSHARE_TOKEN = '';
  env.GITEE_AI_API_KEY = '';
  return env;
}

async function checkServer(script, runtime) {
  const child = spawn(runtime.executable, [script], {
    cwd: projectRoot,
    env: environment(runtime),
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  activeChildren.add(child);
  let diagnostics = '';
  const record = (chunk) => {
    diagnostics += chunk.toString();
    writeFileSync(join(evidenceDir, `${script.split('/').at(-1)}.log`), diagnostics);
  };
  child.stdout.on('data', record);
  child.stderr.on('data', record);
  const exited = new Promise((resolve) => child.once('exit', (code, signal) => {
    activeChildren.delete(child);
    resolve({ code, signal });
  }));
  const url = await new Promise((resolve, reject) => {
    let output = '';
    const timeout = setTimeout(() => finish(new Error('Server startup timed out.')), 10000);
    function finish(error, value) {
      clearTimeout(timeout);
      child.stdout.off('data', onData);
      child.off('error', onError);
      child.off('exit', onExit);
      if (error) reject(error);
      else resolve(value);
    }
    function onData(chunk) {
      output += chunk.toString();
      const match = /Blocks is running at (http:\/\/127\.0\.0\.1:\d+)/.exec(output);
      if (match) finish(undefined, match[1]);
    }
    function onError() { finish(new Error('Server process could not start.')); }
    function onExit() { finish(new Error('Server exited before startup.')); }
    child.stdout.on('data', onData);
    child.once('error', onError);
    child.once('exit', onExit);
  });

  const home = await fetch(url, { signal: AbortSignal.timeout(5000) });
  assert.equal(home.status, 200);
  assert.match(await home.text(), /<title>Blocks<\/title>/);
  const health = await fetch(`${url}/health`, { signal: AbortSignal.timeout(5000) });
  assert.equal(health.status, 200);
  assert.deepEqual(await health.json(), { status: 'ok', node: runtime.version });
  const theme = await fetch(`${url}/assets/theme.css`, { signal: AbortSignal.timeout(5000) });
  assert.equal(theme.status, 200);
  await theme.text();
  assert.equal(existsSync(installationMarker), false, 'Installed dependencies must not trigger installation.');
  child.kill('SIGTERM');
  let timeout;
  try {
    const result = await Promise.race([
      exited,
      new Promise((_, reject) => {
        timeout = setTimeout(() => reject(new Error('Server shutdown timed out.')), 5000);
      }),
    ]);
    assert.deepEqual(result, { code: 0, signal: null });
    await assert.rejects(fetch(`${url}/health`, { signal: AbortSignal.timeout(2000) }));
  } finally {
    clearTimeout(timeout);
  }
}

async function main() {
  const runtime = resolveNode();
  await check('minimum version, newer releases and invalid versions', () => {
    for (const version of ['24.11.0', 'v24.11.1', '24.12.0', 'v25.0.0', '25.1.0', 'v26.8.1']) {
      assert.equal(isSupportedNodeVersion(version), true, version);
    }
    for (const version of ['v20.20.0', 'v23.99.0', '24.10.99', '24.0.0', '24', 'v25.0.0-rc.1', '', 'invalid', 'v024.11.0']) {
      assert.equal(isSupportedNodeVersion(version), false, version);
    }
    const manifest = JSON.parse(readFileSync(join(projectRoot, 'package.json'), 'utf8'));
    assert.equal(manifest.engines.node, '>=24.11.0');
    assert.equal(manifest.scripts.start, 'node scripts/start.mjs');
    assert.equal(manifest.scripts.go, 'node scripts/go.mjs');
  });

  await check('current runtime preference and explicit override failures', () => {
    const original = process.env.BLOCKS_NODE_PATH;
    try {
      delete process.env.BLOCKS_NODE_PATH;
      if (isSupportedNodeVersion(process.version)) {
        assert.equal(resolveNode().executable, process.execPath);
      }
      process.env.BLOCKS_NODE_PATH = runtime.executable;
      assert.deepEqual(resolveNode(), runtime);
      for (const path of ['', ' ', join(evidenceDir, 'invented-missing-node')]) {
        process.env.BLOCKS_NODE_PATH = path;
        assert.throws(() => resolveNode(), /Node.js 24\.11\.0 or later is required/);
      }
    } finally {
      if (original === undefined) delete process.env.BLOCKS_NODE_PATH;
      else process.env.BLOCKS_NODE_PATH = original;
    }
  });

  writeFileSync(fakeNpm, `require('node:fs').writeFileSync(${JSON.stringify(installationMarker)}, JSON.stringify(process.argv.slice(2))); process.exit(73);\n`);
  const emptyProject = join(evidenceDir, 'invented-project');
  mkdirSync(join(emptyProject, 'src'), { recursive: true });
  cpSync(join(projectRoot, 'scripts'), join(emptyProject, 'scripts'), { recursive: true });
  cpSync(join(projectRoot, 'src/platform'), join(emptyProject, 'src/platform'), { recursive: true });
  for (const path of ['package.json', 'package-lock.json', 'src/server.ts']) {
    cpSync(join(projectRoot, path), join(emptyProject, path));
  }
  const invokeEmptyProject = (script) => spawnSync(runtime.executable, [join(emptyProject, script)], {
    cwd: projectRoot,
    env: environment(runtime),
    encoding: 'utf8',
    timeout: 15000,
  });

  await check('start fails without dependencies and never invokes installation', () => {
    const result = invokeEmptyProject('scripts/start.mjs');
    assert.equal(result.status, 1);
    assert.match(result.stderr, /ERR_MODULE_NOT_FOUND/);
    assert.equal(existsSync(installationMarker), false);
  });
  await check('go requests locked production dependencies and stops on installation failure', () => {
    const result = invokeEmptyProject('scripts/go.mjs');
    assert.equal(result.status, 73);
    assert.match(result.stderr, /Dependency installation failed/);
    assert.doesNotMatch(result.stdout, /Starting Blocks/);
    const args = JSON.parse(readFileSync(installationMarker, 'utf8'));
    assert.equal(args[0], 'ci', 'Installation must use the committed lockfile.');
    assert.ok(args.includes('--omit=dev'), 'Installation must select runtime dependencies.');
    assert.ok(args.includes('--fetch-retries=0'), 'Installation must not retry failed requests.');
    rmSync(installationMarker);
  });
  await check(`start serves home, health and theme; forwards shutdown (${runtime.version})`, () => checkServer('scripts/start.mjs', runtime));
  await check(`go uses installed dependencies and starts the same server (${runtime.version})`, () => checkServer('scripts/go.mjs', runtime));
}

let succeeded = false;
try {
  await main();
  succeeded = true;
} catch (error) {
  console.error(`FAIL ${error instanceof Error ? error.message : 'Startup acceptance failed.'}`);
  console.error(`Acceptance evidence retained at ${evidenceDir}`);
  process.exitCode = 1;
} finally {
  for (const child of activeChildren) child.kill('SIGTERM');
  if (succeeded) rmSync(evidenceDir, { recursive: true, force: true });
}
