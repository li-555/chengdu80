/** Isolated clock-loop checks with fictional rows and no network access. */
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { setTimeout as delay } from 'node:timers/promises';
import { nextCronTime } from '../src/platform/cron.ts';

let requests = 0;
globalThis.fetch = async () => { requests++; throw new Error('External requests are forbidden.'); };
process.env.BLOCKS_DB_PATH = join(mkdtempSync(join(tmpdir(), 'blocks-c8-scheduler-')), 'checks.sqlite');
const platform = await import('../src/platform/index.ts');
const { storageOperation, storageTransaction, closeStorage } = await import('../src/platform/database.ts');
const { ownedTask, writeTask } = await import('../src/platform/schedules.ts');
const { inventedScheduledDocument, inventedExecutionAdapter } = await import('../src/platform/invented-execution.ts');
const { NeedsBindingError } = await import('../src/compute/slices.ts');
const profile = 'fictional-clock-check';
const loops: ReturnType<typeof platform.createScheduler>[] = [];
const due = () => new Date(Date.now() - 2000).toISOString();
const fixtureRun: typeof platform.runSavedApplication = (options) => platform.runSavedApplication({ ...options,
  adapter: inventedExecutionAdapter(), allowInventedData: true });
function makeDue(id: string, time = due()): void {
  storageOperation((database) => storageTransaction(database, () => {
    const task = ownedTask(database, id, profile);
    writeTask(database, { ...task, nextRunAt: time });
  }));
}
async function setup() {
  const app = await platform.saveApp(inventedScheduledDocument(), profile);
  const task = await platform.createScheduledTask(app.id, profile, 1);
  const enabled = await platform.setScheduleEnabled(task.id, profile, true);
  assert.equal(enabled.automatic, true);
  assert.ok(enabled.nextRunAt! > new Date().toISOString());
  return { app, task };
}
function loop(run = fixtureRun) {
  const value = platform.createScheduler({ intervalMs: 10, run }); loops.push(value); return value;
}

try {
  assert.equal(nextCronTime('0 8 * * 1-5', 'Asia/Shanghai', '2026-10-16T00:00:00.000Z'), '2026-10-19T00:00:00.000Z');
  assert.equal(nextCronTime('*/15 9-10 * * *', 'Asia/Kathmandu', '2026-10-14T03:15:01.000Z'), '2026-10-14T03:30:00.000Z');
  assert.equal(nextCronTime('5/20 * * * *', 'UTC', '2026-10-14T00:05:00.000Z'), '2026-10-14T00:25:00.000Z');
  assert.equal(nextCronTime('0,30 8 * * 7', 'UTC', '2026-10-17T23:59:00.000Z'), '2026-10-18T08:00:00.000Z');
  assert.equal(nextCronTime('0 0 1 * 1', 'UTC', '2026-10-14T00:00:00.000Z'), '2026-10-19T00:00:00.000Z');
  assert.equal(nextCronTime('0 0 29 2 *', 'UTC', '2025-03-01T00:00:00.000Z'), '2028-02-29T00:00:00.000Z');
  assert.equal(nextCronTime('30 2 * * *', 'America/New_York', '2026-03-08T06:59:00.000Z'), '2026-03-09T06:30:00.000Z');
  assert.equal(nextCronTime('30 1 * * *', 'America/New_York', '2026-11-01T05:30:00.000Z'), '2026-11-01T06:30:00.000Z');
  assert.equal(nextCronTime('45 1 * * *', 'Australia/Lord_Howe', '2026-04-04T14:45:00.000Z'), '2026-04-04T15:15:00.000Z');
  assert.throws(() => nextCronTime('99 * * * *', 'UTC', new Date().toISOString()), /Invalid schedule/);
  assert.throws(() => nextCronTime('* * * * *', 'Not/AZone', new Date().toISOString()), /time zone/);
  assert.throws(() => nextCronTime('0 0 31 2 *', 'UTC', new Date().toISOString()), /eight years/);
  console.log('PASS cron: lists/ranges/steps, time zones, weekdays, leap dates, DST gap/fold and invalid schedules');

  const first = await setup();
  const scanner = loop();
  await scanner.tick();
  assert.equal((await platform.listRuns(first.app.id)).length, 0, 'future task must not run');
  makeDue(first.task.id);
  await Promise.all([scanner.tick(), scanner.tick(), loop().tick()]);
  const runs = await platform.listRuns(first.app.id);
  assert.equal(runs.length, 1);
  assert.equal(runs[0]!.status, 'ok');
  assert.equal(runs[0]!.result!.outputs.total!.rows[0]![0], 20);
  const scheduled = (await platform.getScheduledTask(first.task.id, profile))!;
  assert.equal(scheduled.lastRunId, runs[0]!.id);
  assert.equal(scheduled.nextRunAt, nextCronTime(scheduled.trigger.kind === 'schedule' ? scheduled.trigger.cron : '', 'Asia/Shanghai', runs[0]!.completedAt!));
  await scanner.tick();
  assert.equal((await platform.listRuns(first.app.id)).length, 1);
  console.log('PASS due execution: unified engine, persisted result, next occurrence, overlapping scans deduplicated');

  makeDue(first.task.id);
  await platform.setScheduleEnabled(first.task.id, profile, false);
  await scanner.tick();
  assert.equal((await platform.listRuns(first.app.id)).length, 1);
  assert.equal((await platform.getScheduledTask(first.task.id, profile))!.nextRunAt, null);

  const active = await setup(); makeDue(active.task.id);
  let release!: () => void;
  let entered!: () => void;
  const started = new Promise<void>((resolve) => { entered = resolve; });
  const wait = new Promise<void>((resolve) => { release = resolve; });
  const adapter = inventedExecutionAdapter();
  const slow = loop((options) => platform.runSavedApplication({ ...options, allowInventedData: true,
    adapter: { ...adapter, async resolve(context) { entered(); await wait; return adapter.resolve(context); } } }));
  const inflight = slow.tick(); await started;
  await platform.setScheduleEnabled(active.task.id, profile, false);
  release(); await inflight;
  assert.equal((await platform.listRuns(active.app.id)).length, 1);
  assert.equal((await platform.getScheduledTask(active.task.id, profile))!.enabled, false);
  assert.equal((await platform.getScheduledTask(active.task.id, profile))!.nextRunAt, null);
  console.log('PASS pause: no new starts; an already claimed run finishes without re-enabling the task');

  const broken = await setup(); makeDue(broken.task.id);
  const missing = loop((options) => platform.runSavedApplication({ ...options, allowInventedData: true,
    adapter: { ...inventedExecutionAdapter(), async resolve() { throw new NeedsBindingError([{ key: 'invented_values' }]); } } }));
  await missing.tick(); await missing.tick();
  assert.equal((await platform.getScheduledTask(broken.task.id, profile))!.schedulingIssue!.code, 'needs_data');
  assert.equal((await platform.getScheduledTask(broken.task.id, profile))!.enabled, false);
  assert.equal((await platform.listRuns(broken.app.id)).length, 0);
  assert.ok(!(await platform.listExecutionAttempts(profile)).some((attempt) => attempt.appId === broken.app.id));
  await platform.setScheduleEnabled(broken.task.id, profile, true);
  makeDue(broken.task.id); await scanner.tick();
  assert.equal((await platform.listRuns(broken.app.id)).length, 1);
  console.log('PASS prerequisite: pause without failed history or running claim; explicit re-enable works');

  const failed = await setup(); makeDue(failed.task.id);
  await loop((options) => platform.runSavedApplication({ ...options, allowInventedData: true,
    adapter: { ...inventedExecutionAdapter(), async resolve() { throw new Error('Fictional provider failure'); } } })).tick();
  assert.equal((await platform.listRuns(failed.app.id))[0]!.status, 'failed');
  assert.ok((await platform.getScheduledTask(failed.task.id, profile))!.nextRunAt! > new Date().toISOString());
  console.log('PASS ordinary failure: recorded once and scheduled for the next regular occurrence');

  const timed = await setup();
  const ticking = loop(); ticking.start();
  await delay(30); makeDue(timed.task.id);
  const timeout = Date.now() + 3000;
  while (!(await platform.listRuns(timed.app.id)).length && Date.now() < timeout) await delay(20);
  assert.equal((await platform.listRuns(timed.app.id)).length, 1, 'timer must scan without an explicit tick');
  await ticking.stop();
  makeDue(timed.task.id); await delay(40);
  assert.equal((await platform.listRuns(timed.app.id)).length, 1, 'stopped timer must not run');
  console.log('PASS live timer: automatic scans, stop, and no overlapping execution');
  assert.equal(requests, 0);
  console.log('PASS external requests: 0; fictional data and isolated database only');
} finally {
  await Promise.all(loops.map((value) => value.stop()));
  closeStorage();
}
