import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { createRuntimeEnvironment, resolveNode } from './runtime.mjs';

let runtime;
try {
  runtime = resolveNode();
} catch (error) {
  console.error(error instanceof Error ? error.message : 'Unable to locate a supported Node.js runtime.');
  process.exit(1);
}

const acceptance = spawn(runtime.executable, ['--no-warnings', 'scripts/storage-acceptance.ts'], {
  cwd: fileURLToPath(new URL('../', import.meta.url)),
  env: createRuntimeEnvironment(runtime.executable),
  stdio: 'inherit',
});

process.once('SIGINT', () => acceptance.kill('SIGINT'));
process.once('SIGTERM', () => acceptance.kill('SIGTERM'));
acceptance.once('error', () => {
  console.error('Unable to start storage acceptance checks.');
  process.exitCode = 1;
});
acceptance.once('exit', (code) => { process.exitCode = code ?? 1; });
