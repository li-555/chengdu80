/** Scheduler lifecycle checks use fictional rows, local child processes and isolated SQLite. */
import assert from 'node:assert/strict';
import { mkdtempSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

let requests = 0;
globalThis.fetch = async () => { requests++; throw new Error('External requests are forbidden.'); };
const mode = process.argv[2];
const databasePath = process.argv[3] ?? join(mkdtempSync(join(tmpdir(), 'blocks-c8-lifecycle-')), 'checks.sqlite');
process.env.BLOCKS_DB_PATH = databasePath;
const p = await import('../src/platform/index.ts');
const { storageOperation, storageTransaction, closeStorage } = await import('../src/platform/database.ts');
const { ownedTask, writeTask } = await import('../src/platform/schedules.ts');
const { claimExecution, finishExecution, recoverInterruptedExecutions, renewExecutionLease } = await import('../src/platform/execution-store.ts');
const { encodeStoredValue, decodeStoredValue } = await import('../src/platform/json.ts');
const { nextTriggerTime } = await import('../src/platform/trigger-time.ts');
const { inventedScheduledDocument } = await import('../src/platform/invented-execution.ts');
const { NeedsBindingError, NeedsMappingError } = await import('../src/compute/slices.ts');
const { appVersion } = await import('../src/app-schema/index.ts');
const profile = 'fictional-lifecycle';
const adapter: import('../src/platform/execution-data.ts').InventedDataAdapter = {
  kind: 'invented', id: 'fictional-lifecycle-v1', label: 'Fictional lifecycle rows',
  async resolve() { return { slices: { invented_values: { columns: [{ name: 'company', type: 'string' }, { name: 'amount', type: 'number' }],
    rows: [{ company: 'Fictional Amber', amount: 20 }] } }, datasetVersions: { invented_values: 'fictional-v1' } }; },
};
const fixtureRun: typeof p.runSavedApplication = (options) => p.runSavedApplication({ ...options, adapter, allowInventedData: true });
const loops: ReturnType<typeof p.createScheduler>[] = [];
const scanner = p.createScheduler({ run: fixtureRun }); loops.push(scanner);
function due(id: string, time = new Date(Date.now() - 60_000).toISOString()) {
  storageOperation((db) => storageTransaction(db, () => { const task = ownedTask(db, id, profile); writeTask(db, { ...task, nextRunAt: time }); }));
}
async function setup() {
  const app = await p.saveApp(inventedScheduledDocument(), profile);
  const task = await p.createScheduledTask(app.id, profile, 1);
  await p.setScheduleEnabled(task.id, profile, true);
  return { app, task };
}
function child(action: string): any {
  closeStorage();
  const result = spawnSync(process.execPath, [fileURLToPath(import.meta.url), action, databasePath], { encoding: 'utf8', timeout: 15000 });
  assert.equal(result.status, 0, result.stderr || String(result.error));
  return result.stdout.trim() ? JSON.parse(result.stdout) : undefined;
}
try {
  if (mode === 'abandon') {
    const { app, task } = await setup(); due(task.id);
    await p.setState(app.id, profile, { carry: { n: 7 } });
    const scheduledFor = (await p.getScheduledTask(task.id, profile))!.nextRunAt!;
    const claim = claimExecution({ id: `crashed_${app.id}`, appId: app.id, profile, requestKey: 'fictional-crash', scheduled: { taskId: task.id, scheduledFor } });
    assert.ok('attempt' in claim);
    console.log(JSON.stringify(claim));
  } else if (mode === 'scan') {
    await scanner.tick(); console.log(JSON.stringify({ requests }));
  } else {
    // A fresh process reloads an enabled pending occurrence and saves it only once.
    const restarted = await setup(); due(restarted.task.id);
    child('scan'); child('scan');
    assert.equal((await p.listRuns(restarted.app.id)).length, 1);
    assert.ok((await p.getScheduledTask(restarted.task.id, profile))!.nextRunAt! > new Date().toISOString());
    const old = await setup(); due(old.task.id, new Date(Date.now() - 25 * 3600_000).toISOString());
    await scanner.tick();
    assert.equal((await p.listRuns(old.app.id)).length, 0);
    assert.match((await p.getScheduledTask(old.task.id, profile))!.schedulingNote!, /24 hours/);
    console.log('PASS restart/catch-up: fresh-process reload, one pending occurrence, 24-hour bound, no duplicate result');

    const abandoned = child('abandon');
    recoverInterruptedExecutions(); recoverInterruptedExecutions();
    const interrupted = (await p.listRuns(abandoned.app.id));
    assert.equal(interrupted.length, 1); assert.equal(interrupted[0]!.failure!.code, 'E_RUN_INTERRUPTED');
    assert.deepEqual((await p.getState(abandoned.app.id, profile)).carry, { n: 7 });
    assert.equal((await p.getScheduledTask(abandoned.attempt.taskId, profile))!.schedulingIssue!.code, 'interrupted');
    assert.ok(!(await p.listExecutionAttempts(profile)).some((attempt) => attempt.appId === abandoned.app.id && attempt.status === 'running'));
    assert.throws(() => finishExecution(abandoned, { ...interrupted[0]!, status: 'ok' }, { n: 8 }), /no longer running/);
    const reused = claimExecution({ id: abandoned.attempt.id, appId: abandoned.app.id, profile, requestKey: abandoned.attempt.requestKey,
      scheduled: { taskId: abandoned.attempt.taskId, scheduledFor: abandoned.attempt.scheduledFor } });
    assert.equal('kind' in reused && reused.kind, 'completed');
    await p.setScheduleEnabled(abandoned.attempt.taskId, profile, true);
    assert.ok((await p.getScheduledTask(abandoned.attempt.taskId, profile))!.nextRunAt! > new Date().toISOString());
    console.log('PASS abandoned process: released claim, one interrupted record, carry unchanged, stale writer fenced');

    const leased = await setup(); due(leased.task.id);
    const leasedClaim = claimExecution({ id: `lease_${leased.app.id}`, appId: leased.app.id, profile, requestKey: 'fictional-lease',
      scheduled: { taskId: leased.task.id, scheduledFor: (await p.getScheduledTask(leased.task.id, profile))!.nextRunAt! } });
    assert.ok('attempt' in leasedClaim);
    renewExecutionLease(leasedClaim); recoverInterruptedExecutions();
    assert.equal((await p.listRuns(leased.app.id)).length, 0, 'a live lease must remain running');
    storageOperation((db) => {
      const attempt = (db.prepare('SELECT record FROM executions WHERE id = ?').get(encodeStoredValue(leasedClaim.attempt.id)))!;
      const expired = { ...decodeStoredValue<object>(attempt.record), leaseUntil: '2000-01-01T00:00:00.000Z' };
      db.prepare('UPDATE executions SET record = ? WHERE id = ?').run(encodeStoredValue(expired), encodeStoredValue(leasedClaim.attempt.id));
    });
    recoverInterruptedExecutions(); renewExecutionLease(leasedClaim);
    assert.equal((await p.listRuns(leased.app.id)).length, 1);
    const expiredRecord = (await p.listRuns(leased.app.id))[0]!;
    assert.throws(() => finishExecution(leasedClaim, { ...expiredRecord, status: 'ok' }, { n: 99 }), /no longer running/);
    console.log('PASS leases: live worker retained, expired worker recovered, renewal cannot revive a finished claim');

    for (const error of [new NeedsBindingError([{ key: 'invented_values' }]), new NeedsMappingError([{ key: 'invented_values', field: 'amount', suggestions: ['amount'] }])]) {
      const blocked = await setup(); due(blocked.task.id);
      let resolutions = 0;
      const loop = p.createScheduler({ run: (options) => p.runSavedApplication({ ...options, allowInventedData: true,
        adapter: { ...adapter, async resolve() { resolutions++; throw error; } } }) }); loops.push(loop);
      await loop.tick(); await loop.tick(); closeStorage();
      const waiting = (await p.getScheduledTask(blocked.task.id, profile))!;
      assert.equal(waiting.enabled, false); assert.equal(waiting.schedulingIssue!.dataIssue!.code, error.name);
      assert.equal(resolutions, 1); assert.equal((await p.listRuns(blocked.app.id)).length, 0);
      await p.setState(blocked.app.id, profile, { params: { scale: 2 }, bindings: { invented_values: 'fictional-fixed' } });
      await p.setScheduleEnabled(blocked.task.id, profile, true); due(blocked.task.id); await scanner.tick();
      assert.equal((await p.listRuns(blocked.app.id))[0]!.status, 'ok');
    }
    console.log('PASS both waiting states: persisted detail, no repeated fetch/history, correction and explicit resume');

    const market = { kind: 'market' as const, calendar: 'SSE' as const, at: 'open' as const, offsetMinutes: -15 };
    const calendar = async (date: string) => date === '2026-10-19' ? { open: '09:30', close: '15:00' } : null;
    assert.equal(await nextTriggerTime(market, '2026-10-16T12:00:00Z', calendar), '2026-10-19T01:15:00.000Z');
    assert.equal(await nextTriggerTime({ ...market, at: 'close', offsetMinutes: 30 }, '2026-10-19T01:15:00Z', calendar), '2026-10-19T07:30:00.000Z');
    await assert.rejects(nextTriggerTime(market, new Date().toISOString(), async () => { throw new Error('Fictional calendar outage'); }), /calendar/);
    const doc = inventedScheduledDocument(); doc.triggers[1] = { ...market, offsetMinutes: 0 };
    const app = await p.saveApp(doc, profile); const task = await p.createScheduledTask(app.id, profile, 1);
    const failed = await p.setScheduleEnabled(task.id, profile, true, { calendar: async () => { throw new Error('Fictional outage'); } });
    assert.equal(failed.enabled, false); assert.equal(failed.schedulingIssue!.code, 'calendar_unavailable');
    const time = Math.floor((Date.now() - 120_000) / 60_000) * 60_000;
    const localClock = new Date(time + 8 * 3600_000).toISOString().slice(11, 16);
    const available = async () => ({ open: localClock, close: '15:00' });
    await p.setScheduleEnabled(task.id, profile, true, { calendar: available }); due(task.id, new Date(time).toISOString());
    const marketLoop = p.createScheduler({ run: fixtureRun, calendar: available }); loops.push(marketLoop);
    await marketLoop.tick(); await marketLoop.tick();
    assert.equal((await p.listRuns(app.id))[0]!.status, 'ok');
    assert.ok((await p.getScheduledTask(task.id, profile))!.nextRunAt! > new Date().toISOString());
    console.log('PASS market triggers: holidays, open/close offsets, persisted calendar failure, next market occurrence');

    const changed = await setup(); due(changed.task.id);
    const newDoc = inventedScheduledDocument(); newDoc.meta.description = 'Changed fictional application';
    const version = appVersion(newDoc);
    storageOperation((db) => {
      const row = db.prepare('SELECT record FROM apps WHERE id = ?').get(encodeStoredValue(changed.app.id))!;
      const value = decodeStoredValue<import('../src/platform/types.ts').StoredApp>(row.record);
      db.prepare('UPDATE apps SET record = ? WHERE id = ?').run(encodeStoredValue({ ...value, doc: newDoc, version }), encodeStoredValue(changed.app.id));
    });
    await scanner.tick();
    assert.equal((await p.getScheduledTask(changed.task.id, profile))!.schedulingIssue!.code, 'version_changed');
    await assert.rejects(p.setScheduleEnabled(changed.task.id, profile, true), /Confirm/);
    await p.setScheduleEnabled(changed.task.id, profile, true, { confirmVersion: version });
    assert.equal((await p.getScheduledTask(changed.task.id, profile))!.appVersion, version);
    console.log('PASS changed application: automatic pause, explicit version confirmation before resume');
    assert.equal(requests, 0); console.log('PASS external requests: 0');
  }
} finally { await Promise.all(loops.map((loop) => loop.stop())); closeStorage(); }
